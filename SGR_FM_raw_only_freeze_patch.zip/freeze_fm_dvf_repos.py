#!/usr/bin/env python3
"""Freeze and verify the three audited FM DVF repositories used by SGR-FM.

The script creates a SHA256 manifest outside the repositories, writes a small
freeze marker into each repository, and can optionally remove file write bits
from all tracked DVFs. It does not copy the DVFs, so disk overhead is tiny.

Default repositories relative to --project-root:
  outputs/unigradicon_raw_training/dvfs_canonical_ras
  outputs/unigradicon_raw_validation/dvfs
  outputs/unigradicon_raw_validation/dvfs_canonical_ras

Examples
--------
Freeze with hashes and make the tracked DVFs read-only:

  python freeze_fm_dvf_repos.py freeze \
    --project-root "/home/oussama/Desktop/MICCAI FRANCE" \
    --make-read-only

Verify later:

  python freeze_fm_dvf_repos.py verify \
    --manifest "/home/oussama/Desktop/MICCAI FRANCE/outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json"

Explicitly unfreeze before intentional regeneration:

  python freeze_fm_dvf_repos.py unfreeze \
    --manifest "/home/oussama/Desktop/MICCAI FRANCE/outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json"
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import stat
import sys
import tempfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = 1
MARKER_NAME = ".sgr_fm_frozen.json"
DEFAULT_MANIFEST_REL = Path("outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json")
DEFAULT_VERIFY_REPORT_REL = Path("outputs/sgr_fm/frozen_assets/fm_dvf_verify_report.json")


@dataclass(frozen=True)
class RepoSpec:
    name: str
    relative_path: str
    pattern: str
    expected_count: int


DEFAULT_SPECS = (
    RepoSpec(
        name="training_canonical_ras",
        relative_path="outputs/unigradicon_raw_training/dvfs_canonical_ras",
        pattern="NLST_*_DVF_RAS_XYZC_voxel.nii.gz",
        expected_count=200,
    ),
    RepoSpec(
        name="validation_original_grid",
        relative_path="outputs/unigradicon_raw_validation/dvfs",
        pattern="NLST_*_DVF.nii.gz",
        expected_count=10,
    ),
    RepoSpec(
        name="validation_canonical_ras",
        relative_path="outputs/unigradicon_raw_validation/dvfs_canonical_ras",
        pattern="NLST_*_DVF_RAS_XYZC_voxel.nii.gz",
        expected_count=10,
    ),
)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name + ".", suffix=".tmp", delete=False) as handle:
        tmp = Path(handle.name)
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def atomic_write_json(path: Path, payload: dict[str, Any]) -> bytes:
    data = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    atomic_write_bytes(path, data)
    return data


def case_id_from_name(name: str) -> str | None:
    if len(name) >= 9 and name.startswith("NLST_"):
        candidate = name[:9]
        if candidate[5:].isdigit():
            return candidate
    return None


def collect_repo_files(repo_path: Path, pattern: str) -> list[Path]:
    if not repo_path.exists():
        raise FileNotFoundError(f"Repository does not exist: {repo_path}")
    if not repo_path.is_dir():
        raise NotADirectoryError(repo_path)
    return sorted(path for path in repo_path.glob(pattern) if path.is_file())


def validate_repo_inventory(spec: RepoSpec, repo_path: Path, files: list[Path], allow_count_mismatch: bool) -> None:
    if len(files) != spec.expected_count and not allow_count_mismatch:
        raise RuntimeError(
            f"{spec.name}: expected {spec.expected_count} files matching {spec.pattern!r}, "
            f"found {len(files)} in {repo_path}. Refusing to freeze an incomplete inventory."
        )

    case_ids = [case_id_from_name(path.name) for path in files]
    if any(case_id is None for case_id in case_ids):
        bad = [path.name for path, case_id in zip(files, case_ids) if case_id is None]
        raise RuntimeError(f"{spec.name}: could not parse case IDs from {bad[:10]}")

    duplicates = sorted({case_id for case_id in case_ids if case_ids.count(case_id) > 1})
    if duplicates:
        raise RuntimeError(f"{spec.name}: duplicate case IDs: {duplicates}")


def file_record(path: Path, repo_path: Path) -> dict[str, Any]:
    st = path.stat()
    return {
        "relative_path": str(path.relative_to(repo_path)),
        "case_id": case_id_from_name(path.name),
        "size_bytes": int(st.st_size),
        "mtime_ns_at_freeze": int(st.st_mtime_ns),
        "mode_at_freeze": stat.S_IMODE(st.st_mode),
        "sha256": sha256_file(path),
    }


def repository_record(spec: RepoSpec, project_root: Path, allow_count_mismatch: bool) -> dict[str, Any]:
    repo_path = (project_root / spec.relative_path).resolve()
    files = collect_repo_files(repo_path, spec.pattern)
    validate_repo_inventory(spec, repo_path, files, allow_count_mismatch)

    records: list[dict[str, Any]] = []
    for index, path in enumerate(files, start=1):
        print(f"[{spec.name}] hashing {index:03d}/{len(files):03d} {path.name}", flush=True)
        records.append(file_record(path, repo_path))

    return {
        "name": spec.name,
        "path": str(repo_path),
        "pattern": spec.pattern,
        "expected_count": spec.expected_count,
        "actual_count": len(records),
        "files": records,
    }


def iter_manifest_files(manifest: dict[str, Any]) -> Iterable[tuple[dict[str, Any], Path, dict[str, Any], Path]]:
    for repo in manifest.get("repositories", []):
        repo_path = Path(repo["path"])
        for record in repo.get("files", []):
            yield repo, repo_path, record, repo_path / record["relative_path"]


def set_tracked_files_read_only(manifest: dict[str, Any]) -> None:
    for _, _, _, path in iter_manifest_files(manifest):
        mode = stat.S_IMODE(path.stat().st_mode)
        path.chmod(mode & ~0o222)


def restore_user_write_bit(manifest: dict[str, Any]) -> None:
    for _, _, _, path in iter_manifest_files(manifest):
        if path.exists():
            mode = stat.S_IMODE(path.stat().st_mode)
            path.chmod(mode | stat.S_IWUSR)


def write_repo_markers(manifest: dict[str, Any], manifest_path: Path, manifest_sha256: str) -> None:
    for repo in manifest["repositories"]:
        repo_path = Path(repo["path"])
        marker = {
            "schema_version": SCHEMA_VERSION,
            "status": "frozen",
            "frozen_utc": manifest["frozen_utc"],
            "repository_name": repo["name"],
            "manifest_path": str(manifest_path.resolve()),
            "manifest_sha256": manifest_sha256,
            "tracked_file_count": repo["actual_count"],
        }
        atomic_write_json(repo_path / MARKER_NAME, marker)


def remove_repo_markers(manifest: dict[str, Any]) -> None:
    for repo in manifest.get("repositories", []):
        marker = Path(repo["path"]) / MARKER_NAME
        if marker.exists():
            marker.unlink()


def freeze(args: argparse.Namespace) -> int:
    project_root = Path(args.project_root).expanduser().resolve()
    if not project_root.exists():
        raise FileNotFoundError(f"Project root does not exist: {project_root}")

    manifest_path = Path(args.manifest).expanduser() if args.manifest else project_root / DEFAULT_MANIFEST_REL
    manifest_path = manifest_path.resolve()

    if manifest_path.exists() and not args.overwrite_manifest:
        raise FileExistsError(
            f"Manifest already exists: {manifest_path}. Use --overwrite-manifest only after verifying intent."
        )

    repositories = [repository_record(spec, project_root, args.allow_count_mismatch) for spec in DEFAULT_SPECS]
    manifest: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "status": "frozen",
        "frozen_utc": utc_now_iso(),
        "project_root": str(project_root),
        "hash_algorithm": "sha256",
        "read_only_requested": bool(args.make_read_only),
        "repositories": repositories,
    }

    manifest_bytes = atomic_write_json(manifest_path, manifest)
    manifest_sha = sha256_bytes(manifest_bytes)
    write_repo_markers(manifest, manifest_path, manifest_sha)

    if args.make_read_only:
        set_tracked_files_read_only(manifest)

    csv_path = manifest_path.with_suffix(".csv")
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["repository", "repository_path", "relative_path", "case_id", "size_bytes", "sha256"],
        )
        writer.writeheader()
        for repo in repositories:
            for record in repo["files"]:
                writer.writerow(
                    {
                        "repository": repo["name"],
                        "repository_path": repo["path"],
                        "relative_path": record["relative_path"],
                        "case_id": record["case_id"],
                        "size_bytes": record["size_bytes"],
                        "sha256": record["sha256"],
                    }
                )

    print(json.dumps({
        "status": "frozen",
        "manifest": str(manifest_path),
        "manifest_sha256": manifest_sha,
        "csv": str(csv_path),
        "read_only_applied": bool(args.make_read_only),
        "repository_counts": {repo["name"]: repo["actual_count"] for repo in repositories},
    }, indent=2))
    return 0


def load_manifest(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    if manifest.get("schema_version") != SCHEMA_VERSION:
        raise RuntimeError(
            f"Unsupported manifest schema {manifest.get('schema_version')}; expected {SCHEMA_VERSION}."
        )
    return manifest


def verify(args: argparse.Namespace) -> int:
    manifest_path = Path(args.manifest).expanduser().resolve()
    manifest = load_manifest(manifest_path)

    failures: list[dict[str, Any]] = []
    checked = 0
    repo_summaries: list[dict[str, Any]] = []

    for repo in manifest.get("repositories", []):
        repo_path = Path(repo["path"])
        expected_rel = {record["relative_path"] for record in repo.get("files", [])}
        actual_files = collect_repo_files(repo_path, repo["pattern"])
        actual_rel = {str(path.relative_to(repo_path)) for path in actual_files}

        for missing in sorted(expected_rel - actual_rel):
            failures.append({"repository": repo["name"], "type": "missing", "relative_path": missing})
        for extra in sorted(actual_rel - expected_rel):
            failures.append({"repository": repo["name"], "type": "extra", "relative_path": extra})

        for record in repo.get("files", []):
            path = repo_path / record["relative_path"]
            if not path.exists():
                continue
            checked += 1
            st = path.stat()
            if int(st.st_size) != int(record["size_bytes"]):
                failures.append(
                    {
                        "repository": repo["name"],
                        "type": "size_changed",
                        "relative_path": record["relative_path"],
                        "expected": int(record["size_bytes"]),
                        "actual": int(st.st_size),
                    }
                )
                continue

            print(f"[{repo['name']}] verifying {checked:03d} {path.name}", flush=True)
            actual_hash = sha256_file(path)
            if actual_hash != record["sha256"]:
                failures.append(
                    {
                        "repository": repo["name"],
                        "type": "sha256_changed",
                        "relative_path": record["relative_path"],
                        "expected": record["sha256"],
                        "actual": actual_hash,
                    }
                )

            if args.require_read_only and (stat.S_IMODE(st.st_mode) & 0o222):
                failures.append(
                    {
                        "repository": repo["name"],
                        "type": "writable",
                        "relative_path": record["relative_path"],
                        "mode": oct(stat.S_IMODE(st.st_mode)),
                    }
                )

        marker_path = repo_path / MARKER_NAME
        if not marker_path.exists():
            failures.append({"repository": repo["name"], "type": "freeze_marker_missing", "path": str(marker_path)})

        repo_summaries.append(
            {
                "name": repo["name"],
                "expected_count": len(expected_rel),
                "actual_count": len(actual_rel),
                "marker_present": marker_path.exists(),
            }
        )

    report = {
        "schema_version": SCHEMA_VERSION,
        "verified_utc": utc_now_iso(),
        "manifest": str(manifest_path),
        "status": "PASS" if not failures else "FAIL",
        "checked_files": checked,
        "failure_count": len(failures),
        "repositories": repo_summaries,
        "failures": failures,
    }

    report_path = Path(args.report).expanduser().resolve() if args.report else Path(manifest["project_root"]) / DEFAULT_VERIFY_REPORT_REL
    atomic_write_json(report_path, report)
    print(json.dumps(report, indent=2))
    return 0 if not failures else 2


def unfreeze(args: argparse.Namespace) -> int:
    manifest_path = Path(args.manifest).expanduser().resolve()
    manifest = load_manifest(manifest_path)
    restore_user_write_bit(manifest)
    remove_repo_markers(manifest)
    print(json.dumps({
        "status": "unfrozen",
        "manifest": str(manifest_path),
        "note": "Tracked files were given owner-write permission and freeze markers were removed. The hash manifest was retained.",
    }, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Freeze/verify audited SGR-FM foundation-model DVF repositories.")
    sub = parser.add_subparsers(dest="command", required=True)

    p_freeze = sub.add_parser("freeze", help="Hash the three DVF repositories and optionally make tracked files read-only.")
    p_freeze.add_argument("--project-root", default="/home/oussama/Desktop/MICCAI FRANCE")
    p_freeze.add_argument("--manifest", default=None)
    p_freeze.add_argument("--make-read-only", action="store_true")
    p_freeze.add_argument("--allow-count-mismatch", action="store_true")
    p_freeze.add_argument("--overwrite-manifest", action="store_true")
    p_freeze.set_defaults(func=freeze)

    p_verify = sub.add_parser("verify", help="Recompute SHA256 hashes and compare against a freeze manifest.")
    p_verify.add_argument("--manifest", required=True)
    p_verify.add_argument("--report", default=None)
    p_verify.add_argument("--require-read-only", action="store_true")
    p_verify.set_defaults(func=verify)

    p_unfreeze = sub.add_parser("unfreeze", help="Remove freeze markers and restore owner-write permission.")
    p_unfreeze.add_argument("--manifest", required=True)
    p_unfreeze.set_defaults(func=unfreeze)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
