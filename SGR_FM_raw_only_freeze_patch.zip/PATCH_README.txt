SGR-FM RAW-ONLY + FM-DVF FREEZE PATCH
=====================================

Purpose
-------
1. Remove active runtime dependency/fallback to Learn2Breath_preprocessed.
2. Keep uniGradICON training/validation discovery strictly on raw Learn2Breath CTs.
3. Preserve the previously corrected Patch-B refiner geometry fixes:
   - validation CTs canonicalized to RAS before combining with RAS cached DVFs
   - exact align_corners=True DVF resize scaling
4. Freeze the three audited FM DVF repositories with SHA256 manifests, marker files,
   optional read-only permissions, and later verification.
5. Prevent the patched uniGradICON runner from writing into a marked frozen DVF repo.

Files included
--------------
run_unigradicon.py
utils/unigradicon_runner.py
utils/config.py
utils/data.py
inspect_learn2breath_streamlit_fixed.py
infer_refiner_cached.py
utils/refine_io.py
utils/refine_spatial.py
freeze_fm_dvf_repos.py
configs/unigradicon_baseline.yaml
configs/refiner_baseline.yaml
configs/refiner_stable.yaml
configs/refiner_cached_lowspace.yaml
configs/configs/unigradicon_baseline.yaml

Install / overlay
-----------------
From the project root:

  cd "/home/oussama/Desktop/MICCAI FRANCE"
  unzip -o SGR_FM_raw_only_freeze_patch.zip -d .

The ZIP preserves project-relative paths.

Raw-only behavior after patch
-----------------------------
- utils/unigradicon_runner.py has no preprocessed-data fallback.
- run_unigradicon.py no longer exposes --train-data-root.
- utils/config.py no longer stores a preprocessed train_data_root.
- utils/data.py discovers training data from data.raw_data_root.
- the Streamlit inspector defaults to the raw dataset only.
- relevant YAML configs no longer contain train_data_root.

Important: preprocessing utility scripts may still contain the word "preprocessed"
because their explicit purpose is to create a preprocessing experiment. They are not
runtime dependencies of the raw-only SGR-FM path.

Freeze the FM DVF repositories
-------------------------------
Recommended command:

  cd "/home/oussama/Desktop/MICCAI FRANCE"
  python freeze_fm_dvf_repos.py freeze \
    --project-root "/home/oussama/Desktop/MICCAI FRANCE" \
    --make-read-only

Expected counts are enforced:
- training canonical RAS: 200
- validation original-grid: 10
- validation canonical RAS: 10

Outputs:
  outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json
  outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.csv

Small marker file written into each tracked repo:
  .sgr_fm_frozen.json

Verify immediately
------------------

  python freeze_fm_dvf_repos.py verify \
    --manifest "/home/oussama/Desktop/MICCAI FRANCE/outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json" \
    --require-read-only

Expected final status: PASS

Unfreeze only before intentional regeneration
---------------------------------------------

  python freeze_fm_dvf_repos.py unfreeze \
    --manifest "/home/oussama/Desktop/MICCAI FRANCE/outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json"

The hash manifest is retained after unfreeze.

Delete the obsolete preprocessed repository
-------------------------------------------
After overlaying this patch and confirming the freeze verification PASS:

  rm -rf "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_preprocessed"

This deletion does not affect the raw uniGradICON FM initializer path after the patch.

Validation performed on this patch package
------------------------------------------
- Python syntax compilation passed for all included .py files.
- freeze -> verify PASS tested on synthetic repositories.
- tamper detection tested: verification exits with code 2 on changed content.
- Patch-B inference/orientation and exact DVF-resize files are included.
