from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Sequence

import nibabel as nib
import numpy as np
from nibabel.orientations import aff2axcodes

from utils.data import discover_training_cases
from utils.sgr_fm_segmentation import EXPECTED_LOBE_LABELS, atomic_write_json, write_csv


def load_yaml_or_json(path: str | Path, root_key: str | None = None) -> dict[str, Any]:
    config_path = Path(path).expanduser()
    if not config_path.exists():
        raise FileNotFoundError(f"Config does not exist: {config_path}")
    if config_path.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml
        except ImportError as exc:
            raise RuntimeError("PyYAML is required: pip install pyyaml") from exc
        with config_path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
    elif config_path.suffix.lower() == ".json":
        data = json.loads(config_path.read_text(encoding="utf-8"))
    else:
        raise ValueError(f"Unsupported config format: {config_path.suffix}")
    if not isinstance(data, dict):
        raise ValueError(f"Config must contain a mapping: {config_path}")
    if root_key is not None:
        value = data.get(root_key, data)
        if not isinstance(value, dict):
            raise ValueError(f"Config key {root_key!r} must contain a mapping")
        return value
    return data


def recursive_update(base: dict[str, Any], updates: dict[str, Any]) -> dict[str, Any]:
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            recursive_update(base[key], value)
        else:
            base[key] = value
    return base


def resolve_under_project(project_root: Path, value: str | Path) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = project_root / path
    return path.resolve()


def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def canonical_dvf_path(output_dir: Path, case_id: str) -> Path:
    return output_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz"


def original_dvf_path(output_dir: Path, case_id: str) -> Path:
    return output_dir / "dvfs" / f"{case_id}_DVF.nii.gz"


def segmentation_paths(segmentation_dir: Path, case_id: str, phase: str) -> dict[str, Path]:
    stem = f"{case_id}_{phase}"
    return {
        "support": segmentation_dir / "support" / "training" / f"{stem}_support.nii.gz",
        "lobes": segmentation_dir / "lobes" / "training" / f"{stem}_lobes.nii.gz",
        "interfaces": segmentation_dir / "interfaces" / "training" / f"{stem}_lobe_interfaces.nii.gz",
    }


def _grid_signature(path: Path) -> tuple[tuple[int, ...], np.ndarray, tuple[str, ...]]:
    image = nib.load(str(path))
    return (
        tuple(int(v) for v in image.shape),
        np.asarray(image.affine, dtype=np.float64),
        tuple(str(v) for v in aff2axcodes(image.affine)),
    )


def _same_grid(candidate: Path, reference: Path, affine_atol: float) -> tuple[bool, str]:
    cshape, caff, cax = _grid_signature(candidate)
    rshape, raff, rax = _grid_signature(reference)
    shape_ok = cshape[:3] == rshape[:3]
    affine_ok = bool(np.allclose(caff, raff, atol=affine_atol, rtol=0.0))
    if shape_ok and affine_ok:
        return True, ""
    return False, (
        f"grid mismatch shape={cshape[:3]} vs {rshape[:3]}, "
        f"axcodes={cax} vs {rax}, max_affine_diff={float(np.max(np.abs(caff-raff))):.6g}"
    )


def _canonical_reference_info(fixed_path: Path) -> tuple[tuple[int, ...], np.ndarray]:
    image = nib.as_closest_canonical(nib.load(str(fixed_path)))
    return tuple(int(v) for v in image.shape[:3]), np.asarray(image.affine, dtype=np.float64)


def validate_canonical_dvf_header(path: Path, fixed_path: Path, affine_atol: float = 1e-5) -> dict[str, Any]:
    image = nib.load(str(path))
    shape = tuple(int(v) for v in image.shape)
    if len(shape) != 4 or shape[-1] != 3:
        raise ValueError(f"Expected XYZC canonical DVF, got {shape}: {path}")
    ref_shape, ref_affine = _canonical_reference_info(fixed_path)
    if shape[:3] != ref_shape:
        raise ValueError(f"Canonical DVF shape {shape[:3]} != canonical fixed shape {ref_shape}: {path}")
    if not np.allclose(image.affine, ref_affine, atol=affine_atol, rtol=0.0):
        raise ValueError(
            f"Canonical DVF affine mismatch for {path}; "
            f"max diff={float(np.max(np.abs(np.asarray(image.affine)-ref_affine))):.6g}"
        )
    axcodes = tuple(str(v) for v in aff2axcodes(image.affine))
    if axcodes != ("R", "A", "S"):
        raise ValueError(f"Canonical DVF is not RAS: {axcodes} at {path}")
    return {"shape": list(shape), "axcodes": list(axcodes), "affine_match": True}


def run_training_asset_audit(
    *,
    raw_data_root: Path,
    segmentation_dir: Path,
    c1_output_dir: Path,
    audit_output_dir: Path,
    case_ids: Sequence[str] | None = None,
    expected_case_count: int | None = 200,
    save_original_dvfs: bool = False,
    affine_atol: float = 1e-5,
    full_voxel_scan: bool = False,
) -> dict[str, Any]:
    all_cases = discover_training_cases(raw_data_root)
    requested = set(str(v) for v in (case_ids or []))
    cases = [case for case in all_cases if not requested or case.case_id in requested]
    missing_requested = sorted(requested - {case.case_id for case in cases})
    if missing_requested:
        raise FileNotFoundError(f"Requested training cases not found: {missing_requested}")
    if not requested and expected_case_count is not None and len(cases) != int(expected_case_count):
        raise RuntimeError(f"Expected {expected_case_count} training cases, discovered {len(cases)}")

    rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    allowed_labels = set(int(v) for v in EXPECTED_LOBE_LABELS)

    for case in cases:
        case_row: dict[str, Any] = {"case_id": case.case_id, "status": "PASS"}
        try:
            for phase, ct_path in (("EXP", case.exp_ct), ("INSP", case.insp_ct)):
                paths = segmentation_paths(segmentation_dir, case.case_id, phase)
                for name, path in paths.items():
                    if not path.exists():
                        raise FileNotFoundError(f"Missing {name}: {path}")
                    ok, reason = _same_grid(path, ct_path, affine_atol)
                    if not ok:
                        raise RuntimeError(f"{name} {case.case_id}_{phase}: {reason}")
                if full_voxel_scan:
                    support = np.asanyarray(nib.load(str(paths["support"])).dataobj)
                    lobes = np.asanyarray(nib.load(str(paths["lobes"])).dataobj)
                    interfaces = np.asanyarray(nib.load(str(paths["interfaces"])).dataobj)
                    if not np.isfinite(support).all() or not np.any(support > 0):
                        raise RuntimeError(f"Invalid support voxels: {paths['support']}")
                    labels = set(int(v) for v in np.unique(lobes))
                    if not labels.issubset(allowed_labels):
                        raise RuntimeError(f"Unexpected lobe labels {sorted(labels)}: {paths['lobes']}")
                    if not np.isfinite(interfaces).all():
                        raise RuntimeError(f"Non-finite interfaces: {paths['interfaces']}")

            canonical = canonical_dvf_path(c1_output_dir, case.case_id)
            if not canonical.exists():
                raise FileNotFoundError(f"Missing canonical C1 DVF: {canonical}")
            case_row["canonical_dvf"] = str(canonical)
            case_row["canonical_header"] = validate_canonical_dvf_header(canonical, case.insp_ct, affine_atol)
            if full_voxel_scan:
                dvf = np.asanyarray(nib.load(str(canonical)).dataobj)
                if not np.isfinite(dvf).all():
                    raise RuntimeError(f"Non-finite canonical DVF: {canonical}")

            if save_original_dvfs:
                original = original_dvf_path(c1_output_dir, case.case_id)
                if not original.exists():
                    raise FileNotFoundError(f"Missing original-grid C1 DVF: {original}")
                ok, reason = _same_grid(original, case.insp_ct, affine_atol)
                if not ok:
                    raise RuntimeError(f"Original C1 DVF {case.case_id}: {reason}")
                case_row["original_dvf"] = str(original)
        except Exception as exc:
            case_row["status"] = "FAIL"
            case_row["error_type"] = type(exc).__name__
            case_row["error"] = str(exc)
            failures.append(dict(case_row))
        rows.append(case_row)

    expected_stems = {f"{case.case_id}_{phase}" for case in cases for phase in ("EXP", "INSP")}
    expected_case_ids = {case.case_id for case in cases}
    inventory_specs = {
        "support": (
            segmentation_dir / "support" / "training",
            {f"{stem}_support.nii.gz" for stem in expected_stems},
        ),
        "lobes": (
            segmentation_dir / "lobes" / "training",
            {f"{stem}_lobes.nii.gz" for stem in expected_stems},
        ),
        "interfaces": (
            segmentation_dir / "interfaces" / "training",
            {f"{stem}_lobe_interfaces.nii.gz" for stem in expected_stems},
        ),
        "canonical_dvfs": (
            c1_output_dir / "dvfs_canonical_ras",
            {f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz" for case_id in expected_case_ids},
        ),
        "original_dvfs": (
            c1_output_dir / "dvfs",
            {f"{case_id}_DVF.nii.gz" for case_id in expected_case_ids} if save_original_dvfs else set(),
        ),
    }
    inventory: dict[str, Any] = {}
    inventory_ok = True
    for name, (directory, expected_names) in inventory_specs.items():
        actual_names = {path.name for path in directory.glob("*.nii.gz")} if directory.exists() else set()
        missing = sorted(expected_names - actual_names)
        extra = sorted(actual_names - expected_names)
        # Partial smoke tests audit only requested cases and tolerate unrelated
        # completed assets already present in the same resumable repository.
        strict_extras = not bool(requested)
        item_ok = not missing and (not strict_extras or not extra)
        inventory[name] = {
            "directory": str(directory),
            "expected_count": len(expected_names),
            "actual_count": len(actual_names),
            "missing": missing,
            "extra": extra,
            "strict_extra_check": strict_extras,
            "status": "PASS" if item_ok else "FAIL",
        }
        inventory_ok = inventory_ok and item_ok

    segmentation_summary_path = segmentation_dir / "manifests" / "phase1_segmentation_summary.json"
    c1_summary_path = c1_output_dir / "c1_training_summary.json"
    upstream_summaries: dict[str, Any] = {}
    for name, path in (("segmentation", segmentation_summary_path), ("c1_training", c1_summary_path)):
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                upstream_summaries[name] = {"path": str(path), "present": True, "status": payload.get("status")}
            except Exception as exc:
                upstream_summaries[name] = {"path": str(path), "present": True, "status": "UNREADABLE", "error": str(exc)}
        else:
            upstream_summaries[name] = {"path": str(path), "present": False, "status": "MISSING"}

    status_ok = not failures and len(rows) == len(cases) and inventory_ok
    summary = {
        "schema_version": 1,
        "status": "PASS" if status_ok else "FAIL",
        "case_count": len(cases),
        "expected_volume_count": len(cases) * 2,
        "pass_count": sum(row["status"] == "PASS" for row in rows),
        "failure_count": len(failures),
        "raw_data_root": str(raw_data_root),
        "segmentation_dir": str(segmentation_dir),
        "c1_output_dir": str(c1_output_dir),
        "save_original_dvfs": bool(save_original_dvfs),
        "full_voxel_scan": bool(full_voxel_scan),
        "inventory": inventory,
        "upstream_summaries": upstream_summaries,
        "failures": failures,
    }
    audit_output_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(audit_output_dir / "phase2_training_asset_audit.json", {"summary": summary, "rows": rows})
    write_csv(audit_output_dir / "phase2_training_asset_audit.csv", rows)
    atomic_write_json(audit_output_dir / "phase2_training_asset_audit_summary.json", summary)
    return summary
