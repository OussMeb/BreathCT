#!/usr/bin/env python3
"""Orchestrate SGR-FM Phase-2 training asset generation.

Stages:
1) segment 400 raw training CT volumes (support, five lobes, interfaces)
2) generate 200 C1 support-guided FM initializers with accepted parameters locked
3) audit counts and geometry before any C3 training begins
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Sequence

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.data import discover_training_cases
from utils.sgr_fm_segmentation import atomic_write_json
from utils.sgr_fm_training_assets import (
    load_yaml_or_json,
    recursive_update,
    resolve_under_project,
    run_training_asset_audit,
)


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "output_dir": "outputs/sgr_fm/phase2_training_assets",
        "segmentation_config": "configs/sgr_fm_phase2_training_segmentation.yaml",
        "c1_training_config": "configs/sgr_fm_phase2_c1_training.yaml",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator_training",
        "c1_output_dir": "outputs/sgr_fm/c1_support_guided_training",
        "stages": ["segmentation", "c1", "audit"],
        "expected_training_cases": 200,
        "audit": {"affine_atol": 1e-5, "full_voxel_scan": False, "save_original_dvfs": False},
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="SGR-FM Phase-2 training asset orchestrator")
    parser.add_argument("--config", default="configs/sgr_fm_phase2_training_assets.yaml")
    parser.add_argument("--stages", nargs="+", choices=("segmentation", "c1", "audit"))
    parser.add_argument("--case-ids", nargs="*")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> dict[str, Any]:
    config = default_config()
    path = Path(args.config).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    recursive_update(config, load_yaml_or_json(path, "sgr_fm_training_assets"))
    if args.stages:
        config["stages"] = list(args.stages)
    return config


def run_stage(command: Sequence[str], log_path: Path) -> tuple[int, float]:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()
    with log_path.open("w", encoding="utf-8") as log:
        log.write("$ " + " ".join(str(v) for v in command) + "\n\n")
        log.flush()
        completed = subprocess.run([str(v) for v in command], stdout=log, stderr=subprocess.STDOUT, check=False)
        elapsed = time.time() - started
        log.write(f"\n[exit_code] {completed.returncode}\n[elapsed_sec] {elapsed:.3f}\n")
    return int(completed.returncode), float(elapsed)


def main() -> int:
    args = parse_args()
    config = build_config(args)
    output_dir = resolve_under_project(PROJECT_ROOT, config["output_dir"])
    raw_root = resolve_under_project(PROJECT_ROOT, config["raw_data_root"])
    segmentation_dir = resolve_under_project(PROJECT_ROOT, config["segmentation_dir"])
    c1_output_dir = resolve_under_project(PROJECT_ROOT, config["c1_output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    stages = list(config.get("stages", ["segmentation", "c1", "audit"]))
    effective_case_ids: list[str] = list(args.case_ids or [])
    if args.limit is not None and not effective_case_ids:
        if args.limit < 1:
            raise ValueError("--limit must be >= 1")
        effective_case_ids = [case.case_id for case in discover_training_cases(raw_root)[: args.limit]]

    run_meta = {
        "schema_version": 1,
        "experiment": "SGR-FM Phase-2 training asset generation",
        "project_root": str(PROJECT_ROOT),
        "config": config,
        "stages": stages,
        "case_ids": effective_case_ids,
        "limit": args.limit,
        "overwrite": bool(args.overwrite),
        "dry_run": bool(args.dry_run),
    }
    atomic_write_json(output_dir / "run_config_resolved.json", run_meta)
    print(json.dumps({
        "experiment": run_meta["experiment"],
        "stages": stages,
        "case_ids": run_meta["case_ids"],
        "limit": args.limit,
        "dry_run": bool(args.dry_run),
        "output_dir": str(output_dir),
    }, indent=2))

    stage_results: list[dict[str, Any]] = []
    for stage in stages:
        if stage == "segmentation":
            command = [
                sys.executable,
                str(PROJECT_ROOT / "run_sgr_fm_segmentation.py"),
                "--config",
                str(resolve_under_project(PROJECT_ROOT, config["segmentation_config"])),
            ]
            if effective_case_ids:
                command.extend(["--case-ids", *effective_case_ids])
            if args.overwrite:
                command.append("--overwrite")
            if args.dry_run:
                command.append("--dry-run")
            code, elapsed = run_stage(command, output_dir / "logs" / "segmentation.log")
            result = {"stage": stage, "exit_code": code, "elapsed_sec": elapsed, "command": command}
        elif stage == "c1":
            command = [
                sys.executable,
                str(PROJECT_ROOT / "run_sgr_fm_c1_training.py"),
                "--config",
                str(resolve_under_project(PROJECT_ROOT, config["c1_training_config"])),
            ]
            if effective_case_ids:
                command.extend(["--case-ids", *effective_case_ids])
            if args.overwrite:
                command.append("--overwrite")
            if args.dry_run:
                command.append("--dry-run")
            code, elapsed = run_stage(command, output_dir / "logs" / "c1_training.log")
            result = {"stage": stage, "exit_code": code, "elapsed_sec": elapsed, "command": command}
        else:
            started = time.time()
            if args.dry_run:
                audit_summary = {"status": "SKIPPED_DRY_RUN"}
                code = 0
            else:
                audit_cfg = config.get("audit", {})
                audit_summary = run_training_asset_audit(
                    raw_data_root=raw_root,
                    segmentation_dir=segmentation_dir,
                    c1_output_dir=c1_output_dir,
                    audit_output_dir=output_dir / "audit",
                    case_ids=effective_case_ids or None,
                    expected_case_count=None if effective_case_ids else int(config.get("expected_training_cases", 200)),
                    save_original_dvfs=bool(audit_cfg.get("save_original_dvfs", False)),
                    affine_atol=float(audit_cfg.get("affine_atol", 1e-5)),
                    full_voxel_scan=bool(audit_cfg.get("full_voxel_scan", False)),
                )
                code = 0 if audit_summary.get("status") == "PASS" else 2
            elapsed = time.time() - started
            result = {"stage": stage, "exit_code": code, "elapsed_sec": elapsed, "summary": audit_summary}

        stage_results.append(result)
        atomic_write_json(output_dir / "phase2_stage_results.json", stage_results)
        if int(result["exit_code"]) != 0:
            break

    overall_status = "PASS" if len(stage_results) == len(stages) and all(r["exit_code"] == 0 for r in stage_results) else "FAIL"
    summary = {
        "schema_version": 1,
        "experiment": "SGR-FM Phase-2 training asset generation",
        "status": overall_status,
        "completed_stages": [r["stage"] for r in stage_results],
        "requested_stages": stages,
        "stage_results": stage_results,
        "segmentation_dir": str(segmentation_dir),
        "c1_output_dir": str(c1_output_dir),
        "output_dir": str(output_dir),
    }
    atomic_write_json(output_dir / "phase2_training_assets_summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if overall_status == "PASS" else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
