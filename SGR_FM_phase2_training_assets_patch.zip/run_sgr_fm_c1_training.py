#!/usr/bin/env python3
"""Generate frozen-parameter C1 support-guided uniGradICON DVFs for training pairs.

This is deliberately separate from the validated C1 ablation runner. It reuses
exactly the accepted C1 guidance/FM settings, enforces a fingerprint match to
the completed validation C1 run, never evaluates against validation labels,
and defaults to canonical-RAS DVFs only to reduce disk usage.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import time
import traceback
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.data import discover_training_cases
from utils.dvf_io import (
    dvf_stats,
    original_dvf_xyzc_to_canonical_ras_cxyz,
    save_canonical_ras_dvf_xyzc,
    save_dvf_xyzc,
)
from utils.sgr_fm_segmentation import (
    assert_safe_output_dir,
    assert_same_grid,
    atomic_write_json,
    check_frozen_foundation,
    write_csv,
)
from utils.sgr_fm_support_guided import prepare_guided_ct, support_path
from utils.sgr_fm_training_assets import (
    load_yaml_or_json,
    recursive_update,
    resolve_under_project,
    sha256_json,
    validate_canonical_dvf_header,
)
from utils.unigradicon_runner import (
    UniGradICONConfig,
    _build_cli_command,
    _check_command,
    _run_command,
    _transform_to_voxel_dvf_xyzc,
)


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator_training",
        "output_dir": "outputs/sgr_fm/c1_support_guided_training",
        "case_ids": [],
        "overwrite": False,
        "stop_on_error": True,
        "require_frozen_dvfs": True,
        "frozen_manifest": "outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json",
        "reference_validation_run_config": "outputs/sgr_fm/ablation_C1_support_guided_fm/run_config_resolved.json",
        "require_reference_c1_match": True,
        "expected_training_cases": 200,
        "guidance": {"mode": "soft", "outside_hu": -1024.0, "fade_mm": 7.5},
        "unigradicon": {
            "command": "unigradicon-register",
            "fixed_modality": "ct",
            "moving_modality": "ct",
            "io_iterations": "None",
            "io_sim": "lncc2",
            "save_canonical": True,
            "save_original": False,
            "keep_guided_inputs": False,
            "keep_transforms": False,
        },
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="SGR-FM Phase-2 C1 training DVF generator")
    parser.add_argument("--config", default="configs/sgr_fm_phase2_c1_training.yaml")
    parser.add_argument("--raw-data-root")
    parser.add_argument("--segmentation-dir")
    parser.add_argument("--output-dir")
    parser.add_argument("--case-ids", nargs="*")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--keep-guided-inputs", action="store_true")
    parser.add_argument("--keep-transforms", action="store_true")
    parser.add_argument("--save-original", action="store_true")
    parser.add_argument("--allow-unfrozen-dvfs", action="store_true")
    parser.add_argument("--allow-c1-config-drift", action="store_true")
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> dict[str, Any]:
    config = default_config()
    config_path = Path(args.config).expanduser()
    if not config_path.is_absolute():
        config_path = PROJECT_ROOT / config_path
    recursive_update(config, load_yaml_or_json(config_path, "sgr_fm_c1_training"))
    if args.raw_data_root:
        config["raw_data_root"] = args.raw_data_root
    if args.segmentation_dir:
        config["segmentation_dir"] = args.segmentation_dir
    if args.output_dir:
        config["output_dir"] = args.output_dir
    if args.case_ids is not None:
        config["case_ids"] = list(args.case_ids)
    if args.overwrite:
        config["overwrite"] = True
    if args.keep_guided_inputs:
        config["unigradicon"]["keep_guided_inputs"] = True
    if args.keep_transforms:
        config["unigradicon"]["keep_transforms"] = True
    if args.save_original:
        config["unigradicon"]["save_original"] = True
    if args.allow_unfrozen_dvfs:
        config["require_frozen_dvfs"] = False
    if args.allow_c1_config_drift:
        config["require_reference_c1_match"] = False
    return config


def c1_fingerprint(config: dict[str, Any]) -> str:
    guidance = config["guidance"]
    ug = config["unigradicon"]
    return sha256_json({
        "guidance": guidance,
        "unigradicon": {
            "fixed_modality": ug.get("fixed_modality", "ct"),
            "moving_modality": ug.get("moving_modality", "ct"),
            "io_iterations": str(ug.get("io_iterations", "None")),
            "io_sim": ug.get("io_sim", "lncc2"),
        },
    })


def enforce_reference_c1(config: dict[str, Any], fingerprint: str) -> dict[str, Any]:
    reference_path = resolve_under_project(PROJECT_ROOT, config["reference_validation_run_config"])
    status: dict[str, Any] = {"path": str(reference_path), "present": reference_path.exists()}
    require = bool(config.get("require_reference_c1_match", True))
    if not reference_path.exists():
        if require:
            raise FileNotFoundError(
                "Accepted validation C1 run config is required to lock Phase-2 parameters: "
                f"{reference_path}"
            )
        status.update({"match": None, "reason": "reference_missing_but_not_required"})
        return status
    reference = json.loads(reference_path.read_text(encoding="utf-8"))
    reference_fp = reference.get("config_fingerprint_sha256")
    status.update({"reference_fingerprint": reference_fp, "training_fingerprint": fingerprint})
    status["match"] = bool(reference_fp == fingerprint)
    if require and not status["match"]:
        raise RuntimeError(
            "Phase-2 C1 parameters drifted from the accepted validation C1 run. "
            f"reference={reference_fp} training={fingerprint}"
        )
    return status


def _atomic_save_canonical(dvf_cxyz: np.ndarray, fixed_path: Path, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = output_path.with_name(output_path.name + ".tmp.nii.gz")
    tmp.unlink(missing_ok=True)
    try:
        save_canonical_ras_dvf_xyzc(dvf_cxyz, fixed_path, tmp)
        os.replace(tmp, output_path)
    finally:
        tmp.unlink(missing_ok=True)


def _atomic_save_original(dvf_xyzc: np.ndarray, fixed_path: Path, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = output_path.with_name(output_path.name + ".tmp.nii.gz")
    tmp.unlink(missing_ok=True)
    try:
        save_dvf_xyzc(dvf_xyzc, fixed_path, tmp)
        os.replace(tmp, output_path)
    finally:
        tmp.unlink(missing_ok=True)


def validate_original_dvf(path: Path, fixed_path: Path, affine_atol: float = 1e-5) -> dict[str, Any]:
    assert_same_grid(path, fixed_path, affine_atol=affine_atol, name="C1_training_original_DVF")
    data = np.asanyarray(nib.load(str(path)).dataobj)
    if data.ndim != 4 or data.shape[-1] != 3:
        raise ValueError(f"Expected XYZC DVF, got {data.shape}: {path}")
    if not np.isfinite(data).all():
        raise ValueError(f"Non-finite DVF: {path}")
    return {"shape": list(data.shape), "finite": True}


def main() -> int:
    args = parse_args()
    config = build_config(args)

    raw_root = resolve_under_project(PROJECT_ROOT, config["raw_data_root"])
    segmentation_dir = resolve_under_project(PROJECT_ROOT, config["segmentation_dir"])
    output_dir = resolve_under_project(PROJECT_ROOT, config["output_dir"])
    config["raw_data_root"] = str(raw_root)
    config["segmentation_dir"] = str(segmentation_dir)
    config["output_dir"] = str(output_dir)

    assert_safe_output_dir(output_dir, PROJECT_ROOT)
    foundation = check_frozen_foundation(
        PROJECT_ROOT,
        config.get("frozen_manifest", "outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json"),
        require=bool(config.get("require_frozen_dvfs", True)),
    )
    executable = _check_command(str(config["unigradicon"].get("command", "unigradicon-register")))

    cases = discover_training_cases(raw_root)
    requested = set(str(v) for v in config.get("case_ids", []))
    if requested:
        cases = [case for case in cases if case.case_id in requested]
        missing = sorted(requested - {case.case_id for case in cases})
        if missing:
            raise FileNotFoundError(f"Requested training cases not found: {missing}")
    elif len(cases) != int(config.get("expected_training_cases", 200)):
        raise RuntimeError(
            f"Expected {config.get('expected_training_cases', 200)} training cases, discovered {len(cases)}"
        )
    if args.limit is not None:
        if args.limit < 1:
            raise ValueError("--limit must be >= 1")
        cases = cases[: args.limit]
    if not cases:
        raise RuntimeError("No training cases discovered")

    guidance = config["guidance"]
    ug = config["unigradicon"]
    if not bool(ug.get("save_canonical", True)) and not bool(ug.get("save_original", False)):
        raise ValueError("At least one of save_canonical or save_original must be true")

    fingerprint = c1_fingerprint(config)
    reference_lock = enforce_reference_c1(config, fingerprint)

    output_dir.mkdir(parents=True, exist_ok=True)
    for sub in ("dvfs_canonical_ras", "dvfs", "logs", "case_manifests"):
        (output_dir / sub).mkdir(parents=True, exist_ok=True)
    if bool(ug.get("keep_transforms", False)):
        (output_dir / "transforms").mkdir(parents=True, exist_ok=True)
    if bool(ug.get("keep_guided_inputs", False)):
        (output_dir / "guided_inputs").mkdir(parents=True, exist_ok=True)

    previous_run_config = output_dir / "run_config_resolved.json"
    if previous_run_config.exists() and not bool(config.get("overwrite", False)):
        previous = json.loads(previous_run_config.read_text(encoding="utf-8"))
        previous_fp = previous.get("config_fingerprint_sha256")
        if previous_fp and previous_fp != fingerprint:
            raise RuntimeError(
                "Training C1 output contains a different configuration. "
                f"existing={previous_fp} current={fingerprint}. Use a new output dir or --overwrite."
            )

    run_meta = {
        "schema_version": 1,
        "experiment": "SGR-FM Phase-2 C1 training asset generation",
        "project_root": str(PROJECT_ROOT),
        "config": config,
        "config_fingerprint_sha256": fingerprint,
        "accepted_validation_c1_lock": reference_lock,
        "frozen_foundation": foundation,
        "case_count": len(cases),
        "dry_run": bool(args.dry_run),
        "note": "No validation GT is used; C1 parameters are locked to the accepted validation run.",
    }
    atomic_write_json(previous_run_config, run_meta)
    print(json.dumps({
        "experiment": run_meta["experiment"],
        "case_count": len(cases),
        "guidance": guidance,
        "save_canonical": bool(ug.get("save_canonical", True)),
        "save_original": bool(ug.get("save_original", False)),
        "c1_reference_match": reference_lock.get("match"),
        "frozen_foundation_ok": foundation.get("ok"),
        "output_dir": str(output_dir),
        "dry_run": bool(args.dry_run),
    }, indent=2))

    rows: list[dict[str, Any]] = []
    overwrite = bool(config.get("overwrite", False))
    canonical_count = 0
    original_count = 0

    for index, case in enumerate(cases, start=1):
        started = time.time()
        case_id = case.case_id
        print(f"[{index:03d}/{len(cases):03d}] {case_id}", flush=True)
        exp_support = support_path(segmentation_dir, "training", case_id, "EXP")
        insp_support = support_path(segmentation_dir, "training", case_id, "INSP")
        canonical_dvf = output_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz"
        original_dvf = output_dir / "dvfs" / f"{case_id}_DVF.nii.gz"
        log_path = output_dir / "logs" / f"{case_id}.log"
        record: dict[str, Any] = {
            "case_id": case_id,
            "status": "started",
            "raw_EXP": str(case.exp_ct),
            "raw_INSP": str(case.insp_ct),
            "support_EXP": str(exp_support),
            "support_INSP": str(insp_support),
            "canonical_dvf": str(canonical_dvf) if bool(ug.get("save_canonical", True)) else "",
            "original_dvf": str(original_dvf) if bool(ug.get("save_original", False)) else "",
            "config_fingerprint_sha256": fingerprint,
        }
        try:
            if not exp_support.exists() or not insp_support.exists():
                raise FileNotFoundError(
                    f"Missing training support mask(s): EXP={exp_support.exists()} INSP={insp_support.exists()}"
                )
            assert_same_grid(exp_support, case.exp_ct, affine_atol=1e-5, name="training_EXP_support")
            assert_same_grid(insp_support, case.insp_ct, affine_atol=1e-5, name="training_INSP_support")

            if args.dry_run:
                record["status"] = "dry_run"
                record["elapsed_sec"] = 0.0
                rows.append(record)
                continue

            canonical_ok = True
            original_ok = True
            if bool(ug.get("save_canonical", True)):
                canonical_ok = canonical_dvf.exists()
                if canonical_ok:
                    validate_canonical_dvf_header(canonical_dvf, case.insp_ct)
            if bool(ug.get("save_original", False)):
                original_ok = original_dvf.exists()
                if original_ok:
                    validate_original_dvf(original_dvf, case.insp_ct)
            if canonical_ok and original_ok and not overwrite:
                record["status"] = "reused"
                if bool(ug.get("save_canonical", True)):
                    canonical_count += 1
                if bool(ug.get("save_original", False)):
                    original_count += 1
                record["elapsed_sec"] = float(time.time() - started)
                rows.append(record)
                atomic_write_json(output_dir / "case_manifests" / f"{case_id}.json", record)
                write_csv(output_dir / "case_manifest.csv", rows)
                atomic_write_json(output_dir / "case_manifest.json", rows)
                continue

            if overwrite:
                canonical_dvf.unlink(missing_ok=True)
                original_dvf.unlink(missing_ok=True)

            persistent_inputs = bool(ug.get("keep_guided_inputs", False))
            cleanup_ctx: tempfile.TemporaryDirectory[str] | None = None
            if persistent_inputs:
                guided_root = output_dir / "guided_inputs" / case_id
                guided_root.mkdir(parents=True, exist_ok=True)
            else:
                cleanup_ctx = tempfile.TemporaryDirectory(prefix=f"sgrfm_c1train_{case_id}_", dir=output_dir)
                guided_root = Path(cleanup_ctx.name)

            try:
                guided_exp = guided_root / f"{case_id}_EXP_support_guided.nii.gz"
                guided_insp = guided_root / f"{case_id}_INSP_support_guided.nii.gz"
                record["guidance_EXP"] = prepare_guided_ct(
                    case.exp_ct,
                    exp_support,
                    guided_exp,
                    mode=str(guidance.get("mode", "soft")),
                    outside_hu=float(guidance.get("outside_hu", -1024.0)),
                    fade_mm=float(guidance.get("fade_mm", 7.5)),
                )
                record["guidance_INSP"] = prepare_guided_ct(
                    case.insp_ct,
                    insp_support,
                    guided_insp,
                    mode=str(guidance.get("mode", "soft")),
                    outside_hu=float(guidance.get("outside_hu", -1024.0)),
                    fade_mm=float(guidance.get("fade_mm", 7.5)),
                )
                if (
                    record["guidance_EXP"]["inside_max_abs_change_hu"] != 0.0
                    or record["guidance_INSP"]["inside_max_abs_change_hu"] != 0.0
                ):
                    raise RuntimeError("Guidance changed voxels inside predicted anatomy")

                if bool(ug.get("keep_transforms", False)):
                    transform_path = output_dir / "transforms" / f"{case_id}_unigradicon.hdf5"
                else:
                    transform_path = guided_root / f"{case_id}_unigradicon.hdf5"

                ug_config = UniGradICONConfig(
                    raw_data_root=str(raw_root),
                    output_dir=str(output_dir),
                    split="training",
                    command=str(ug.get("command", "unigradicon-register")),
                    fixed_modality=str(ug.get("fixed_modality", "ct")),
                    moving_modality=str(ug.get("moving_modality", "ct")),
                    io_iterations=str(ug.get("io_iterations", "None")),
                    io_sim=str(ug.get("io_sim", "lncc2")),
                    make_zip=False,
                    evaluate=False,
                    overwrite=overwrite,
                    save_warped=False,
                    save_canonical=bool(ug.get("save_canonical", True)),
                    stop_on_error=True,
                    case_ids=[case_id],
                )
                command = _build_cli_command(
                    ug_config,
                    fixed_path=guided_insp,
                    moving_path=guided_exp,
                    transform_out=transform_path,
                    warped_out=None,
                )
                record["command"] = command
                exit_code = _run_command(command, log_path)
                record["exit_code"] = int(exit_code)
                if exit_code != 0:
                    raise RuntimeError(f"uniGradICON failed for {case_id}; see {log_path}")
                if not transform_path.exists():
                    raise FileNotFoundError(f"Missing uniGradICON transform: {transform_path}")

                dvf_xyzc = _transform_to_voxel_dvf_xyzc(transform_path, case.insp_ct)
                record["dvf_stats_voxel"] = dvf_stats(dvf_xyzc)

                if bool(ug.get("save_canonical", True)):
                    dvf_cxyz = original_dvf_xyzc_to_canonical_ras_cxyz(dvf_xyzc, case.insp_ct)
                    _atomic_save_canonical(dvf_cxyz, case.insp_ct, canonical_dvf)
                    record["canonical_validation"] = validate_canonical_dvf_header(canonical_dvf, case.insp_ct)
                    canonical_count += 1
                if bool(ug.get("save_original", False)):
                    _atomic_save_original(dvf_xyzc, case.insp_ct, original_dvf)
                    record["original_validation"] = validate_original_dvf(original_dvf, case.insp_ct)
                    original_count += 1
                record["status"] = "ok"
            finally:
                if cleanup_ctx is not None:
                    cleanup_ctx.cleanup()
        except Exception as exc:
            record["status"] = "failed"
            record["error_type"] = type(exc).__name__
            record["error"] = str(exc)
            record["traceback"] = traceback.format_exc()
        record["elapsed_sec"] = float(time.time() - started)
        rows.append(record)
        write_csv(output_dir / "case_manifest.csv", rows)
        atomic_write_json(output_dir / "case_manifest.json", rows)
        atomic_write_json(output_dir / "case_manifests" / f"{case_id}.json", record)
        if record["status"] == "failed" and bool(config.get("stop_on_error", True)):
            break

    if args.dry_run:
        summary = {
            "schema_version": 1,
            "status": "DRY_RUN",
            "case_count": len(rows),
            "config_fingerprint_sha256": fingerprint,
            "accepted_validation_c1_lock": reference_lock,
            "output_dir": str(output_dir),
        }
        atomic_write_json(output_dir / "c1_training_summary.json", summary)
        print(json.dumps(summary, indent=2))
        return 0

    failed = [row for row in rows if row.get("status") == "failed"]
    summary = {
        "schema_version": 1,
        "experiment": "SGR-FM Phase-2 C1 training asset generation",
        "status": "PASS" if not failed and len(rows) == len(cases) else "FAIL",
        "case_count": len(cases),
        "processed_count": len(rows),
        "failed_count": len(failed),
        "canonical_dvf_count": canonical_count,
        "original_dvf_count": original_count,
        "guidance": guidance,
        "config_fingerprint_sha256": fingerprint,
        "accepted_validation_c1_lock": reference_lock,
        "frozen_foundation_ok": foundation.get("ok"),
        "output_dir": str(output_dir),
    }
    atomic_write_json(output_dir / "c1_training_summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if summary["status"] == "PASS" else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
