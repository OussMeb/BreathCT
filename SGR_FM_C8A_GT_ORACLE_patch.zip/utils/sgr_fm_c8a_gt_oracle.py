#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

try:
    import nibabel as nib
except Exception:
    nib = None

try:
    import torch
    import torch.nn.functional as F
except Exception:
    torch = None
    F = None


LABELS_DEFAULT = [8, 16, 32, 64, 128]


def _parse_scalar(v: str):
    s = v.strip()
    if s.lower() in ("true", "false"):
        return s.lower() == "true"
    if s.startswith("[") and s.endswith("]"):
        return json.loads(s.replace("'", '"'))
    try:
        return json.loads(s)
    except Exception:
        return s.strip('"').strip("'")


def _simple_yaml(text: str) -> Dict:
    out: Dict = {}
    stack: List[Tuple[int, Dict]] = [(-1, out)]
    for raw in text.splitlines():
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        k = k.strip()
        v = v.strip()
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if v == "":
            child = {}
            parent[k] = child
            stack.append((indent, child))
        else:
            parent[k] = _parse_scalar(v)
    return out


def load_config(path: str) -> Dict:
    p = Path(path)
    text = p.read_text()
    if p.suffix.lower() == ".json":
        cfg = json.loads(text)
    else:
        try:
            import yaml
            cfg = yaml.safe_load(text)
        except Exception:
            cfg = _simple_yaml(text)

    cfg.setdefault("output_root", "outputs/sgr_fm/c8a_gt_oracle")
    cfg.setdefault("parent_dir", "outputs/sgr_fm/c7b_multi_init_semantic")
    cfg.setdefault("fallback_parent_dir", "outputs/sgr_fm/c7a_v2_relaxed_selector")
    cfg.setdefault("raw_data_root", "Learn2Breath_train_val_data")
    cfg.setdefault("validation_root", "Learn2Breath_train_val_data/validation")
    cfg.setdefault("pseudo_segmentation_root", "outputs/sgr_fm/segmentation_phase1_totalsegmentator")
    cfg.setdefault("evaluate_script", "evaluate_validation.py")
    cfg.setdefault("labels", LABELS_DEFAULT)
    cfg.setdefault("device", "cuda")
    cfg.setdefault("continue_on_error", False)
    cfg.setdefault("hard_reject_folding_pct", 0.50)
    cfg.setdefault("soft_folding_start_pct", 0.25)
    cfg.setdefault("soft_folding_full_pct", 0.30)
    cfg.setdefault("candidate_scales", [1.0, 0.75, 0.5, 0.25, 0.125, 0.0])
    cfg.setdefault("stages", [
        {"name": "O1_label_global", "reduce_factor": 4, "control_factor": 5, "iterations": 100, "lr": 0.08, "max_residual_vox": 2.0},
        {"name": "O2_label_refine", "reduce_factor": 2, "control_factor": 4, "iterations": 140, "lr": 0.04, "max_residual_vox": 1.2},
    ])
    cfg.setdefault("loss_weights", {"dice": 1.0, "smooth": 0.04, "magnitude": 0.015})
    return cfg


def discover_cases(validation_root: Path, cfg: Dict) -> List[str]:
    cases = set()
    if validation_root.exists():
        for p in validation_root.rglob("*.nii*"):
            m = re.search(r"(NLST_\d+)", p.name)
            if m and ("lobe" in p.name.lower() or "seg" in p.name.lower() or "label" in p.name.lower()):
                cases.add(m.group(1))
    if not cases:
        parent = Path(cfg["parent_dir"]) / "dvfs"
        for p in parent.glob("NLST_*_DVF.nii.gz"):
            cases.add(p.name.split("_DVF")[0])
    return sorted(cases)


def _load_img(path: Path):
    if nib is None:
        raise RuntimeError("nibabel is required")
    img = nib.load(str(path))
    return img, img.get_fdata(dtype=np.float32)


def _save_like(ref_img, data: np.ndarray, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    img = nib.Nifti1Image(data.astype(np.float32), ref_img.affine, ref_img.header)
    img.to_filename(str(path))


def _find_case_file(root: Path, case_id: str, phase: str, kind: str) -> Optional[Path]:
    if not root.exists():
        return None
    phase_l = phase.lower()
    case_l = case_id.lower()
    files = list(root.rglob("*.nii*"))

    def score(p: Path) -> int:
        n = p.name.lower()
        s = 0
        if case_l not in n:
            return -999
        if phase_l in n:
            s += 20
        if kind == "lobe_gt":
            if "lobe" in n:
                s += 20
            if any(x in n for x in ["seg", "label", "mask"]):
                s += 5
            if "fissure" in n or "interface" in n or "support" in n:
                s -= 50
            if "ct" in n:
                s -= 20
        elif kind == "pseudo_lobe":
            if "lobe" in n:
                s += 20
            if "interface" in n or "fissure" in n or "support" in n:
                s -= 80
            if "seg" in n or "label" in n:
                s += 5
        return s

    scored = [(score(p), p) for p in files]
    scored = [x for x in scored if x[0] > 0]
    if not scored:
        return None
    scored.sort(key=lambda x: (x[0], -len(str(x[1]))), reverse=True)
    return scored[0][1]


def _find_parent_dvf(case_id: str, cfg: Dict) -> Path:
    for root_key in ["parent_dir", "fallback_parent_dir"]:
        root = Path(cfg[root_key]) / "dvfs"
        p = root / f"{case_id}_DVF.nii.gz"
        if p.exists():
            return p
    raise FileNotFoundError(f"Could not find parent DVF for {case_id}")


def _downsample_label(arr: np.ndarray, r: int) -> np.ndarray:
    if r <= 1:
        return arr.astype(np.int16)
    return arr[::r, ::r, ::r].astype(np.int16)


def _downsample_dvf(dvf: np.ndarray, r: int) -> np.ndarray:
    if r <= 1:
        return dvf.astype(np.float32)
    return (dvf[::r, ::r, ::r, :] / float(r)).astype(np.float32)


def _labels_to_onehot(label_xyz: np.ndarray, labels: List[int], device: str):
    vols = []
    for lab in labels:
        vols.append((label_xyz == lab).astype(np.float32).transpose(2, 1, 0))
    arr = np.stack(vols, axis=0)[None]
    return torch.from_numpy(arr).to(device)


def _dvf_xyz_to_torch(dvf_xyz: np.ndarray, device: str):
    comps = [
        dvf_xyz[..., 0].transpose(2, 1, 0),
        dvf_xyz[..., 1].transpose(2, 1, 0),
        dvf_xyz[..., 2].transpose(2, 1, 0),
    ]
    arr = np.stack(comps, axis=0)[None].astype(np.float32)
    return torch.from_numpy(arr).to(device)


def _torch_dvf_to_xyz(dvf_t) -> np.ndarray:
    a = dvf_t.detach().cpu().numpy()[0]
    out = np.stack([
        a[0].transpose(2, 1, 0),
        a[1].transpose(2, 1, 0),
        a[2].transpose(2, 1, 0),
    ], axis=-1)
    return out.astype(np.float32)


def _warp_onehot(mov_oh, dvf_t):
    _, _, D, H, W = mov_oh.shape
    z = torch.linspace(0, D - 1, D, device=mov_oh.device)
    y = torch.linspace(0, H - 1, H, device=mov_oh.device)
    x = torch.linspace(0, W - 1, W, device=mov_oh.device)
    zz, yy, xx = torch.meshgrid(z, y, x, indexing="ij")
    mx = xx + dvf_t[:, 0]
    my = yy + dvf_t[:, 1]
    mz = zz + dvf_t[:, 2]
    gx = 2.0 * mx / max(W - 1, 1) - 1.0
    gy = 2.0 * my / max(H - 1, 1) - 1.0
    gz = 2.0 * mz / max(D - 1, 1) - 1.0
    grid = torch.stack([gx[0], gy[0], gz[0]], dim=-1)[None]
    return F.grid_sample(mov_oh, grid, mode="bilinear", padding_mode="border", align_corners=True)


def _dice_loss(warped, fixed, eps=1e-5):
    dims = (0, 2, 3, 4)
    inter = torch.sum(warped * fixed, dim=dims)
    den = torch.sum(warped + fixed, dim=dims)
    dice = (2.0 * inter + eps) / (den + eps)
    return 1.0 - torch.mean(dice), dice.detach().cpu().numpy().tolist()


def _smoothness_loss(res):
    vals = [
        torch.mean((res[:, :, 1:, :, :] - res[:, :, :-1, :, :]) ** 2),
        torch.mean((res[:, :, :, 1:, :] - res[:, :, :, :-1, :]) ** 2),
        torch.mean((res[:, :, :, :, 1:] - res[:, :, :, :, :-1]) ** 2),
    ]
    return sum(vals) / len(vals)


def _make_control_shape(shape_xyz: Tuple[int, int, int], cf: int):
    X, Y, Z = shape_xyz
    return (max(2, int(np.ceil(Z / cf))), max(2, int(np.ceil(Y / cf))), max(2, int(np.ceil(X / cf))))


def _optimize_stage(fixed_lab, moving_lab, base_dvf, labels, cfg, stage, device):
    r = int(stage["reduce_factor"])
    base_red = _downsample_dvf(base_dvf, r)
    fix_red = _downsample_label(fixed_lab, r)
    mov_red = _downsample_label(moving_lab, r)
    shape_xyz = fix_red.shape

    fixed_oh = _labels_to_onehot(fix_red, labels, device)
    moving_oh = _labels_to_onehot(mov_red, labels, device)
    base_t = _dvf_xyz_to_torch(base_red, device)

    D, H, W = fixed_oh.shape[-3:]
    cd, ch, cw = _make_control_shape(shape_xyz, int(stage["control_factor"]))
    ctrl = torch.zeros((1, 3, cd, ch, cw), device=device, requires_grad=True)
    opt = torch.optim.Adam([ctrl], lr=float(stage["lr"]))

    max_res = float(stage["max_residual_vox"])
    weights = cfg["loss_weights"]
    best = {"loss": float("inf"), "iter": -1, "ctrl": None, "dice": None}

    for it in range(1, int(stage["iterations"]) + 1):
        opt.zero_grad(set_to_none=True)
        res = F.interpolate(ctrl, size=(D, H, W), mode="trilinear", align_corners=True)
        res = max_res * torch.tanh(res)
        dvf = base_t + res
        warped = _warp_onehot(moving_oh, dvf)
        dloss, dice_vec = _dice_loss(warped, fixed_oh)
        smooth = _smoothness_loss(res)
        mag = torch.mean(res * res)
        loss = weights["dice"] * dloss + weights["smooth"] * smooth + weights["magnitude"] * mag
        loss.backward()
        opt.step()
        val = float(loss.detach().cpu())
        if val < best["loss"]:
            best = {"loss": val, "iter": it, "ctrl": ctrl.detach().clone(), "dice": dice_vec}

    with torch.no_grad():
        best_ctrl = best["ctrl"]
        res = F.interpolate(best_ctrl, size=(D, H, W), mode="trilinear", align_corners=True)
        res = max_res * torch.tanh(res)
        res_xyz_red = _torch_dvf_to_xyz(res)
    return res_xyz_red, best


def _upsample_residual_to_full(res_red_xyz: np.ndarray, full_shape_xyz: Tuple[int, int, int], r: int) -> np.ndarray:
    device = "cpu"
    t = _dvf_xyz_to_torch(res_red_xyz, device)
    X, Y, Z = full_shape_xyz
    up = F.interpolate(t, size=(Z, Y, X), mode="trilinear", align_corners=True)
    return (_torch_dvf_to_xyz(up) * float(r)).astype(np.float32)


def _warp_label_numpy(moving_lab: np.ndarray, dvf: np.ndarray) -> np.ndarray:
    try:
        from scipy.ndimage import map_coordinates
    except Exception as e:
        raise RuntimeError("scipy is required for gap audit label warping") from e
    X, Y, Z = moving_lab.shape
    xx, yy, zz = np.meshgrid(np.arange(X), np.arange(Y), np.arange(Z), indexing="ij")
    coords = [xx + dvf[..., 0], yy + dvf[..., 1], zz + dvf[..., 2]]
    return map_coordinates(moving_lab.astype(np.float32), coords, order=0, mode="nearest").round().astype(np.int16)


def _dice_np(a: np.ndarray, b: np.ndarray, labels: List[int]):
    d = {}
    vals = []
    for lab in labels:
        aa = a == lab
        bb = b == lab
        den = int(aa.sum() + bb.sum())
        if den == 0:
            val = float("nan")
        else:
            val = float(2.0 * np.logical_and(aa, bb).sum() / den)
            vals.append(val)
        d[f"dice_{lab}"] = val
    return (float(np.nanmean(vals)) if vals else float("nan")), d


def _folding_pct(dvf: np.ndarray) -> float:
    ux, uy, uz = dvf[..., 0], dvf[..., 1], dvf[..., 2]
    dux_dx, dux_dy, dux_dz = np.gradient(ux)
    duy_dx, duy_dy, duy_dz = np.gradient(uy)
    duz_dx, duz_dy, duz_dz = np.gradient(uz)
    J00 = 1 + dux_dx; J01 = dux_dy; J02 = dux_dz
    J10 = duy_dx; J11 = 1 + duy_dy; J12 = duy_dz
    J20 = duz_dx; J21 = duz_dy; J22 = 1 + duz_dz
    det = J00 * (J11 * J22 - J12 * J21) - J01 * (J10 * J22 - J12 * J20) + J02 * (J10 * J21 - J11 * J20)
    return float(100.0 * np.mean(det < 0))


def _stage_select(current_full, residual_full, fixed_lab, moving_lab, labels, cfg):
    best = None
    details = []
    for sc in cfg["candidate_scales"]:
        cand = current_full + float(sc) * residual_full
        fold = _folding_pct(cand)
        warped = _warp_label_numpy(moving_lab, cand)
        mean_dice, per_lobe = _dice_np(fixed_lab, warped, labels)
        rejected = fold > float(cfg["hard_reject_folding_pct"])
        score = mean_dice
        if fold > float(cfg["soft_folding_start_pct"]):
            if fold <= float(cfg["soft_folding_full_pct"]):
                score -= 0.005 * (fold - cfg["soft_folding_start_pct"]) / max(1e-6, cfg["soft_folding_full_pct"] - cfg["soft_folding_start_pct"])
            else:
                score -= 0.005 + 0.05 * min(1.0, (fold - cfg["soft_folding_full_pct"]) / max(1e-6, cfg["hard_reject_folding_pct"] - cfg["soft_folding_full_pct"]))
        rec = {"scale": float(sc), "mean_gt_dice": mean_dice, "score": float(score), "folding_pct": fold, "rejected": rejected, **per_lobe}
        details.append(rec)
        if not rejected and (best is None or rec["score"] > best["score"]):
            best = rec
    if best is None:
        best = [x for x in details if x["scale"] == 0.0][0]
    return best, details


def _pseudo_gap(case_id: str, phase: str, gt_lab: np.ndarray, labels: List[int], cfg: Dict):
    root = Path(cfg.get("pseudo_segmentation_root", ""))
    p = _find_case_file(root, case_id, phase, "pseudo_lobe")
    if p is None:
        return {"path": None, "mean_dice": None}
    _, arr = _load_img(p)
    arr = arr.astype(np.int16)
    if arr.shape != gt_lab.shape:
        return {"path": str(p), "mean_dice": None, "error": f"shape mismatch {arr.shape} vs {gt_lab.shape}"}
    mean, per = _dice_np(gt_lab, arr, labels)
    return {"path": str(p), "mean_dice": mean, **per}


def run_case(case_id: str, cfg: Dict) -> Dict:
    if torch is None or nib is None:
        raise RuntimeError("torch and nibabel are required")
    t0 = time.time()
    labels = [int(x) for x in cfg["labels"]]
    device = cfg.get("device", "cuda")
    if device == "cuda" and not torch.cuda.is_available():
        device = "cpu"

    val_root = Path(cfg["validation_root"])
    fixed_lab_p = _find_case_file(val_root, case_id, "INSP", "lobe_gt")
    moving_lab_p = _find_case_file(val_root, case_id, "EXP", "lobe_gt")
    if fixed_lab_p is None or moving_lab_p is None:
        raise FileNotFoundError(f"Could not locate GT lobe labels for {case_id}")

    fixed_img, fixed_lab = _load_img(fixed_lab_p)
    _, moving_lab = _load_img(moving_lab_p)
    fixed_lab = fixed_lab.astype(np.int16)
    moving_lab = moving_lab.astype(np.int16)

    parent_p = _find_parent_dvf(case_id, cfg)
    parent_img, parent_dvf = _load_img(parent_p)
    parent_dvf = parent_dvf.astype(np.float32)
    current = parent_dvf.copy()

    parent_warp = _warp_label_numpy(moving_lab, parent_dvf)
    parent_mean, parent_lobes = _dice_np(fixed_lab, parent_warp, labels)
    parent_fold = _folding_pct(parent_dvf)

    stages_out = []
    for stage in cfg["stages"]:
        res_red, opt_info = _optimize_stage(fixed_lab, moving_lab, current, labels, cfg, stage, device)
        r = int(stage["reduce_factor"])
        residual_full = _upsample_residual_to_full(res_red, current.shape[:3], r)
        best, candidates = _stage_select(current, residual_full, fixed_lab, moving_lab, labels, cfg)
        current = current + float(best["scale"]) * residual_full
        stages_out.append({
            "stage": stage["name"],
            "reduce_factor": r,
            "best_optimization_loss": opt_info["loss"],
            "best_optimization_iter": opt_info["iter"],
            "selected": best,
            "candidates": candidates,
        })

    oracle_warp = _warp_label_numpy(moving_lab, current)
    oracle_mean, oracle_lobes = _dice_np(fixed_lab, oracle_warp, labels)
    oracle_fold = _folding_pct(current)

    out_root = Path(cfg["output_root"])
    out_dvf = out_root / "dvfs" / f"{case_id}_DVF.nii.gz"
    _save_like(parent_img, current, out_dvf)
    out_can = out_root / "dvfs_canonical_ras" / f"{case_id}_DVF.nii.gz"
    _save_like(parent_img, current, out_can)

    pseudo_insp = _pseudo_gap(case_id, "INSP", fixed_lab, labels, cfg)
    pseudo_exp = _pseudo_gap(case_id, "EXP", moving_lab, labels, cfg)

    rec = {
        "case_id": case_id,
        "status": "ok",
        "warning": "validation GT labels used in optimizer; diagnostic upper-bound only",
        "device": device,
        "parent_dvf": str(parent_p),
        "fixed_gt_lobe": str(fixed_lab_p),
        "moving_gt_lobe": str(moving_lab_p),
        "output_dvf": str(out_dvf),
        "parent_gt_mean_dice": parent_mean,
        "oracle_gt_mean_dice": oracle_mean,
        "oracle_minus_parent_mean_dice": oracle_mean - parent_mean,
        "parent_folding_pct": parent_fold,
        "oracle_folding_pct": oracle_fold,
        "parent_lobe_dice": parent_lobes,
        "oracle_lobe_dice": oracle_lobes,
        "oracle_minus_parent_lobe_dice": {
            k: oracle_lobes[k] - parent_lobes[k] for k in parent_lobes if not (math.isnan(parent_lobes[k]) or math.isnan(oracle_lobes[k]))
        },
        "pseudo_vs_gt": {"INSP": pseudo_insp, "EXP": pseudo_exp},
        "stages": stages_out,
        "elapsed_sec": time.time() - t0,
    }
    mani = out_root / "case_manifests" / f"{case_id}_manifest.json"
    mani.write_text(json.dumps(rec, indent=2))
    return rec


def summarize(cfg: Dict, records: List[Dict], failed: List[Dict]) -> Dict:
    vals_parent = [r["parent_gt_mean_dice"] for r in records]
    vals_oracle = [r["oracle_gt_mean_dice"] for r in records]
    folds = [r["oracle_folding_pct"] for r in records]
    return {
        "status": "PASS" if not failed else "PARTIAL_FAIL",
        "method": "SGR-FM C8A GT-oracle label registration",
        "warning": "Uses validation ground-truth labels in optimization. Do not treat as hidden-test-safe.",
        "case_count": len(records),
        "failure_count": len(failed),
        "parent_mean_gt_dice": float(np.mean(vals_parent)) if vals_parent else None,
        "oracle_mean_gt_dice": float(np.mean(vals_oracle)) if vals_oracle else None,
        "oracle_minus_parent_mean_gt_dice": float(np.mean(vals_oracle) - np.mean(vals_parent)) if vals_oracle else None,
        "min_oracle_case_gt_dice": float(np.min(vals_oracle)) if vals_oracle else None,
        "max_oracle_case_gt_dice": float(np.max(vals_oracle)) if vals_oracle else None,
        "mean_oracle_folding_pct": float(np.mean(folds)) if folds else None,
        "max_oracle_folding_pct": float(np.max(folds)) if folds else None,
        "failed_cases": failed,
        "output_root": cfg["output_root"],
        "parent_dir": cfg["parent_dir"],
    }


def write_gap_tables(cfg: Dict, records: List[Dict]):
    out = Path(cfg["output_root"]) / "gap_audit"
    out.mkdir(parents=True, exist_ok=True)

    labels = [int(x) for x in cfg["labels"]]
    per_case = out / "c8a_gt_oracle_gap_per_case.csv"
    with per_case.open("w", newline="") as f:
        fieldnames = [
            "case_id", "parent_gt_mean_dice", "oracle_gt_mean_dice", "delta_mean_dice",
            "parent_folding_pct", "oracle_folding_pct",
            "pseudo_INSP_mean_dice", "pseudo_EXP_mean_dice",
        ] + [f"delta_dice_{lab}" for lab in labels]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in records:
            row = {
                "case_id": r["case_id"],
                "parent_gt_mean_dice": r["parent_gt_mean_dice"],
                "oracle_gt_mean_dice": r["oracle_gt_mean_dice"],
                "delta_mean_dice": r["oracle_minus_parent_mean_dice"],
                "parent_folding_pct": r["parent_folding_pct"],
                "oracle_folding_pct": r["oracle_folding_pct"],
                "pseudo_INSP_mean_dice": r["pseudo_vs_gt"]["INSP"].get("mean_dice"),
                "pseudo_EXP_mean_dice": r["pseudo_vs_gt"]["EXP"].get("mean_dice"),
            }
            for lab in labels:
                row[f"delta_dice_{lab}"] = r["oracle_minus_parent_lobe_dice"].get(f"dice_{lab}")
            w.writerow(row)

    per_lobe = out / "c8a_gt_oracle_gap_per_lobe.csv"
    with per_lobe.open("w", newline="") as f:
        fieldnames = ["case_id", "label", "parent_dice", "oracle_dice", "delta"]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in records:
            for lab in labels:
                k = f"dice_{lab}"
                w.writerow({
                    "case_id": r["case_id"],
                    "label": lab,
                    "parent_dice": r["parent_lobe_dice"].get(k),
                    "oracle_dice": r["oracle_lobe_dice"].get(k),
                    "delta": r["oracle_minus_parent_lobe_dice"].get(k),
                })
