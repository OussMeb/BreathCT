#!/usr/bin/env python3
"""
SGR-FM C8A: validation-GT oracle label registration and gap audit.

This experiment intentionally uses validation ground-truth lobe labels inside the
optimizer. It is an upper-bound / diagnostic run, not a hidden-test-safe method.
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

from utils.sgr_fm_c8a_gt_oracle import (
    load_config,
    discover_cases,
    run_case,
    summarize,
    write_gap_tables,
)


def main() -> int:
    ap = argparse.ArgumentParser(description="Run C8A GT-oracle label registration on validation cases.")
    ap.add_argument("--config", required=True, help="Path to configs/sgr_fm_c8a_gt_oracle.yaml")
    ap.add_argument("--cases", nargs="*", default=None, help="Optional case IDs, e.g. NLST_0006 NLST_0007")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    out_root = Path(cfg["output_root"])
    for sub in ["dvfs", "dvfs_canonical_ras", "case_manifests", "eval", "gap_audit", "traces"]:
        (out_root / sub).mkdir(parents=True, exist_ok=True)

    cases = args.cases or discover_cases(Path(cfg["validation_root"]), cfg)

    if args.dry_run:
        payload = {
            "status": "DRY_RUN",
            "method": "SGR-FM C8A GT-oracle label registration",
            "cases": cases,
            "output_root": str(out_root),
            "parent_dir": cfg["parent_dir"],
            "validation_root": cfg["validation_root"],
            "pseudo_segmentation_root": cfg.get("pseudo_segmentation_root"),
            "warning": "This run uses validation ground-truth lobe labels in the optimizer.",
        }
        print(json.dumps(payload, indent=2))
        return 0

    records = []
    failed = []
    for case_id in cases:
        try:
            rec = run_case(case_id, cfg)
            records.append(rec)
            print(
                f"PASS {case_id} "
                f"parent_dice={rec['parent_gt_mean_dice']:.6f} "
                f"oracle_dice={rec['oracle_gt_mean_dice']:.6f} "
                f"gain={rec['oracle_minus_parent_mean_dice']:+.6f} "
                f"fold={rec['oracle_folding_pct']:.6f}%"
            )
        except Exception as exc:
            failed.append({"case_id": case_id, "error": repr(exc)})
            print(f"FAIL {case_id}: {exc!r}", file=sys.stderr)
            if not cfg.get("continue_on_error", False):
                break

    summary = summarize(cfg, records, failed)
    summary_path = out_root / "c8a_gt_oracle_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2))

    write_gap_tables(cfg, records)

    eval_script = Path(cfg.get("evaluate_script", "evaluate_validation.py"))
    if len(records) == 10 and not failed and eval_script.exists():
        cmd = [
            sys.executable,
            str(eval_script),
            "--raw-data-root",
            str(cfg["raw_data_root"]),
            "--dvf-dir",
            str(out_root / "dvfs"),
            "--output-dir",
            str(out_root / "eval"),
        ]
        subprocess.run(cmd, check=False)

    print(json.dumps(summary, indent=2))
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
