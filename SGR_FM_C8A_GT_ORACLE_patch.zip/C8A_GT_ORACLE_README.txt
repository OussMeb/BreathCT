SGR-FM C8A GT-oracle + gap audit
=================================

Purpose
-------
This is a diagnostic upper-bound experiment. It intentionally uses validation
ground-truth lobe labels inside the optimizer.

It answers:
- If the anatomical target is perfect, can the current registration machinery go much higher?
- How large is the gap between pseudo-label-guided C7B and GT-label-guided oracle registration?
- Which cases/lobes/RML components explain the remaining gap?

This is not hidden-test-safe by itself.

Install
-------
cd "/home/oussama/Desktop/MICCAI FRANCE"
unzip -o SGR_FM_C8A_GT_ORACLE_patch.zip -d .

Compile
-------
python -m py_compile \
  run_sgr_fm_c8a_gt_oracle_validation.py \
  utils/sgr_fm_c8a_gt_oracle.py \
  smoke_sgr_fm_c8a_gt_oracle_synthetic.py

Smoke
-----
python smoke_sgr_fm_c8a_gt_oracle_synthetic.py

Dry run
-------
python run_sgr_fm_c8a_gt_oracle_validation.py \
  --config configs/sgr_fm_c8a_gt_oracle.yaml \
  --dry-run

Hard-case test
--------------
python run_sgr_fm_c8a_gt_oracle_validation.py \
  --config configs/sgr_fm_c8a_gt_oracle.yaml \
  --cases NLST_0006 NLST_0007 NLST_0009

Full validation
---------------
python run_sgr_fm_c8a_gt_oracle_validation.py \
  --config configs/sgr_fm_c8a_gt_oracle.yaml

Upload after full run
---------------------
outputs/sgr_fm/c8a_gt_oracle/c8a_gt_oracle_summary.json
outputs/sgr_fm/c8a_gt_oracle/eval/validation_metrics.json
outputs/sgr_fm/c8a_gt_oracle/gap_audit/c8a_gt_oracle_gap_per_case.csv
outputs/sgr_fm/c8a_gt_oracle/gap_audit/c8a_gt_oracle_gap_per_lobe.csv
outputs/sgr_fm/c8a_gt_oracle/case_manifests/NLST_0006_manifest.json
outputs/sgr_fm/c8a_gt_oracle/case_manifests/NLST_0007_manifest.json
