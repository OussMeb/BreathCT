#!/usr/bin/env python3
import tempfile
from pathlib import Path
import numpy as np
import nibabel as nib

from utils.sgr_fm_c8a_gt_oracle import load_config, run_case, summarize


def save(path: Path, arr):
    path.parent.mkdir(parents=True, exist_ok=True)
    nib.Nifti1Image(arr.astype(np.float32), np.eye(4)).to_filename(str(path))


def main():
    case = "NLST_0006"
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        parent = root / "outputs/sgr_fm/c7b_multi_init_semantic/dvfs"
        val = root / "Learn2Breath_train_val_data/validation/labels"
        pseudo = root / "outputs/sgr_fm/segmentation_phase1_totalsegmentator/lobes"

        shape = (16, 14, 12)
        fixed = np.zeros(shape, np.int16)
        moving = np.zeros(shape, np.int16)
        fixed[6:12, 5:10, 4:9] = 64
        moving[5:11, 5:10, 4:9] = 64
        fixed[2:6, 2:6, 2:6] = 8
        moving[2:6, 2:6, 2:6] = 8

        dvf = np.zeros(shape + (3,), np.float32)
        save(parent / f"{case}_DVF.nii.gz", dvf)
        save(val / f"{case}_INSP_lobe_gt.nii.gz", fixed)
        save(val / f"{case}_EXP_lobe_gt.nii.gz", moving)
        save(pseudo / f"{case}_INSP_lobes.nii.gz", fixed)
        save(pseudo / f"{case}_EXP_lobes.nii.gz", moving)

        cfgp = root / "cfg.yaml"
        cfgp.write_text("\n".join([
            f'output_root: "{root / "outputs/sgr_fm/c8a_gt_oracle"}"',
            f'parent_dir: "{root / "outputs/sgr_fm/c7b_multi_init_semantic"}"',
            f'fallback_parent_dir: "{root / "outputs/sgr_fm/c7a_v2_relaxed_selector"}"',
            f'raw_data_root: "{root / "Learn2Breath_train_val_data"}"',
            f'validation_root: "{root / "Learn2Breath_train_val_data/validation"}"',
            f'pseudo_segmentation_root: "{pseudo}"',
            'device: cpu',
            'labels: [8, 16, 32, 64, 128]',
            'hard_reject_folding_pct: 0.5',
            'soft_folding_start_pct: 0.25',
            'soft_folding_full_pct: 0.3',
            'stages:',
            '  - name: smoke',
            '    reduce_factor: 2',
            '    control_factor: 3',
            '    iterations: 3',
            '    lr: 0.05',
            '    max_residual_vox: 0.5',
        ]))
        cfg = load_config(str(cfgp))
        rec = run_case(case, cfg)
        sm = summarize(cfg, [rec], [])
        assert rec["oracle_gt_mean_dice"] >= 0.0
        assert (Path(cfg["output_root"]) / "dvfs" / f"{case}_DVF.nii.gz").exists()
        print("SGR-FM C8A GT-ORACLE SYNTHETIC SMOKE: PASS")
        print(sm)


if __name__ == "__main__":
    main()
