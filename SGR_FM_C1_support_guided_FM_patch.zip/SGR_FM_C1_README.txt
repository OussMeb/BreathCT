SGR-FM C1 anatomical-support-guided FM ablation
================================================

Purpose
-------
Compare the frozen C0 raw-FM baseline against C1 where the only intended
change is the EXP/INSP registration input exterior:

  C0: raw EXP + raw INSP -> uniGradICON
  C1: support-guided EXP + support-guided INSP -> same uniGradICON settings

Default C1 guidance
-------------------
- predicted support masks from Phase 1
- raw HU values inside support are preserved exactly
- outside support uses a 7.5 mm cosine fade to -1024 HU
- no cropping, resizing, clipping, or HU normalization
- validation GT is evaluation-only

Files
-----
run_sgr_fm_support_ablation.py
utils/sgr_fm_support_guided.py
configs/sgr_fm_c1_support_guided_fm.yaml
main.py  (adds: python main.py support-fm ...)

Recommended sequence
--------------------
1) Overlay patch in project root.
2) Dry-run one case:

   python main.py support-fm \
     --config configs/sgr_fm_c1_support_guided_fm.yaml \
     --case-ids NLST_0001 \
     --dry-run

3) Real one-case smoke test:

   python main.py support-fm \
     --config configs/sgr_fm_c1_support_guided_fm.yaml \
     --case-ids NLST_0001

4) Inspect:

   outputs/sgr_fm/ablation_C1_support_guided_fm/
     c1_summary.json
     logs/NLST_0001.log
     case_manifests/NLST_0001.json

   The exact evaluator is intentionally skipped for partial runs because it
   expects all 10 validation DVFs.
     logs/NLST_0001.log
     case_manifests/NLST_0001.json

5) Full validation run:

   python main.py support-fm \
     --config configs/sgr_fm_c1_support_guided_fm.yaml

Expected final comparison files
-------------------------------
comparison/C0_vs_C1_summary.json
comparison/C0_vs_C1_per_case.csv

Disk policy
-----------
Guided CTs and HDF5 transforms are temporary by default and deleted after
successful DVF conversion. Challenge and canonical-RAS DVFs are retained.

Important
---------
The C0 frozen DVF repositories are not modified. C1 writes to a separate
output namespace and requires the frozen C0 markers/manifest by default.
