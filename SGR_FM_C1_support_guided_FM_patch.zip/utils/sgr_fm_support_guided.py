from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np

from utils.sgr_fm_segmentation import assert_same_grid, load_3d


def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def load_yaml_or_json(path: str | Path) -> dict[str, Any]:
    config_path = Path(path).expanduser()
    if not config_path.exists():
        raise FileNotFoundError(config_path)
    if config_path.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml
        except ImportError as exc:
            raise RuntimeError("PyYAML is required: pip install pyyaml") from exc
        with config_path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
    elif config_path.suffix.lower() == ".json":
        with config_path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    else:
        raise ValueError(f"Unsupported config format: {config_path.suffix}")
    if not isinstance(data, dict):
        raise ValueError(f"Config must be a mapping: {config_path}")
    return data.get("sgr_fm_c1", data)


def recursive_update(base: dict[str, Any], updates: dict[str, Any]) -> dict[str, Any]:
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            recursive_update(base[key], value)
        else:
            base[key] = value
    return base


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "output_dir": "outputs/sgr_fm/ablation_C1_support_guided_fm",
        "split": "validation",
        "case_ids": [],
        "overwrite": False,
        "stop_on_error": True,
        "require_frozen_dvfs": True,
        "frozen_manifest": "outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json",
        "guidance": {
            "mode": "soft",
            "outside_hu": -1024.0,
            "fade_mm": 7.5,
        },
        "unigradicon": {
            "command": "unigradicon-register",
            "fixed_modality": "ct",
            "moving_modality": "ct",
            "io_iterations": "None",
            "io_sim": "lncc2",
            "save_canonical": True,
            "keep_guided_inputs": False,
            "keep_transforms": False,
        },
        "evaluation": {
            "enabled": True,
            "device": "cuda",
            "baseline_metrics_json": "outputs/unigradicon_raw_validation/eval/validation_metrics.json",
        },
    }


def resolve_under_project(project_root: Path, value: str | Path) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = project_root / path
    return path.resolve()


def support_path(segmentation_dir: Path, split: str, case_id: str, phase: str) -> Path:
    return segmentation_dir / "support" / split / f"{case_id}_{phase}_support.nii.gz"


def _cosine_fade(distance_mm: np.ndarray, fade_mm: float) -> np.ndarray:
    alpha = np.zeros(distance_mm.shape, dtype=np.float32)
    inside_band = distance_mm < fade_mm
    if np.any(inside_band):
        x = np.clip(distance_mm[inside_band] / float(fade_mm), 0.0, 1.0)
        alpha[inside_band] = 0.5 * (1.0 + np.cos(np.pi * x))
    return alpha


def make_support_alpha(
    support: np.ndarray,
    spacing: tuple[float, float, float],
    *,
    mode: str,
    fade_mm: float,
) -> np.ndarray:
    mask = np.asarray(support, dtype=bool)
    if mask.ndim != 3:
        raise ValueError(f"Support mask must be 3D, got {mask.shape}")
    if not np.any(mask):
        raise ValueError("Support mask is empty")

    normalized_mode = str(mode).lower().strip()
    if normalized_mode == "hard":
        return mask.astype(np.float32)
    if normalized_mode != "soft":
        raise ValueError(f"Unsupported guidance mode: {mode!r}; expected 'soft' or 'hard'")
    if fade_mm <= 0:
        raise ValueError("fade_mm must be > 0 for soft guidance")

    try:
        from scipy.ndimage import distance_transform_edt
    except ImportError as exc:
        raise RuntimeError("SciPy is required for soft support guidance: pip install scipy") from exc

    # Distance is zero on/inside anatomy and increases only outside support.
    outside_distance_mm = distance_transform_edt(~mask, sampling=spacing).astype(np.float32)
    alpha = _cosine_fade(outside_distance_mm, float(fade_mm))
    alpha[mask] = 1.0
    return alpha


def make_guided_ct(
    ct: np.ndarray,
    support: np.ndarray,
    spacing: tuple[float, float, float],
    *,
    mode: str,
    outside_hu: float,
    fade_mm: float,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    raw = np.asarray(ct, dtype=np.float32)
    if raw.ndim != 3:
        raise ValueError(f"CT must be 3D, got {raw.shape}")
    if not np.isfinite(raw).all():
        raise ValueError("CT contains NaN/Inf")
    mask = np.asarray(support, dtype=bool)
    if mask.shape != raw.shape:
        raise ValueError(f"Support/CT shape mismatch: {mask.shape} vs {raw.shape}")

    alpha = make_support_alpha(mask, spacing, mode=mode, fade_mm=fade_mm)
    guided = alpha * raw + (1.0 - alpha) * np.float32(outside_hu)
    guided = np.asarray(guided, dtype=np.float32)

    outside = ~mask
    transition = (alpha > 0.0) & (alpha < 1.0)
    suppressed = alpha == 0.0
    stats = {
        "mode": str(mode),
        "outside_hu": float(outside_hu),
        "fade_mm": float(fade_mm),
        "voxel_count": int(raw.size),
        "support_voxels": int(mask.sum()),
        "support_fraction": float(mask.mean()),
        "outside_voxels": int(outside.sum()),
        "transition_voxels": int(transition.sum()),
        "transition_fraction": float(transition.mean()),
        "fully_suppressed_voxels": int(suppressed.sum()),
        "fully_suppressed_fraction": float(suppressed.mean()),
        "alpha_min": float(alpha.min()),
        "alpha_max": float(alpha.max()),
        "alpha_mean": float(alpha.mean()),
        "inside_max_abs_change_hu": float(np.max(np.abs(guided[mask] - raw[mask]))),
        "raw_min": float(raw.min()),
        "raw_max": float(raw.max()),
        "guided_min": float(guided.min()),
        "guided_max": float(guided.max()),
    }
    if np.any(outside):
        stats.update({
            "raw_outside_mean": float(raw[outside].mean()),
            "guided_outside_mean": float(guided[outside].mean()),
        })
    return guided, alpha, stats


def save_float_ct_like(data: np.ndarray, reference_path: Path, output_path: Path) -> None:
    reference = nib.load(str(reference_path))
    array = np.asarray(data, dtype=np.float32)
    if tuple(array.shape) != tuple(reference.shape[:3]):
        raise ValueError(f"Guided CT shape {array.shape} != reference {reference.shape[:3]}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        prefix=output_path.name + ".tmp.", suffix=".nii.gz", dir=output_path.parent, delete=False
    ) as handle:
        tmp = Path(handle.name)
    try:
        header = reference.header.copy()
        image = nib.Nifti1Image(array, reference.affine, header=header)
        image.header.set_data_dtype(np.float32)
        image.header.set_slope_inter(1.0, 0.0)
        _, qcode = reference.get_qform(coded=True)
        _, scode = reference.get_sform(coded=True)
        image.set_qform(reference.affine, code=int(qcode or 1))
        image.set_sform(reference.affine, code=int(scode or 1))
        nib.save(image, str(tmp))
        os.replace(tmp, output_path)
    finally:
        tmp.unlink(missing_ok=True)


def prepare_guided_ct(
    raw_ct_path: Path,
    support_mask_path: Path,
    output_path: Path,
    *,
    mode: str,
    outside_hu: float,
    fade_mm: float,
    affine_atol: float = 1e-5,
) -> dict[str, Any]:
    assert_same_grid(support_mask_path, raw_ct_path, affine_atol=affine_atol, name="support_guidance")
    raw_img = nib.load(str(raw_ct_path))
    raw = np.asanyarray(raw_img.dataobj).astype(np.float32)
    support = load_3d(support_mask_path) > 0
    spacing = tuple(float(v) for v in raw_img.header.get_zooms()[:3])
    guided, _, stats = make_guided_ct(
        raw,
        support,
        spacing,
        mode=mode,
        outside_hu=outside_hu,
        fade_mm=fade_mm,
    )
    save_float_ct_like(guided, raw_ct_path, output_path)
    assert_same_grid(output_path, raw_ct_path, affine_atol=affine_atol, name="guided_ct")
    return stats
