#!/usr/bin/env python3
"""SGR-FM C1: anatomical-support-guided uniGradICON ablation.

Only the registration inputs change. The raw CT values inside predicted anatomy
are preserved exactly; exterior voxels are standardized using a hard or soft
support mask. The FM, IO settings, DVF conversion, and evaluator remain the
same as C0.
"""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
import time
import traceback
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.data import discover_validation_cases
from utils.dvf_io import (
    dvf_stats,
    original_dvf_xyzc_to_canonical_ras_cxyz,
    save_canonical_ras_dvf_xyzc,
    save_dvf_xyzc,
)
from utils.sgr_fm_segmentation import (
    assert_safe_output_dir,
    assert_same_grid,
    atomic_write_json,
    check_frozen_foundation,
    write_csv,
)
from utils.sgr_fm_support_guided import (
    default_config,
    load_yaml_or_json,
    prepare_guided_ct,
    recursive_update,
    resolve_under_project,
    sha256_json,
    support_path,
)
from utils.unigradicon_runner import (
    UniGradICONConfig,
    _build_cli_command,
    _check_command,
    _run_command,
    _transform_to_voxel_dvf_xyzc,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="SGR-FM C1 support-guided FM ablation")
    parser.add_argument("--config", default="configs/sgr_fm_c1_support_guided_fm.yaml")
    parser.add_argument("--raw-data-root")
    parser.add_argument("--segmentation-dir")
    parser.add_argument("--output-dir")
    parser.add_argument("--case-ids", nargs="*")
    parser.add_argument("--mode", choices=("soft", "hard"))
    parser.add_argument("--outside-hu", type=float)
    parser.add_argument("--fade-mm", type=float)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--keep-guided-inputs", action="store_true")
    parser.add_argument("--keep-transforms", action="store_true")
    parser.add_argument("--skip-evaluation", action="store_true")
    parser.add_argument("--allow-unfrozen-dvfs", action="store_true")
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> dict[str, Any]:
    config = default_config()
    config_path = Path(args.config).expanduser()
    if not config_path.is_absolute():
        config_path = PROJECT_ROOT / config_path
    recursive_update(config, load_yaml_or_json(config_path))
    if args.raw_data_root:
        config["raw_data_root"] = args.raw_data_root
    if args.segmentation_dir:
        config["segmentation_dir"] = args.segmentation_dir
    if args.output_dir:
        config["output_dir"] = args.output_dir
    if args.case_ids is not None:
        config["case_ids"] = list(args.case_ids)
    if args.mode:
        config["guidance"]["mode"] = args.mode
    if args.outside_hu is not None:
        config["guidance"]["outside_hu"] = float(args.outside_hu)
    if args.fade_mm is not None:
        config["guidance"]["fade_mm"] = float(args.fade_mm)
    if args.overwrite:
        config["overwrite"] = True
    if args.keep_guided_inputs:
        config["unigradicon"]["keep_guided_inputs"] = True
    if args.keep_transforms:
        config["unigradicon"]["keep_transforms"] = True
    if args.skip_evaluation:
        config["evaluation"]["enabled"] = False
    if args.allow_unfrozen_dvfs:
        config["require_frozen_dvfs"] = False
    return config


def validate_dvf(path: Path, fixed_path: Path, affine_atol: float = 1e-5) -> dict[str, Any]:
    assert_same_grid(path, fixed_path, affine_atol=affine_atol, name="C1_DVF")
    data = np.asanyarray(nib.load(str(path)).dataobj)
    if data.ndim != 4 or data.shape[-1] != 3:
        raise ValueError(f"Expected XYZC DVF, got {data.shape}: {path}")
    if not np.isfinite(data).all():
        raise ValueError(f"Non-finite DVF: {path}")
    return {"shape": list(data.shape), "finite": True}



def load_metrics_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def compare_metrics(c0: dict[str, Any], c1: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    c0_rows = {row["case_id"]: row for row in c0.get("case_metrics", [])}
    c1_rows = {row["case_id"]: row for row in c1.get("case_metrics", [])}
    common = sorted(set(c0_rows) & set(c1_rows))
    rows: list[dict[str, Any]] = []
    for case_id in common:
        a = c0_rows[case_id]
        b = c1_rows[case_id]
        rows.append({
            "case_id": case_id,
            "C0_mean_lobe_dice": float(a["mean_lobe_dice"]),
            "C1_mean_lobe_dice": float(b["mean_lobe_dice"]),
            "delta_mean_lobe_dice": float(b["mean_lobe_dice"] - a["mean_lobe_dice"]),
            "C0_folding_percentage": float(a["folding_percentage"]),
            "C1_folding_percentage": float(b["folding_percentage"]),
            "delta_folding_percentage": float(b["folding_percentage"] - a["folding_percentage"]),
        })
    deltas = np.asarray([row["delta_mean_lobe_dice"] for row in rows], dtype=np.float64)
    fold_deltas = np.asarray([row["delta_folding_percentage"] for row in rows], dtype=np.float64)
    summary = {
        "common_case_count": len(rows),
        "C0_mean_lobe_dice": float(c0["mean_lobe_dice"]),
        "C1_mean_lobe_dice": float(c1["mean_lobe_dice"]),
        "delta_mean_lobe_dice": float(c1["mean_lobe_dice"] - c0["mean_lobe_dice"]),
        "C0_mean_folding_percentage": float(c0["mean_folding_percentage"]),
        "C1_mean_folding_percentage": float(c1["mean_folding_percentage"]),
        "delta_mean_folding_percentage": float(c1["mean_folding_percentage"] - c0["mean_folding_percentage"]),
        "improved_cases": int(np.sum(deltas > 0)) if len(deltas) else 0,
        "unchanged_cases": int(np.sum(np.isclose(deltas, 0.0, atol=1e-12))) if len(deltas) else 0,
        "worsened_cases": int(np.sum(deltas < 0)) if len(deltas) else 0,
        "mean_paired_dice_delta": float(deltas.mean()) if len(deltas) else None,
        "min_paired_dice_delta": float(deltas.min()) if len(deltas) else None,
        "max_paired_dice_delta": float(deltas.max()) if len(deltas) else None,
        "mean_paired_folding_delta": float(fold_deltas.mean()) if len(fold_deltas) else None,
    }
    return summary, rows


def main() -> int:
    args = parse_args()
    config = build_config(args)

    raw_root = resolve_under_project(PROJECT_ROOT, config["raw_data_root"])
    segmentation_dir = resolve_under_project(PROJECT_ROOT, config["segmentation_dir"])
    output_dir = resolve_under_project(PROJECT_ROOT, config["output_dir"])
    config["raw_data_root"] = str(raw_root)
    config["segmentation_dir"] = str(segmentation_dir)
    config["output_dir"] = str(output_dir)

    assert_safe_output_dir(output_dir, PROJECT_ROOT)
    foundation = check_frozen_foundation(
        PROJECT_ROOT,
        config.get("frozen_manifest", "outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json"),
        require=bool(config.get("require_frozen_dvfs", True)),
    )
    executable = _check_command(str(config["unigradicon"].get("command", "unigradicon-register")))

    if str(config.get("split", "validation")) != "validation":
        raise ValueError("C1 first ablation is intentionally validation-only")
    cases = discover_validation_cases(raw_root)
    requested = set(str(v) for v in config.get("case_ids", []))
    if requested:
        cases = [case for case in cases if case.case_id in requested]
        missing = sorted(requested - {case.case_id for case in cases})
        if missing:
            raise FileNotFoundError(f"Requested cases not found: {missing}")
    if not cases:
        raise RuntimeError("No validation cases discovered")

    guidance = config["guidance"]
    ug = config["unigradicon"]
    output_dir.mkdir(parents=True, exist_ok=True)
    for sub in ("dvfs", "dvfs_canonical_ras", "logs", "case_manifests", "eval", "comparison"):
        (output_dir / sub).mkdir(parents=True, exist_ok=True)
    if bool(ug.get("keep_transforms", False)):
        (output_dir / "transforms").mkdir(parents=True, exist_ok=True)
    if bool(ug.get("keep_guided_inputs", False)):
        (output_dir / "guided_inputs").mkdir(parents=True, exist_ok=True)

    config_fingerprint = sha256_json({
        "guidance": guidance,
        "unigradicon": {
            "fixed_modality": ug.get("fixed_modality", "ct"),
            "moving_modality": ug.get("moving_modality", "ct"),
            "io_iterations": ug.get("io_iterations", "None"),
            "io_sim": ug.get("io_sim", "lncc2"),
        },
    })
    previous_run_config = output_dir / "run_config_resolved.json"
    if previous_run_config.exists() and not bool(config.get("overwrite", False)):
        previous = json.loads(previous_run_config.read_text(encoding="utf-8"))
        previous_fingerprint = previous.get("config_fingerprint_sha256")
        if previous_fingerprint and previous_fingerprint != config_fingerprint:
            raise RuntimeError(
                "C1 output directory contains results from a different guidance/FM configuration. "
                "Use a new --output-dir or rerun with --overwrite. "
                f"existing={previous_fingerprint} current={config_fingerprint}"
            )
    run_meta = {
        "schema_version": 1,
        "experiment": "SGR-FM C1 anatomical-support-guided FM",
        "project_root": str(PROJECT_ROOT),
        "config": config,
        "config_fingerprint_sha256": config_fingerprint,
        "frozen_foundation": foundation,
        "case_count": len(cases),
        "dry_run": bool(args.dry_run),
        "note": "Raw HU values inside predicted support are preserved; validation GT is evaluation-only.",
    }
    atomic_write_json(output_dir / "run_config_resolved.json", run_meta)

    print(json.dumps({
        "experiment": run_meta["experiment"],
        "case_count": len(cases),
        "guidance": guidance,
        "output_dir": str(output_dir),
        "frozen_foundation_ok": foundation.get("ok"),
        "dry_run": bool(args.dry_run),
    }, indent=2))

    rows: list[dict[str, Any]] = []
    dvf_paths: list[Path] = []
    overwrite = bool(config.get("overwrite", False))

    for index, case in enumerate(cases, start=1):
        started = time.time()
        case_id = case.case_id
        print(f"[{index:02d}/{len(cases):02d}] {case_id}", flush=True)
        exp_support = support_path(segmentation_dir, "validation", case_id, "EXP")
        insp_support = support_path(segmentation_dir, "validation", case_id, "INSP")
        challenge_dvf = output_dir / "dvfs" / f"{case_id}_DVF.nii.gz"
        canonical_dvf = output_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz"
        log_path = output_dir / "logs" / f"{case_id}.log"
        record: dict[str, Any] = {
            "case_id": case_id,
            "status": "started",
            "raw_EXP": str(case.exp_ct),
            "raw_INSP": str(case.insp_ct),
            "support_EXP": str(exp_support),
            "support_INSP": str(insp_support),
            "challenge_dvf": str(challenge_dvf),
            "canonical_dvf": str(canonical_dvf),
        }
        try:
            if not exp_support.exists() or not insp_support.exists():
                raise FileNotFoundError(f"Missing support mask(s): EXP={exp_support.exists()} INSP={insp_support.exists()}")
            assert_same_grid(exp_support, case.exp_ct, affine_atol=1e-5, name="EXP_support")
            assert_same_grid(insp_support, case.insp_ct, affine_atol=1e-5, name="INSP_support")

            if args.dry_run:
                record["status"] = "dry_run"
                record["elapsed_sec"] = 0.0
                rows.append(record)
                continue

            complete_existing = challenge_dvf.exists() and (
                canonical_dvf.exists() or not bool(ug.get("save_canonical", True))
            )
            if complete_existing and not overwrite:
                record["status"] = "reused"
                record["dvf_validation"] = validate_dvf(challenge_dvf, case.insp_ct)
                dvf_paths.append(challenge_dvf)
                record["elapsed_sec"] = float(time.time() - started)
                rows.append(record)
                continue

            if overwrite:
                challenge_dvf.unlink(missing_ok=True)
                canonical_dvf.unlink(missing_ok=True)

            persistent_inputs = bool(ug.get("keep_guided_inputs", False))
            if persistent_inputs:
                guided_root = output_dir / "guided_inputs" / case_id
                guided_root.mkdir(parents=True, exist_ok=True)
                cleanup_ctx = None
            else:
                cleanup_ctx = tempfile.TemporaryDirectory(prefix=f"sgrfm_c1_{case_id}_", dir=output_dir)
                guided_root = Path(cleanup_ctx.name)

            try:
                guided_exp = guided_root / f"{case_id}_EXP_support_guided.nii.gz"
                guided_insp = guided_root / f"{case_id}_INSP_support_guided.nii.gz"
                record["guidance_EXP"] = prepare_guided_ct(
                    case.exp_ct, exp_support, guided_exp,
                    mode=str(guidance.get("mode", "soft")),
                    outside_hu=float(guidance.get("outside_hu", -1024.0)),
                    fade_mm=float(guidance.get("fade_mm", 7.5)),
                )
                record["guidance_INSP"] = prepare_guided_ct(
                    case.insp_ct, insp_support, guided_insp,
                    mode=str(guidance.get("mode", "soft")),
                    outside_hu=float(guidance.get("outside_hu", -1024.0)),
                    fade_mm=float(guidance.get("fade_mm", 7.5)),
                )
                if record["guidance_EXP"]["inside_max_abs_change_hu"] != 0.0 or record["guidance_INSP"]["inside_max_abs_change_hu"] != 0.0:
                    raise RuntimeError("Guidance changed voxels inside predicted anatomy")

                if bool(ug.get("keep_transforms", False)):
                    transform_path = output_dir / "transforms" / f"{case_id}_unigradicon.hdf5"
                else:
                    transform_path = guided_root / f"{case_id}_unigradicon.hdf5"

                ug_config = UniGradICONConfig(
                    raw_data_root=str(raw_root),
                    output_dir=str(output_dir),
                    split="validation",
                    command=str(ug.get("command", "unigradicon-register")),
                    fixed_modality=str(ug.get("fixed_modality", "ct")),
                    moving_modality=str(ug.get("moving_modality", "ct")),
                    io_iterations=str(ug.get("io_iterations", "None")),
                    io_sim=str(ug.get("io_sim", "lncc2")),
                    make_zip=False,
                    evaluate=False,
                    overwrite=overwrite,
                    save_warped=False,
                    save_canonical=bool(ug.get("save_canonical", True)),
                    stop_on_error=True,
                    case_ids=[case_id],
                )
                command = _build_cli_command(
                    ug_config,
                    fixed_path=guided_insp,
                    moving_path=guided_exp,
                    transform_out=transform_path,
                    warped_out=None,
                )
                record["command"] = command
                exit_code = _run_command(command, log_path)
                record["exit_code"] = int(exit_code)
                if exit_code != 0:
                    raise RuntimeError(f"uniGradICON failed for {case_id}; see {log_path}")
                if not transform_path.exists():
                    raise FileNotFoundError(f"Missing uniGradICON transform: {transform_path}")

                # Convert on the original INSP grid. Guided INSP has the same geometry,
                # but the original reference guarantees challenge-header fidelity.
                dvf_xyzc = _transform_to_voxel_dvf_xyzc(transform_path, case.insp_ct)
                save_dvf_xyzc(dvf_xyzc, case.insp_ct, challenge_dvf)
                record["dvf_validation"] = validate_dvf(challenge_dvf, case.insp_ct)
                record["dvf_stats_voxel"] = dvf_stats(dvf_xyzc)
                if bool(ug.get("save_canonical", True)):
                    dvf_cxyz = original_dvf_xyzc_to_canonical_ras_cxyz(dvf_xyzc, case.insp_ct)
                    save_canonical_ras_dvf_xyzc(dvf_cxyz, case.insp_ct, canonical_dvf)
                dvf_paths.append(challenge_dvf)
                record["status"] = "ok"
            finally:
                if cleanup_ctx is not None:
                    cleanup_ctx.cleanup()

        except Exception as exc:
            record["status"] = "failed"
            record["error_type"] = type(exc).__name__
            record["error"] = str(exc)
            record["traceback"] = traceback.format_exc()
        record["elapsed_sec"] = float(time.time() - started)
        rows.append(record)
        write_csv(output_dir / "case_manifest.csv", rows)
        atomic_write_json(output_dir / "case_manifest.json", rows)
        atomic_write_json(output_dir / "case_manifests" / f"{case_id}.json", record)
        if record["status"] == "failed" and bool(config.get("stop_on_error", True)):
            break

    if args.dry_run:
        summary = {
            "status": "DRY_RUN",
            "case_count": len(rows),
            "output_dir": str(output_dir),
            "config_fingerprint_sha256": config_fingerprint,
        }
        atomic_write_json(output_dir / "c1_summary.json", summary)
        print(json.dumps(summary, indent=2))
        return 0

    failed = [row for row in rows if row.get("status") == "failed"]
    summary: dict[str, Any] = {
        "schema_version": 1,
        "experiment": "SGR-FM C1 anatomical-support-guided FM",
        "status": "PASS" if not failed and len(dvf_paths) == len(cases) else "FAIL",
        "case_count": len(cases),
        "dvf_count": len(dvf_paths),
        "failed_count": len(failed),
        "output_dir": str(output_dir),
        "config_fingerprint_sha256": config_fingerprint,
        "guidance": guidance,
        "frozen_foundation_ok": foundation.get("ok"),
    }

    evaluation = config.get("evaluation", {})
    full_validation_run = len(cases) == 10 and not requested
    if summary["status"] == "PASS" and bool(evaluation.get("enabled", True)) and full_validation_run:
        eval_dir = output_dir / "eval"
        eval_script = PROJECT_ROOT / "evaluate_validation.py"
        eval_cmd = [
            sys.executable,
            str(eval_script),
            "--raw-data-root", str(raw_root),
            "--dvf-dir", str(output_dir / "dvfs"),
            "--output-dir", str(eval_dir),
            "--device", str(evaluation.get("device", "cuda")),
        ]
        eval_log = output_dir / "logs" / "evaluate_validation.log"
        eval_code = _run_command(eval_cmd, eval_log)
        summary["evaluation"] = {
            "exit_code": int(eval_code),
            "output_dir": str(eval_dir),
            "log_path": str(eval_log),
        }
        c1_metrics_path = eval_dir / "validation_metrics.json"
        if c1_metrics_path.exists():
            summary["evaluation"]["metrics_json"] = str(c1_metrics_path)
            c1 = load_metrics_json(c1_metrics_path)
            baseline_path = resolve_under_project(PROJECT_ROOT, evaluation.get(
                "baseline_metrics_json", "outputs/unigradicon_raw_validation/eval/validation_metrics.json"
            ))
            summary["evaluation"]["baseline_metrics_json"] = str(baseline_path)
            c0 = load_metrics_json(baseline_path)
            if c0 is not None and c1 is not None:
                comparison_summary, comparison_rows = compare_metrics(c0, c1)
                atomic_write_json(output_dir / "comparison" / "C0_vs_C1_summary.json", comparison_summary)
                write_csv(output_dir / "comparison" / "C0_vs_C1_per_case.csv", comparison_rows)
                summary["comparison"] = comparison_summary
            else:
                summary["comparison_warning"] = f"C0 metrics not found at {baseline_path}"
        if eval_code != 0:
            summary["status"] = "FAIL"
    elif summary["status"] == "PASS" and bool(evaluation.get("enabled", True)) and not full_validation_run:
        summary["evaluation"] = {
            "status": "skipped_partial_run",
            "reason": "Exact project evaluator requires all 10 validation DVFs; run all cases for C0-vs-C1 comparison.",
        }

    atomic_write_json(output_dir / "c1_summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if summary["status"] == "PASS" else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
