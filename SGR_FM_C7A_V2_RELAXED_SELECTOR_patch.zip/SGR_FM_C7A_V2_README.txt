SGR-FM C7A-v2: relaxed semantic-Adam with proxy case selector
=================================================================

Purpose
-------
C7A-v2 continues the C7A label-first semantic registration branch. It changes
C7A in two important ways:

1. Folding is relaxed to a normal/controlled range rather than forced near zero.
2. A non-GT case-level selector keeps the exact C6 parent for cases whose
   internal predicted-anatomy/CT proxies suggest easy/high-risk over-warping.

No validation GT labels are used by the optimizer or selector. Evaluation is run
only after DVFs are exported.

Install
-------
cd "/home/oussama/Desktop/MICCAI FRANCE"
unzip -o SGR_FM_C7A_V2_RELAXED_SELECTOR_patch.zip -d .

Compile
-------
python -m py_compile \
  run_sgr_fm_c7a_v2_relaxed_selector_validation.py \
  utils/sgr_fm_c7a_v2_relaxed_selector.py \
  smoke_sgr_fm_c7a_v2_relaxed_selector_synthetic.py

Smoke test
----------
python smoke_sgr_fm_c7a_v2_relaxed_selector_synthetic.py

Dry run
-------
python run_sgr_fm_c7a_v2_relaxed_selector_validation.py \
  --config configs/sgr_fm_c7a_v2_relaxed_selector.yaml \
  --dry-run

Hard-case test
--------------
python run_sgr_fm_c7a_v2_relaxed_selector_validation.py \
  --config configs/sgr_fm_c7a_v2_relaxed_selector.yaml \
  --cases NLST_0006 NLST_0007 NLST_0009

Full validation
---------------
python run_sgr_fm_c7a_v2_relaxed_selector_validation.py \
  --config configs/sgr_fm_c7a_v2_relaxed_selector.yaml

Outputs
-------
outputs/sgr_fm/c7a_v2_relaxed_selector/
  dvfs/
  dvfs_canonical_ras/
  case_manifests/
  traces/
  eval/validation_metrics.json
  comparison/PARENT_vs_C7A_V2_summary.json
  comparison/PARENT_vs_C7A_V2_per_case.csv
  c7a_v2_relaxed_selector_summary.json

After run, upload these files:
  outputs/sgr_fm/c7a_v2_relaxed_selector/c7a_v2_relaxed_selector_summary.json
  outputs/sgr_fm/c7a_v2_relaxed_selector/eval/validation_metrics.json
  outputs/sgr_fm/c7a_v2_relaxed_selector/comparison/PARENT_vs_C7A_V2_summary.json
  outputs/sgr_fm/c7a_v2_relaxed_selector/comparison/PARENT_vs_C7A_V2_per_case.csv

Expected behavior
-----------------
Compared with C7A, C7A-v2 should be more aggressive inside accepted hard cases,
but it should copy the exact C6 parent for internally easy/high-risk cases. This
is designed to keep the large gains seen in NLST_0006/NLST_0007 while reducing
damage to already-good cases.
