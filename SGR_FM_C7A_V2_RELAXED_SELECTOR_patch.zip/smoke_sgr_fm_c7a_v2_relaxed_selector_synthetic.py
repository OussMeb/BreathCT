#!/usr/bin/env python3
from __future__ import annotations
import tempfile
from pathlib import Path
import numpy as np
import nibabel as nib

from utils.sgr_fm_c7a_v2_relaxed_selector import (
    build_feature_maps,
    optimize_stage,
    proxy_metrics,
    compose_pull,
    jacobian_folding_pct_np,
    export_canonical_pull_dvf_to_original_grid,
    as_canonical_float,
    decide_case_accept_proxy,
)


def make_blob(shape, center, radius, label):
    x, y, z = np.meshgrid(np.arange(shape[0]), np.arange(shape[1]), np.arange(shape[2]), indexing="ij")
    d = ((x-center[0])**2 + (y-center[1])**2 + (z-center[2])**2) ** 0.5
    out = np.zeros(shape, dtype=np.int16)
    out[d <= radius] = label
    return out


def test_compose_identity():
    p = np.zeros((12,10,8,3), dtype=np.float32)
    r = np.zeros_like(p)
    r[...,0] = 0.25
    c = compose_pull(p, r)
    assert np.allclose(c, r, atol=1e-5)


def test_topology_identity():
    d = np.zeros((10,9,8,3), dtype=np.float32)
    st = jacobian_folding_pct_np(d)
    assert st["folding_pct"] == 0.0
    assert abs(st["min_det"] - 1.0) < 1e-6


def test_stage_loss_improves():
    shape = (24,22,20)
    fixed_l = make_blob(shape, (12,11,10), 5, 64)
    moving_l = make_blob(shape, (10,11,10), 5, 64)
    fixed_l += make_blob(shape, (7,7,7), 3, 8)
    moving_l += make_blob(shape, (5,7,7), 3, 8)
    fixed_ct = fixed_l.astype(np.float32) / 128.0
    moving_ct = moving_l.astype(np.float32) / 128.0
    spacing = (1.0, 1.0, 1.0)
    fc = build_feature_maps(fixed_ct, fixed_l, None, spacing, {})
    mc = build_feature_maps(moving_ct, moving_l, None, spacing, {})
    parent = np.zeros(shape + (3,), dtype=np.float32)
    before = proxy_metrics(fc, mc, parent, device="cpu")
    opt = optimize_stage(fc, mc, parent, {
        "control_factor": 4,
        "iterations": 8,
        "lr": 0.04,
        "max_residual_vox": 1.5,
        "weights": {"ct_lncc":0.05,"lobe_dice":1.0,"sdf":0.3,"support":0.1,"fissure":0.1,"bend":0.01,"smooth":0.01,"mag":0.001},
    }, device="cpu")
    cand = parent + opt["residual"]
    after = proxy_metrics(fc, mc, cand, device="cpu")
    assert np.isfinite(opt["best_loss"])
    assert after["lobe_dice_loss"] <= before["lobe_dice_loss"] + 0.05


def test_selector_accept_reject():
    cfg = {"case_selector": {"enabled": True}}
    hard_records = [{
        "decision": "apply",
        "base_proxy": {"lobe_dice_loss": 0.020, "support_dice_loss": 0.004, "ct_lncc_loss": 0.02},
        "selected": {"score": 0.008, "scale": 0.75},
    }]
    easy_records = [{
        "decision": "apply",
        "base_proxy": {"lobe_dice_loss": 0.013, "support_dice_loss": 0.030, "ct_lncc_loss": 0.12},
        "selected": {"score": 0.012, "scale": 1.0},
    }]
    top = {"folding_pct": 0.03, "min_det": -0.2}
    assert decide_case_accept_proxy(hard_records, top, cfg)["accept"] is True
    assert decide_case_accept_proxy(easy_records, top, cfg)["accept"] is False


def test_export_orientation_lps_like():
    shape = (8,7,6)
    aff_orig = np.array([[-1,0,0,7],[0,-1,0,6],[0,0,1,0],[0,0,0,1]], dtype=float)
    img_f = nib.Nifti1Image(np.zeros(shape, dtype=np.float32), aff_orig)
    img_m = nib.Nifti1Image(np.zeros(shape, dtype=np.float32), aff_orig)
    _, f_can = as_canonical_float(img_f)
    _, m_can = as_canonical_float(img_m)
    dvf_can = np.zeros(shape + (3,), dtype=np.float32)
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "dvf.nii.gz"
        export_canonical_pull_dvf_to_original_grid(dvf_can, img_f, f_can, img_m, m_can, out, slab_z=3)
        arr = np.asarray(nib.load(str(out)).dataobj)
        assert arr.shape == shape + (3,)
        assert np.max(np.abs(arr)) < 1e-5


def main():
    test_compose_identity()
    test_topology_identity()
    test_stage_loss_improves()
    test_selector_accept_reject()
    test_export_orientation_lps_like()
    print("SGR-FM C7A-v2 RELAXED SELECTOR SYNTHETIC SMOKE: PASS")
    print("  compose_pull_identity=PASS")
    print("  topology_identity=PASS")
    print("  optimization_forward_backward=PASS")
    print("  proxy_case_selector=PASS")
    print("  orientation_export_zero_field=PASS")


if __name__ == "__main__":
    main()
