#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
from utils.sgr_fm_c7a_v2_relaxed_selector import load_yaml, run_validation, assert_no_gt_leakage_source_scan, save_json


def main():
    ap = argparse.ArgumentParser(description="Run SGR-FM C7A-v2 relaxed semantic-Adam with proxy case selector")
    ap.add_argument("--config", default="configs/sgr_fm_c7a_v2_relaxed_selector.yaml")
    ap.add_argument("--cases", nargs="*", default=None, help="Optional case IDs, e.g. NLST_0006 NLST_0007")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--skip-gt-leakage-scan", action="store_true")
    args = ap.parse_args()
    cfg = load_yaml(args.config)
    if not args.skip_gt_leakage_scan:
        bad = []
        bad += assert_no_gt_leakage_source_scan(Path(__file__))
        bad += assert_no_gt_leakage_source_scan(Path(__file__).parent / "utils" / "sgr_fm_c7a_v2_relaxed_selector.py")
        if bad:
            raise RuntimeError("Potential GT leakage strings found in source: " + ", ".join(bad))
    summary = run_validation(cfg, cases=args.cases, dry_run=args.dry_run)
    save_json(summary, Path(cfg["output_dir"]) / "last_run_summary.json")
    print(summary.get("status", "OK"))
    print(Path(cfg["output_dir"]) / "c7a_v2_relaxed_selector_summary.json")


if __name__ == "__main__":
    main()
