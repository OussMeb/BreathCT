#!/usr/bin/env python3
"""Core helpers for SGR-FM C5a FireANTs residual refinement.

C5a starts from the frozen C4.1-HAST-PCF pull DVF. The raw EXP CT is first
warped once with C4.1 into the fixed INSP grid. FireANTs then estimates a
*small residual pull transform* between this near-aligned image and INSP.
The residual is composed exactly with C4.1; DVFs are never added.

Optimization inputs are inference-time only:
  * raw EXP/INSP CT,
  * predicted support masks,
  * predicted five-lobe masks (selector/safety only),
  * frozen C4.1 initializer.

Validation ground truth is never loaded by this module.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import torch

from utils.refine_spatial import downsample_dvf_5d, resize_volume_5d, warp_volume
from utils.sgr_fm_c3 import (
    assert_same_canonical_grid,
    compose_pull,
    dvf_xyzc_to_tensor,
    labels_to_one_hot,
    load_canonical_dvf,
    load_canonical_label,
    load_canonical_support,
    soft_dice_per_lobe,
    support_to_tensor,
)
from utils.sgr_fm_c4_hast import load_canonical_ct, structural_gradient_loss
from utils.sgr_fm_training_assets import load_yaml_or_json, recursive_update
from utils.sgr_fm_tto import binary_soft_dice, masked_local_ncc_loss, topology_stats, volume_to_tensor


def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "initializer_dir": "outputs/sgr_fm/c4_1_hast_pcf",
        "output_dir": "outputs/sgr_fm/c5a_fireants_residual",
        "case_ids": [],
        "overwrite": False,
        "stop_on_error": True,
        "device": "cuda",
        "require_initializer_fingerprint": True,
        "accepted_initializer_method_fingerprint": "0b7e49fee00fd2ef84db9abf3121b82d971ea7b9b01a5b3b28b5005b6cd636b2",
        "ct": {
            "clip_min_hu": -1000.0,
            "clip_max_hu": 400.0,
            "lncc_window": 9,
            "lncc_min_valid_fraction": 0.25,
            "gradient_min_magnitude": 0.03,
        },
        "fireants": {
            "required_version": "1.5.0",
            "scales": [4, 2, 1],
            "iterations": [60, 40, 20],
            "loss_type": "masked_cc",
            "cc_kernel_size": 5,
            "deformation_type": "compositive",
            "optimizer": "Adam",
            "optimizer_lr": 0.15,
            "smooth_warp_sigma": 0.70,
            "smooth_grad_sigma": 1.50,
            "reduction": "mean",
            "tolerance": 1.0e-7,
            "max_tolerance_iters": 1000,
            "blur": True,
            "freeform": False,
            "progress_bar": False,
            "mask_threshold": 0.05,
            "require_identity_affine_atol": 1.0e-5,
        },
        "selector": {
            "proxy_reduce_factor": 2,
            "selection_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            "min_composite_score_gain": 1.0e-4,
            "max_direct_proxy_lobe_drop": 2.5e-4,
            "max_lncc_loss_increase": 2.5e-4,
            "max_support_dice_drop": 1.0e-3,
            "max_residual_p99_voxels": 2.5,
            "max_residual_max_voxels": 8.0,
            "topology_guard_mode": "relative_to_initializer",
            "max_folding_increase_pct": 5.0e-5,
            "max_absolute_folding_pct": 1.0e-3,
            "score_lncc_gain": 1.00,
            "score_structural_gain": 0.55,
            "score_direct_lobe_gain": 0.35,
            "score_support_gain": 0.05,
        },
        "evaluation": {
            "enabled": True,
            "device": "cuda",
            "initializer_metrics_json": "outputs/sgr_fm/c4_1_hast_pcf/eval/validation_metrics.json",
        },
    }


def build_config(config_path: str | Path | None, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = default_config()
    if config_path is not None:
        recursive_update(cfg, load_yaml_or_json(config_path, root_key="sgr_fm_c5a_fireants"))
    if overrides:
        recursive_update(cfg, overrides)
    return cfg


def validation_asset_paths(segmentation_dir: Path, initializer_dir: Path, case_id: str) -> dict[str, Path]:
    return {
        "exp_support": segmentation_dir / "support" / "validation" / f"{case_id}_EXP_support.nii.gz",
        "insp_support": segmentation_dir / "support" / "validation" / f"{case_id}_INSP_support.nii.gz",
        "exp_lobes": segmentation_dir / "lobes" / "validation" / f"{case_id}_EXP_lobes.nii.gz",
        "insp_lobes": segmentation_dir / "lobes" / "validation" / f"{case_id}_INSP_lobes.nii.gz",
        "initializer_canonical": initializer_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz",
        "initializer_original": initializer_dir / "dvfs" / f"{case_id}_DVF.nii.gz",
    }


def check_fireants_backend(required_version: str) -> dict[str, str]:
    """Import and pin-check the external FireANTs backend lazily."""
    try:
        version = importlib.metadata.version("fireants")
    except importlib.metadata.PackageNotFoundError as exc:
        raise RuntimeError(
            "FireANTs is not installed in this Python environment. "
            f"Install the tested backend with: {Path(__import__('sys').executable).name} -m pip install 'fireants=={required_version}'"
        ) from exc

    if str(version) != str(required_version):
        raise RuntimeError(
            "Untested FireANTs version; refusing silent API drift. "
            f"required={required_version} actual={version}"
        )

    try:
        import SimpleITK as sitk  # noqa: F401
        from fireants.io import BatchedImages, Image  # noqa: F401
        from fireants.io.imagemask import apply_mask_to_image  # noqa: F401
        from fireants.registration.greedy import GreedyRegistration
    except Exception as exc:
        raise RuntimeError(f"FireANTs backend import failed: {type(exc).__name__}: {exc}") from exc

    if not hasattr(GreedyRegistration, "get_warp_parameters"):
        raise RuntimeError("FireANTs GreedyRegistration lacks get_warp_parameters")

    return {"fireants_version": str(version), "backend": "GreedyRegistration"}


def load_case_tensors(
    *,
    exp_ct_path: Path,
    insp_ct_path: Path,
    assets: dict[str, Path],
    device: torch.device,
    ct_cfg: dict[str, Any],
    affine_atol: float = 1e-5,
) -> dict[str, Any]:
    for name, path in assets.items():
        if not path.exists():
            raise FileNotFoundError(f"Missing {name}: {path}")

    moving_ct_np, moving_ct_img = load_canonical_ct(
        exp_ct_path,
        clip_min_hu=float(ct_cfg.get("clip_min_hu", -1000.0)),
        clip_max_hu=float(ct_cfg.get("clip_max_hu", 400.0)),
    )
    fixed_ct_np, fixed_ct_img = load_canonical_ct(
        insp_ct_path,
        clip_min_hu=float(ct_cfg.get("clip_min_hu", -1000.0)),
        clip_max_hu=float(ct_cfg.get("clip_max_hu", 400.0)),
    )
    assert_same_canonical_grid(moving_ct_img, fixed_ct_img, name="EXP/INSP CT", affine_atol=affine_atol)

    moving_labels, _ = load_canonical_label(assets["exp_lobes"], exp_ct_path, affine_atol=affine_atol)
    fixed_labels, _ = load_canonical_label(assets["insp_lobes"], insp_ct_path, affine_atol=affine_atol)
    moving_support_np, _ = load_canonical_support(assets["exp_support"], exp_ct_path, affine_atol=affine_atol)
    fixed_support_np, _ = load_canonical_support(assets["insp_support"], insp_ct_path, affine_atol=affine_atol)
    init_np, init_img = load_canonical_dvf(assets["initializer_canonical"], insp_ct_path, affine_atol=affine_atol)

    return {
        "moving_ct": volume_to_tensor(moving_ct_np, device=device),
        "fixed_ct": volume_to_tensor(fixed_ct_np, device=device),
        "moving_lobes": labels_to_one_hot(moving_labels, device=device),
        "fixed_lobes": labels_to_one_hot(fixed_labels, device=device),
        "moving_support": support_to_tensor(moving_support_np, device=device),
        "fixed_support": support_to_tensor(fixed_support_np, device=device),
        "init_dvf": dvf_xyzc_to_tensor(init_np, device=device),
        "canonical_reference": init_img,
        "full_shape": tuple(int(v) for v in init_np.shape[:3]),
    }


def make_lowres_state(full: dict[str, Any], *, reduce_factor: int) -> dict[str, torch.Tensor]:
    factor = int(reduce_factor)
    if factor < 1:
        raise ValueError("proxy_reduce_factor must be >= 1")

    def rs(x: torch.Tensor, mode: str) -> torch.Tensor:
        return x if factor == 1 else resize_volume_5d(x, factor, mode=mode)

    return {
        "moving_ct": rs(full["moving_ct"], "trilinear"),
        "fixed_ct": rs(full["fixed_ct"], "trilinear"),
        "moving_lobes": rs(full["moving_lobes"], "nearest"),
        "fixed_lobes": rs(full["fixed_lobes"], "nearest"),
        "moving_support": rs(full["moving_support"], "nearest"),
        "fixed_support": rs(full["fixed_support"], "nearest"),
        "init_dvf": full["init_dvf"] if factor == 1 else downsample_dvf_5d(full["init_dvf"], factor),
    }


def compute_proxy_metrics(*, state: dict[str, torch.Tensor], dvf: torch.Tensor, ct_cfg: dict[str, Any]) -> dict[str, float]:
    with torch.no_grad():
        warped_ct = warp_volume(state["moving_ct"], dvf, mode="bilinear")
        warped_lobes = warp_volume(state["moving_lobes"], dvf, mode="bilinear")
        warped_support = warp_volume(state["moving_support"], dvf, mode="bilinear")
        direct_dice = soft_dice_per_lobe(warped_lobes, state["fixed_lobes"]).mean()
        support = binary_soft_dice(warped_support, state["fixed_support"])
        lncc = masked_local_ncc_loss(
            state["fixed_ct"], warped_ct, state["fixed_support"],
            window=int(ct_cfg.get("lncc_window", 9)),
            min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
        )
        structural = structural_gradient_loss(
            state["fixed_ct"], warped_ct, state["fixed_support"],
            min_magnitude=float(ct_cfg.get("gradient_min_magnitude", 0.03)),
        )
    return {
        "direct_proxy_lobe_dice": float(direct_dice.item()),
        "proxy_support_dice": float(support.item()),
        "lncc_loss": float(lncc.item()),
        "structural_gradient_loss": float(structural.item()),
    }


def _tensor_scalar_xyz(tensor: torch.Tensor) -> np.ndarray:
    if tensor.ndim != 5 or tensor.shape[0] != 1 or tensor.shape[1] != 1:
        raise ValueError(f"Expected [1,1,X,Y,Z], got {tuple(tensor.shape)}")
    return tensor.detach().float().cpu().numpy()[0, 0].astype(np.float32, copy=False)


def normalized_fireants_grid_to_voxel_pull(grid: torch.Tensor | np.ndarray, xyz_shape: tuple[int, int, int]) -> np.ndarray:
    """Convert FireANTs [1,Z,Y,X,3] normalized pull displacement to [X,Y,Z,3] voxels.

    FireANTs/SimpleITK stores image tensors in Z,Y,X order while grid vectors use
    PyTorch coordinate order x,y,z. FireANTs uses align_corners=True normalized
    coordinates, hence voxel scale=(size-1)/2 for each vector component.
    """
    arr = grid.detach().float().cpu().numpy() if isinstance(grid, torch.Tensor) else np.asarray(grid)
    if arr.ndim != 5 or arr.shape[0] != 1 or arr.shape[-1] != 3:
        raise ValueError(f"Expected FireANTs grid [1,Z,Y,X,3], got {arr.shape}")
    x, y, z = (int(v) for v in xyz_shape)
    expected = (1, z, y, x, 3)
    if tuple(arr.shape) != expected:
        raise ValueError(f"FireANTs grid shape mismatch: expected={expected} actual={arr.shape}")
    out = np.transpose(arr[0], (2, 1, 0, 3)).astype(np.float32, copy=True)
    out[..., 0] *= 0.5 * max(x - 1, 1)
    out[..., 1] *= 0.5 * max(y - 1, 1)
    out[..., 2] *= 0.5 * max(z - 1, 1)
    if not np.isfinite(out).all():
        raise RuntimeError("Converted FireANTs residual contains NaN/Inf")
    return out


def residual_norm_stats(residual_dvf: torch.Tensor) -> dict[str, float]:
    if residual_dvf.ndim != 5 or residual_dvf.shape[1] != 3:
        raise ValueError(f"Expected [B,3,X,Y,Z], got {tuple(residual_dvf.shape)}")
    norm = torch.linalg.vector_norm(residual_dvf.detach().float(), dim=1).reshape(-1)
    q = torch.quantile(norm, torch.tensor([0.50, 0.95, 0.99], device=norm.device))
    return {
        "residual_norm_mean_vox": float(norm.mean().item()),
        "residual_norm_p50_vox": float(q[0].item()),
        "residual_norm_p95_vox": float(q[1].item()),
        "residual_norm_p99_vox": float(q[2].item()),
        "residual_norm_max_vox": float(norm.max().item()),
    }


def run_fireants_residual(
    *,
    full: dict[str, Any],
    device: torch.device,
    fireants_cfg: dict[str, Any],
) -> tuple[torch.Tensor, dict[str, Any]]:
    """Estimate a residual pull DVF after prewarping EXP with frozen C4.1."""
    backend = check_fireants_backend(str(fireants_cfg.get("required_version", "1.5.0")))

    import SimpleITK as sitk
    from fireants.io import BatchedImages, Image
    from fireants.io.imagemask import apply_mask_to_image
    from fireants.registration.greedy import GreedyRegistration

    with torch.no_grad():
        prewarped_ct = warp_volume(full["moving_ct"], full["init_dvf"], mode="bilinear")
        prewarped_support = warp_volume(full["moving_support"], full["init_dvf"], mode="bilinear").clamp(0.0, 1.0)

    fixed_xyz = _tensor_scalar_xyz(full["fixed_ct"])
    moving_xyz = _tensor_scalar_xyz(prewarped_ct)
    fixed_mask_xyz = _tensor_scalar_xyz(full["fixed_support"]).clip(0.0, 1.0)
    moving_mask_xyz = _tensor_scalar_xyz(prewarped_support).clip(0.0, 1.0)

    threshold = float(fireants_cfg.get("mask_threshold", 0.05))
    fixed_mask_xyz = np.where(fixed_mask_xyz >= threshold, fixed_mask_xyz, 0.0).astype(np.float32)
    moving_mask_xyz = np.where(moving_mask_xyz >= threshold, moving_mask_xyz, 0.0).astype(np.float32)
    if float(fixed_mask_xyz.sum()) <= 0.0 or float(moving_mask_xyz.sum()) <= 0.0:
        raise RuntimeError("FireANTs support mask is empty")

    def sitk_from_xyz(array_xyz: np.ndarray):
        image = sitk.GetImageFromArray(np.transpose(array_xyz.astype(np.float32, copy=False), (2, 1, 0)))
        image.SetSpacing((1.0, 1.0, 1.0))
        image.SetOrigin((0.0, 0.0, 0.0))
        image.SetDirection((1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0))
        return image

    dev = str(device)
    fixed_image = Image(sitk_from_xyz(fixed_xyz), device=dev)
    moving_image = Image(sitk_from_xyz(moving_xyz), device=dev)
    fixed_mask = Image(sitk_from_xyz(fixed_mask_xyz), device=dev)
    moving_mask = Image(sitk_from_xyz(moving_mask_xyz), device=dev)
    fixed_masked = apply_mask_to_image(fixed_image, fixed_mask)
    moving_masked = apply_mask_to_image(moving_image, moving_mask)
    fixed_batch = BatchedImages([fixed_masked])
    moving_batch = BatchedImages([moving_masked])

    scales = [float(v) for v in fireants_cfg.get("scales", [4, 2, 1])]
    iterations = [int(v) for v in fireants_cfg.get("iterations", [60, 40, 20])]
    if len(scales) != len(iterations) or not scales or float(scales[-1]) != 1.0:
        raise ValueError("FireANTs scales/iterations must have equal length and end at scale 1")

    reg = GreedyRegistration(
        scales=scales,
        iterations=iterations,
        fixed_images=fixed_batch,
        moving_images=moving_batch,
        loss_type=str(fireants_cfg.get("loss_type", "masked_cc")),
        cc_kernel_size=int(fireants_cfg.get("cc_kernel_size", 5)),
        deformation_type=str(fireants_cfg.get("deformation_type", "compositive")),
        optimizer=str(fireants_cfg.get("optimizer", "Adam")),
        optimizer_lr=float(fireants_cfg.get("optimizer_lr", 0.15)),
        smooth_warp_sigma=float(fireants_cfg.get("smooth_warp_sigma", 0.70)),
        smooth_grad_sigma=float(fireants_cfg.get("smooth_grad_sigma", 1.50)),
        reduction=str(fireants_cfg.get("reduction", "mean")),
        tolerance=float(fireants_cfg.get("tolerance", 1.0e-7)),
        max_tolerance_iters=int(fireants_cfg.get("max_tolerance_iters", 1000)),
        blur=bool(fireants_cfg.get("blur", True)),
        freeform=bool(fireants_cfg.get("freeform", False)),
        progress_bar=bool(fireants_cfg.get("progress_bar", False)),
    )
    reg.optimize()
    params = reg.get_warp_parameters(fixed_batch, moving_batch, displacement=True)
    grid = params["grid"]
    affine = params["affine"].detach().float().cpu().numpy()
    identity = np.eye(4, dtype=np.float32)[None, :3, :]
    affine_max_abs_diff = float(np.max(np.abs(affine - identity)))
    affine_atol = float(fireants_cfg.get("require_identity_affine_atol", 1.0e-5))
    if affine_max_abs_diff > affine_atol:
        raise RuntimeError(
            "FireANTs residual unexpectedly contains non-identity affine mapping: "
            f"max_abs_diff={affine_max_abs_diff:.9g} atol={affine_atol:.9g}"
        )

    residual_xyzc = normalized_fireants_grid_to_voxel_pull(grid, full["full_shape"])
    residual = dvf_xyzc_to_tensor(residual_xyzc, device=device)
    diagnostics: dict[str, Any] = {
        **backend,
        "scales": scales,
        "iterations": iterations,
        "affine_identity_max_abs_diff": affine_max_abs_diff,
        **residual_norm_stats(residual),
    }
    return residual, diagnostics


def candidate_score(candidate: dict[str, float], baseline: dict[str, float], selector: dict[str, Any]) -> float:
    return (
        float(selector.get("score_lncc_gain", 1.0)) * (baseline["lncc_loss"] - candidate["lncc_loss"])
        + float(selector.get("score_structural_gain", 0.55)) * (baseline["structural_gradient_loss"] - candidate["structural_gradient_loss"])
        + float(selector.get("score_direct_lobe_gain", 0.35)) * (candidate["direct_proxy_lobe_dice"] - baseline["direct_proxy_lobe_dice"])
        + float(selector.get("score_support_gain", 0.05)) * (candidate["proxy_support_dice"] - baseline["proxy_support_dice"])
    )


def topology_folding_limit(*, baseline_folding_pct: float, selector: dict[str, Any]) -> float:
    mode = str(selector.get("topology_guard_mode", "relative_to_initializer")).strip().lower()
    max_absolute = float(selector.get("max_absolute_folding_pct", 1e-3))
    max_increase = float(selector.get("max_folding_increase_pct", 5e-5))
    if max_absolute < 0.0 or max_increase < 0.0:
        raise ValueError("Folding guard limits must be non-negative")
    if mode == "relative_to_initializer":
        return min(max_absolute, float(baseline_folding_pct) + max_increase)
    if mode == "absolute":
        return max_absolute
    raise ValueError(f"Unsupported topology_guard_mode={mode!r}")


def passes_acceptance(
    candidate: dict[str, float],
    baseline: dict[str, float],
    *,
    baseline_folding_pct: float,
    selector: dict[str, Any],
) -> tuple[bool, list[str], float, float]:
    reasons: list[str] = []
    score = candidate_score(candidate, baseline, selector)
    direct_drop = baseline["direct_proxy_lobe_dice"] - candidate["direct_proxy_lobe_dice"]
    lncc_increase = candidate["lncc_loss"] - baseline["lncc_loss"]
    support_drop = baseline["proxy_support_dice"] - candidate["proxy_support_dice"]
    fold_limit = topology_folding_limit(baseline_folding_pct=baseline_folding_pct, selector=selector)

    if score < float(selector.get("min_composite_score_gain", 1e-4)):
        reasons.append(f"composite_score_gain={score:.6g} below minimum")
    if direct_drop > float(selector.get("max_direct_proxy_lobe_drop", 2.5e-4)):
        reasons.append(f"direct_proxy_lobe_drop={direct_drop:.6g} above maximum")
    if lncc_increase > float(selector.get("max_lncc_loss_increase", 2.5e-4)):
        reasons.append(f"lncc_loss_increase={lncc_increase:.6g} above maximum")
    if support_drop > float(selector.get("max_support_dice_drop", 1e-3)):
        reasons.append(f"support_dice_drop={support_drop:.6g} above maximum")
    if candidate["residual_norm_p99_vox"] > float(selector.get("max_residual_p99_voxels", 2.5)):
        reasons.append(f"residual_p99={candidate['residual_norm_p99_vox']:.6g} above maximum")
    if candidate["residual_norm_max_vox"] > float(selector.get("max_residual_max_voxels", 8.0)):
        reasons.append(f"residual_max={candidate['residual_norm_max_vox']:.6g} above maximum")
    if candidate["folding_pct"] > fold_limit + 1e-12:
        reasons.append(f"folding_pct={candidate['folding_pct']:.6g} above limit={fold_limit:.6g}")
    return len(reasons) == 0, reasons, float(fold_limit), float(score)
