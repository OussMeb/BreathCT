SGR-FM C5a FireANTs residual refinement
========================================

Purpose
-------
C5a is an independent image-driven residual branch on top of frozen C4.1.
It does NOT overwrite C4.1.

Pipeline:
  frozen C4.1 pull DVF
      -> warp raw EXP once into INSP grid
      -> FireANTs masked-CC residual registration on the near-aligned pair
      -> convert FireANTs normalized residual to XYZ voxel pull convention
      -> exact pull composition with C4.1
      -> inference-only candidate scale selection
      -> full-resolution topology guard
      -> exact C4.1 byte-copy fallback when no candidate passes

No validation GT is loaded by optimization. GT is used only by the existing
10-case evaluator after outputs are written.

External backend pin
--------------------
The adapter is intentionally pinned to FireANTs 1.5.0 because grid/API drift is
unsafe for a challenge DVF pipeline.

Check/install in the SAME Python environment used for the project:

  python -m pip install "fireants==1.5.0"

Then verify:

  python -c "import importlib.metadata as m; print(m.version('fireants'))"

Expected: 1.5.0

If installation fails because of dependency/Python-version constraints, do not
edit the C5 source to bypass the version check. Use a compatible environment or
resolve the dependency explicitly first.

Install patch
-------------
From project root:

  unzip -o SGR_FM_C5A_FIREANTS_patch.zip -d .

Compile:

  python -m py_compile \
    main.py \
    run_sgr_fm_c5a_fireants_validation.py \
    utils/sgr_fm_c5_fireants.py \
    smoke_sgr_fm_c5a_fireants_synthetic.py

Synthetic geometry smoke (does not require FireANTs):

  python smoke_sgr_fm_c5a_fireants_synthetic.py

Expected final line:
  C5a FIREANTS SYNTHETIC SMOKE: PASS

Backend/assets/fingerprint dry-run:

  python main.py c5-fireants \
    --config configs/sgr_fm_c5a_fireants.yaml \
    --dry-run

Recommended real smoke cases
----------------------------
Hard cases:

  python main.py c5-fireants \
    --config configs/sgr_fm_c5a_fireants.yaml \
    --case-ids NLST_0006 \
    --skip-evaluation

  python main.py c5-fireants \
    --config configs/sgr_fm_c5a_fireants.yaml \
    --case-ids NLST_0007 \
    --skip-evaluation

High-score safety cases:

  python main.py c5-fireants \
    --config configs/sgr_fm_c5a_fireants.yaml \
    --case-ids NLST_0003 \
    --skip-evaluation

  python main.py c5-fireants \
    --config configs/sgr_fm_c5a_fireants.yaml \
    --case-ids NLST_0009 \
    --skip-evaluation

Outputs
-------
  outputs/sgr_fm/c5a_fireants_residual/
    dvfs/
    dvfs_canonical_ras/
    case_manifests/
    eval/
    comparison/
    run_config_resolved.json
    c5a_fireants_summary.json

Design notes
------------
1. FireANTs sees C4.1-prewarped EXP and INSP, not the original large-motion pair.
2. Fixed/moving residual images are created with identical unit metadata; the
   returned affine is required to remain identity.
3. FireANTs grid layout [1,Z,Y,X,3] and normalized x,y,z displacement is
   explicitly converted to [X,Y,Z,3] voxel pull displacement.
4. Candidate fields are composed exactly with C4.1; DVFs are never added.
5. The selector uses only predicted lobes/support and CT structure.
6. Exact C4.1 is always available as scale 0 fallback.
7. Do not tune against validation GT before assessing the first full run.
