#!/usr/bin/env python3
"""Synthetic geometry/safety smoke for C5a FireANTs adapter.

This smoke does not require the external FireANTs package. It validates the
critical normalized-grid -> XYZ voxel conversion, exact pull composition, and
no-op acceptance behavior used around the backend.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F

from utils.sgr_fm_c3 import compose_pull
from utils.refine_spatial import warp_volume
from utils.sgr_fm_c5_fireants import (
    normalized_fireants_grid_to_voxel_pull,
    passes_acceptance,
    residual_norm_stats,
)


def main() -> int:
    x, y, z = 11, 9, 7
    # FireANTs layout [1,Z,Y,X,3], vector order x,y,z, normalized align_corners=True.
    grid = np.zeros((1, z, y, x, 3), dtype=np.float32)
    expected_shift = np.asarray([1.25, -0.75, 0.50], dtype=np.float32)
    grid[..., 0] = expected_shift[0] / ((x - 1) / 2.0)
    grid[..., 1] = expected_shift[1] / ((y - 1) / 2.0)
    grid[..., 2] = expected_shift[2] / ((z - 1) / 2.0)
    residual_xyzc = normalized_fireants_grid_to_voxel_pull(grid, (x, y, z))
    if not np.allclose(residual_xyzc, expected_shift, atol=1e-6):
        raise AssertionError("FireANTs normalized-grid conversion failed")

    residual = torch.from_numpy(np.moveaxis(residual_xyzc, -1, 0)[None]).float()

    # Axis-semantics equivalence: FireANTs/SimpleITK tensor is [Z,Y,X] with
    # grid vectors [x,y,z]; project tensor is [X,Y,Z] with DVF [X,Y,Z].
    values_xyz = torch.arange(x * y * z, dtype=torch.float32).reshape(1, 1, x, y, z)
    ours = warp_volume(values_xyz, residual, mode="bilinear")
    fire_input = values_xyz.permute(0, 1, 4, 3, 2).contiguous()  # [1,1,Z,Y,X]
    bx = torch.linspace(-1.0, 1.0, x)
    by = torch.linspace(-1.0, 1.0, y)
    bz = torch.linspace(-1.0, 1.0, z)
    zz, yy, xx = torch.meshgrid(bz, by, bx, indexing="ij")
    fire_grid = torch.stack([xx, yy, zz], dim=-1)[None] + torch.from_numpy(grid)
    fire_warped = F.grid_sample(fire_input, fire_grid, mode="bilinear", padding_mode="border", align_corners=True)
    fire_as_xyz = fire_warped.permute(0, 1, 4, 3, 2).contiguous()
    if not torch.allclose(ours, fire_as_xyz, atol=1e-4):
        raise AssertionError("FireANTs/project axis semantics are inconsistent")

    init = torch.zeros_like(residual)
    init[:, 0] = 2.0
    final = compose_pull(init, residual)
    expected = residual.clone()
    expected[:, 0] += 2.0
    if not torch.allclose(final, expected, atol=1e-5):
        raise AssertionError("Exact pull composition failed for constant fields")

    stats = residual_norm_stats(residual * 0.0)
    baseline = {
        "direct_proxy_lobe_dice": 0.97,
        "proxy_support_dice": 0.99,
        "lncc_loss": 0.20,
        "structural_gradient_loss": 0.30,
    }
    noop = {
        **baseline,
        "folding_pct": 0.0,
        **stats,
    }
    selector = {
        "min_composite_score_gain": 1e-4,
        "max_direct_proxy_lobe_drop": 2.5e-4,
        "max_lncc_loss_increase": 2.5e-4,
        "max_support_dice_drop": 1e-3,
        "max_residual_p99_voxels": 2.5,
        "max_residual_max_voxels": 8.0,
        "topology_guard_mode": "relative_to_initializer",
        "max_folding_increase_pct": 5e-5,
        "max_absolute_folding_pct": 1e-3,
        "score_lncc_gain": 1.0,
        "score_structural_gain": 0.55,
        "score_direct_lobe_gain": 0.35,
        "score_support_gain": 0.05,
    }
    ok, reasons, _, score = passes_acceptance(
        noop, baseline, baseline_folding_pct=0.0, selector=selector
    )
    if ok or not reasons or score != 0.0:
        raise AssertionError("Exact no-op should not be accepted as an improvement")

    print("C5a FIREANTS SYNTHETIC SMOKE: PASS")
    print(f"  conversion shift vox={expected_shift.tolist()}")
    print("  axis/grid equivalence=PASS")
    print("  exact pull composition=PASS")
    print("  no-op selector rejection=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
