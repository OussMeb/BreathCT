#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Learn2Breath MICCAI runner.")
    parser.add_argument(
        "command",
        choices=(
            "train",
            "infer",
            "evaluate",
            "unigradicon",
            "segment",
            "support-fm",
            "c1-train",
            "training-assets",
            "phase2-freeze",
            "c3-cache",
            "c3-train",
            "c3-holdout",
            "c3-infer",
            "tto",
            "c4-hast",
            "c4.1-hast-pcf",
            "c5-fireants",
        ),
    )
    parser.add_argument("args", nargs=argparse.REMAINDER)
    return parser.parse_args()


def main() -> None:
    parsed = parse_args()

    if parsed.command == "train":
        import train_refiner as module
        sys.argv = ["train_refiner.py", *parsed.args]
    elif parsed.command == "infer":
        import infer_validation as module
        sys.argv = ["infer_validation.py", *parsed.args]
    elif parsed.command == "evaluate":
        import evaluate_validation as module
        sys.argv = ["evaluate_validation.py", *parsed.args]
    elif parsed.command == "segment":
        import run_sgr_fm_segmentation as module
        sys.argv = ["run_sgr_fm_segmentation.py", *parsed.args]
    elif parsed.command == "support-fm":
        import run_sgr_fm_support_ablation as module
        sys.argv = ["run_sgr_fm_support_ablation.py", *parsed.args]
    elif parsed.command == "c1-train":
        import run_sgr_fm_c1_training as module
        sys.argv = ["run_sgr_fm_c1_training.py", *parsed.args]
    elif parsed.command == "training-assets":
        import run_sgr_fm_training_assets as module
        sys.argv = ["run_sgr_fm_training_assets.py", *parsed.args]
    elif parsed.command == "phase2-freeze":
        import freeze_sgr_fm_phase2_assets as module
        sys.argv = ["freeze_sgr_fm_phase2_assets.py", *parsed.args]
    elif parsed.command == "c3-cache":
        import prepare_sgr_fm_c3_cache as module
        sys.argv = ["prepare_sgr_fm_c3_cache.py", *parsed.args]
    elif parsed.command == "c3-train":
        import train_sgr_fm_c3 as module
        sys.argv = ["train_sgr_fm_c3.py", *parsed.args]
    elif parsed.command == "c3-holdout":
        import evaluate_sgr_fm_c3_holdout as module
        sys.argv = ["evaluate_sgr_fm_c3_holdout.py", *parsed.args]
    elif parsed.command == "c3-infer":
        import infer_sgr_fm_c3_validation as module
        sys.argv = ["infer_sgr_fm_c3_validation.py", *parsed.args]
    elif parsed.command == "tto":
        import run_sgr_fm_tto_validation as module
        sys.argv = ["run_sgr_fm_tto_validation.py", *parsed.args]
    elif parsed.command == "c4-hast":
        import run_sgr_fm_c4_hast_validation as module
        sys.argv = ["run_sgr_fm_c4_hast_validation.py", *parsed.args]
    elif parsed.command == "c4.1-hast-pcf":
        import run_sgr_fm_c4_1_hast_pcf_validation as module
        sys.argv = ["run_sgr_fm_c4_1_hast_pcf_validation.py", *parsed.args]
    elif parsed.command == "c5-fireants":
        import run_sgr_fm_c5a_fireants_validation as module
        sys.argv = ["run_sgr_fm_c5a_fireants_validation.py", *parsed.args]
    else:
        import run_unigradicon as module
        sys.argv = ["run_unigradicon.py", *parsed.args]

    raise SystemExit(module.main() or 0)


if __name__ == "__main__":
    main()
