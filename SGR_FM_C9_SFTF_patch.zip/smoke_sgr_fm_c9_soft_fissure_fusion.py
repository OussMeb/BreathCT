#!/usr/bin/env python3
import numpy as np, torch
from utils.sgr_fm_c9_soft_fissure_fusion import _signed_distance_channels, _interface_surfaces, _interface_distance, _labels_onehot, _residual_from_param
from utils.sgr_fm_c3 import compose_pull

def main():
    lab=np.zeros((32,28,30),np.int16)
    lab[4:16,4:13,4:14]=32; lab[4:16,13:22,4:14]=64; lab[4:16,4:22,14:26]=128
    sdf=_signed_distance_channels(lab,(1.5,1.5,1.5),12.0,[8,16,32,64,128])
    surf=_interface_surfaces(lab,1); dist=_interface_distance(surf,(1.5,1.5,1.5),10.0)
    assert sdf.shape==(5,32,28,30) and surf.shape==(2,32,28,30) and np.isfinite(sdf).all()
    z=torch.zeros((1,3,16,14,15)); assert torch.allclose(compose_pull(z,z),z)
    state={'target_shape':(16,14,15),'full_shape':(32,28,30),'gate':torch.ones((1,1,16,14,15))}
    stage={'max_residual_fullres_voxels':0.7,'integration_steps':5}
    p=torch.zeros((1,3,4,4,4),requires_grad=True); r=_residual_from_param(p,state,stage,1.0)
    loss=r.square().mean(); loss.backward(); assert r.shape==z.shape and torch.isfinite(loss)
    print('C9-SFTF SYNTHETIC SMOKE: PASS')
    print({'sdf_shape':sdf.shape,'interface_voxels':[int(x.sum()) for x in surf],'distance_range':[float(dist.min()),float(dist.max())]})
if __name__=='__main__': main()
