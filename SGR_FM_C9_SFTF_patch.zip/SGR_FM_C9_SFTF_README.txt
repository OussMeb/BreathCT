SGR-FM C9-SFTF PATCH
======================

Purpose
-------
C9-SFTF starts from the frozen C8B output and applies patient-specific,
continuous soft-SDF/right-fissure refinement without loading validation GT.
It replaces C8C's hard centroid/scale morphology with:
  - continuous five-lobe SDFs;
  - right horizontal and oblique interface surfaces;
  - patient-specific EXP/INSP disagreement;
  - fixed-CT edge and MIND evidence;
  - a localized right-lung priority gate;
  - residual SVF integration and exact pull composition;
  - non-GT candidate selection and exact C8B fallback.

Install
-------
Extract this ZIP into:
  /home/oussama/Desktop/MICCAI FRANCE

The patch only adds new C9 files. It does not overwrite C8B or C8C.

Checks
------
python -m py_compile \
  utils/sgr_fm_c9_soft_fissure_fusion.py \
  run_sgr_fm_c9_soft_fissure_fusion_validation.py \
  smoke_sgr_fm_c9_soft_fissure_fusion.py

python smoke_sgr_fm_c9_soft_fissure_fusion.py
python run_sgr_fm_c9_soft_fissure_fusion_validation.py \
  --config configs/sgr_fm_c9_soft_fissure_fusion.yaml --dry-run

Recommended smoke cases
-----------------------
Run hard case 0006 and easy case 0009 first:

python run_sgr_fm_c9_soft_fissure_fusion_validation.py \
  --config configs/sgr_fm_c9_soft_fissure_fusion.yaml \
  --cases NLST_0006 NLST_0009

Inspect both case manifests before launching all ten cases. Important fields:
  state_diagnostics.gate_mean
  optimizer.best_iteration
  selection.selected.scale
  selection.selected.score
  selection.selected.folding_pct
  max_abs_dvf_change_vox

Full run
--------
python run_sgr_fm_c9_soft_fissure_fusion_validation.py \
  --config configs/sgr_fm_c9_soft_fissure_fusion.yaml

Outputs
-------
outputs/sgr_fm/c9_soft_fissure_fusion/
  dvfs/
  case_manifests/
  eval/validation_metrics.json
  c9_soft_fissure_fusion_summary.json
  c9_soft_fissure_fusion_per_case.csv

Important
---------
- C8B remains untouched and is the exact fallback.
- C9 intentionally does not create a dvfs_canonical_ras folder because recent
  lightweight branches did not independently audit canonical conversion.
- Final challenge-grid dvfs/ are authoritative.
- Do not infer a Dice gain from proxy metrics; use evaluate_validation.py.
