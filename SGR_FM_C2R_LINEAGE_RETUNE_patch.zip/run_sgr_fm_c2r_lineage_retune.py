#!/usr/bin/env python3
"""C2R-LRT: isolated, lineage-aware retuning of the frozen C2-LONG stage.

The runner materializes interpretable C2 variants into unique output folders,
executes the existing audited C2 TTO runner unchanged, verifies B0 against the
frozen C2-LONG reference, and produces proxy + GT-diagnostic rankings.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.sgr_fm_c2r_lineage import (
    assert_output_isolation,
    baseline_reproduction_check,
    build_rankings,
    collect_proxy_stats,
    compare_metrics,
    load_sweep_config,
    read_metrics,
    resolve_variants,
    write_child_config,
)
from utils.sgr_fm_segmentation import atomic_write_json, write_csv
from utils.sgr_fm_training_assets import resolve_under_project


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="SGR-FM C2R-LRT lineage retuning sweep.")
    p.add_argument("--config", default="configs/sgr_fm_c2r_lineage_retune.yaml")
    p.add_argument("--variants", nargs="*", default=None, help="Subset, e.g. B0 V1_lobe_plus")
    p.add_argument("--case-ids", nargs="*", default=None)
    p.add_argument("--device", default=None)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--skip-evaluation", action="store_true")
    p.add_argument("--list-variants", action="store_true")
    return p.parse_args()


def _stream_command(command: list[str], *, cwd: Path, log_path: Path) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as log:
        proc = subprocess.Popen(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            print(line, end="", flush=True)
            log.write(line)
            log.flush()
        return int(proc.wait())


def _load_run_status(output_dir: Path) -> str:
    path = output_dir / "c2_tto_summary.json"
    if not path.exists():
        return "MISSING"
    try:
        return str(json.loads(path.read_text(encoding="utf-8")).get("status", "UNKNOWN"))
    except Exception:
        return "INVALID"


def _baseline_verification_path(output_root: Path) -> Path:
    return output_root / "sweep_summary" / "baseline_reproduction.json"


def _require_existing_baseline_pass(output_root: Path) -> None:
    path = _baseline_verification_path(output_root)
    if not path.exists():
        raise RuntimeError(
            "B0 is not selected and no verified baseline reproduction exists. "
            "Run B0 first or run the full default sweep."
        )
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("status") != "PASS":
        raise RuntimeError(f"Existing B0 reproduction is not PASS: {path}")


def main() -> int:
    args = parse_args()
    sweep_cfg = load_sweep_config(args.config)
    output_root = resolve_under_project(PROJECT_ROOT, sweep_cfg["output_root"])
    output_root.mkdir(parents=True, exist_ok=True)

    if args.list_variants:
        for name, meta in sweep_cfg["variants"].items():
            print(f"{name:30s} {meta.get('description', '')}")
        return 0

    case_ids_override = list(args.case_ids) if args.case_ids else None
    full_case_run = case_ids_override is None
    variants = resolve_variants(
        sweep_cfg,
        project_root=PROJECT_ROOT,
        selected_names=args.variants,
        device_override=args.device,
        case_ids_override=case_ids_override,
    )
    assert_output_isolation(PROJECT_ROOT, sweep_cfg, variants)

    selected_names = [v["name"] for v in variants]
    has_b0 = "B0" in selected_names
    expected_fp = str(sweep_cfg["expected_c2_long_fingerprint"])
    b0_item = next((v for v in variants if v["name"] == "B0"), None)
    if b0_item is not None and bool(sweep_cfg.get("require_baseline_fingerprint_match", True)):
        actual = str(b0_item["method_fingerprint_sha256"])
        if actual != expected_fp:
            raise RuntimeError(f"B0 fingerprint mismatch before execution: expected={expected_fp} actual={actual}")

    require_b0 = bool(sweep_cfg.get("require_baseline_reproduction_before_variants", True))
    non_b0_selected = any(name != "B0" for name in selected_names)
    if require_b0 and not args.dry_run and full_case_run:
        if not has_b0:
            _require_existing_baseline_pass(output_root)
        elif args.skip_evaluation and non_b0_selected:
            # B0 cannot be verified in this invocation because evaluation is skipped.
            # A prior verified reproduction is therefore mandatory before variants run.
            _require_existing_baseline_pass(output_root)

    sweep_meta = {
        "schema_version": 1,
        "experiment": str(sweep_cfg.get("experiment_name", "C2R-LRT")),
        "started_utc_epoch": time.time(),
        "config_path": str(Path(args.config).resolve()),
        "output_root": str(output_root),
        "selected_variants": selected_names,
        "case_ids_override": case_ids_override,
        "dry_run": bool(args.dry_run),
        "skip_evaluation": bool(args.skip_evaluation),
        "expected_c2_long_fingerprint": expected_fp,
        "critical_note": "Optimization remains GT-free. GT metrics are post-hoc diagnostic only; no variant is auto-promoted downstream.",
    }
    atomic_write_json(output_root / "sweep_run_config.json", sweep_meta)

    run_records: list[dict[str, Any]] = []
    for index, item in enumerate(variants, start=1):
        name = item["name"]
        out_dir = Path(item["output_dir"])
        config_path = output_root / "variant_configs" / f"{name}.json"
        write_child_config(config_path, item["config"])
        command = [
            sys.executable,
            str(PROJECT_ROOT / "run_sgr_fm_tto_validation.py"),
            "--config", str(config_path),
        ]
        if case_ids_override is not None:
            command.extend(["--case-ids", *case_ids_override])
        if args.device is not None:
            command.extend(["--device", str(args.device)])
        if args.dry_run:
            command.append("--dry-run")
        if args.skip_evaluation:
            command.append("--skip-evaluation")

        print(f"\n=== [{index}/{len(variants)}] {name}: {item['description']} ===", flush=True)
        started = time.time()
        exit_code = _stream_command(
            command,
            cwd=PROJECT_ROOT,
            log_path=output_root / "logs" / f"{name}.log",
        )
        record = {
            "variant": name,
            "description": item["description"],
            "output_dir": str(out_dir),
            "config_path": str(config_path),
            "method_fingerprint_sha256": item["method_fingerprint_sha256"],
            "exit_code": exit_code,
            "elapsed_sec": float(time.time() - started),
            "run_status": _load_run_status(out_dir),
        }
        run_records.append(record)
        if exit_code != 0:
            atomic_write_json(output_root / "sweep_summary" / "partial_run_records.json", run_records)
            print(f"Variant {name} failed; stopping sweep.", file=sys.stderr)
            return 1

        # B0 must be verified before later variants in a full 10-case evaluated sweep.
        if (
            name == "B0"
            and not args.dry_run
            and not args.skip_evaluation
            and full_case_run
            and bool(sweep_cfg.get("require_baseline_reproduction_before_variants", True))
        ):
            ref_dir = resolve_under_project(PROJECT_ROOT, sweep_cfg["reference_c2_long_dir"])
            ref_metrics_path = ref_dir / "eval" / "validation_metrics.json"
            b0_metrics_path = out_dir / "eval" / "validation_metrics.json"
            ref_run_path = ref_dir / "run_config_resolved.json"
            fingerprint_ok = False
            reference_fp = None
            if ref_run_path.exists():
                reference_fp = json.loads(ref_run_path.read_text(encoding="utf-8")).get("method_fingerprint_sha256")
                fingerprint_ok = reference_fp == expected_fp
            if not ref_metrics_path.exists():
                raise FileNotFoundError(f"Missing frozen C2-LONG reference metrics: {ref_metrics_path}")
            if not b0_metrics_path.exists():
                raise FileNotFoundError(f"Missing B0 metrics after successful run: {b0_metrics_path}")
            reproduction = baseline_reproduction_check(
                read_metrics(ref_metrics_path),
                read_metrics(b0_metrics_path),
                sweep_cfg.get("baseline_reproduction_tolerance", {}),
            )
            reproduction["expected_fingerprint"] = expected_fp
            reproduction["reference_fingerprint"] = reference_fp
            reproduction["reference_fingerprint_ok"] = bool(fingerprint_ok)
            if not fingerprint_ok:
                reproduction["status"] = "FAIL"
            atomic_write_json(_baseline_verification_path(output_root), reproduction)
            print(json.dumps(reproduction, indent=2), flush=True)
            if reproduction["status"] != "PASS" and bool(sweep_cfg.get("stop_if_baseline_reproduction_fails", True)):
                print("B0 reproduction failed; refusing to continue retuning variants.", file=sys.stderr)
                return 2

    # Partial or dry runs stop after preserving provenance; rankings require complete eval metrics.
    summary_dir = output_root / "sweep_summary"
    summary_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(summary_dir / "run_records.json", run_records)

    b0_output = output_root / str(sweep_cfg["variants"]["B0"].get("output_subdir", "baseline_repro"))
    b0_metrics_path = b0_output / "eval" / "validation_metrics.json"
    b0_metrics = read_metrics(b0_metrics_path) if b0_metrics_path.exists() else None

    table_rows: list[dict[str, Any]] = []
    all_case_rows: list[dict[str, Any]] = []
    for item in resolve_variants(sweep_cfg, project_root=PROJECT_ROOT):
        out_dir = Path(item["output_dir"])
        metrics_path = out_dir / "eval" / "validation_metrics.json"
        proxy = collect_proxy_stats(out_dir)
        row: dict[str, Any] = {
            "variant": item["name"],
            "description": item["description"],
            "output_dir": str(out_dir),
            "method_fingerprint_sha256": item["method_fingerprint_sha256"],
            "run_status": _load_run_status(out_dir),
            "mean_lobe_dice": None,
            "mean_folding_percentage": None,
            "delta_mean_lobe_dice_vs_B0": None,
            "improved_cases_vs_B0": None,
            "worsened_cases_vs_B0": None,
            **{k: v for k, v in proxy.items() if k != "decision_counts"},
            "decision_counts": json.dumps(proxy.get("decision_counts", {}), sort_keys=True),
        }
        if metrics_path.exists():
            metrics = read_metrics(metrics_path)
            row["mean_lobe_dice"] = float(metrics["mean_lobe_dice"])
            row["mean_folding_percentage"] = float(metrics["mean_folding_percentage"])
            if b0_metrics is not None:
                comp, case_rows = compare_metrics(b0_metrics, metrics)
                row["delta_mean_lobe_dice_vs_B0"] = float(comp["delta_mean_lobe_dice"])
                row["improved_cases_vs_B0"] = int(comp["improved_cases"])
                row["worsened_cases_vs_B0"] = int(comp["worsened_cases"])
                for c in case_rows:
                    all_case_rows.append({"variant": item["name"], **c})
        table_rows.append(row)

    write_csv(summary_dir / "C2R_variant_summary.csv", table_rows)
    atomic_write_json(summary_dir / "C2R_variant_summary.json", {"variants": table_rows})
    if all_case_rows:
        write_csv(summary_dir / "C2R_vs_B0_per_case.csv", all_case_rows)

    rankings = build_rankings(table_rows, int(sweep_cfg.get("shortlist_top_k", 3)))
    atomic_write_json(summary_dir / "C2R_rankings_and_shortlist.json", rankings)

    final_summary = {
        "schema_version": 1,
        "experiment": str(sweep_cfg.get("experiment_name", "C2R-LRT")),
        "status": "PASS" if all(r["exit_code"] == 0 for r in run_records) else "FAIL",
        "executed_variants": [r["variant"] for r in run_records],
        "variant_count_with_metrics": sum(r.get("mean_lobe_dice") is not None for r in table_rows),
        "rankings": rankings,
        "note": "Do not propagate automatically. Inspect B0 reproduction, topology, per-case behavior, and shortlist before rebuilding C4→C4.1→C5b.",
    }
    atomic_write_json(summary_dir / "C2R_sweep_summary.json", final_summary)
    print(json.dumps(final_summary, indent=2), flush=True)
    return 0 if final_summary["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
