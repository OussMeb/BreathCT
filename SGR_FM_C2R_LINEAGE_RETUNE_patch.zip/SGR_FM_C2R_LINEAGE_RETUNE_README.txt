SGR-FM C2R-LRT — C2-LONG Lineage Retuning
==========================================

Purpose
-------
Retune the high-leverage C2-LONG stage without modifying any existing C2-LONG,
C4, C4.1, or C5b outputs. C2-LONG is upstream of C4 and is reused as a
secondary source in later consensus stages, so a better upstream state may
change the final descendant basin.

Protected outputs (never written by this patch)
------------------------------------------------
outputs/sgr_fm/c2_long_tto
outputs/sgr_fm/c4_hast
outputs/sgr_fm/c4_1_hast_pcf
outputs/sgr_fm/c5b_lmind_residual

New isolated root
-----------------
outputs/sgr_fm/c2r_lineage_retune/

Variants
--------
B0  exact C2-LONG reproduction
V1  lobe weight 0.60 -> 0.75
V2  interface weight 0.15 -> 0.225
V3  LNCC 1.00 -> 0.85, lobe 0.60 -> 0.75, interface 0.15 -> 0.20
V4  max residual 1.50 -> 1.25, LR 0.05/0.02 -> 0.04/0.015
V5  fine control 4 -> 3, fine LR 0.02 -> 0.015, fine iters 160 -> 200
V6  lobe 0.70, interface 0.20, bending 0.04, Jacobian 30
V7  max residual 1.75, magnitude 0.015, Jacobian 25

Critical baseline lock
----------------------
B0 must reproduce the exact C2-LONG method fingerprint:
fdc2c0a64374aee658b647b55ae673f50faf2d08aed79ea7e0d6dd3d17fadcd3

For a full 10-case evaluated sweep, B0 is compared against the frozen
outputs/sgr_fm/c2_long_tto/eval/validation_metrics.json. By default the sweep
stops before V1-V7 if B0 reproduction fails tolerance.

No GT leakage into optimization
-------------------------------
Each variant invokes the existing audited C2 TTO runner unchanged. Optimization
uses raw CT, predicted lobes, predicted support, and frozen C1. Validation GT is
read only after evaluation for diagnostic comparison. No variant is
automatically propagated downstream.

Install
-------
unzip -o SGR_FM_C2R_LINEAGE_RETUNE_patch.zip -d .

Compile
-------
python -m py_compile \
  main.py \
  run_sgr_fm_c2r_lineage_retune.py \
  utils/sgr_fm_c2r_lineage.py \
  smoke_sgr_fm_c2r_lineage_retune.py

Synthetic smoke
---------------
python smoke_sgr_fm_c2r_lineage_retune.py

Expected first line:
C2R-LRT SYNTHETIC SMOKE: PASS

List variants
-------------
python main.py c2r-lineage \
  --config configs/sgr_fm_c2r_lineage_retune.yaml \
  --list-variants

Recommended execution sequence
------------------------------
1) Run B0 alone first:

python main.py c2r-lineage \
  --config configs/sgr_fm_c2r_lineage_retune.yaml \
  --variants B0

Inspect:
outputs/sgr_fm/c2r_lineage_retune/sweep_summary/baseline_reproduction.json

It must be PASS before continuing.

2) Run the seven retuning variants:

python main.py c2r-lineage \
  --config configs/sgr_fm_c2r_lineage_retune.yaml \
  --variants \
    V1_lobe_plus \
    V2_interface_plus \
    V3_anatomy_balanced \
    V4_conservative_residual \
    V5_fine_local \
    V6_topology_stable_anatomy \
    V7_capacity_balanced

The runner refuses this second command unless a prior B0 reproduction PASS is
present (for a full 10-case run).

3) Or run everything in one command. B0 runs first and blocks later variants if
reproduction fails:

python main.py c2r-lineage \
  --config configs/sgr_fm_c2r_lineage_retune.yaml

Smoke subset
------------
A subset is supported, but it is not a baseline-reproduction proof and cannot
produce the complete ranking:

python main.py c2r-lineage \
  --config configs/sgr_fm_c2r_lineage_retune.yaml \
  --variants V3_anatomy_balanced V5_fine_local \
  --case-ids NLST_0006 NLST_0007 \
  --skip-evaluation

Main outputs
------------
outputs/sgr_fm/c2r_lineage_retune/
  baseline_repro/
  V1_lobe_plus/
  V2_interface_plus/
  V3_anatomy_balanced/
  V4_conservative_residual/
  V5_fine_local/
  V6_topology_stable_anatomy/
  V7_capacity_balanced/
  variant_configs/
  logs/
  sweep_summary/

Sweep summary artifacts
-----------------------
baseline_reproduction.json
C2R_variant_summary.csv
C2R_variant_summary.json
C2R_vs_B0_per_case.csv
C2R_rankings_and_shortlist.json
C2R_sweep_summary.json

Ranking policy
--------------
Two rankings are reported:
1. proxy_rank — inference-only proxy behavior;
2. gt_diagnostic_rank — post-hoc validation GT diagnostic.

A rank-sum shortlist is generated for inspection only. There is no automatic
winner and no automatic C4/C4.1/C5b propagation. The next step is to inspect
broad case behavior and propagate only 2-3 candidates through the descendant
lineage.
