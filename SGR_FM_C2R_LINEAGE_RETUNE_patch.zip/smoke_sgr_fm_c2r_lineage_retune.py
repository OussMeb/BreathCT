#!/usr/bin/env python3
"""CPU-only synthetic/configuration smoke tests for C2R-LRT."""
from __future__ import annotations

import copy
import json
import tempfile
from pathlib import Path

import torch

PROJECT_ROOT = Path(__file__).resolve().parent

from utils.sgr_fm_c2r_lineage import (
    assert_output_isolation,
    baseline_reproduction_check,
    build_rankings,
    c2_method_fingerprint,
    compare_metrics,
    load_sweep_config,
    resolve_variants,
    write_child_config,
)
from utils.sgr_fm_tto import build_config, make_control_parameter

EXPECTED_B0_FP = "fdc2c0a64374aee658b647b55ae673f50faf2d08aed79ea7e0d6dd3d17fadcd3"


def synthetic_metrics(delta: float = 0.0) -> dict:
    cases = []
    for i in range(1, 11):
        cases.append({
            "case_id": f"NLST_{i:04d}",
            "mean_lobe_dice": 0.97 + i * 1e-4 + delta,
            "folding_percentage": 0.0,
        })
    return {
        "mean_lobe_dice": sum(r["mean_lobe_dice"] for r in cases) / len(cases),
        "mean_folding_percentage": 0.0,
        "case_metrics": cases,
    }


def main() -> int:
    cfg_path = PROJECT_ROOT / "configs" / "sgr_fm_c2r_lineage_retune.yaml"
    sweep = load_sweep_config(cfg_path)
    variants = resolve_variants(sweep, project_root=PROJECT_ROOT)
    assert_output_isolation(PROJECT_ROOT, sweep, variants)
    by_name = {v["name"]: v for v in variants}

    assert set(by_name) == {
        "B0", "V1_lobe_plus", "V2_interface_plus", "V3_anatomy_balanced",
        "V4_conservative_residual", "V5_fine_local", "V6_topology_stable_anatomy",
        "V7_capacity_balanced",
    }
    assert by_name["B0"]["method_fingerprint_sha256"] == EXPECTED_B0_FP
    assert c2_method_fingerprint(by_name["B0"]["config"]) == EXPECTED_B0_FP

    b0 = by_name["B0"]["config"]
    assert by_name["V1_lobe_plus"]["config"]["loss"]["lobe"] == 0.75
    assert by_name["V2_interface_plus"]["config"]["loss"]["interface"] == 0.225
    assert by_name["V3_anatomy_balanced"]["config"]["loss"]["image_lncc"] == 0.85
    assert by_name["V4_conservative_residual"]["config"]["optimization"]["max_residual_fullres_voxels"] == 1.25
    assert by_name["V5_fine_local"]["config"]["optimization"]["fine_control_factor"] == 3
    assert by_name["V6_topology_stable_anatomy"]["config"]["loss"]["jacobian"] == 30.0
    assert by_name["V7_capacity_balanced"]["config"]["optimization"]["max_residual_fullres_voxels"] == 1.75
    assert b0["optimization"]["fine_control_factor"] == 4  # deep merge did not mutate baseline

    # V5 factor 3 is supported by the existing control-lattice implementation.
    p = make_control_parameter((112, 96, 112), 3, device=torch.device("cpu"), dtype=torch.float32)
    assert tuple(p.shape) == (1, 3, 38, 32, 38), tuple(p.shape)

    # Materialized child config must round-trip through the audited C2 config loader.
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "B0.json"
        write_child_config(path, b0)
        loaded = build_config(path)
        assert c2_method_fingerprint(loaded) == EXPECTED_B0_FP

    ref = synthetic_metrics(0.0)
    same = copy.deepcopy(ref)
    better = synthetic_metrics(2e-4)
    comp, rows = compare_metrics(ref, better)
    assert comp["improved_cases"] == 10 and comp["worsened_cases"] == 0
    assert len(rows) == 10 and comp["delta_mean_lobe_dice"] > 0
    repro = baseline_reproduction_check(ref, same, {
        "mean_lobe_dice_abs": 1e-8,
        "per_case_lobe_dice_abs": 1e-8,
        "mean_folding_percentage_abs": 1e-8,
    })
    assert repro["status"] == "PASS"

    ranking_rows = [
        {"variant": "B0", "run_status": "PASS", "mean_lobe_dice": 0.9722, "mean_folding_percentage": 1e-5, "mean_selected_score": 0.01, "mean_proxy_lobe_gain": 0.002},
        {"variant": "V1", "run_status": "PASS", "mean_lobe_dice": 0.9724, "mean_folding_percentage": 1e-5, "mean_selected_score": 0.009, "mean_proxy_lobe_gain": 0.0021},
        {"variant": "V2", "run_status": "PASS", "mean_lobe_dice": 0.9723, "mean_folding_percentage": 1e-5, "mean_selected_score": 0.011, "mean_proxy_lobe_gain": 0.0022},
    ]
    ranks = build_rankings(ranking_rows, 2)
    assert ranks["gt_diagnostic_rank"][0] == "V1"
    assert ranks["proxy_rank"][0] == "V2"
    assert len(ranks["rank_sum_shortlist"]) == 2

    print("C2R-LRT SYNTHETIC SMOKE: PASS")
    print(f"  variant_count={len(variants)}")
    print(f"  B0_fingerprint={EXPECTED_B0_FP}")
    print(f"  V5_control_shape={tuple(p.shape)}")
    print("  output_isolation=PASS")
    print("  config_roundtrip=PASS")
    print("  baseline_reproduction_logic=PASS")
    print("  ranking_logic=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
