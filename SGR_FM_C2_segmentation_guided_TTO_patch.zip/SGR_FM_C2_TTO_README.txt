SGR-FM C2 — segmentation-guided, image-constrained test-time optimization
========================================================================

Purpose
-------
Start from the frozen C1 DVF and optimize a small residual SVF separately for
each case. The optimizer uses only signals available at inference time:
  * raw EXP/INSP CT (in-memory clipped normalization only for LNCC),
  * TotalSegmentator five-lobe predictions,
  * predicted anatomical support masks.

Validation GT is NOT loaded by the optimizer. It is used only after inference by
the existing evaluate_validation.py script.

Why this differs from failed C3
-------------------------------
* no learned global refiner/checkpoint;
* zero-initialized case-specific optimization;
* CT LNCC is the strongest loss term;
* predicted lobes/interfaces are guidance, not the only target;
* conservative scale search after optimization;
* explicit no-op gate: exact C1 is copied when TTO is not justified;
* full-resolution topology guard before accepting a residual.

Default method
--------------
C1 pull DVF -> coarse-to-fine residual SVF TTO -> exact pull composition.
Optimization runs at factor-2 resolution. A smooth control field is optimized
coarse-to-fine and evaluated at full resolution. Candidate residual scales are:
1.0, 0.75, 0.5, 0.25, 0.125, 0.0.

The 0.0 candidate is an exact C1 fallback. A non-zero candidate is accepted only
if it improves predicted-lobe alignment enough, does not materially worsen CT
LNCC/support overlap, and passes a full-resolution folding guard.

Install / overlay
-----------------
From project root:

  unzip -o SGR_FM_C2_segmentation_guided_TTO_patch.zip -d .

1) Dry-run all assets
---------------------

  python main.py tto \
    --config configs/sgr_fm_c2_tto.yaml \
    --dry-run

2) One-case smoke test
----------------------

Start with a difficult case and an easy case separately:

  python main.py tto \
    --config configs/sgr_fm_c2_tto.yaml \
    --case-ids NLST_0006 \
    --skip-evaluation

  python main.py tto \
    --config configs/sgr_fm_c2_tto.yaml \
    --case-ids NLST_0009 \
    --skip-evaluation

Inspect:
  outputs/sgr_fm/c2_segmentation_guided_tto/case_manifests/NLST_0006.json
  outputs/sgr_fm/c2_segmentation_guided_tto/case_manifests/NLST_0009.json

The desired behavior is case-adaptive: difficult cases may accept TTO; easy
cases should often fall back to exact C1.

3) Full 10-case validation run
------------------------------

  python main.py tto \
    --config configs/sgr_fm_c2_tto.yaml

Outputs
-------
  outputs/sgr_fm/c2_segmentation_guided_tto/
    dvfs/
    dvfs_canonical_ras/
    case_manifests/
    traces/
    eval/validation_metrics.json
    comparison/C1_vs_C2_TTO_summary.json
    comparison/C1_vs_C2_TTO_per_case.csv
    c2_tto_summary.json

First files to upload after the full run
----------------------------------------
  c2_tto_summary.json
  eval/validation_metrics.json
  comparison/C1_vs_C2_TTO_summary.json
  comparison/C1_vs_C2_TTO_per_case.csv

Do not tune defaults from validation GT before the first full result. The first
run is an ablation of a fixed, test-compatible TTO policy.
