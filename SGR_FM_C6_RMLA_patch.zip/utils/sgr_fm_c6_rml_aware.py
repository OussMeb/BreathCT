#!/usr/bin/env python3
"""Core helpers for SGR-FM C6-RMLA.

C6-RMLA = confidence-aware Right-Middle-Lobe / right-fissure residual
refinement on top of the frozen B0 full lineage champion.

Design invariants:
  * frozen B0 final DVF is the immutable initializer and exact fallback;
  * no validation GT is loaded by this module;
  * RML guidance comes only from predicted lobes, B0-lineage transported
    predictions, predicted right-fissure interfaces, raw CT structure, and MIND;
  * non-RML alignment is explicitly preserved against the frozen B0 warp;
  * small gated residual SVFs are composed exactly in pull convention.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch
import torch.nn.functional as F

from utils.refine_spatial import downsample_dvf_5d, integrate_svf, warp_volume
from utils.sgr_fm_c3 import compose_pull, dvf_xyzc_to_tensor, load_canonical_dvf
from utils.sgr_fm_c4_1_hast_pcf import (
    load_case_tensors as load_c41_case_tensors,
    make_lowres_state as make_c41_lowres_state,
    validation_asset_paths as c41_validation_asset_paths,
)
from utils.sgr_fm_c4_hast import structural_gradient_loss
from utils.sgr_fm_c5b_lmind import (
    _robust_unit_normalize,
    mind_ssc_3d,
    mind_voxel_mismatch,
    mind_weighted_loss,
    residual_norm_stats,
)
from utils.sgr_fm_training_assets import load_yaml_or_json, recursive_update
from utils.sgr_fm_tto import (
    bending_energy,
    binary_soft_dice,
    build_residual_svf,
    jacobian_barrier,
    make_control_parameter,
    topology_stats,
)

RML_INDEX = 3
NON_RML_INDICES = (0, 1, 2, 4)
RH_INTERFACE_INDEX = 1
RO_INTERFACE_INDEX = 2


def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "initializer_dir": "outputs/sgr_fm/lineage_propagation/B0/c5b_lmind",
        "secondary_initializer_dir": "outputs/sgr_fm/c2r_lineage_retune/baseline_repro",
        "history_c41_dir": "outputs/sgr_fm/lineage_propagation/B0/c4_1_hast_pcf",
        "output_dir": "outputs/sgr_fm/c6_rml_aware",
        "case_ids": [],
        "overwrite": False,
        "stop_on_error": True,
        "device": "cuda",
        "require_initializer_fingerprint": True,
        "accepted_initializer_method_fingerprint": "d064cd195baa6b721126bf27b9ca735845a83b39a1c18660b970958414711d4b",
        "require_secondary_fingerprint": True,
        "accepted_secondary_method_fingerprint": "fdc2c0a64374aee658b647b55ae673f50faf2d08aed79ea7e0d6dd3d17fadcd3",
        "require_history_parent_match": True,
        "ct": {
            "clip_min_hu": -1000.0,
            "clip_max_hu": 400.0,
            "gradient_min_magnitude": 0.03,
        },
        "anatomy": {
            "sdf_band_mm": 12.0,
            "interface_band_mm": 10.0,
            "interface_dilation_iterations": 1,
            "charbonnier_eps": 1.0e-3,
            "sdf_band_fraction": 0.75,
        },
        "consensus": {
            "direct_weight": 1.0,
            "c4_transport_weight": 0.85,
            "c2_transport_weight": 0.35,
            "direct_transport_sigma": 0.30,
            "cross_transport_sigma": 0.25,
            "confidence_floor": 0.05,
            "normalize_lobe_sum": True,
            "size_weight_power": 0.5,
            "size_weight_min": 0.75,
            "size_weight_max": 2.5,
            "sdf_band_fraction": 0.85,
            "interface_confidence_sigma": 0.30,
        },
        "rml_consensus": {
            "direct_weight": 1.0,
            "final_transport_weight": 1.0,
            "c41_transport_weight": 0.55,
            "c2_transport_weight": 0.25,
            "agreement_sigma": 0.20,
            "confidence_floor": 0.05,
        },
        "mind": {
            "descriptor": "MIND-SSC-3D-12ch",
            "delta": 1,
            "patch_radius": 1,
            "variance_floor_fraction": 0.001,
            "variance_ceiling_fraction": 1000.0,
            "loss": "charbonnier",
            "charbonnier_eps": 0.001,
        },
        "priority": {
            "boundary_weight": 0.55,
            "uncertainty_weight": 0.35,
            "mind_mismatch_weight": 0.25,
            "right_horizontal_weight": 0.45,
            "right_oblique_weight": 0.35,
            "boundary_sigma": 0.24,
            "horizontal_sigma": 0.24,
            "oblique_sigma": 0.24,
            "mind_quantile_low": 0.50,
            "mind_quantile_high": 0.95,
            "sigmoid_center": 0.38,
            "sigmoid_temperature": 0.09,
            "gate_floor": 0.02,
            "support_dilation_kernel": 5,
            "smooth_kernel": 3,
            "f2_interface_boost": 1.35,
        },
        "stage_f1": {
            "name": "F1_RML_boundary",
            "gate_mode": "rml_boundary",
            "reduce_factor": 2,
            "control_factor": 4,
            "iterations": 140,
            "lr": 0.018,
            "max_residual_fullres_voxels": 0.60,
            "integration_steps": 6,
            "early_stop_patience": 45,
            "min_objective_improvement": 1.0e-6,
            "grad_clip": 1.0,
            "selection_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            "weights": {
                "rml_direct_dice": 0.70,
                "rml_consensus_dice": 1.00,
                "rml_sdf": 0.70,
                "right_horizontal": 0.55,
                "right_oblique": 0.35,
                "mind": 0.20,
                "structural_gradient": 0.10,
                "non_rml_preservation": 1.25,
                "outside_gate_magnitude": 0.15,
                "support": 0.03,
                "bending": 0.06,
                "residual_magnitude": 0.02,
                "jacobian": 35.0,
                "jacobian_margin": 0.025,
            },
        },
        "stage_f2": {
            "name": "F2_right_fissure_micro",
            "gate_mode": "right_fissure",
            "reduce_factor": 2,
            "control_factor": 3,
            "iterations": 180,
            "lr": 0.012,
            "max_residual_fullres_voxels": 0.45,
            "integration_steps": 6,
            "early_stop_patience": 55,
            "min_objective_improvement": 1.0e-6,
            "grad_clip": 1.0,
            "selection_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            "weights": {
                "rml_direct_dice": 0.55,
                "rml_consensus_dice": 0.85,
                "rml_sdf": 0.55,
                "right_horizontal": 1.00,
                "right_oblique": 0.85,
                "mind": 0.18,
                "structural_gradient": 0.12,
                "non_rml_preservation": 1.50,
                "outside_gate_magnitude": 0.20,
                "support": 0.03,
                "bending": 0.08,
                "residual_magnitude": 0.025,
                "jacobian": 40.0,
                "jacobian_margin": 0.025,
            },
        },
        "selection": {
            "min_composite_score_gain": 5.0e-5,
            "min_combined_rml_gain": -1.0e-5,
            "max_rml_direct_drop": 2.0e-4,
            "max_rml_consensus_drop": 1.5e-4,
            "max_global_direct_lobe_drop": 2.0e-4,
            "max_non_rml_preservation_drop": 7.5e-4,
            "max_support_dice_drop": 1.0e-3,
            "max_mind_loss_increase": 5.0e-4,
            "max_residual_p99_voxels": 1.0,
            "max_residual_max_voxels": 3.0,
            "topology_guard_mode": "relative_to_stage_input",
            "max_folding_increase_pct": 5.0e-5,
            "max_absolute_folding_pct": 1.0e-3,
            "score_rml_consensus_gain": 1.20,
            "score_rml_direct_gain": 0.70,
            "score_horizontal_gain": 0.70,
            "score_oblique_gain": 0.60,
            "score_sdf_gain": 0.55,
            "score_mind_gain": 0.25,
            "score_structural_gain": 0.15,
            "score_global_lobe_gain": 0.20,
            "score_non_rml_preservation_gain": 0.25,
            "score_support_gain": 0.03,
        },
        "evaluation": {
            "enabled": True,
            "device": "cuda",
            "initializer_metrics_json": "outputs/sgr_fm/lineage_propagation/B0/c5b_lmind/eval/validation_metrics.json",
        },
    }


def build_config(config_path: str | Path | None, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = default_config()
    if config_path is not None:
        recursive_update(cfg, load_yaml_or_json(config_path, root_key="sgr_fm_c6_rml_aware"))
    if overrides:
        recursive_update(cfg, overrides)
    return cfg


def validation_asset_paths(
    segmentation_dir: Path,
    initializer_dir: Path,
    secondary_initializer_dir: Path,
    history_c41_dir: Path,
    case_id: str,
) -> dict[str, Path]:
    out = c41_validation_asset_paths(
        segmentation_dir=segmentation_dir,
        initializer_dir=initializer_dir,
        secondary_initializer_dir=secondary_initializer_dir,
        case_id=case_id,
    )
    out["history_c41_canonical"] = history_c41_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz"
    return out


def load_case_tensors(
    *,
    exp_ct_path: Path,
    insp_ct_path: Path,
    assets: dict[str, Path],
    device: torch.device,
    ct_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
    consensus_cfg: dict[str, Any],
    rml_cfg: dict[str, Any],
    affine_atol: float = 1e-5,
) -> dict[str, Any]:
    base_assets = {k: v for k, v in assets.items() if k != "history_c41_canonical"}
    full = load_c41_case_tensors(
        exp_ct_path=exp_ct_path,
        insp_ct_path=insp_ct_path,
        assets=base_assets,
        device=device,
        ct_cfg=ct_cfg,
        anatomy_cfg=anatomy_cfg,
        consensus_cfg=consensus_cfg,
        affine_atol=affine_atol,
    )

    c41_np, _ = load_canonical_dvf(assets["history_c41_canonical"], insp_ct_path, affine_atol=affine_atol)
    c41_dvf = dvf_xyzc_to_tensor(c41_np, device=device)

    with torch.no_grad():
        moving_rml = full["moving_lobes"][:, RML_INDEX : RML_INDEX + 1]
        direct = full["fixed_direct_lobes"][:, RML_INDEX : RML_INDEX + 1].clamp(0.0, 1.0)
        final_view = warp_volume(moving_rml, full["init_dvf"], mode="bilinear").clamp(0.0, 1.0)
        c41_view = warp_volume(moving_rml, c41_dvf, mode="bilinear").clamp(0.0, 1.0)
        c2_view = warp_volume(moving_rml, full["secondary_dvf"], mode="bilinear").clamp(0.0, 1.0)

        wd = float(rml_cfg.get("direct_weight", 1.0))
        wf = float(rml_cfg.get("final_transport_weight", 1.0))
        w41 = float(rml_cfg.get("c41_transport_weight", 0.55))
        w2 = float(rml_cfg.get("c2_transport_weight", 0.25))
        weights = torch.tensor([wd, wf, w41, w2], device=device, dtype=direct.dtype).view(1, 4, 1, 1, 1)
        views = torch.cat([direct, final_view, c41_view, c2_view], dim=1)
        consensus = (views * weights).sum(dim=1, keepdim=True) / weights.sum().clamp_min(1.0e-6)
        mean = consensus
        variance = ((views - mean) ** 2 * weights).sum(dim=1, keepdim=True) / weights.sum().clamp_min(1.0e-6)
        uncertainty = (4.0 * variance).clamp(0.0, 1.0)
        sigma = max(float(rml_cfg.get("agreement_sigma", 0.20)), 1.0e-6)
        mad = (torch.abs(views - mean) * weights).sum(dim=1, keepdim=True) / weights.sum().clamp_min(1.0e-6)
        floor = float(rml_cfg.get("confidence_floor", 0.05))
        confidence = torch.exp(-mad / sigma).clamp(floor, 1.0)

        frozen_base_warped_lobes = warp_volume(full["moving_lobes"], full["init_dvf"], mode="bilinear").clamp(0.0, 1.0)

    full.update({
        "rml_consensus": consensus.detach(),
        "rml_confidence": confidence.detach(),
        "rml_uncertainty": uncertainty.detach(),
        "frozen_base_dvf": full["init_dvf"].detach().clone(),
        "frozen_base_warped_lobes": frozen_base_warped_lobes.detach(),
    })
    del c41_dvf, c41_np
    return full


def _resize(x: torch.Tensor, factor: int, mode: str) -> torch.Tensor:
    if factor == 1:
        return x
    size = tuple(max(1, int(round(v / factor))) for v in x.shape[-3:])
    if mode == "nearest":
        return F.interpolate(x, size=size, mode=mode)
    return F.interpolate(x, size=size, mode=mode, align_corners=True)


def channel_soft_dice(pred: torch.Tensor, target: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    if pred.shape != target.shape or pred.ndim != 5:
        raise ValueError(f"Expected matching [B,C,X,Y,Z], got {tuple(pred.shape)} and {tuple(target.shape)}")
    dims = (0, 2, 3, 4)
    inter = (pred * target).sum(dim=dims)
    denom = pred.sum(dim=dims) + target.sum(dim=dims)
    return (2.0 * inter + eps) / (denom + eps)


def _surface_distance_loss(
    *,
    warped_dist: torch.Tensor,
    target_dist: torch.Tensor,
    warped_surface: torch.Tensor,
    target_surface: torch.Tensor,
    eps: float = 1e-6,
) -> torch.Tensor:
    a = (target_surface * warped_dist).sum() / target_surface.sum().clamp_min(eps)
    b = (warped_surface * target_dist).sum() / warped_surface.sum().clamp_min(eps)
    return 0.5 * (a + b)


def rml_sdf_loss(
    warped_rml_sdf: torch.Tensor,
    target_rml_sdf: torch.Tensor,
    confidence: torch.Tensor,
    *,
    band_fraction: float,
    charbonnier_eps: float,
) -> torch.Tensor:
    band = ((warped_rml_sdf.abs() <= band_fraction) | (target_rml_sdf.abs() <= band_fraction)).float()
    weight = band * confidence.clamp(0.0, 1.0)
    robust = torch.sqrt((warped_rml_sdf - target_rml_sdf).square() + float(charbonnier_eps) ** 2)
    return (robust * weight).sum() / weight.sum().clamp_min(1.0)


def prepare_stage_state(
    full: dict[str, Any],
    *,
    current_dvf_full: torch.Tensor,
    reduce_factor: int,
    stage_cfg: dict[str, Any],
    priority_cfg: dict[str, Any],
    mind_cfg: dict[str, Any],
) -> dict[str, Any]:
    factor = int(reduce_factor)
    if factor < 1:
        raise ValueError("reduce_factor must be >= 1")
    state: dict[str, Any] = make_c41_lowres_state(full, reduce_factor=factor)
    state["init_dvf"] = current_dvf_full if factor == 1 else downsample_dvf_5d(current_dvf_full, factor)
    state["frozen_base_dvf"] = full["frozen_base_dvf"] if factor == 1 else downsample_dvf_5d(full["frozen_base_dvf"], factor)
    state["rml_consensus"] = _resize(full["rml_consensus"], factor, "trilinear")
    state["rml_confidence"] = _resize(full["rml_confidence"], factor, "trilinear")
    state["rml_uncertainty"] = _resize(full["rml_uncertainty"], factor, "trilinear")
    state["frozen_base_warped_lobes"] = _resize(full["frozen_base_warped_lobes"], factor, "trilinear")

    with torch.no_grad():
        prewarped_ct = warp_volume(state["moving_ct"], state["init_dvf"], mode="bilinear")
        fixed_mind = mind_ssc_3d(state["fixed_ct"], mind_cfg)
        prewarped_mind = mind_ssc_3d(prewarped_ct, mind_cfg)
        mismatch = mind_voxel_mismatch(fixed_mind, prewarped_mind)
        mismatch_norm, qlo, qhi = _robust_unit_normalize(
            mismatch,
            state["fixed_support"].clamp(0.0, 1.0),
            q_low=float(priority_cfg.get("mind_quantile_low", 0.50)),
            q_high=float(priority_cfg.get("mind_quantile_high", 0.95)),
        )

        rml_sdf = state["consensus_sdf"][:, RML_INDEX : RML_INDEX + 1].abs()
        bsigma = max(float(priority_cfg.get("boundary_sigma", 0.24)), 1.0e-6)
        boundary = torch.exp(-rml_sdf / bsigma)
        rh_dist = state["consensus_interface_dist"][:, RH_INTERFACE_INDEX : RH_INTERFACE_INDEX + 1].clamp_min(0.0)
        ro_dist = state["consensus_interface_dist"][:, RO_INTERFACE_INDEX : RO_INTERFACE_INDEX + 1].clamp_min(0.0)
        horizontal = torch.exp(-rh_dist / max(float(priority_cfg.get("horizontal_sigma", 0.24)), 1.0e-6))
        oblique = torch.exp(-ro_dist / max(float(priority_cfg.get("oblique_sigma", 0.24)), 1.0e-6))
        uncertainty = state["rml_uncertainty"].clamp(0.0, 1.0)

        wb = float(priority_cfg.get("boundary_weight", 0.55))
        wu = float(priority_cfg.get("uncertainty_weight", 0.35))
        wm = float(priority_cfg.get("mind_mismatch_weight", 0.25))
        wh = float(priority_cfg.get("right_horizontal_weight", 0.45))
        wo = float(priority_cfg.get("right_oblique_weight", 0.35))
        if str(stage_cfg.get("gate_mode", "rml_boundary")).lower() == "right_fissure":
            boost = float(priority_cfg.get("f2_interface_boost", 1.35))
            wh *= boost
            wo *= boost
            wb *= 0.75
        denom = max(wb + wu + wm + wh + wo, 1.0e-6)
        raw = (wb * boundary + wu * uncertainty + wm * mismatch_norm + wh * horizontal + wo * oblique) / denom
        center = float(priority_cfg.get("sigmoid_center", 0.38))
        temp = max(float(priority_cfg.get("sigmoid_temperature", 0.09)), 1.0e-6)
        active = torch.sigmoid((raw - center) / temp)

        right_lung = state["fixed_direct_lobes"][:, 2:5].sum(dim=1, keepdim=True).clamp(0.0, 1.0)
        k = int(priority_cfg.get("support_dilation_kernel", 5))
        if k < 1 or k % 2 == 0:
            raise ValueError("support_dilation_kernel must be positive odd")
        right_band = F.max_pool3d(right_lung, kernel_size=k, stride=1, padding=k // 2)
        sk = int(priority_cfg.get("smooth_kernel", 3))
        if sk < 1 or sk % 2 == 0:
            raise ValueError("smooth_kernel must be positive odd")
        if sk > 1:
            active = F.avg_pool3d(active, kernel_size=sk, stride=1, padding=sk // 2)
        floor = float(priority_cfg.get("gate_floor", 0.02))
        gate = right_band * (floor + (1.0 - floor) * active.clamp(0.0, 1.0))
        gate = gate.detach().clamp(0.0, 1.0)

    state.update({
        "fixed_mind": fixed_mind.detach(),
        "prewarped_mind": prewarped_mind.detach(),
        "priority_map": gate,
        "priority_components": {
            "rml_boundary": boundary.detach(),
            "uncertainty": uncertainty.detach(),
            "mind_mismatch_norm": mismatch_norm.detach(),
            "right_horizontal": horizontal.detach(),
            "right_oblique": oblique.detach(),
        },
        "priority_diagnostics": {
            "mind_mismatch_quantile_low": qlo,
            "mind_mismatch_quantile_high": qhi,
            "priority_mean": float(gate.mean().item()),
            "priority_p90": float(torch.quantile(gate.flatten().float(), 0.90).item()),
            "priority_p99": float(torch.quantile(gate.flatten().float(), 0.99).item()),
            "priority_fraction_gt_0_5": float((gate > 0.5).float().mean().item()),
            "rml_confidence_mean": float(state["rml_confidence"].mean().item()),
            "rml_uncertainty_mean": float(state["rml_uncertainty"].mean().item()),
        },
    })
    return state


def make_stage_parameter(
    target_shape: Sequence[int],
    *,
    stage_cfg: dict[str, Any],
    device: torch.device,
    dtype: torch.dtype,
) -> torch.nn.Parameter:
    return make_control_parameter(target_shape, int(stage_cfg.get("control_factor", 3)), device=device, dtype=dtype)


def build_localized_residual_dvf(
    param: torch.Tensor,
    *,
    target_shape: Sequence[int],
    full_shape: Sequence[int],
    stage_cfg: dict[str, Any],
    priority_map: torch.Tensor,
    scale: float = 1.0,
) -> torch.Tensor:
    svf = build_residual_svf(
        param,
        None,
        target_shape=target_shape,
        full_shape=full_shape,
        max_fullres_voxels=float(stage_cfg.get("max_residual_fullres_voxels", 0.45)),
        scale=float(scale),
    )
    if tuple(priority_map.shape[-3:]) != tuple(int(v) for v in target_shape):
        priority_map = F.interpolate(priority_map, size=tuple(int(v) for v in target_shape), mode="trilinear", align_corners=True)
    return integrate_svf(svf * priority_map.clamp(0.0, 1.0), int(stage_cfg.get("integration_steps", 6)))


def _metric_tensors(
    *,
    state: dict[str, Any],
    residual_dvf: torch.Tensor,
    ct_cfg: dict[str, Any],
    mind_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> dict[str, torch.Tensor]:
    final_dvf = compose_pull(state["init_dvf"], residual_dvf)
    warped_ct = warp_volume(state["moving_ct"], final_dvf, mode="bilinear")
    warped_lobes = warp_volume(state["moving_lobes"], final_dvf, mode="bilinear").clamp(0.0, 1.0)
    warped_support = warp_volume(state["moving_support"], final_dvf, mode="bilinear")
    warped_sdf = warp_volume(state["moving_sdf"], final_dvf, mode="bilinear")
    warped_idist = warp_volume(state["moving_interface_dist"], final_dvf, mode="bilinear")
    warped_isurf = warp_volume(state["moving_interface_surface"], final_dvf, mode="bilinear").clamp(0.0, 1.0)

    rml = warped_lobes[:, RML_INDEX : RML_INDEX + 1]
    direct_rml = binary_soft_dice(rml, state["fixed_direct_lobes"][:, RML_INDEX : RML_INDEX + 1])
    consensus_rml = binary_soft_dice(rml, state["rml_consensus"])
    global_lobe = channel_soft_dice(warped_lobes, state["fixed_direct_lobes"]).mean()
    non_rml_pres = channel_soft_dice(
        warped_lobes[:, NON_RML_INDICES],
        state["frozen_base_warped_lobes"][:, NON_RML_INDICES],
    ).mean()
    support = binary_soft_dice(warped_support, state["fixed_support"])
    sdf = rml_sdf_loss(
        warped_sdf[:, RML_INDEX : RML_INDEX + 1],
        state["consensus_sdf"][:, RML_INDEX : RML_INDEX + 1],
        state["rml_confidence"],
        band_fraction=float(anatomy_cfg.get("sdf_band_fraction", 0.75)),
        charbonnier_eps=float(anatomy_cfg.get("charbonnier_eps", 1.0e-3)),
    )
    rh = _surface_distance_loss(
        warped_dist=warped_idist[:, RH_INTERFACE_INDEX : RH_INTERFACE_INDEX + 1],
        target_dist=state["consensus_interface_dist"][:, RH_INTERFACE_INDEX : RH_INTERFACE_INDEX + 1],
        warped_surface=warped_isurf[:, RH_INTERFACE_INDEX : RH_INTERFACE_INDEX + 1],
        target_surface=state["consensus_interface_surface"][:, RH_INTERFACE_INDEX : RH_INTERFACE_INDEX + 1],
    )
    ro = _surface_distance_loss(
        warped_dist=warped_idist[:, RO_INTERFACE_INDEX : RO_INTERFACE_INDEX + 1],
        target_dist=state["consensus_interface_dist"][:, RO_INTERFACE_INDEX : RO_INTERFACE_INDEX + 1],
        warped_surface=warped_isurf[:, RO_INTERFACE_INDEX : RO_INTERFACE_INDEX + 1],
        target_surface=state["consensus_interface_surface"][:, RO_INTERFACE_INDEX : RO_INTERFACE_INDEX + 1],
    )
    mind = mind_weighted_loss(
        fixed_mind=state["fixed_mind"],
        prewarped_moving_mind=state["prewarped_mind"],
        residual_dvf=residual_dvf,
        priority_map=state["priority_map"],
        mind_cfg=mind_cfg,
    )
    structural = structural_gradient_loss(
        state["fixed_ct"], warped_ct, state["priority_map"],
        min_magnitude=float(ct_cfg.get("gradient_min_magnitude", 0.03)),
    )
    return {
        "rml_direct_dice": direct_rml,
        "rml_consensus_dice": consensus_rml,
        "global_direct_lobe_dice": global_lobe,
        "non_rml_preservation_dice": non_rml_pres,
        "proxy_support_dice": support,
        "rml_sdf_loss": sdf,
        "right_horizontal_loss": rh,
        "right_oblique_loss": ro,
        "mind_loss": mind,
        "structural_gradient_loss": structural,
        "final_dvf": final_dvf,
    }


def compute_proxy_metrics(
    *,
    state: dict[str, Any],
    residual_dvf: torch.Tensor,
    ct_cfg: dict[str, Any],
    mind_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> dict[str, float]:
    with torch.no_grad():
        t = _metric_tensors(state=state, residual_dvf=residual_dvf, ct_cfg=ct_cfg, mind_cfg=mind_cfg, anatomy_cfg=anatomy_cfg)
        return {k: float(v.item()) for k, v in t.items() if k != "final_dvf"}


def objective_terms(
    *,
    state: dict[str, Any],
    residual_dvf: torch.Tensor,
    weights: dict[str, Any],
    ct_cfg: dict[str, Any],
    mind_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    t = _metric_tensors(state=state, residual_dvf=residual_dvf, ct_cfg=ct_cfg, mind_cfg=mind_cfg, anatomy_cfg=anatomy_cfg)
    final_dvf = t.pop("final_dvf")
    bend = bending_energy(residual_dvf)
    magnitude = residual_dvf.square().mean()
    outside = 1.0 - state["priority_map"].clamp(0.0, 1.0)
    outside_mag = (residual_dvf.square().sum(dim=1, keepdim=True) * outside).sum() / outside.sum().clamp_min(1.0)
    jac, folding_pct, min_det = jacobian_barrier(final_dvf, margin=float(weights.get("jacobian_margin", 0.025)))

    total = (
        float(weights.get("rml_direct_dice", 0.0)) * (1.0 - t["rml_direct_dice"])
        + float(weights.get("rml_consensus_dice", 0.0)) * (1.0 - t["rml_consensus_dice"])
        + float(weights.get("rml_sdf", 0.0)) * t["rml_sdf_loss"]
        + float(weights.get("right_horizontal", 0.0)) * t["right_horizontal_loss"]
        + float(weights.get("right_oblique", 0.0)) * t["right_oblique_loss"]
        + float(weights.get("mind", 0.0)) * t["mind_loss"]
        + float(weights.get("structural_gradient", 0.0)) * t["structural_gradient_loss"]
        + float(weights.get("non_rml_preservation", 0.0)) * (1.0 - t["non_rml_preservation_dice"])
        + float(weights.get("outside_gate_magnitude", 0.0)) * outside_mag
        + float(weights.get("support", 0.0)) * (1.0 - t["proxy_support_dice"])
        + float(weights.get("bending", 0.0)) * bend
        + float(weights.get("residual_magnitude", 0.0)) * magnitude
        + float(weights.get("jacobian", 0.0)) * jac
    )
    terms = dict(t)
    terms.update({
        "total": total,
        "outside_gate_magnitude": outside_mag,
        "bending": bend,
        "residual_magnitude": magnitude,
        "jacobian_loss": jac,
        "folding_pct": folding_pct,
        "min_det": min_det,
    })
    return total, terms


def tensor_terms_to_float(terms: dict[str, torch.Tensor]) -> dict[str, float]:
    return {k: float(v.detach().float().item()) for k, v in terms.items()}


def candidate_score(candidate: dict[str, float], baseline: dict[str, float], selection: dict[str, Any]) -> float:
    return (
        float(selection.get("score_rml_consensus_gain", 1.20)) * (candidate["rml_consensus_dice"] - baseline["rml_consensus_dice"])
        + float(selection.get("score_rml_direct_gain", 0.70)) * (candidate["rml_direct_dice"] - baseline["rml_direct_dice"])
        + float(selection.get("score_horizontal_gain", 0.70)) * (baseline["right_horizontal_loss"] - candidate["right_horizontal_loss"])
        + float(selection.get("score_oblique_gain", 0.60)) * (baseline["right_oblique_loss"] - candidate["right_oblique_loss"])
        + float(selection.get("score_sdf_gain", 0.55)) * (baseline["rml_sdf_loss"] - candidate["rml_sdf_loss"])
        + float(selection.get("score_mind_gain", 0.25)) * (baseline["mind_loss"] - candidate["mind_loss"])
        + float(selection.get("score_structural_gain", 0.15)) * (baseline["structural_gradient_loss"] - candidate["structural_gradient_loss"])
        + float(selection.get("score_global_lobe_gain", 0.20)) * (candidate["global_direct_lobe_dice"] - baseline["global_direct_lobe_dice"])
        + float(selection.get("score_non_rml_preservation_gain", 0.25)) * (candidate["non_rml_preservation_dice"] - baseline["non_rml_preservation_dice"])
        + float(selection.get("score_support_gain", 0.03)) * (candidate["proxy_support_dice"] - baseline["proxy_support_dice"])
    )


def topology_folding_limit(*, baseline_folding_pct: float, selection: dict[str, Any]) -> float:
    mode = str(selection.get("topology_guard_mode", "relative_to_stage_input")).lower()
    max_abs = float(selection.get("max_absolute_folding_pct", 1.0e-3))
    max_inc = float(selection.get("max_folding_increase_pct", 5.0e-5))
    if mode in {"relative_to_stage_input", "relative_to_initializer"}:
        return min(max_abs, float(baseline_folding_pct) + max_inc)
    if mode == "absolute":
        return max_abs
    raise ValueError(f"Unsupported topology_guard_mode={mode!r}")


def passes_acceptance(
    candidate: dict[str, float],
    baseline: dict[str, float],
    *,
    baseline_folding_pct: float,
    selection: dict[str, Any],
) -> tuple[bool, list[str], float, float]:
    reasons: list[str] = []
    score = candidate_score(candidate, baseline, selection)
    rml_direct_gain = candidate["rml_direct_dice"] - baseline["rml_direct_dice"]
    rml_cons_gain = candidate["rml_consensus_dice"] - baseline["rml_consensus_dice"]
    combined_rml_gain = 0.5 * (rml_direct_gain + rml_cons_gain)
    fold_limit = topology_folding_limit(baseline_folding_pct=baseline_folding_pct, selection=selection)

    checks = [
        (score < float(selection.get("min_composite_score_gain", 5.0e-5)), f"composite_score_gain={score:.6g} below minimum"),
        (combined_rml_gain < float(selection.get("min_combined_rml_gain", -1.0e-5)), f"combined_rml_gain={combined_rml_gain:.6g} below minimum"),
        (-rml_direct_gain > float(selection.get("max_rml_direct_drop", 2.0e-4)), f"rml_direct_drop={-rml_direct_gain:.6g} above maximum"),
        (-rml_cons_gain > float(selection.get("max_rml_consensus_drop", 1.5e-4)), f"rml_consensus_drop={-rml_cons_gain:.6g} above maximum"),
        (baseline["global_direct_lobe_dice"] - candidate["global_direct_lobe_dice"] > float(selection.get("max_global_direct_lobe_drop", 2.0e-4)), "global_direct_lobe_drop above maximum"),
        (baseline["non_rml_preservation_dice"] - candidate["non_rml_preservation_dice"] > float(selection.get("max_non_rml_preservation_drop", 7.5e-4)), "non_rml_preservation_drop above maximum"),
        (baseline["proxy_support_dice"] - candidate["proxy_support_dice"] > float(selection.get("max_support_dice_drop", 1.0e-3)), "support_dice_drop above maximum"),
        (candidate["mind_loss"] - baseline["mind_loss"] > float(selection.get("max_mind_loss_increase", 5.0e-4)), "mind_loss_increase above maximum"),
        (candidate["residual_norm_p99_vox"] > float(selection.get("max_residual_p99_voxels", 1.0)), "residual_p99 above maximum"),
        (candidate["residual_norm_max_vox"] > float(selection.get("max_residual_max_voxels", 3.0)), "residual_max above maximum"),
        (candidate["folding_pct"] > fold_limit + 1.0e-12, f"folding_pct={candidate['folding_pct']:.6g} above limit={fold_limit:.6g}"),
    ]
    reasons.extend(msg for failed, msg in checks if failed)
    return len(reasons) == 0, reasons, float(fold_limit), float(score)


def clone_parameter_state(params: Sequence[torch.Tensor]) -> list[torch.Tensor]:
    return [p.detach().clone() for p in params]


def restore_parameter_state(params: Sequence[torch.Tensor], state: Sequence[torch.Tensor]) -> None:
    if len(params) != len(state):
        raise ValueError("Parameter state length mismatch")
    with torch.no_grad():
        for param, value in zip(params, state):
            param.copy_(value)
