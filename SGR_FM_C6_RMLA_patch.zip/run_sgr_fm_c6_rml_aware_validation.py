#!/usr/bin/env python3
"""Run SGR-FM C6-RMLA on Learn2Breath validation.

The frozen B0 full-lineage C5b result is the immutable initializer. Two small,
confidence-aware residual stages target the RML boundary and the right
horizontal/oblique fissures while explicitly preserving all non-RML lobes.
Validation ground truth is used only after DVFs are written by the existing
evaluator.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.data import discover_validation_cases
from utils.dvf_io import canonical_ras_cxyz_to_original_dvf_xyzc, save_dvf_xyzc
from utils.sgr_fm_c3 import atomic_save_nifti_xyzc, compose_pull, dvf_tensor_to_xyzc
from utils.sgr_fm_c6_rml_aware import (
    build_config,
    build_localized_residual_dvf,
    clone_parameter_state,
    compute_proxy_metrics,
    load_case_tensors,
    make_stage_parameter,
    objective_terms,
    passes_acceptance,
    prepare_stage_state,
    residual_norm_stats,
    restore_parameter_state,
    sha256_json,
    tensor_terms_to_float,
    topology_stats,
    validation_asset_paths,
)
from utils.sgr_fm_segmentation import assert_safe_output_dir, atomic_write_json, write_csv
from utils.sgr_fm_training_assets import resolve_under_project


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="SGR-FM C6 RML-aware right-fissure refinement.")
    p.add_argument("--config", default="configs/sgr_fm_c6_rml_aware.yaml")
    p.add_argument("--case-ids", nargs="*", default=None)
    p.add_argument("--output-dir", default=None)
    p.add_argument("--device", default=None)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--skip-evaluation", action="store_true")
    return p.parse_args()


def _resolve_config(args: argparse.Namespace) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    if args.case_ids is not None:
        overrides["case_ids"] = list(args.case_ids)
    if args.output_dir is not None:
        overrides["output_dir"] = args.output_dir
    if args.device is not None:
        overrides["device"] = args.device
    if args.overwrite:
        overrides["overwrite"] = True
    cfg = build_config(args.config, overrides)
    for key in (
        "raw_data_root",
        "segmentation_dir",
        "initializer_dir",
        "secondary_initializer_dir",
        "history_c41_dir",
        "output_dir",
    ):
        cfg[key] = str(resolve_under_project(PROJECT_ROOT, cfg[key]))
    return cfg


def _read_run_meta(run_dir: Path) -> dict[str, Any]:
    path = run_dir / "run_config_resolved.json"
    if not path.exists():
        raise FileNotFoundError(f"Missing run config: {path}")
    meta = json.loads(path.read_text(encoding="utf-8"))
    if not str(meta.get("method_fingerprint_sha256", "")):
        raise RuntimeError(f"Missing method_fingerprint_sha256 in {path}")
    return meta


def _optimize_stage(
    *,
    stage_cfg: dict[str, Any],
    param: torch.nn.Parameter,
    state: dict[str, Any],
    full_shape: tuple[int, int, int],
    ct_cfg: dict[str, Any],
    mind_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
    trace: list[dict[str, Any]],
) -> dict[str, Any]:
    stage_name = str(stage_cfg["name"])
    iterations = int(stage_cfg.get("iterations", 160))
    optimizer = torch.optim.Adam([param], lr=float(stage_cfg.get("lr", 0.015)))
    patience = int(stage_cfg.get("early_stop_patience", 50))
    min_improvement = float(stage_cfg.get("min_objective_improvement", 1.0e-6))
    grad_clip = float(stage_cfg.get("grad_clip", 1.0))
    weights = dict(stage_cfg.get("weights", {}))

    best_value = float("inf")
    best_state = clone_parameter_state([param])
    best_iter = 0
    stale = 0
    completed = 0

    for iteration in range(1, iterations + 1):
        completed = iteration
        optimizer.zero_grad(set_to_none=True)
        residual = build_localized_residual_dvf(
            param,
            target_shape=state["init_dvf"].shape[-3:],
            full_shape=full_shape,
            stage_cfg=stage_cfg,
            priority_map=state["priority_map"],
            scale=1.0,
        )
        total, terms = objective_terms(
            state=state,
            residual_dvf=residual,
            weights=weights,
            ct_cfg=ct_cfg,
            mind_cfg=mind_cfg,
            anatomy_cfg=anatomy_cfg,
        )
        if not torch.isfinite(total):
            raise RuntimeError(f"{stage_name}: non-finite objective at iteration {iteration}")
        total.backward()
        if grad_clip > 0.0:
            torch.nn.utils.clip_grad_norm_([param], max_norm=grad_clip)

        value = float(total.detach().item())
        trace.append({"stage": stage_name, "iteration": iteration, **tensor_terms_to_float(terms)})
        state_now = clone_parameter_state([param])
        if value < best_value - min_improvement:
            best_value = value
            best_state = state_now
            best_iter = iteration
            stale = 0
        else:
            stale += 1
        optimizer.step()
        if stale >= patience:
            break

    restore_parameter_state([param], best_state)
    return {
        "stage": stage_name,
        "requested_iterations": iterations,
        "completed_iterations": completed,
        "best_iteration": int(best_iter),
        "best_objective": float(best_value),
        "early_stopped": bool(stale >= patience),
        "reduce_factor": int(stage_cfg.get("reduce_factor", 2)),
        "control_factor": int(stage_cfg.get("control_factor", 3)),
        "max_residual_fullres_voxels": float(stage_cfg.get("max_residual_fullres_voxels", 0.45)),
    }


def _select_stage(
    *,
    full: dict[str, Any],
    current_full: torch.Tensor,
    stage_cfg: dict[str, Any],
    priority_cfg: dict[str, Any],
    selection_cfg: dict[str, Any],
    ct_cfg: dict[str, Any],
    mind_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
    device: torch.device,
    trace: list[dict[str, Any]],
) -> tuple[torch.Tensor, dict[str, Any]]:
    reduce_factor = int(stage_cfg.get("reduce_factor", 2))
    state = prepare_stage_state(
        full,
        current_dvf_full=current_full,
        reduce_factor=reduce_factor,
        stage_cfg=stage_cfg,
        priority_cfg=priority_cfg,
        mind_cfg=mind_cfg,
    )
    zero = torch.zeros_like(state["init_dvf"])
    baseline_proxy = compute_proxy_metrics(
        state=state,
        residual_dvf=zero,
        ct_cfg=ct_cfg,
        mind_cfg=mind_cfg,
        anatomy_cfg=anatomy_cfg,
    )
    baseline_topology = topology_stats(current_full)

    param = make_stage_parameter(
        state["init_dvf"].shape[-3:],
        stage_cfg=stage_cfg,
        device=device,
        dtype=state["init_dvf"].dtype,
    )
    optimization = _optimize_stage(
        stage_cfg=stage_cfg,
        param=param,
        state=state,
        full_shape=full["full_shape"],
        ct_cfg=ct_cfg,
        mind_cfg=mind_cfg,
        anatomy_cfg=anatomy_cfg,
        trace=trace,
    )

    scales = [float(v) for v in stage_cfg.get("selection_scales", [1.0, 0.75, 0.5, 0.25, 0.125, 0.0])]
    if 0.0 not in scales:
        raise ValueError(f"{stage_cfg['name']}: selection_scales must include 0.0")
    if any((s < 0.0 or s > 1.0) for s in scales):
        raise ValueError(f"{stage_cfg['name']}: scales must be in [0,1], got {scales}")

    rows: list[dict[str, Any]] = []
    accepted: list[tuple[float, dict[str, Any], torch.Tensor]] = []
    for scale in scales:
        with torch.no_grad():
            residual_low = build_localized_residual_dvf(
                param,
                target_shape=state["init_dvf"].shape[-3:],
                full_shape=full["full_shape"],
                stage_cfg=stage_cfg,
                priority_map=state["priority_map"],
                scale=scale,
            )
            proxy = compute_proxy_metrics(
                state=state,
                residual_dvf=residual_low,
                ct_cfg=ct_cfg,
                mind_cfg=mind_cfg,
                anatomy_cfg=anatomy_cfg,
            )
            residual_full = build_localized_residual_dvf(
                param,
                target_shape=current_full.shape[-3:],
                full_shape=full["full_shape"],
                stage_cfg=stage_cfg,
                priority_map=state["priority_map"],
                scale=scale,
            )
            final_full = compose_pull(current_full, residual_full)
            metrics = {**proxy, **topology_stats(final_full), **residual_norm_stats(residual_full)}
            ok, reasons, fold_limit, score = passes_acceptance(
                metrics,
                baseline_proxy,
                baseline_folding_pct=float(baseline_topology["folding_pct"]),
                selection=selection_cfg,
            )
            if scale == 0.0:
                ok = False
                reasons = [*reasons, "scale=0 reserved for exact stage no-op"]
            row = {
                "scale": scale,
                "score": float(score),
                "accepted": bool(ok),
                "rejection_reasons": reasons,
                "folding_limit_pct": float(fold_limit),
                **metrics,
            }
            rows.append(row)
            if ok:
                accepted.append((float(score), row, final_full.detach().clone()))

    if accepted:
        accepted.sort(key=lambda x: x[0], reverse=True)
        _, selected, next_full = accepted[0]
        decision = "apply"
    else:
        selected = next(r for r in rows if float(r["scale"]) == 0.0)
        next_full = current_full.detach().clone()
        decision = "noop"

    stage_record = {
        "stage": str(stage_cfg["name"]),
        "decision": decision,
        "baseline_proxy": baseline_proxy,
        "baseline_topology_fullres": baseline_topology,
        "priority_diagnostics": state["priority_diagnostics"],
        "optimization": optimization,
        "selection_candidates": rows,
        "selected": selected,
        "final_topology_fullres": topology_stats(next_full),
    }
    del state, param
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return next_full, stage_record


def _compare_metrics(init_json: Path, final_json: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    a = json.loads(init_json.read_text(encoding="utf-8"))
    b = json.loads(final_json.read_text(encoding="utf-8"))
    ar = {str(r["case_id"]): r for r in a.get("case_metrics", [])}
    br = {str(r["case_id"]): r for r in b.get("case_metrics", [])}
    common = sorted(set(ar) & set(br))
    rows: list[dict[str, Any]] = []
    for cid in common:
        x, y = ar[cid], br[cid]
        rows.append({
            "case_id": cid,
            "B0_mean_lobe_dice": float(x["mean_lobe_dice"]),
            "C6_mean_lobe_dice": float(y["mean_lobe_dice"]),
            "delta_dice": float(y["mean_lobe_dice"] - x["mean_lobe_dice"]),
            "B0_RML_dice": float(x["dice_64"]),
            "C6_RML_dice": float(y["dice_64"]),
            "delta_RML_dice": float(y["dice_64"] - x["dice_64"]),
            "B0_folding_percentage": float(x["folding_percentage"]),
            "C6_folding_percentage": float(y["folding_percentage"]),
            "delta_folding_percentage": float(y["folding_percentage"] - x["folding_percentage"]),
        })
    dd = np.asarray([r["delta_dice"] for r in rows], dtype=np.float64)
    dr = np.asarray([r["delta_RML_dice"] for r in rows], dtype=np.float64)
    summary = {
        "common_case_count": len(rows),
        "B0_mean_lobe_dice": float(a["mean_lobe_dice"]),
        "C6_mean_lobe_dice": float(b["mean_lobe_dice"]),
        "delta_mean_lobe_dice": float(b["mean_lobe_dice"] - a["mean_lobe_dice"]),
        "B0_mean_folding_percentage": float(a["mean_folding_percentage"]),
        "C6_mean_folding_percentage": float(b["mean_folding_percentage"]),
        "delta_mean_folding_percentage": float(b["mean_folding_percentage"] - a["mean_folding_percentage"]),
        "B0_mean_RML_dice": float(np.mean([ar[c]["dice_64"] for c in common])) if common else None,
        "C6_mean_RML_dice": float(np.mean([br[c]["dice_64"] for c in common])) if common else None,
        "delta_mean_RML_dice": float(dr.mean()) if len(dr) else None,
        "improved_cases": int(np.sum(dd > 0)) if len(dd) else 0,
        "worsened_cases": int(np.sum(dd < 0)) if len(dd) else 0,
        "improved_RML_cases": int(np.sum(dr > 0)) if len(dr) else 0,
        "worsened_RML_cases": int(np.sum(dr < 0)) if len(dr) else 0,
        "min_paired_dice_delta": float(dd.min()) if len(dd) else None,
        "max_paired_dice_delta": float(dd.max()) if len(dd) else None,
        "min_paired_RML_delta": float(dr.min()) if len(dr) else None,
        "max_paired_RML_delta": float(dr.max()) if len(dr) else None,
    }
    return summary, rows


def main() -> int:
    args = parse_args()
    config = _resolve_config(args)
    raw_root = Path(config["raw_data_root"])
    segmentation_dir = Path(config["segmentation_dir"])
    initializer_dir = Path(config["initializer_dir"])
    secondary_dir = Path(config["secondary_initializer_dir"])
    history_c41_dir = Path(config["history_c41_dir"])
    output_dir = Path(config["output_dir"])
    assert_safe_output_dir(output_dir, PROJECT_ROOT)

    init_meta = _read_run_meta(initializer_dir)
    init_fp = str(init_meta["method_fingerprint_sha256"])
    if bool(config.get("require_initializer_fingerprint", True)) and init_fp != str(config.get("accepted_initializer_method_fingerprint", "")):
        raise RuntimeError(f"B0 final initializer fingerprint mismatch: expected={config.get('accepted_initializer_method_fingerprint')} actual={init_fp}")

    secondary_meta = _read_run_meta(secondary_dir)
    secondary_fp = str(secondary_meta["method_fingerprint_sha256"])
    if bool(config.get("require_secondary_fingerprint", True)) and secondary_fp != str(config.get("accepted_secondary_method_fingerprint", "")):
        raise RuntimeError(f"B0 C2R secondary fingerprint mismatch: expected={config.get('accepted_secondary_method_fingerprint')} actual={secondary_fp}")

    history_meta = _read_run_meta(history_c41_dir)
    history_fp = str(history_meta["method_fingerprint_sha256"])
    expected_parent = str(init_meta.get("verified_initializer_method_fingerprint", ""))
    if bool(config.get("require_history_parent_match", True)):
        if not expected_parent:
            raise RuntimeError("B0 final run config does not record verified_initializer_method_fingerprint")
        if history_fp != expected_parent:
            raise RuntimeError(f"B0 C4.1 history mismatch: final expected parent={expected_parent} actual={history_fp}")

    recorded_secondary = str(init_meta.get("verified_secondary_method_fingerprint", ""))
    if recorded_secondary and recorded_secondary != secondary_fp:
        raise RuntimeError(f"B0 final secondary ancestry mismatch: recorded={recorded_secondary} actual={secondary_fp}")

    method_fp = sha256_json({
        "ct": config["ct"],
        "anatomy": config["anatomy"],
        "consensus": config["consensus"],
        "rml_consensus": config["rml_consensus"],
        "mind": config["mind"],
        "priority": config["priority"],
        "stage_f1": config["stage_f1"],
        "stage_f2": config["stage_f2"],
        "selection": config["selection"],
        "initializer_fingerprint": init_fp,
        "secondary_fingerprint": secondary_fp,
        "history_c41_fingerprint": history_fp,
    })

    previous = output_dir / "run_config_resolved.json"
    if previous.exists() and not bool(config.get("overwrite", False)):
        old = json.loads(previous.read_text(encoding="utf-8"))
        old_fp = str(old.get("method_fingerprint_sha256", ""))
        if old_fp and old_fp != method_fp:
            raise RuntimeError(f"C6 output contains a different configuration: existing={old_fp} current={method_fp}")

    cases = discover_validation_cases(raw_root)
    requested = {str(v) for v in config.get("case_ids", [])}
    if requested:
        cases = [c for c in cases if c.case_id in requested]
        missing = sorted(requested - {c.case_id for c in cases})
        if missing:
            raise FileNotFoundError(f"Requested cases not found: {missing}")
    if not cases:
        raise RuntimeError("No validation cases selected")

    device_name = str(config.get("device", "cuda"))
    if device_name.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    device = torch.device(device_name)

    for sub in ("dvfs", "dvfs_canonical_ras", "case_manifests", "traces", "eval", "comparison"):
        (output_dir / sub).mkdir(parents=True, exist_ok=True)

    atomic_write_json(output_dir / "run_config_resolved.json", {
        "schema_version": 1,
        "experiment": "SGR-FM C6-RMLA confidence-aware RML/right-fissure refinement",
        "config": config,
        "case_count": len(cases),
        "dry_run": bool(args.dry_run),
        "method_fingerprint_sha256": method_fp,
        "verified_initializer_method_fingerprint": init_fp,
        "verified_secondary_method_fingerprint": secondary_fp,
        "verified_history_c41_method_fingerprint": history_fp,
        "critical_note": "Optimization uses predicted anatomy/raw CT/MIND/B0-lineage transports only; validation GT is evaluation-only.",
    })

    records: list[dict[str, Any]] = []
    for idx, case in enumerate(cases, start=1):
        started = time.time()
        print(f"[{idx:02d}/{len(cases):02d}] {case.case_id}", flush=True)
        assets = validation_asset_paths(segmentation_dir, initializer_dir, secondary_dir, history_c41_dir, case.case_id)
        out_original = output_dir / "dvfs" / f"{case.case_id}_DVF.nii.gz"
        out_canonical = output_dir / "dvfs_canonical_ras" / f"{case.case_id}_DVF_RAS_XYZC_voxel.nii.gz"
        manifest_path = output_dir / "case_manifests" / f"{case.case_id}.json"
        trace_path = output_dir / "traces" / f"{case.case_id}.csv"
        record: dict[str, Any] = {
            "case_id": case.case_id,
            "status": "started",
            "EXP": str(case.exp_ct),
            "INSP": str(case.insp_ct),
            "assets": {k: str(v) for k, v in assets.items()},
            "output_dvf": str(out_original),
            "output_canonical_dvf": str(out_canonical),
        }
        try:
            if out_original.exists() and out_canonical.exists() and not bool(config.get("overwrite", False)):
                record["status"] = "reused"
                record["elapsed_sec"] = float(time.time() - started)
                records.append(record)
                continue

            if args.dry_run:
                for name, path in assets.items():
                    if not path.exists():
                        raise FileNotFoundError(f"Missing {name}: {path}")
                record["status"] = "dry_run"
                record["elapsed_sec"] = 0.0
                records.append(record)
                atomic_write_json(manifest_path, record)
                continue

            full = load_case_tensors(
                exp_ct_path=case.exp_ct,
                insp_ct_path=case.insp_ct,
                assets=assets,
                device=device,
                ct_cfg=config["ct"],
                anatomy_cfg=config["anatomy"],
                consensus_cfg=config["consensus"],
                rml_cfg=config["rml_consensus"],
            )
            current_full = full["init_dvf"].detach().clone()
            record["initializer_topology_fullres"] = topology_stats(current_full)
            record["rml_consensus_diagnostics"] = {
                "confidence_mean": float(full["rml_confidence"].mean().item()),
                "uncertainty_mean": float(full["rml_uncertainty"].mean().item()),
            }

            trace: list[dict[str, Any]] = []
            applied_any = False
            stage_records: list[dict[str, Any]] = []
            for stage_key in ("stage_f1", "stage_f2"):
                next_full, stage_record = _select_stage(
                    full=full,
                    current_full=current_full,
                    stage_cfg=config[stage_key],
                    priority_cfg=config["priority"],
                    selection_cfg=config["selection"],
                    ct_cfg=config["ct"],
                    mind_cfg=config["mind"],
                    anatomy_cfg=config["anatomy"],
                    device=device,
                    trace=trace,
                )
                if stage_record["decision"] == "apply":
                    applied_any = True
                current_full = next_full
                stage_records.append(stage_record)
                print(
                    f"  {stage_record['stage']}: {stage_record['decision']} "
                    f"scale={stage_record['selected']['scale']} score={stage_record['selected']['score']:+.6f} "
                    f"RML={stage_record['selected']['rml_direct_dice']:.6f} "
                    f"nonRML={stage_record['selected']['non_rml_preservation_dice']:.6f} "
                    f"fold={stage_record['selected']['folding_pct']:.6g}%",
                    flush=True,
                )

            record["stages"] = stage_records
            record["decision"] = "apply" if applied_any else "exact_B0_fallback"
            record["final_topology_fullres"] = topology_stats(current_full)
            record["fallback_exact_B0_copy"] = not applied_any
            if trace:
                write_csv(trace_path, trace)

            if not applied_any:
                shutil.copy2(assets["initializer_canonical"], out_canonical)
                shutil.copy2(assets["initializer_original"], out_original)
            else:
                canonical_xyzc = dvf_tensor_to_xyzc(current_full)
                if not np.isfinite(canonical_xyzc).all():
                    raise RuntimeError("Final canonical DVF contains NaN/Inf")
                atomic_save_nifti_xyzc(canonical_xyzc, full["canonical_reference"], out_canonical)
                original_xyzc = canonical_ras_cxyz_to_original_dvf_xyzc(np.moveaxis(canonical_xyzc, -1, 0), case.insp_ct)
                save_dvf_xyzc(original_xyzc, case.insp_ct, out_original)

            record["status"] = "ok"
            record["elapsed_sec"] = float(time.time() - started)
            atomic_write_json(manifest_path, record)
            records.append(record)
            del full, current_full
            if device.type == "cuda":
                torch.cuda.empty_cache()
        except Exception as exc:
            record["status"] = "failed"
            record["error"] = f"{type(exc).__name__}: {exc}"
            record["traceback"] = traceback.format_exc()
            record["elapsed_sec"] = float(time.time() - started)
            records.append(record)
            atomic_write_json(manifest_path, record)
            print(record["error"], file=sys.stderr, flush=True)
            if bool(config.get("stop_on_error", True)):
                break

    ok_count = sum(r["status"] in {"ok", "reused", "dry_run"} for r in records)
    failed_count = sum(r["status"] == "failed" for r in records)
    summary: dict[str, Any] = {
        "schema_version": 1,
        "experiment": "SGR-FM C6-RMLA confidence-aware RML/right-fissure refinement",
        "status": "PASS" if failed_count == 0 and ok_count == len(cases) else "FAIL",
        "case_count": len(cases),
        "processed_count": ok_count,
        "failed_count": failed_count,
        "output_dir": str(output_dir),
        "initializer_dir": str(initializer_dir),
        "secondary_initializer_dir": str(secondary_dir),
        "history_c41_dir": str(history_c41_dir),
        "records": records,
    }

    eval_enabled = bool(config.get("evaluation", {}).get("enabled", True)) and not args.skip_evaluation and not args.dry_run
    if summary["status"] == "PASS" and eval_enabled and len(cases) == 10:
        eval_dir = output_dir / "eval"
        command = [
            sys.executable,
            str(PROJECT_ROOT / "evaluate_validation.py"),
            "--raw-data-root", str(raw_root),
            "--dvf-dir", str(output_dir / "dvfs"),
            "--output-dir", str(eval_dir),
            "--device", str(config.get("evaluation", {}).get("device", config.get("device", "cuda"))),
        ]
        proc = subprocess.run(command, cwd=str(PROJECT_ROOT), check=False)
        summary["evaluation"] = {"command": command, "exit_code": int(proc.returncode)}
        if proc.returncode != 0:
            summary["status"] = "FAIL"
        else:
            init_json = resolve_under_project(PROJECT_ROOT, config["evaluation"]["initializer_metrics_json"])
            final_json = eval_dir / "validation_metrics.json"
            if init_json.exists() and final_json.exists():
                comparison, rows = _compare_metrics(init_json, final_json)
                atomic_write_json(output_dir / "comparison" / "B0_vs_C6_RMLA_summary.json", comparison)
                write_csv(output_dir / "comparison" / "B0_vs_C6_RMLA_per_case.csv", rows)
                summary["comparison"] = comparison
            else:
                summary["comparison_warning"] = f"Missing metrics: B0={init_json.exists()} C6={final_json.exists()}"

    atomic_write_json(output_dir / "c6_rml_aware_summary.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k != "records"}, indent=2))
    return 0 if summary["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
