#!/usr/bin/env python3
"""Synthetic safety smoke for SGR-FM C6-RMLA."""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import torch

from utils.sgr_fm_c3 import compose_pull
from utils.sgr_fm_c6_rml_aware import (
    build_localized_residual_dvf,
    candidate_score,
    compute_proxy_metrics,
    default_config,
    make_stage_parameter,
    objective_terms,
    passes_acceptance,
    prepare_stage_state,
    sha256_json,
)


def _synthetic_full(device: torch.device) -> dict:
    shape = (16, 16, 16)
    x = torch.linspace(-1.0, 1.0, shape[0], device=device)
    y = torch.linspace(-1.0, 1.0, shape[1], device=device)
    z = torch.linspace(-1.0, 1.0, shape[2], device=device)
    xx, yy, zz = torch.meshgrid(x, y, z, indexing="ij")
    fixed_ct = (0.4 * xx + 0.25 * yy - 0.15 * zz + 0.2 * torch.sin(5 * xx)).unsqueeze(0).unsqueeze(0)
    moving_ct = torch.roll(fixed_ct, shifts=1, dims=2)

    lobes = torch.zeros((1, 5, *shape), device=device)
    left = xx < 0
    right = ~left
    lobes[:, 0] = (left & (zz >= 0)).float()
    lobes[:, 1] = (left & (zz < 0)).float()
    lobes[:, 2] = (right & (zz > 0.20)).float()
    lobes[:, 3] = (right & (zz <= 0.20) & (zz >= -0.20)).float()
    lobes[:, 4] = (right & (zz < -0.20)).float()
    moving_lobes = torch.roll(lobes, shifts=1, dims=2)
    support = (lobes.sum(dim=1, keepdim=True) > 0).float()
    moving_support = torch.roll(support, shifts=1, dims=2)

    # Simple normalized pseudo-SDFs and right-interface distance channels.
    sdf = torch.zeros_like(lobes)
    for c in range(5):
        sdf[:, c] = (0.5 - lobes[:, c]).clamp(-1, 1)
    moving_sdf = torch.roll(sdf, shifts=1, dims=2)
    iface_dist = torch.ones((1, 3, *shape), device=device)
    iface_dist[:, 0] = zz.abs().unsqueeze(0)
    iface_dist[:, 1] = (zz - 0.20).abs().unsqueeze(0)
    iface_dist[:, 2] = (zz + 0.20).abs().unsqueeze(0)
    iface_dist = iface_dist.clamp(0, 1)
    iface_surf = (iface_dist < 0.12).float()
    moving_iface_dist = torch.roll(iface_dist, shifts=1, dims=2)
    moving_iface_surf = torch.roll(iface_surf, shifts=1, dims=2)

    zero = torch.zeros((1, 3, *shape), device=device)
    confidence_lobes = torch.full_like(lobes, 0.9)
    confidence_iface = torch.full_like(iface_dist, 0.9)
    rml_consensus = lobes[:, 3:4].clone()
    rml_uncertainty = torch.zeros_like(rml_consensus)
    # Deliberately add uncertainty near one RML edge.
    rml_uncertainty[:, :, 8:12, :, 6:10] = 0.8

    return {
        "moving_ct": moving_ct,
        "fixed_ct": fixed_ct,
        "moving_lobes": moving_lobes,
        "fixed_direct_lobes": lobes,
        "consensus_lobes": lobes.clone(),
        "confidence_lobes": confidence_lobes,
        "moving_support": moving_support,
        "fixed_support": support,
        "moving_sdf": moving_sdf,
        "consensus_sdf": sdf.clone(),
        "moving_interface_surface": moving_iface_surf,
        "moving_interface_dist": moving_iface_dist,
        "consensus_interface_surface": iface_surf,
        "consensus_interface_dist": iface_dist,
        "confidence_interfaces": confidence_iface,
        "right_confidence": torch.ones_like(support),
        "right_distance": torch.minimum(iface_dist[:, 1:2], iface_dist[:, 2:3]),
        "init_dvf": zero.clone(),
        "secondary_dvf": zero.clone(),
        "rml_consensus": rml_consensus,
        "rml_confidence": torch.full_like(rml_consensus, 0.9),
        "rml_uncertainty": rml_uncertainty,
        "frozen_base_dvf": zero.clone(),
        "frozen_base_warped_lobes": moving_lobes.clone(),
        "full_shape": shape,
    }


def main() -> int:
    device = torch.device("cpu")
    cfg = default_config()
    full = _synthetic_full(device)
    stage = dict(cfg["stage_f1"])
    stage.update({"reduce_factor": 1, "control_factor": 4, "iterations": 2})
    state = prepare_stage_state(
        full,
        current_dvf_full=full["init_dvf"],
        reduce_factor=1,
        stage_cfg=stage,
        priority_cfg=cfg["priority"],
        mind_cfg=cfg["mind"],
    )
    gate = state["priority_map"]
    assert gate.shape == (1, 1, 16, 16, 16)
    assert torch.isfinite(gate).all() and 0.0 <= gate.min() and gate.max() <= 1.0
    right_mean = float(gate[:, :, 8:].mean())
    left_mean = float(gate[:, :, :6].mean())
    assert right_mean > left_mean, (right_mean, left_mean)

    param = make_stage_parameter(state["init_dvf"].shape[-3:], stage_cfg=stage, device=device, dtype=state["init_dvf"].dtype)
    residual = build_localized_residual_dvf(
        param,
        target_shape=state["init_dvf"].shape[-3:],
        full_shape=full["full_shape"],
        stage_cfg=stage,
        priority_map=gate,
        scale=1.0,
    )
    total, terms = objective_terms(
        state=state,
        residual_dvf=residual,
        weights=stage["weights"],
        ct_cfg=cfg["ct"],
        mind_cfg=cfg["mind"],
        anatomy_cfg=cfg["anatomy"],
    )
    assert torch.isfinite(total)
    total.backward()
    assert param.grad is not None and torch.isfinite(param.grad).all()

    zero = torch.zeros_like(state["init_dvf"])
    base = compute_proxy_metrics(state=state, residual_dvf=zero, ct_cfg=cfg["ct"], mind_cfg=cfg["mind"], anatomy_cfg=cfg["anatomy"])
    assert all(torch.isfinite(torch.tensor(v)) for v in base.values())

    # Pull-composition constant translation sanity check.
    a = torch.zeros((1, 3, 8, 8, 8))
    b = torch.zeros_like(a)
    a[:, 0] = 0.25
    b[:, 1] = -0.50
    c = compose_pull(a, b)
    assert torch.allclose(c[:, 0], torch.full_like(c[:, 0], 0.25), atol=1e-6)
    assert torch.allclose(c[:, 1], torch.full_like(c[:, 1], -0.50), atol=1e-6)

    # Selector: accept a synthetic RML improvement, reject non-RML damage.
    baseline = {
        "rml_direct_dice": 0.90, "rml_consensus_dice": 0.91,
        "global_direct_lobe_dice": 0.96, "non_rml_preservation_dice": 1.0,
        "proxy_support_dice": 0.99, "rml_sdf_loss": 0.10,
        "right_horizontal_loss": 0.10, "right_oblique_loss": 0.10,
        "mind_loss": 0.10, "structural_gradient_loss": 0.10,
    }
    good = {
        **baseline,
        "rml_direct_dice": 0.9010, "rml_consensus_dice": 0.9112,
        "global_direct_lobe_dice": 0.9602, "non_rml_preservation_dice": 0.9998,
        "rml_sdf_loss": 0.099, "right_horizontal_loss": 0.099,
        "right_oblique_loss": 0.099, "mind_loss": 0.0998,
        "folding_pct": 0.0, "residual_norm_p99_vox": 0.4, "residual_norm_max_vox": 1.0,
    }
    ok, reasons, _, score = passes_acceptance(good, baseline, baseline_folding_pct=0.0, selection=cfg["selection"])
    assert ok, (reasons, score, candidate_score(good, baseline, cfg["selection"]))
    bad = dict(good)
    bad["non_rml_preservation_dice"] = 0.995
    ok2, reasons2, _, _ = passes_acceptance(bad, baseline, baseline_folding_pct=0.0, selection=cfg["selection"])
    assert not ok2 and any("non_rml" in r for r in reasons2)

    # Exact no-op copy behavior used by the runner.
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        src = td / "base.bin"
        dst = td / "out.bin"
        src.write_bytes(b"B0-EXACT-FALLBACK")
        shutil.copy2(src, dst)
        assert src.read_bytes() == dst.read_bytes()

    # Fingerprint stability.
    fp1 = sha256_json({"a": 1, "b": [2, 3]})
    fp2 = sha256_json({"b": [2, 3], "a": 1})
    assert fp1 == fp2

    # Optimizer utility source must not load validation GT/evaluator.
    src_text = Path(__file__).with_name("utils").joinpath("sgr_fm_c6_rml_aware.py").read_text(encoding="utf-8")
    assert "evaluate_validation" not in src_text
    assert "dice_64" not in src_text

    print("SGR-FM C6-RMLA SYNTHETIC SMOKE: PASS")
    print(f"  gate_right_mean={right_mean:.6f} gate_left_mean={left_mean:.6f}")
    print("  objective_forward_backward=PASS")
    print("  exact_pull_composition=PASS")
    print("  selector_accept_reject=PASS")
    print("  exact_B0_fallback_copy=PASS")
    print("  optimizer_GT_leakage_scan=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
