SGR-FM C6-RMLA
================
Confidence-aware RML / right-fissure residual refinement.

Purpose
-------
Final targeted refinement on top of the frozen B0 full-lineage champion:

  C2R B0 -> C4(B0) -> C4.1(B0) -> C5b(B0)

Frozen initializer:
  outputs/sgr_fm/lineage_propagation/B0/c5b_lmind

Expected exact initializer method fingerprint:
  d064cd195baa6b721126bf27b9ca735845a83b39a1c18660b970958414711d4b

Method
------
C6-RMLA does not train new shared neural weights. For each validation pair it:

1. Starts from the frozen B0 final DVF.
2. Builds a confidence-aware RML target from predicted lobes only:
   - direct INSP RML prediction,
   - EXP RML transported by B0 final,
   - EXP RML transported by the B0 C4.1 parent,
   - EXP RML transported by the B0 C2R source.
3. Uses disagreement as uncertainty / residual-capacity guidance, not as GT.
4. Targets:
   - RML body/boundary,
   - right-horizontal fissure (RUL <-> RML),
   - right-oblique system (RLL <-> RUL/RML),
   - local MIND structural mismatch.
5. Explicitly preserves non-RML lobes against the frozen B0 warp.
6. Runs two sequential small residual-SVF stages:
   - F1_RML_boundary
   - F2_right_fissure_micro
7. Backtracks scales [1, .75, .5, .25, .125, 0] with strict guards.
8. Uses exact B0 byte-copy fallback when both stages are no-ops.

No validation lobe/fissure GT is loaded by the optimizer utility. GT is used only
by evaluate_validation.py after all DVFs are written.

Files
-----
  main.py
  configs/sgr_fm_c6_rml_aware.yaml
  utils/sgr_fm_c6_rml_aware.py
  run_sgr_fm_c6_rml_aware_validation.py
  smoke_sgr_fm_c6_rml_aware_synthetic.py
  PATCH_MANIFEST_C6_RMLA.json

Install
-------
From the project root:

  unzip -o SGR_FM_C6_RMLA_patch.zip -d .

Compile
-------
  python -m py_compile \
    main.py \
    run_sgr_fm_c6_rml_aware_validation.py \
    utils/sgr_fm_c6_rml_aware.py \
    smoke_sgr_fm_c6_rml_aware_synthetic.py

Synthetic smoke
---------------
  python smoke_sgr_fm_c6_rml_aware_synthetic.py

Dry run
-------
  python main.py c6-rml \
    --config configs/sgr_fm_c6_rml_aware.yaml \
    --dry-run

Full validation
---------------
  python main.py c6-rml \
    --config configs/sgr_fm_c6_rml_aware.yaml

Output
------
  outputs/sgr_fm/c6_rml_aware/
    dvfs/
    dvfs_canonical_ras/
    case_manifests/
    traces/
    eval/validation_metrics.json
    comparison/B0_vs_C6_RMLA_summary.json
    comparison/B0_vs_C6_RMLA_per_case.csv
    c6_rml_aware_summary.json

Important
---------
- Do not change the accepted B0 fingerprint to bypass a mismatch.
- Do not delete the B0 c4_1_hast_pcf folder before C6 finishes; it is used as
  a lineage-history view for confidence estimation.
- Do not delete c2r_lineage_retune/baseline_repro before C6 finishes.
- No performance gain is claimed by this patch until the real validation run
  is evaluated.
