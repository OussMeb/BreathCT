SGR-FM MULTI-HYPOTHESIS LINEAGE PROPAGATION
===========================================

Purpose
-------
Propagate selected C2R hypotheses through the complete downstream chain:

  C2R source -> C4-HAST -> C4.1-HAST-PCF -> C5b-LMIND

Default hypotheses:
  B0  same-environment C2-LONG control
  V3  anatomy-balanced retune
  V7  capacity-balanced retune

Critical lineage rule
---------------------
For a given lineage X:

  X C2R
    -> C4(X)
    -> C4.1(primary=C4(X), secondary=X C2R)
    -> C5b(primary=C4.1(X), secondary=X C2R)

The runner never mixes a retuned C4 parent with the old C2-LONG secondary view.
Every parent/secondary fingerprint is checked exactly.

Ground-truth isolation
----------------------
The propagation runner does not load validation GT. C4, C4.1 and C5b keep their
existing inference-only optimization/selection logic. GT is accessed only by
the existing post-hoc evaluate_validation.py after DVFs are written.

Output isolation
----------------
  outputs/sgr_fm/lineage_propagation/
    B0/
      generated_configs/
      c4_hast/
      c4_1_hast_pcf/
      c5b_lmind/
      comparison/
      lineage_summary.json
    V3/
      ...
    V7/
      ...
    final_lineage_ranking.json
    final_lineage_ranking.csv
    lineage_propagation_summary.json

The existing c2_long_tto, c4_hast, c4_1_hast_pcf and c5b_lmind_residual folders
are not overwritten.

Install
-------
  cd "/home/oussama/Desktop/MICCAI FRANCE"
  unzip -o SGR_FM_LINEAGE_PROPAGATION_patch.zip -d .

Compile
-------
  python -m py_compile \
    main.py \
    run_sgr_fm_lineage_propagation.py \
    utils/sgr_fm_lineage_propagation.py \
    smoke_sgr_fm_lineage_propagation.py

Smoke
-----
  python smoke_sgr_fm_lineage_propagation.py

Preflight / dry run
-------------------
  python main.py lineage-propagate \
    --config configs/sgr_fm_lineage_propagation.yaml \
    --dry-run

Full default propagation
------------------------
  python main.py lineage-propagate \
    --config configs/sgr_fm_lineage_propagation.yaml

One lineage first (recommended when disk space is tight)
--------------------------------------------------------
  python main.py lineage-propagate \
    --config configs/sgr_fm_lineage_propagation.yaml \
    --lineages V3

Resume
------
Resume is enabled by default. A stage is reused only when it has a valid method
fingerprint and a 10-case eval/validation_metrics.json.

Stop after one stage
--------------------
  --stop-after c4
  --stop-after c4_1
  --stop-after c5b

Recommended order under low disk space
--------------------------------------
1. V3 first.
2. Compare final V3 descendant with current C5b champion.
3. Then B0 control.
4. Then V7 diversity lineage.
