#!/usr/bin/env python3
"""Helpers for multi-hypothesis C2R -> C4 -> C4.1 -> C5b propagation.

This module only orchestrates already-audited registration stages. It does not
load validation ground-truth segmentations and does not alter stage objectives.
Ground truth can be accessed only by the existing post-hoc evaluator invoked by
each stage runner.
"""
from __future__ import annotations

import copy
import csv
import json
from pathlib import Path
from typing import Any

import yaml


def load_yaml(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise TypeError(f"Expected mapping in {p}")
    return data


def dump_yaml(path: str | Path, data: dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


def read_json(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise TypeError(f"Expected JSON object in {p}")
    return data


def write_json(path: str | Path, data: dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=False), encoding="utf-8")
    tmp.replace(p)


def write_csv(path: str | Path, rows: list[dict[str, Any]]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        p.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with p.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def resolve_under_project(project_root: Path, value: str | Path) -> Path:
    p = Path(value).expanduser()
    if not p.is_absolute():
        p = project_root / p
    return p.resolve()


def read_method_fingerprint(run_dir: Path) -> str:
    path = run_dir / "run_config_resolved.json"
    if not path.exists():
        raise FileNotFoundError(f"Missing run config: {path}")
    meta = read_json(path)
    fp = str(meta.get("method_fingerprint_sha256", ""))
    if not fp:
        raise RuntimeError(f"Missing method_fingerprint_sha256 in {path}")
    return fp


def validate_source_lineage(
    *, project_root: Path, lineage_name: str, lineage_cfg: dict[str, Any], expected_case_count: int = 10
) -> dict[str, Any]:
    source_dir = resolve_under_project(project_root, lineage_cfg["source_dir"])
    expected_fp = str(lineage_cfg["expected_source_fingerprint"])
    actual_fp = read_method_fingerprint(source_dir)
    metrics_path = source_dir / "eval" / "validation_metrics.json"
    if not metrics_path.exists():
        raise FileNotFoundError(f"{lineage_name}: missing source metrics: {metrics_path}")
    metrics = read_json(metrics_path)
    case_count = int(metrics.get("case_count", len(metrics.get("case_metrics", []))))
    if case_count != expected_case_count:
        raise RuntimeError(
            f"{lineage_name}: source case_count mismatch: expected={expected_case_count} actual={case_count}"
        )
    if actual_fp != expected_fp:
        raise RuntimeError(
            f"{lineage_name}: source fingerprint mismatch: expected={expected_fp} actual={actual_fp}"
        )
    return {
        "lineage": lineage_name,
        "source_dir": str(source_dir),
        "expected_fingerprint": expected_fp,
        "actual_fingerprint": actual_fp,
        "source_mean_lobe_dice": float(metrics["mean_lobe_dice"]),
        "source_mean_folding_percentage": float(metrics["mean_folding_percentage"]),
        "case_count": case_count,
        "status": "PASS",
    }


def _load_stage_section(path: Path, section_key: str) -> dict[str, Any]:
    root = load_yaml(path)
    section = root.get(section_key)
    if not isinstance(section, dict):
        raise KeyError(f"Missing mapping {section_key!r} in {path}")
    return copy.deepcopy(section)


def build_c4_config(
    *, base_path: Path, source_dir: str, source_fp: str, output_dir: str, device: str
) -> dict[str, Any]:
    cfg = _load_stage_section(base_path, "sgr_fm_c4_hast")
    cfg["initializer_dir"] = source_dir
    cfg["output_dir"] = output_dir
    cfg["device"] = device
    cfg["overwrite"] = False
    cfg["require_initializer_fingerprint"] = True
    cfg["accepted_initializer_method_fingerprint"] = source_fp
    cfg.setdefault("evaluation", {})["initializer_metrics_json"] = str(Path(source_dir) / "eval" / "validation_metrics.json")
    return {"sgr_fm_c4_hast": cfg}


def build_c41_config(
    *, base_path: Path, c4_dir: str, c4_fp: str, source_dir: str, source_fp: str, output_dir: str, device: str
) -> dict[str, Any]:
    cfg = _load_stage_section(base_path, "sgr_fm_c4_1_hast_pcf")
    cfg["initializer_dir"] = c4_dir
    cfg["secondary_initializer_dir"] = source_dir
    cfg["output_dir"] = output_dir
    cfg["device"] = device
    cfg["overwrite"] = False
    cfg["require_initializer_fingerprint"] = True
    cfg["accepted_initializer_method_fingerprint"] = c4_fp
    cfg["require_secondary_fingerprint"] = True
    cfg["accepted_secondary_method_fingerprint"] = source_fp
    cfg.setdefault("evaluation", {})["initializer_metrics_json"] = str(Path(c4_dir) / "eval" / "validation_metrics.json")
    return {"sgr_fm_c4_1_hast_pcf": cfg}


def build_c5b_config(
    *, base_path: Path, c41_dir: str, c41_fp: str, source_dir: str, source_fp: str, output_dir: str, device: str
) -> dict[str, Any]:
    cfg = _load_stage_section(base_path, "sgr_fm_c5b_lmind")
    cfg["initializer_dir"] = c41_dir
    cfg["secondary_initializer_dir"] = source_dir
    cfg["output_dir"] = output_dir
    cfg["device"] = device
    cfg["overwrite"] = False
    cfg["require_initializer_fingerprint"] = True
    cfg["accepted_initializer_method_fingerprint"] = c41_fp
    cfg["require_secondary_fingerprint"] = True
    cfg["accepted_secondary_method_fingerprint"] = source_fp
    cfg.setdefault("evaluation", {})["initializer_metrics_json"] = str(Path(c41_dir) / "eval" / "validation_metrics.json")
    return {"sgr_fm_c5b_lmind": cfg}


def stage_complete(stage_dir: Path, *, expected_case_count: int = 10, require_eval_metrics: bool = True) -> tuple[bool, str]:
    run_cfg = stage_dir / "run_config_resolved.json"
    if not run_cfg.exists():
        return False, "missing run_config_resolved.json"
    try:
        read_method_fingerprint(stage_dir)
    except Exception as exc:  # noqa: BLE001
        return False, f"invalid run config: {exc}"
    if require_eval_metrics:
        metrics_path = stage_dir / "eval" / "validation_metrics.json"
        if not metrics_path.exists():
            return False, "missing eval/validation_metrics.json"
        try:
            metrics = read_json(metrics_path)
            count = int(metrics.get("case_count", len(metrics.get("case_metrics", []))))
            if count != expected_case_count:
                return False, f"case_count={count}, expected={expected_case_count}"
        except Exception as exc:  # noqa: BLE001
            return False, f"invalid metrics: {exc}"
    return True, "complete"


def compare_metrics(reference: dict[str, Any], candidate: dict[str, Any], *, reference_name: str, candidate_name: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    a_rows = {str(r["case_id"]): r for r in reference.get("case_metrics", [])}
    b_rows = {str(r["case_id"]): r for r in candidate.get("case_metrics", [])}
    common = sorted(set(a_rows) & set(b_rows))
    rows: list[dict[str, Any]] = []
    deltas: list[float] = []
    for case_id in common:
        a = float(a_rows[case_id]["mean_lobe_dice"])
        b = float(b_rows[case_id]["mean_lobe_dice"])
        d = b - a
        deltas.append(d)
        rows.append({
            "case_id": case_id,
            f"{reference_name}_mean_lobe_dice": a,
            f"{candidate_name}_mean_lobe_dice": b,
            "delta_dice": d,
            f"{reference_name}_folding_percentage": float(a_rows[case_id]["folding_percentage"]),
            f"{candidate_name}_folding_percentage": float(b_rows[case_id]["folding_percentage"]),
        })
    summary = {
        "common_case_count": len(common),
        f"{reference_name}_mean_lobe_dice": float(reference["mean_lobe_dice"]),
        f"{candidate_name}_mean_lobe_dice": float(candidate["mean_lobe_dice"]),
        "delta_mean_lobe_dice": float(candidate["mean_lobe_dice"] - reference["mean_lobe_dice"]),
        f"{reference_name}_mean_folding_percentage": float(reference["mean_folding_percentage"]),
        f"{candidate_name}_mean_folding_percentage": float(candidate["mean_folding_percentage"]),
        "delta_mean_folding_percentage": float(candidate["mean_folding_percentage"] - reference["mean_folding_percentage"]),
        "improved_cases": sum(d > 0.0 for d in deltas),
        "worsened_cases": sum(d < 0.0 for d in deltas),
        "unchanged_cases": sum(abs(d) <= 1.0e-12 for d in deltas),
        "min_paired_dice_delta": min(deltas) if deltas else None,
        "max_paired_dice_delta": max(deltas) if deltas else None,
    }
    return summary, rows


def final_ranking(records: list[dict[str, Any]], *, max_mean_folding_pct: float) -> list[dict[str, Any]]:
    ranked = []
    for record in records:
        row = copy.deepcopy(record)
        fold = float(row["final_mean_folding_percentage"])
        row["topology_eligible"] = fold <= max_mean_folding_pct
        ranked.append(row)
    ranked.sort(key=lambda r: (not bool(r["topology_eligible"]), -float(r["final_mean_lobe_dice"]), float(r["final_mean_folding_percentage"])))
    for i, row in enumerate(ranked, start=1):
        row["rank"] = i
    return ranked
