#!/usr/bin/env python3
"""Propagate selected C2R hypotheses through C4 -> C4.1 -> C5b.

Each lineage is isolated. The same C2R source is used both as the C4 initializer
and as the secondary transport source in C4.1 and C5b. Downstream accepted
fingerprints are derived from the actual completed parent stage, not hard-coded.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.sgr_fm_lineage_propagation import (
    build_c4_config,
    build_c41_config,
    build_c5b_config,
    compare_metrics,
    dump_yaml,
    final_ranking,
    load_yaml,
    read_json,
    read_method_fingerprint,
    resolve_under_project,
    stage_complete,
    validate_source_lineage,
    write_csv,
    write_json,
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Propagate B0/V3/V7 C2R hypotheses through C4 -> C4.1 -> C5b.")
    p.add_argument("--config", default="configs/sgr_fm_lineage_propagation.yaml")
    p.add_argument("--lineages", nargs="*", default=None, help="Subset, e.g. B0 V3 V7")
    p.add_argument("--device", default=None)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--no-resume", action="store_true")
    p.add_argument("--stop-after", choices=("c4", "c4_1", "c5b"), default=None)
    return p.parse_args()


def _run(command: list[str]) -> None:
    print("\n[RUN]", " ".join(command), flush=True)
    proc = subprocess.run(command, cwd=str(PROJECT_ROOT), check=False)
    if proc.returncode != 0:
        raise RuntimeError(f"Command failed with exit code {proc.returncode}: {' '.join(command)}")


def _stage_or_skip(
    *, stage_key: str, stage_dir: Path, config_path: Path, command: str, device: str,
    expected_case_count: int, require_eval_metrics: bool, resume: bool, dry_run: bool,
) -> dict[str, Any]:
    complete, reason = stage_complete(
        stage_dir, expected_case_count=expected_case_count, require_eval_metrics=require_eval_metrics
    )
    if resume and complete:
        print(f"[SKIP] {stage_key}: {stage_dir} ({reason})", flush=True)
        return {"stage": stage_key, "action": "reused", "status": "PASS", "output_dir": str(stage_dir)}
    if dry_run:
        print(f"[DRY-RUN] {stage_key}: would run with {config_path}", flush=True)
        return {"stage": stage_key, "action": "dry_run", "status": "PASS", "output_dir": str(stage_dir)}
    _run([
        sys.executable,
        str(PROJECT_ROOT / "main.py"),
        command,
        "--config",
        str(config_path),
        "--device",
        device,
    ])
    complete, reason = stage_complete(
        stage_dir, expected_case_count=expected_case_count, require_eval_metrics=require_eval_metrics
    )
    if not complete:
        raise RuntimeError(f"{stage_key}: runner returned but stage is incomplete: {reason}")
    return {"stage": stage_key, "action": "ran", "status": "PASS", "output_dir": str(stage_dir)}


def main() -> int:
    args = parse_args()
    root_cfg = load_yaml(resolve_under_project(PROJECT_ROOT, args.config))
    cfg = root_cfg.get("lineage_propagation")
    if not isinstance(cfg, dict):
        raise KeyError("Missing lineage_propagation mapping")

    output_root = resolve_under_project(PROJECT_ROOT, cfg["output_root"])
    output_root.mkdir(parents=True, exist_ok=True)
    device = str(args.device or cfg.get("device", "cuda"))
    expected_case_count = int(cfg.get("resume", {}).get("expected_case_count", 10))
    require_eval_metrics = bool(cfg.get("resume", {}).get("require_eval_metrics", True))
    resume = bool(cfg.get("resume", {}).get("enabled", True)) and not args.no_resume
    base_configs = cfg["base_configs"]

    available = cfg["lineages"]
    requested = list(args.lineages) if args.lineages else list(cfg.get("default_lineages", []))
    unknown = [name for name in requested if name not in available]
    if unknown:
        raise KeyError(f"Unknown lineage(s): {unknown}; available={sorted(available)}")
    if not requested:
        raise RuntimeError("No lineages selected")

    current_champion_dir = resolve_under_project(PROJECT_ROOT, cfg["current_champion_dir"])
    champion_metrics_path = current_champion_dir / "eval" / "validation_metrics.json"
    champion_metrics = read_json(champion_metrics_path) if champion_metrics_path.exists() else None

    global_records: list[dict[str, Any]] = []
    run_summary: dict[str, Any] = {
        "schema_version": 1,
        "experiment": cfg.get("experiment_name"),
        "status": "PASS",
        "requested_lineages": requested,
        "device": device,
        "dry_run": bool(args.dry_run),
        "resume": resume,
        "records": [],
    }

    for lineage_name in requested:
        started = time.time()
        lineage_cfg = available[lineage_name]
        record: dict[str, Any] = {
            "lineage": lineage_name,
            "description": lineage_cfg.get("description", ""),
            "status": "PASS",
            "stages": [],
        }
        try:
            source_audit = validate_source_lineage(
                project_root=PROJECT_ROOT,
                lineage_name=lineage_name,
                lineage_cfg=lineage_cfg,
                expected_case_count=expected_case_count,
            )
            record["source_audit"] = source_audit
            source_dir = resolve_under_project(PROJECT_ROOT, lineage_cfg["source_dir"])
            source_fp = source_audit["actual_fingerprint"]

            lineage_root = output_root / lineage_name
            generated_dir = lineage_root / "generated_configs"
            generated_dir.mkdir(parents=True, exist_ok=True)
            c4_dir = lineage_root / str(cfg["stage_names"]["c4"])
            c41_dir = lineage_root / str(cfg["stage_names"]["c4_1"])
            c5b_dir = lineage_root / str(cfg["stage_names"]["c5b"])

            c4_cfg_path = generated_dir / "c4_hast.yaml"
            c4_cfg = build_c4_config(
                base_path=resolve_under_project(PROJECT_ROOT, base_configs["c4"]),
                source_dir=str(source_dir),
                source_fp=source_fp,
                output_dir=str(c4_dir),
                device=device,
            )
            dump_yaml(c4_cfg_path, c4_cfg)
            record["stages"].append(_stage_or_skip(
                stage_key="c4", stage_dir=c4_dir, config_path=c4_cfg_path,
                command="c4-hast", device=device, expected_case_count=expected_case_count,
                require_eval_metrics=require_eval_metrics, resume=resume, dry_run=args.dry_run,
            ))
            if args.stop_after == "c4" or args.dry_run:
                record["elapsed_sec"] = time.time() - started
                run_summary["records"].append(record)
                continue

            c4_fp = read_method_fingerprint(c4_dir)
            c41_cfg_path = generated_dir / "c4_1_hast_pcf.yaml"
            c41_cfg = build_c41_config(
                base_path=resolve_under_project(PROJECT_ROOT, base_configs["c4_1"]),
                c4_dir=str(c4_dir), c4_fp=c4_fp,
                source_dir=str(source_dir), source_fp=source_fp,
                output_dir=str(c41_dir), device=device,
            )
            dump_yaml(c41_cfg_path, c41_cfg)
            record["stages"].append(_stage_or_skip(
                stage_key="c4_1", stage_dir=c41_dir, config_path=c41_cfg_path,
                command="c4.1-hast-pcf", device=device, expected_case_count=expected_case_count,
                require_eval_metrics=require_eval_metrics, resume=resume, dry_run=False,
            ))
            if args.stop_after == "c4_1":
                record["elapsed_sec"] = time.time() - started
                run_summary["records"].append(record)
                continue

            c41_fp = read_method_fingerprint(c41_dir)
            c5b_cfg_path = generated_dir / "c5b_lmind.yaml"
            c5b_cfg = build_c5b_config(
                base_path=resolve_under_project(PROJECT_ROOT, base_configs["c5b"]),
                c41_dir=str(c41_dir), c41_fp=c41_fp,
                source_dir=str(source_dir), source_fp=source_fp,
                output_dir=str(c5b_dir), device=device,
            )
            dump_yaml(c5b_cfg_path, c5b_cfg)
            record["stages"].append(_stage_or_skip(
                stage_key="c5b", stage_dir=c5b_dir, config_path=c5b_cfg_path,
                command="c5-mind", device=device, expected_case_count=expected_case_count,
                require_eval_metrics=require_eval_metrics, resume=resume, dry_run=False,
            ))

            final_metrics = read_json(c5b_dir / "eval" / "validation_metrics.json")
            record.update({
                "final_mean_lobe_dice": float(final_metrics["mean_lobe_dice"]),
                "final_mean_folding_percentage": float(final_metrics["mean_folding_percentage"]),
                "final_max_folding_percentage": float(final_metrics.get("max_folding_percentage", 0.0)),
                "final_case_count": int(final_metrics.get("case_count", len(final_metrics.get("case_metrics", [])))),
                "final_c5b_fingerprint": read_method_fingerprint(c5b_dir),
            })

            source_metrics = read_json(source_dir / "eval" / "validation_metrics.json")
            src_cmp, src_rows = compare_metrics(
                source_metrics, final_metrics, reference_name=f"{lineage_name}_C2R", candidate_name=f"{lineage_name}_C5b"
            )
            write_json(lineage_root / "comparison" / "SOURCE_vs_FINAL_summary.json", src_cmp)
            write_csv(lineage_root / "comparison" / "SOURCE_vs_FINAL_per_case.csv", src_rows)
            record["source_to_final_comparison"] = src_cmp

            if champion_metrics is not None:
                champ_cmp, champ_rows = compare_metrics(
                    champion_metrics, final_metrics, reference_name="current_C5b", candidate_name=f"{lineage_name}_final"
                )
                write_json(lineage_root / "comparison" / "CURRENT_CHAMPION_vs_FINAL_summary.json", champ_cmp)
                write_csv(lineage_root / "comparison" / "CURRENT_CHAMPION_vs_FINAL_per_case.csv", champ_rows)
                record["vs_current_champion"] = champ_cmp

            global_records.append({
                "lineage": lineage_name,
                "source_mean_lobe_dice": float(source_audit["source_mean_lobe_dice"]),
                "source_mean_folding_percentage": float(source_audit["source_mean_folding_percentage"]),
                "final_mean_lobe_dice": float(final_metrics["mean_lobe_dice"]),
                "final_mean_folding_percentage": float(final_metrics["mean_folding_percentage"]),
                "delta_final_vs_current_champion": (
                    float(final_metrics["mean_lobe_dice"] - champion_metrics["mean_lobe_dice"])
                    if champion_metrics is not None else None
                ),
                "output_dir": str(c5b_dir),
            })

        except Exception as exc:  # noqa: BLE001
            record["status"] = "FAIL"
            record["error"] = f"{type(exc).__name__}: {exc}"
            run_summary["status"] = "FAIL"
            record["elapsed_sec"] = time.time() - started
            run_summary["records"].append(record)
            write_json(output_root / "lineage_propagation_summary.json", run_summary)
            if bool(cfg.get("stop_on_error", True)):
                raise
            continue

        record["elapsed_sec"] = time.time() - started
        run_summary["records"].append(record)
        write_json(lineage_root / "lineage_summary.json", record)
        write_json(output_root / "lineage_propagation_summary.json", run_summary)

    if global_records:
        ranking_cfg = cfg.get("ranking", {})
        ranked = final_ranking(
            global_records,
            max_mean_folding_pct=float(ranking_cfg.get("max_mean_folding_pct", 0.001)),
        )
        run_summary["final_ranking"] = ranked
        write_json(output_root / "final_lineage_ranking.json", {"ranking": ranked})
        write_csv(output_root / "final_lineage_ranking.csv", ranked)

    write_json(output_root / "lineage_propagation_summary.json", run_summary)
    print(json.dumps({k: v for k, v in run_summary.items() if k != "records"}, indent=2))
    return 0 if run_summary["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
