#!/usr/bin/env python3
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import yaml

from utils.sgr_fm_lineage_propagation import (
    build_c4_config,
    build_c41_config,
    build_c5b_config,
    compare_metrics,
    final_ranking,
)

ROOT = Path(__file__).resolve().parent


def main() -> int:
    c4 = build_c4_config(
        base_path=ROOT / "configs/sgr_fm_c4_hast.yaml",
        source_dir="outputs/source/V3",
        source_fp="source_fp",
        output_dir="outputs/prop/V3/c4",
        device="cuda",
    )["sgr_fm_c4_hast"]
    assert c4["initializer_dir"] == "outputs/source/V3"
    assert c4["accepted_initializer_method_fingerprint"] == "source_fp"
    assert c4["evaluation"]["initializer_metrics_json"] == "outputs/source/V3/eval/validation_metrics.json"

    c41 = build_c41_config(
        base_path=ROOT / "configs/sgr_fm_c4_1_hast_pcf.yaml",
        c4_dir="outputs/prop/V3/c4", c4_fp="c4_fp",
        source_dir="outputs/source/V3", source_fp="source_fp",
        output_dir="outputs/prop/V3/c41", device="cuda",
    )["sgr_fm_c4_1_hast_pcf"]
    assert c41["accepted_initializer_method_fingerprint"] == "c4_fp"
    assert c41["secondary_initializer_dir"] == "outputs/source/V3"
    assert c41["accepted_secondary_method_fingerprint"] == "source_fp"

    c5b = build_c5b_config(
        base_path=ROOT / "configs/sgr_fm_c5b_lmind.yaml",
        c41_dir="outputs/prop/V3/c41", c41_fp="c41_fp",
        source_dir="outputs/source/V3", source_fp="source_fp",
        output_dir="outputs/prop/V3/c5b", device="cuda",
    )["sgr_fm_c5b_lmind"]
    assert c5b["accepted_initializer_method_fingerprint"] == "c41_fp"
    assert c5b["secondary_initializer_dir"] == "outputs/source/V3"
    assert c5b["accepted_secondary_method_fingerprint"] == "source_fp"

    a = {
        "mean_lobe_dice": 0.90,
        "mean_folding_percentage": 0.0,
        "case_metrics": [
            {"case_id": "A", "mean_lobe_dice": 0.89, "folding_percentage": 0.0},
            {"case_id": "B", "mean_lobe_dice": 0.91, "folding_percentage": 0.0},
        ],
    }
    b = {
        "mean_lobe_dice": 0.905,
        "mean_folding_percentage": 0.0,
        "case_metrics": [
            {"case_id": "A", "mean_lobe_dice": 0.90, "folding_percentage": 0.0},
            {"case_id": "B", "mean_lobe_dice": 0.91, "folding_percentage": 0.0},
        ],
    }
    summary, rows = compare_metrics(a, b, reference_name="a", candidate_name="b")
    assert abs(summary["delta_mean_lobe_dice"] - 0.005) < 1e-12
    assert summary["improved_cases"] == 1
    assert len(rows) == 2

    ranked = final_ranking([
        {"lineage": "X", "final_mean_lobe_dice": 0.98, "final_mean_folding_percentage": 0.002},
        {"lineage": "Y", "final_mean_lobe_dice": 0.97, "final_mean_folding_percentage": 0.0},
    ], max_mean_folding_pct=0.001)
    assert ranked[0]["lineage"] == "Y"
    assert ranked[0]["topology_eligible"] is True

    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "cfg.yaml"
        p.write_text(yaml.safe_dump({"x": c5b}, sort_keys=False), encoding="utf-8")
        assert json.loads(json.dumps(yaml.safe_load(p.read_text(encoding="utf-8"))))["x"]["initializer_dir"] == "outputs/prop/V3/c41"

    print("SGR-FM LINEAGE PROPAGATION SYNTHETIC SMOKE: PASS")
    print("  C4 source rewiring=PASS")
    print("  C4.1 primary/secondary rewiring=PASS")
    print("  C5b primary/secondary rewiring=PASS")
    print("  comparison logic=PASS")
    print("  topology-aware ranking=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
