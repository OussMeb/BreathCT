#!/usr/bin/env python3
"""
SGR-FM C7A: semantic-Adam / ConvexAdam-style label-first registration branch.

This module is intentionally self-contained. It does not require the official
ConvexAdam repository. It implements a comparable optimization idea for this
project: multi-channel semantic/SDF/MIND-like features, Adam over a smooth
control-grid displacement field, candidate-scale backtracking, relaxed topology
limits, and exact parent fallback.

Displacement convention:
    pull field in voxel units: warped_EXP[x] = EXP[x + DVF[x]]
Internal work grid:
    canonical RAS NIfTI array grid, shape (X,Y,Z), vector components in the
    moving canonical voxel basis.
Export:
    fixed original INSP grid/header, vector components in original moving voxel
    index basis, using affine-coordinate conversion rather than sign heuristics.
"""
from __future__ import annotations

import csv
import dataclasses
import hashlib
import json
import math
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import nibabel as nib
import numpy as np
import scipy.ndimage as ndi
import torch
import torch.nn.functional as F

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

LABELS = [8, 16, 32, 64, 128]
LABEL_NAMES = {8: "LUL", 16: "LLL", 32: "RUL", 64: "RML", 128: "RLL"}


def load_yaml(path: str | os.PathLike) -> Dict:
    if yaml is None:
        raise RuntimeError("PyYAML is required to read YAML configs")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def save_json(obj, path: str | os.PathLike) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def sha256_file(path: str | os.PathLike, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def find_cases(dataset_root: str | os.PathLike) -> List[str]:
    ct_dir = Path(dataset_root) / "validation" / "ct_data"
    if not ct_dir.exists():
        raise FileNotFoundError(f"Validation CT directory not found: {ct_dir}")
    cases = []
    for p in sorted(ct_dir.glob("*_INSP.nii.gz")):
        cid = p.name.replace("_INSP.nii.gz", "")
        exp = ct_dir / f"{cid}_EXP.nii.gz"
        if exp.exists():
            cases.append(cid)
    if not cases:
        raise RuntimeError(f"No validation EXP/INSP pairs found in {ct_dir}")
    return cases


def as_canonical_float(img: nib.Nifti1Image, dtype=np.float32) -> Tuple[np.ndarray, nib.Nifti1Image]:
    can = nib.as_closest_canonical(img)
    arr = np.asarray(can.dataobj).astype(dtype, copy=False)
    return arr, can


def as_canonical_label(img: nib.Nifti1Image) -> Tuple[np.ndarray, nib.Nifti1Image]:
    can = nib.as_closest_canonical(img)
    arr = np.asarray(can.dataobj).astype(np.int16, copy=False)
    return arr, can


def clip_norm_ct(x: np.ndarray, lo=-1000.0, hi=400.0) -> np.ndarray:
    y = np.clip(x.astype(np.float32), lo, hi)
    return (y - lo) / (hi - lo) * 2.0 - 1.0


def one_hot_lobes(lbl: np.ndarray, labels: Sequence[int] = LABELS) -> np.ndarray:
    return np.stack([(lbl == int(l)).astype(np.float32) for l in labels], axis=0)


def support_from_labels(lbl: np.ndarray) -> np.ndarray:
    return np.isin(lbl, np.asarray(LABELS, dtype=lbl.dtype)).astype(np.float32)


def signed_distance_channels(lbl: np.ndarray, spacing=(1.0, 1.0, 1.0), labels: Sequence[int] = LABELS, clip_mm=18.0) -> np.ndarray:
    """Positive outside, negative inside, clipped/normalized to [-1,1]."""
    chans = []
    for lab in labels:
        m = (lbl == int(lab))
        if m.any():
            out = ndi.distance_transform_edt(~m, sampling=spacing)
            inn = ndi.distance_transform_edt(m, sampling=spacing)
            sdf = out - inn
        else:
            sdf = np.full(lbl.shape, clip_mm, dtype=np.float32)
        sdf = np.clip(sdf.astype(np.float32), -clip_mm, clip_mm) / float(clip_mm)
        chans.append(sdf.astype(np.float32))
    return np.stack(chans, axis=0)


def fissure_band_channels(lbl: np.ndarray, spacing=(1.0, 1.0, 1.0), radius_mm=7.5, clip_mm=12.0) -> np.ndarray:
    """Three coarse interface bands: left oblique, right horizontal, right oblique."""
    lbl = lbl.astype(np.int16, copy=False)
    # Conservative adjacency by binary dilation. These are only soft bands for the objective.
    struct = ndi.generate_binary_structure(3, 1)
    masks = []
    pairs = [((8,), (16,)), ((32,), (64,)), ((128,), (32, 64))]
    for a, b in pairs:
        ma = np.isin(lbl, np.asarray(a, dtype=lbl.dtype))
        mb = np.isin(lbl, np.asarray(b, dtype=lbl.dtype))
        iface = (ndi.binary_dilation(ma, structure=struct) & mb) | (ndi.binary_dilation(mb, structure=struct) & ma)
        if iface.any():
            d = ndi.distance_transform_edt(~iface, sampling=spacing)
            band = np.exp(-np.minimum(d, clip_mm) / max(radius_mm, 1e-3))
        else:
            band = np.zeros(lbl.shape, dtype=np.float32)
        masks.append(band.astype(np.float32))
    return np.stack(masks, axis=0)


def downsample_np_channels(ch: np.ndarray, out_shape: Tuple[int, int, int], mode: str = "trilinear") -> np.ndarray:
    """ch: (C,X,Y,Z) -> (C,Xo,Yo,Zo)."""
    ten = torch.from_numpy(ch[None]).float()  # 1,C,X,Y,Z
    ten = ten.permute(0, 1, 4, 3, 2)          # 1,C,Z,Y,X
    if mode == "nearest":
        out = F.interpolate(ten, size=(out_shape[2], out_shape[1], out_shape[0]), mode="nearest")
    else:
        out = F.interpolate(ten, size=(out_shape[2], out_shape[1], out_shape[0]), mode="trilinear", align_corners=True)
    out = out.permute(0, 1, 4, 3, 2)[0].cpu().numpy().astype(np.float32)
    return out


def make_torch_volume(ch: np.ndarray, device: str) -> torch.Tensor:
    """(C,X,Y,Z) -> [1,C,Z,Y,X] float."""
    t = torch.from_numpy(ch.astype(np.float32, copy=False))[None]
    t = t.permute(0, 1, 4, 3, 2).contiguous().to(device)
    return t


def make_identity_grid_zyx(shape_xyz: Tuple[int, int, int], device: str) -> torch.Tensor:
    X, Y, Z = shape_xyz
    z = torch.linspace(-1.0, 1.0, Z, device=device)
    y = torch.linspace(-1.0, 1.0, Y, device=device)
    x = torch.linspace(-1.0, 1.0, X, device=device)
    zz, yy, xx = torch.meshgrid(z, y, x, indexing="ij")
    return torch.stack([xx, yy, zz], dim=-1)[None]  # [1,Z,Y,X,3]


def disp_xyz_to_norm_grid(disp_xyz_zyx: torch.Tensor, shape_xyz: Tuple[int, int, int]) -> torch.Tensor:
    """disp tensor [1,3,Z,Y,X] in voxel units (x,y,z) -> normalized grid delta [1,Z,Y,X,3]."""
    X, Y, Z = shape_xyz
    scales = torch.tensor([2.0 / max(X - 1, 1), 2.0 / max(Y - 1, 1), 2.0 / max(Z - 1, 1)],
                          dtype=disp_xyz_zyx.dtype, device=disp_xyz_zyx.device)
    d = disp_xyz_zyx.permute(0, 2, 3, 4, 1) * scales
    return d


def warp_torch(moving: torch.Tensor, disp_xyz_zyx: torch.Tensor, grid: torch.Tensor, shape_xyz: Tuple[int, int, int], mode="bilinear") -> torch.Tensor:
    sample_grid = grid + disp_xyz_to_norm_grid(disp_xyz_zyx, shape_xyz)
    return F.grid_sample(moving, sample_grid, mode=mode, padding_mode="border", align_corners=True)


def smoothness_loss(d: torch.Tensor) -> torch.Tensor:
    # d [1,3,Z,Y,X]
    loss = 0.0
    loss = loss + (d[:, :, 1:, :, :] - d[:, :, :-1, :, :]).pow(2).mean()
    loss = loss + (d[:, :, :, 1:, :] - d[:, :, :, :-1, :]).pow(2).mean()
    loss = loss + (d[:, :, :, :, 1:] - d[:, :, :, :, :-1]).pow(2).mean()
    return loss / 3.0


def bending_loss(d: torch.Tensor) -> torch.Tensor:
    loss = 0.0
    if d.shape[2] > 2:
        loss = loss + (d[:, :, 2:, :, :] - 2*d[:, :, 1:-1, :, :] + d[:, :, :-2, :, :]).pow(2).mean()
    if d.shape[3] > 2:
        loss = loss + (d[:, :, :, 2:, :] - 2*d[:, :, :, 1:-1, :] + d[:, :, :, :-2, :]).pow(2).mean()
    if d.shape[4] > 2:
        loss = loss + (d[:, :, :, :, 2:] - 2*d[:, :, :, :, 1:-1] + d[:, :, :, :, :-2]).pow(2).mean()
    return loss / 3.0


def dice_loss_soft(a: torch.Tensor, b: torch.Tensor, eps=1e-5) -> torch.Tensor:
    dims = tuple(range(2, a.ndim))
    inter = (a * b).sum(dim=dims)
    den = (a * a + b * b).sum(dim=dims) + eps
    return (1.0 - (2.0 * inter + eps) / den).mean()


def lncc_loss(a: torch.Tensor, b: torch.Tensor, mask: Optional[torch.Tensor] = None, eps=1e-5) -> torch.Tensor:
    if mask is None:
        mask = torch.ones_like(a[:, :1])
    m = mask.clamp(0, 1)
    n = m.sum().clamp_min(1.0)
    ma = (a * m).sum() / n
    mb = (b * m).sum() / n
    va = ((a - ma) * m).pow(2).sum() / n
    vb = ((b - mb) * m).pow(2).sum() / n
    cov = (((a - ma) * (b - mb)) * m).sum() / n
    return 1.0 - cov / torch.sqrt(va * vb + eps)


def jacobian_folding_pct_np(dvf_xyz: np.ndarray) -> Dict[str, float]:
    """Approximate Jacobian det statistics for pull field x + dvf, in canonical voxels."""
    # dvf (X,Y,Z,3); F = identity + u; gradients dF_i/daxis_j
    u = dvf_xyz.astype(np.float32, copy=False)
    grads = []
    for c in range(3):
        gx, gy, gz = np.gradient(u[..., c])
        grads.append((gx, gy, gz))
    X, Y, Z = u.shape[:3]
    J = np.empty(u.shape[:3] + (3, 3), dtype=np.float32)
    # rows output coordinate c, columns input x,y,z
    for c in range(3):
        for a in range(3):
            J[..., c, a] = grads[c][a]
    J[..., 0, 0] += 1.0
    J[..., 1, 1] += 1.0
    J[..., 2, 2] += 1.0
    det = np.linalg.det(J.reshape(-1, 3, 3)).reshape(X, Y, Z)
    fold = float((det <= 0).mean() * 100.0)
    return {
        "folding_pct": fold,
        "min_det": float(np.nanmin(det)),
        "p0_1": float(np.nanpercentile(det, 0.1)),
        "p1": float(np.nanpercentile(det, 1.0)),
        "p50": float(np.nanpercentile(det, 50.0)),
        "p99": float(np.nanpercentile(det, 99.0)),
        "max_det": float(np.nanmax(det)),
    }


def affine_index_transform(src_aff: np.ndarray, dst_aff: np.ndarray) -> np.ndarray:
    """Matrix mapping src voxel index homogeneous coordinates to dst voxel coordinates."""
    return np.linalg.inv(dst_aff) @ src_aff


def sample_vector_field_at_can_coords(dvf_can: np.ndarray, coords_can: np.ndarray) -> np.ndarray:
    """coords_can shape (3,N) in canonical fixed index coordinates."""
    out = np.empty((3, coords_can.shape[1]), dtype=np.float32)
    for c in range(3):
        out[c] = ndi.map_coordinates(dvf_can[..., c], coords_can, order=1, mode="nearest").astype(np.float32)
    return out


def export_canonical_pull_dvf_to_original_grid(
    dvf_can: np.ndarray,
    fixed_orig_img: nib.Nifti1Image,
    fixed_can_img: nib.Nifti1Image,
    moving_orig_img: nib.Nifti1Image,
    moving_can_img: nib.Nifti1Image,
    out_path: str | os.PathLike,
    slab_z: int = 16,
) -> None:
    """Convert canonical voxel pull DVF to original fixed grid/orientation.

    For each fixed original voxel i_f_orig:
      i_f_can = inv(A_f_can) A_f_orig i_f_orig
      i_m_can = i_f_can + u_can(i_f_can)
      i_m_orig = inv(A_m_orig) A_m_can i_m_can
      u_orig = i_m_orig - i_f_orig
    """
    fixed_shape = fixed_orig_img.shape[:3]
    X, Y, Z = fixed_shape
    out = np.zeros((X, Y, Z, 3), dtype=np.float32)
    T_fo_to_fc = affine_index_transform(fixed_orig_img.affine, fixed_can_img.affine)
    T_mc_to_mo = affine_index_transform(moving_can_img.affine, moving_orig_img.affine)
    for z0 in range(0, Z, slab_z):
        z1 = min(Z, z0 + slab_z)
        xs, ys, zs = np.meshgrid(np.arange(X, dtype=np.float32),
                                 np.arange(Y, dtype=np.float32),
                                 np.arange(z0, z1, dtype=np.float32), indexing="ij")
        n = xs.size
        p_orig = np.vstack([xs.reshape(-1), ys.reshape(-1), zs.reshape(-1), np.ones(n, dtype=np.float32)])
        p_fc = (T_fo_to_fc @ p_orig)[:3]
        u_can = sample_vector_field_at_can_coords(dvf_can, p_fc)
        p_mc = p_fc + u_can
        p_mc_h = np.vstack([p_mc, np.ones(n, dtype=np.float32)])
        p_mo = (T_mc_to_mo @ p_mc_h)[:3]
        u_orig = p_mo - p_orig[:3]
        out[:, :, z0:z1, 0] = u_orig[0].reshape(X, Y, z1 - z0)
        out[:, :, z0:z1, 1] = u_orig[1].reshape(X, Y, z1 - z0)
        out[:, :, z0:z1, 2] = u_orig[2].reshape(X, Y, z1 - z0)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img = nib.Nifti1Image(out.astype(np.float32), fixed_orig_img.affine, fixed_orig_img.header)
    img.header.set_data_dtype(np.float32)
    nib.save(img, str(out_path))


def load_parent_dvf_canonical(parent_dir: Optional[str], case_id: str, expected_shape: Tuple[int,int,int]) -> Optional[np.ndarray]:
    if not parent_dir:
        return None
    p = Path(parent_dir) / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz"
    if not p.exists():
        return None
    arr = np.asarray(nib.load(str(p)).dataobj).astype(np.float32)
    if arr.shape != expected_shape + (3,):
        raise ValueError(f"Parent DVF shape mismatch for {case_id}: {arr.shape}, expected {expected_shape+(3,)} at {p}")
    return arr


def resample_parent_to_stage(parent: np.ndarray, out_shape: Tuple[int,int,int]) -> np.ndarray:
    if parent is None:
        return np.zeros(out_shape + (3,), dtype=np.float32)
    ch = parent.transpose(3,0,1,2)
    ds = downsample_np_channels(ch, out_shape, mode="trilinear").transpose(1,2,3,0)
    scale = np.asarray(out_shape, dtype=np.float32) / np.asarray(parent.shape[:3], dtype=np.float32)
    # voxel displacement scales with index units under downsampling
    ds[..., 0] *= scale[0]
    ds[..., 1] *= scale[1]
    ds[..., 2] *= scale[2]
    return ds.astype(np.float32)


def upsample_stage_disp_to_full(d: np.ndarray, full_shape: Tuple[int,int,int]) -> np.ndarray:
    stage_shape = d.shape[:3]
    ch = d.transpose(3,0,1,2)
    up = downsample_np_channels(ch, full_shape, mode="trilinear").transpose(1,2,3,0)
    scale = np.asarray(full_shape, dtype=np.float32) / np.asarray(stage_shape, dtype=np.float32)
    up[..., 0] *= scale[0]
    up[..., 1] *= scale[1]
    up[..., 2] *= scale[2]
    return up.astype(np.float32)


def compose_pull(parent: np.ndarray, residual: np.ndarray) -> np.ndarray:
    """Compose pull fields: final(x)=residual(x)+parent(x+residual(x))."""
    if residual.shape != parent.shape:
        raise ValueError("compose shape mismatch")
    X,Y,Z,_ = parent.shape
    xs, ys, zs = np.meshgrid(np.arange(X, dtype=np.float32), np.arange(Y, dtype=np.float32), np.arange(Z, dtype=np.float32), indexing="ij")
    coords = np.vstack([(xs + residual[...,0]).reshape(-1), (ys + residual[...,1]).reshape(-1), (zs + residual[...,2]).reshape(-1)])
    warped_parent = np.empty_like(parent.reshape(-1,3).T)
    for c in range(3):
        warped_parent[c] = ndi.map_coordinates(parent[...,c], coords, order=1, mode="nearest")
    final = residual.reshape(-1,3).T + warped_parent
    return final.T.reshape(parent.shape).astype(np.float32)


def build_feature_maps(ct: np.ndarray, lobes: np.ndarray, support: Optional[np.ndarray], spacing: Sequence[float], cfg: Dict) -> Dict[str,np.ndarray]:
    if support is None:
        support = support_from_labels(lobes)
    support = (support > 0.5).astype(np.float32)
    ct_ch = clip_norm_ct(ct)[None]
    oh = one_hot_lobes(lobes)
    sdf = signed_distance_channels(lobes, spacing=spacing, clip_mm=float(cfg.get("sdf_clip_mm", 18.0)))
    fiss = fissure_band_channels(lobes, spacing=spacing,
                                 radius_mm=float(cfg.get("fissure_band_radius_mm", 7.5)),
                                 clip_mm=float(cfg.get("fissure_clip_mm", 12.0)))
    return {
        "ct": ct_ch.astype(np.float32),
        "onehot": oh.astype(np.float32),
        "sdf": sdf.astype(np.float32),
        "support": support[None].astype(np.float32),
        "fissure": fiss.astype(np.float32),
    }


def optimize_stage(fixed_feats: Dict[str,np.ndarray], moving_feats: Dict[str,np.ndarray], parent_stage: np.ndarray, stage_cfg: Dict, device: str) -> Dict:
    shape = fixed_feats["ct"].shape[1:]
    X,Y,Z = shape
    grid = make_identity_grid_zyx(shape, device)
    parent_t = torch.from_numpy(parent_stage.transpose(3,2,1,0)[None]).float().to(device)  # 1,3,Z,Y,X

    # Control-grid residual in voxel units at a smaller grid.
    cf = int(stage_cfg.get("control_factor", 4))
    ctrl_shape = (max(3, math.ceil(Z/cf)), max(3, math.ceil(Y/cf)), max(3, math.ceil(X/cf)))
    ctrl = torch.zeros((1,3,ctrl_shape[0],ctrl_shape[1],ctrl_shape[2]), device=device, requires_grad=True)
    opt = torch.optim.Adam([ctrl], lr=float(stage_cfg.get("lr", 0.02)))
    max_res = float(stage_cfg.get("max_residual_vox", 1.0))

    f_ct = make_torch_volume(fixed_feats["ct"], device)
    m_ct = make_torch_volume(moving_feats["ct"], device)
    f_oh = make_torch_volume(fixed_feats["onehot"], device)
    m_oh = make_torch_volume(moving_feats["onehot"], device)
    f_sdf = make_torch_volume(fixed_feats["sdf"], device)
    m_sdf = make_torch_volume(moving_feats["sdf"], device)
    f_sup = make_torch_volume(fixed_feats["support"], device)
    m_sup = make_torch_volume(moving_feats["support"], device)
    f_fis = make_torch_volume(fixed_feats["fissure"], device)
    m_fis = make_torch_volume(moving_feats["fissure"], device)
    mask = torch.clamp(f_sup + warp_torch(m_sup, parent_t, grid, shape, mode="bilinear"), 0, 1)

    w = stage_cfg.get("weights", {})
    best = {"loss": float("inf"), "iter": 0, "residual": None}
    traces = []
    iters = int(stage_cfg.get("iterations", 120))
    for it in range(1, iters+1):
        opt.zero_grad(set_to_none=True)
        res = F.interpolate(ctrl, size=(Z,Y,X), mode="trilinear", align_corners=True)
        # Bound residual smoothly.
        res = torch.tanh(res / max(max_res,1e-6)) * max_res
        d = parent_t + res
        w_ct = warp_torch(m_ct, d, grid, shape, mode="bilinear")
        w_oh = warp_torch(m_oh, d, grid, shape, mode="bilinear")
        w_sdf = warp_torch(m_sdf, d, grid, shape, mode="bilinear")
        w_sup = warp_torch(m_sup, d, grid, shape, mode="bilinear")
        w_fis = warp_torch(m_fis, d, grid, shape, mode="bilinear")
        loss_ct = lncc_loss(f_ct, w_ct, mask)
        loss_oh = dice_loss_soft(f_oh, w_oh)
        loss_sdf = torch.sqrt((f_sdf - w_sdf).pow(2) + 1e-4).mean()
        loss_sup = dice_loss_soft(f_sup, w_sup)
        loss_fis = torch.sqrt((f_fis - w_fis).pow(2) + 1e-4).mean()
        loss_b = bending_loss(res)
        loss_s = smoothness_loss(res)
        loss_mag = res.pow(2).mean()
        loss = (float(w.get("ct_lncc", 0.20))*loss_ct +
                float(w.get("lobe_dice", 1.00))*loss_oh +
                float(w.get("sdf", 0.80))*loss_sdf +
                float(w.get("support", 0.10))*loss_sup +
                float(w.get("fissure", 0.35))*loss_fis +
                float(w.get("bend", 0.06))*loss_b +
                float(w.get("smooth", 0.02))*loss_s +
                float(w.get("mag", 0.01))*loss_mag)
        loss.backward()
        torch.nn.utils.clip_grad_norm_([ctrl], 2.0)
        opt.step()
        val = float(loss.detach().cpu())
        if val < best["loss"]:
            best["loss"] = val
            best["iter"] = it
            best["residual"] = res.detach().cpu().numpy()[0].transpose(3,2,1,0).astype(np.float32)
        if it == 1 or it == iters or it % int(stage_cfg.get("trace_every", 20)) == 0:
            traces.append({
                "iter": it,
                "loss": val,
                "ct_lncc": float(loss_ct.detach().cpu()),
                "lobe_dice_loss": float(loss_oh.detach().cpu()),
                "sdf": float(loss_sdf.detach().cpu()),
                "support": float(loss_sup.detach().cpu()),
                "fissure": float(loss_fis.detach().cpu()),
                "bend": float(loss_b.detach().cpu()),
                "smooth": float(loss_s.detach().cpu()),
                "mag": float(loss_mag.detach().cpu()),
            })
    if best["residual"] is None:
        best["residual"] = np.zeros(shape + (3,), dtype=np.float32)
    return {"best_iteration": best["iter"], "best_loss": best["loss"], "residual": best["residual"], "traces": traces}


def proxy_metrics(fixed_feats: Dict[str,np.ndarray], moving_feats: Dict[str,np.ndarray], dvf_stage: np.ndarray, device: str) -> Dict[str,float]:
    shape = fixed_feats["ct"].shape[1:]
    grid = make_identity_grid_zyx(shape, device)
    d = torch.from_numpy(dvf_stage.transpose(3,2,1,0)[None]).float().to(device)
    f_ct = make_torch_volume(fixed_feats["ct"], device); m_ct = make_torch_volume(moving_feats["ct"], device)
    f_oh = make_torch_volume(fixed_feats["onehot"], device); m_oh = make_torch_volume(moving_feats["onehot"], device)
    f_sdf = make_torch_volume(fixed_feats["sdf"], device); m_sdf = make_torch_volume(moving_feats["sdf"], device)
    f_sup = make_torch_volume(fixed_feats["support"], device); m_sup = make_torch_volume(moving_feats["support"], device)
    f_fis = make_torch_volume(fixed_feats["fissure"], device); m_fis = make_torch_volume(moving_feats["fissure"], device)
    with torch.no_grad():
        w_ct = warp_torch(m_ct, d, grid, shape)
        w_oh = warp_torch(m_oh, d, grid, shape)
        w_sdf = warp_torch(m_sdf, d, grid, shape)
        w_sup = warp_torch(m_sup, d, grid, shape)
        w_fis = warp_torch(m_fis, d, grid, shape)
        mask = torch.clamp(f_sup + w_sup, 0, 1)
        out = {
            "ct_lncc_loss": float(lncc_loss(f_ct, w_ct, mask).cpu()),
            "lobe_dice_loss": float(dice_loss_soft(f_oh, w_oh).cpu()),
            "sdf_loss": float(torch.sqrt((f_sdf - w_sdf).pow(2)+1e-4).mean().cpu()),
            "support_dice_loss": float(dice_loss_soft(f_sup, w_sup).cpu()),
            "fissure_loss": float(torch.sqrt((f_fis - w_fis).pow(2)+1e-4).mean().cpu()),
        }
    return out


def score_candidate(base: Dict[str,float], cand: Dict[str,float], weights: Dict[str,float]) -> float:
    score = 0.0
    # Positive score means improvement.
    for k, wk in weights.items():
        if k in base and k in cand:
            score += float(wk) * (float(base[k]) - float(cand[k]))
    return float(score)


def run_case(case_id: str, cfg: Dict, device: str) -> Dict:
    t0 = time.time()
    dataset_root = Path(cfg["dataset_root"])
    seg_dir = Path(cfg["segmentation_dir"])
    out_dir = Path(cfg["output_dir"])
    ct_dir = dataset_root / "validation" / "ct_data"
    exp_p = ct_dir / f"{case_id}_EXP.nii.gz"
    insp_p = ct_dir / f"{case_id}_INSP.nii.gz"
    exp_img = nib.load(str(exp_p)); insp_img = nib.load(str(insp_p))
    exp, exp_can = as_canonical_float(exp_img)
    insp, insp_can = as_canonical_float(insp_img)
    if exp.shape != insp.shape:
        raise ValueError(f"Canonical EXP/INSP shape mismatch for {case_id}: {exp.shape} vs {insp.shape}")
    spacing = tuple(np.sqrt((insp_can.affine[:3,:3] ** 2).sum(axis=0)).tolist())

    exp_lobes_p = seg_dir / "lobes" / "validation" / f"{case_id}_EXP_lobes.nii.gz"
    insp_lobes_p = seg_dir / "lobes" / "validation" / f"{case_id}_INSP_lobes.nii.gz"
    exp_sup_p = seg_dir / "support" / "validation" / f"{case_id}_EXP_support.nii.gz"
    insp_sup_p = seg_dir / "support" / "validation" / f"{case_id}_INSP_support.nii.gz"
    if not exp_lobes_p.exists() or not insp_lobes_p.exists():
        raise FileNotFoundError(f"Missing predicted lobe segmentations for {case_id}: {exp_lobes_p}, {insp_lobes_p}")
    exp_lobes, _ = as_canonical_label(nib.load(str(exp_lobes_p)))
    insp_lobes, _ = as_canonical_label(nib.load(str(insp_lobes_p)))
    exp_sup = as_canonical_float(nib.load(str(exp_sup_p)))[0] if exp_sup_p.exists() else support_from_labels(exp_lobes)
    insp_sup = as_canonical_float(nib.load(str(insp_sup_p)))[0] if insp_sup_p.exists() else support_from_labels(insp_lobes)

    feat_cfg = cfg.get("features", {})
    fixed_feats_full = build_feature_maps(insp, insp_lobes, insp_sup, spacing, feat_cfg)
    moving_feats_full = build_feature_maps(exp, exp_lobes, exp_sup, spacing, feat_cfg)

    parent_dir = cfg.get("initializer_dir") or None
    parent_full = load_parent_dvf_canonical(parent_dir, case_id, insp.shape)
    if parent_full is None:
        parent_full = np.zeros(insp.shape + (3,), dtype=np.float32)
        init_mode = "identity"
    else:
        init_mode = str(parent_dir)
    original_parent_full = parent_full.copy()

    records = []
    current_full = parent_full
    for stage_cfg in cfg.get("stages", []):
        stage_name = stage_cfg.get("name", "stage")
        reduce = int(stage_cfg.get("reduce_factor", 2))
        stage_shape = tuple(max(8, int(round(s / reduce))) for s in insp.shape)
        fixed_stage = {k: downsample_np_channels(v, stage_shape, mode="trilinear") for k,v in fixed_feats_full.items()}
        moving_stage = {k: downsample_np_channels(v, stage_shape, mode="trilinear") for k,v in moving_feats_full.items()}
        parent_stage = resample_parent_to_stage(current_full, stage_shape)
        base_proxy = proxy_metrics(fixed_stage, moving_stage, parent_stage, device)
        opt = optimize_stage(fixed_stage, moving_stage, parent_stage, stage_cfg, device)
        res_stage = opt["residual"]
        # Candidate scales on residual only.
        scales = [float(x) for x in stage_cfg.get("candidate_scales", [1.0,0.75,0.5,0.25,0.125,0.0])]
        candidates = []
        best_c = None
        base_top = jacobian_folding_pct_np(parent_stage)
        score_w = stage_cfg.get("selection_score_weights", {
            "lobe_dice_loss": 1.0, "sdf_loss": 0.5, "fissure_loss": 0.3, "support_dice_loss": 0.2, "ct_lncc_loss": 0.1
        })
        fold_limit = float(stage_cfg.get("folding_limit_pct", cfg.get("relaxed_folding_limit_pct", 0.02)))
        rel_plus = float(stage_cfg.get("relative_folding_plus_pct", 0.02))
        fold_limit = max(fold_limit, base_top["folding_pct"] + rel_plus)
        min_score = float(stage_cfg.get("min_score_gain", 1e-5))
        max_proxy_lobe_drop = float(stage_cfg.get("max_proxy_lobe_loss_increase", 0.0020))
        max_support_drop = float(stage_cfg.get("max_support_loss_increase", 0.0020))
        for sc in scales:
            cand_stage = parent_stage + sc * res_stage
            prox = proxy_metrics(fixed_stage, moving_stage, cand_stage, device)
            top = jacobian_folding_pct_np(cand_stage)
            sc_score = score_candidate(base_proxy, prox, score_w)
            reasons = []
            if sc == 0.0:
                reasons += ["scale=0 reserved for exact stage no-op"]
            if sc_score < min_score:
                reasons += [f"score_gain={sc_score:.6g} below minimum {min_score}"]
            if top["folding_pct"] > fold_limit:
                reasons += [f"folding_pct={top['folding_pct']:.6g} > limit {fold_limit:.6g}"]
            if prox["lobe_dice_loss"] > base_proxy["lobe_dice_loss"] + max_proxy_lobe_drop:
                reasons += ["proxy_lobe_loss_increase"]
            if prox["support_dice_loss"] > base_proxy["support_dice_loss"] + max_support_drop:
                reasons += ["support_loss_increase"]
            cand = {"scale": sc, "score": sc_score, "accepted": len(reasons)==0, "rejection_reasons": reasons, **prox, **top}
            candidates.append(cand)
            if cand["accepted"] and (best_c is None or cand["score"] > best_c["score"]):
                best_c = cand
        if best_c is None:
            selected_scale = 0.0
            decision = "no-op"
        else:
            selected_scale = float(best_c["scale"])
            decision = "apply"
        selected_res_full = upsample_stage_disp_to_full(selected_scale * res_stage, insp.shape)
        current_full = current_full + selected_res_full
        rec = {
            "stage": stage_name,
            "decision": decision,
            "stage_shape": stage_shape,
            "base_proxy": base_proxy,
            "base_topology": base_top,
            "optimization": {"best_iteration": opt["best_iteration"], "best_loss": opt["best_loss"], "iterations": int(stage_cfg.get("iterations", 120))},
            "selected": best_c if best_c is not None else {"scale": 0.0, "score": 0.0, "accepted": False},
            "candidates": candidates,
        }
        records.append(rec)
        # Write trace per stage.
        trace_path = out_dir / "traces" / f"{case_id}_{stage_name}_trace.json"
        save_json(opt["traces"], trace_path)

    # Optional exact fallback if no stage accepted.
    if all(r["decision"] == "no-op" for r in records):
        current_full = original_parent_full.copy()
        fallback = True
    else:
        fallback = False

    out_can = out_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz"
    out_can.parent.mkdir(parents=True, exist_ok=True)
    nib.save(nib.Nifti1Image(current_full.astype(np.float32), insp_can.affine), str(out_can))
    out_orig = out_dir / "dvfs" / f"{case_id}_DVF.nii.gz"
    export_canonical_pull_dvf_to_original_grid(current_full, insp_img, insp_can, exp_img, exp_can, out_orig,
                                               slab_z=int(cfg.get("export_slab_z", 16)))
    final_top = jacobian_folding_pct_np(current_full)
    rec = {
        "case_id": case_id,
        "status": "ok",
        "initializer_mode": init_mode,
        "fallback_exact_parent_copy": fallback,
        "output_dvf": str(out_orig),
        "output_canonical_dvf": str(out_can),
        "stages": records,
        "final_topology_canonical": final_top,
        "elapsed_sec": time.time()-t0,
    }
    save_json(rec, out_dir / "case_manifests" / f"{case_id}_manifest.json")
    return rec


def run_evaluation_if_available(cfg: Dict) -> Dict:
    eval_script = Path(cfg.get("evaluation_script", "evaluate_validation.py"))
    out_dir = Path(cfg["output_dir"])
    eval_dir = out_dir / "eval"
    if not bool(cfg.get("run_evaluation", True)):
        return {"skipped": True, "reason": "run_evaluation=false"}
    if not eval_script.exists():
        return {"skipped": True, "reason": f"evaluation script not found: {eval_script}"}
    cmd = [
        "python", str(eval_script),
        "--raw-data-root", str(cfg["dataset_root"]),
        "--dvf-dir", str(out_dir / "dvfs"),
        "--output-dir", str(eval_dir),
    ]
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return {"skipped": False, "cmd": cmd, "exit_code": p.returncode, "output_tail": p.stdout[-4000:]}


def summarize_against_parent(cfg: Dict, records: List[Dict]) -> Dict:
    out_dir = Path(cfg["output_dir"])
    parent_dir = Path(cfg.get("initializer_dir") or "")
    this_eval = out_dir / "eval" / "validation_metrics.json"
    parent_eval = parent_dir / "eval" / "validation_metrics.json"
    summary = {"comparison_available": False}
    if not this_eval.exists() or not parent_eval.exists():
        return summary
    a = json.loads(parent_eval.read_text())
    b = json.loads(this_eval.read_text())
    ma = {m["case_id"]: m for m in a.get("case_metrics", [])}
    mb = {m["case_id"]: m for m in b.get("case_metrics", [])}
    rows = []
    for cid in sorted(set(ma) & set(mb)):
        ra, rb = ma[cid], mb[cid]
        row = {"case_id": cid,
               "parent_mean_lobe_dice": ra.get("mean_lobe_dice"),
               "C7A_mean_lobe_dice": rb.get("mean_lobe_dice"),
               "delta_mean_lobe_dice": rb.get("mean_lobe_dice") - ra.get("mean_lobe_dice"),
               "parent_RML_dice": ra.get("dice_64"),
               "C7A_RML_dice": rb.get("dice_64"),
               "delta_RML_dice": rb.get("dice_64") - ra.get("dice_64"),
               "parent_folding_percentage": ra.get("folding_percentage"),
               "C7A_folding_percentage": rb.get("folding_percentage"),
               "delta_folding_percentage": rb.get("folding_percentage") - ra.get("folding_percentage")}
        rows.append(row)
    if rows:
        comp_dir = out_dir / "comparison"; comp_dir.mkdir(parents=True, exist_ok=True)
        with open(comp_dir / "PARENT_vs_C7A_per_case.csv", "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader(); writer.writerows(rows)
        deltas = [r["delta_mean_lobe_dice"] for r in rows]
        rd = [r["delta_RML_dice"] for r in rows]
        summary = {
            "comparison_available": True,
            "common_case_count": len(rows),
            "parent_mean_lobe_dice": a.get("mean_lobe_dice"),
            "C7A_mean_lobe_dice": b.get("mean_lobe_dice"),
            "delta_mean_lobe_dice": b.get("mean_lobe_dice") - a.get("mean_lobe_dice"),
            "parent_mean_folding_percentage": a.get("mean_folding_percentage"),
            "C7A_mean_folding_percentage": b.get("mean_folding_percentage"),
            "delta_mean_folding_percentage": b.get("mean_folding_percentage") - a.get("mean_folding_percentage"),
            "mean_delta_RML_dice": float(np.mean(rd)),
            "improved_cases": int(np.sum(np.asarray(deltas) > 0)),
            "worsened_cases": int(np.sum(np.asarray(deltas) < 0)),
            "improved_RML_cases": int(np.sum(np.asarray(rd) > 0)),
            "worsened_RML_cases": int(np.sum(np.asarray(rd) < 0)),
            "min_paired_dice_delta": float(np.min(deltas)),
            "max_paired_dice_delta": float(np.max(deltas)),
            "min_paired_RML_delta": float(np.min(rd)),
            "max_paired_RML_delta": float(np.max(rd)),
        }
        save_json(summary, comp_dir / "PARENT_vs_C7A_summary.json")
    return summary


def run_validation(cfg: Dict, cases: Optional[List[str]] = None, dry_run: bool = False) -> Dict:
    out_dir = Path(cfg["output_dir"]); out_dir.mkdir(parents=True, exist_ok=True)
    device = "cuda" if bool(cfg.get("use_cuda", True)) and torch.cuda.is_available() else "cpu"
    if cases is None or not cases:
        cases = find_cases(cfg["dataset_root"])
    if dry_run:
        summary = {"schema_version": 1, "experiment": "SGR-FM C7A semantic-Adam", "dry_run": True,
                   "device": device, "cases": cases, "output_dir": str(out_dir)}
        save_json(summary, out_dir / "c7a_semantic_adam_summary.json")
        return summary
    records = []
    failed = []
    for cid in cases:
        try:
            records.append(run_case(cid, cfg, device))
        except Exception as e:
            failed.append({"case_id": cid, "error": repr(e)})
            save_json({"case_id": cid, "status": "failed", "error": repr(e)}, out_dir / "case_manifests" / f"{cid}_FAILED.json")
            if not bool(cfg.get("continue_on_error", False)):
                raise
    eval_info = run_evaluation_if_available(cfg)
    comp = summarize_against_parent(cfg, records)
    summary = {
        "schema_version": 1,
        "experiment": "SGR-FM C7A semantic-Adam / ConvexAdam-style label-first branch",
        "status": "PASS" if not failed and (eval_info.get("skipped") or eval_info.get("exit_code", 0) == 0) else "CHECK",
        "case_count": len(cases),
        "processed_count": len(records),
        "failed_count": len(failed),
        "failed": failed,
        "device": device,
        "output_dir": str(out_dir),
        "initializer_dir": cfg.get("initializer_dir"),
        "records": records,
        "evaluation": eval_info,
        "comparison": comp,
    }
    save_json(summary, out_dir / "c7a_semantic_adam_summary.json")
    return summary


def assert_no_gt_leakage_source_scan(root: str | os.PathLike) -> List[str]:
    """Very small guard: optimizer source should not reference validation label GT folders."""
    bad = []
    root_path = Path(root)
    files = [root_path] if root_path.is_file() else list(root_path.rglob("*.py"))
    for p in files:
        text = p.read_text(encoding="utf-8", errors="ignore")
        forbidden = ["validation" + "/" + "labels", "validation" + "/" + "label_data", "gt" + "_lobes", "gt" + "_fissures"]
        if any(x in text for x in forbidden):
            bad.append(str(p))
    return bad
