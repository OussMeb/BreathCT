SGR-FM C7A semantic-Adam / ConvexAdam-style branch
=====================================================

Purpose
-------
C7A tests a label-first registration approach. It uses the existing predicted
lobe/support segmentations, builds lobe one-hot, signed-distance, fissure-band,
and CT features, then optimizes a smooth pull displacement field with Adam over
a low-resolution control grid. It is ConvexAdam-style in objective design, but
it is self-contained and does not require the official ConvexAdam repository.

It starts from the current C6-RMLA champion by default:
  outputs/sgr_fm/c6_rml_aware

To test identity-only C7A, edit initializer_dir: "" in the YAML.

Commands
--------
cd "/home/oussama/Desktop/MICCAI FRANCE"
unzip -o SGR_FM_C7A_SEMANTIC_ADAM_patch.zip -d .

python -m py_compile \
  run_sgr_fm_c7a_semantic_adam_validation.py \
  utils/sgr_fm_c7a_semantic_adam.py \
  smoke_sgr_fm_c7a_semantic_adam_synthetic.py

python smoke_sgr_fm_c7a_semantic_adam_synthetic.py

python run_sgr_fm_c7a_semantic_adam_validation.py \
  --config configs/sgr_fm_c7a_semantic_adam.yaml \
  --dry-run

Recommended first real test on hard cases:
python run_sgr_fm_c7a_semantic_adam_validation.py \
  --config configs/sgr_fm_c7a_semantic_adam.yaml \
  --cases NLST_0006 NLST_0007 NLST_0009

Full validation:
python run_sgr_fm_c7a_semantic_adam_validation.py \
  --config configs/sgr_fm_c7a_semantic_adam.yaml

Outputs
-------
outputs/sgr_fm/c7a_semantic_adam/
  dvfs/
  dvfs_canonical_ras/
  case_manifests/
  traces/
  eval/validation_metrics.json
  comparison/PARENT_vs_C7A_summary.json
  comparison/PARENT_vs_C7A_per_case.csv
  c7a_semantic_adam_summary.json

After the full run, upload:
  outputs/sgr_fm/c7a_semantic_adam/c7a_semantic_adam_summary.json
  outputs/sgr_fm/c7a_semantic_adam/eval/validation_metrics.json
  outputs/sgr_fm/c7a_semantic_adam/comparison/PARENT_vs_C7A_summary.json
  outputs/sgr_fm/c7a_semantic_adam/comparison/PARENT_vs_C7A_per_case.csv

Important
---------
The optimizer does not read validation GT labels. The validation evaluator is
called only after DVFs are exported.
