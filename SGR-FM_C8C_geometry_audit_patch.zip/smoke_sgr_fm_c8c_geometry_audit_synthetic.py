#!/usr/bin/env python3
"""Dependency-light synthetic check for C8C SDF geometry calibration."""

import numpy as np

from utils.sgr_fm_c8c_geometry_audit import (
    PreparedCase,
    _prepare_right_scores,
    apply_right_lobe_biases,
    calibrate_prepared_cases,
    dice_by_lobe,
    generate_bias_candidates,
)


def make_case(case_id: str) -> tuple[np.ndarray, np.ndarray]:
    shape = (28, 22, 18)
    pseudo = np.zeros(shape, dtype=np.int16)
    target = np.zeros(shape, dtype=np.int16)
    # Left lung is unchanged and must be preserved by the correction.
    pseudo[2:10, 3:10, 3:15] = 8
    target[2:10, 3:10, 3:15] = 8
    # Right union is fixed. The pseudo RML is systematically too thin.
    region = (slice(15, 26), slice(4, 19), slice(2, 16))
    pseudo[region] = 128
    target[region] = 128
    pseudo[15:26, 4:19, 2:7] = 32
    pseudo[15:26, 4:19, 7:9] = 64
    target[15:26, 4:19, 2:6] = 32
    target[15:26, 4:19, 6:10] = 64
    return pseudo, target


def main() -> None:
    labels = [8, 16, 32, 64, 128]
    right = [32, 64, 128]
    candidates = generate_bias_candidates(right, 128, -3.0, 3.0, 1.0)
    cases = []
    for index in range(4):
        pseudo, target = make_case(f"SYN_{index}")
        scores, gt_union, gt_counts = _prepare_right_scores(pseudo, target, (1.0, 1.0, 1.0), right)
        cases.append(PreparedCase(
            case_id=f"SYN_{index}",
            phase="EXP",
            pseudo_path=None,
            gt_path=None,
            spacing_mm=(1.0, 1.0, 1.0),
            scores_at_union=scores,
            gt_at_union=gt_union,
            gt_counts=gt_counts,
            baseline_per_lobe=dice_by_lobe(pseudo, target, labels),
            diagnostics={},
        ))

    result = calibrate_prepared_cases(cases, candidates, labels, right, {32: 1.0, 64: 1.0, 128: 1.0})
    assert result["loo_minus_baseline_five_lobe_dice"] > 0.0
    assert result["global_biases_mm"][64] > 0.0

    pseudo, _ = make_case("PRESERVE")
    corrected = apply_right_lobe_biases(pseudo, (1.0, 1.0, 1.0), result["global_biases_mm"], right)
    assert np.array_equal(np.isin(corrected, right), np.isin(pseudo, right))
    assert np.array_equal(corrected[pseudo == 8], pseudo[pseudo == 8])
    print("SGR-FM C8C GEOMETRY AUDIT SYNTHETIC SMOKE: PASS")
    print({
        "global_biases_mm": result["global_biases_mm"],
        "loo_gain": result["loo_minus_baseline_five_lobe_dice"],
    })


if __name__ == "__main__":
    main()

