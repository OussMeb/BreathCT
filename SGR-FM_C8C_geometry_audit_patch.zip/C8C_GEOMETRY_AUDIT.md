# C8C pseudo-label geometry audit

This diagnostic must run before the C8C registration branch. C8A measured the
size of the GT-assisted registration gap, but its Dice-only gap tables do not
identify whether the EXP/INSP RUL, RML, and RLL boundaries should expand,
contract, or shift.

The audit:

- measures phase-specific lobe volume, centroid, and right-fissure errors;
- searches conservative signed-distance biases for RUL and RML while using RLL
  as the zero-bias reference;
- preserves the right-lung union, background, and both left lobes exactly;
- reports in-sample global calibration and leave-one-case-out (LOO) results;
- does not create or modify DVFs.

Run from the project root:

```bash
python run_sgr_fm_c8c_geometry_audit.py \
  --config configs/sgr_fm_c8c_geometry_audit.yaml
```

Expected outputs:

```text
outputs/sgr_fm/c8c_geometry_audit/
├── c8c_geometry_audit_summary.json
├── c8c_geometry_audit_per_case_phase.csv
├── c8c_geometry_calibration.json
└── run_config_resolved.json
```

Interpret the LOO result as the main generalization check. The global result is
optimistic because it evaluates the same ten cases used to fit the bias. The
generated calibration remains validation-GT-derived, but applying its global
biases later does not require case-specific GT at inference.

Do not launch geometry-corrected registration until the summary decision and
per-case losses have been reviewed. If the audit passes, C8C registration will
use C8B as the exact fallback and will compare additive versus exact-pull
residual composition as a separate ablation.
