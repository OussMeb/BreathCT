from __future__ import annotations

import csv
import itertools
import json
import math
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import numpy as np

try:
    import nibabel as nib
except Exception:  # pragma: no cover - allows dependency-light core smoke tests
    nib = None

try:
    from scipy.ndimage import binary_dilation, distance_transform_edt
except Exception as exc:  # pragma: no cover
    raise RuntimeError("C8C geometry audit requires scipy.ndimage") from exc


LOBE_LABELS = (8, 16, 32, 64, 128)
RIGHT_LABELS = (32, 64, 128)
CASE_RE = re.compile(r"^(NLST_\d{4})_(EXP|INSP)_lobe\.nii\.gz$", re.IGNORECASE)


def _recursive_update(base: dict[str, Any], updates: dict[str, Any]) -> dict[str, Any]:
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _recursive_update(base[key], value)
        else:
            base[key] = value
    return base


def default_config() -> dict[str, Any]:
    return {
        "output_root": "outputs/sgr_fm/c8c_geometry_audit",
        "raw_data_root": "Learn2Breath_train_val_data",
        "pseudo_segmentation_root": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "phases": ["EXP", "INSP"],
        "labels": list(LOBE_LABELS),
        "right_labels": list(RIGHT_LABELS),
        "reference_label": 128,
        "bias_min_mm": -4.5,
        "bias_max_mm": 4.5,
        "bias_step_mm": 0.75,
        "objective_weights": {"32": 1.0, "64": 1.0, "128": 1.0},
        "affine_atol": 1e-5,
        "interface_dilation_iterations": 1,
        "compute_interface_diagnostics": True,
        "minimum_loo_five_lobe_gain": 0.00020,
        "minimum_loo_improved_fraction": 0.60,
        "max_allowed_loo_case_loss": 0.0020,
    }


def load_config(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    if p.suffix.lower() == ".json":
        loaded = json.loads(text)
    else:
        try:
            import yaml
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("PyYAML is required for a YAML C8C config") from exc
        loaded = yaml.safe_load(text) or {}
    if not isinstance(loaded, dict):
        raise ValueError(f"Config must contain a mapping: {p}")
    loaded = loaded.get("sgr_fm_c8c_geometry_audit", loaded)
    cfg = default_config()
    _recursive_update(cfg, loaded)
    return cfg


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_jsonable(value), indent=2, allow_nan=False), encoding="utf-8")


def dice_by_lobe(pred: np.ndarray, target: np.ndarray, labels: Sequence[int]) -> dict[int, float]:
    result: dict[int, float] = {}
    for label in labels:
        p = np.asarray(pred) == int(label)
        t = np.asarray(target) == int(label)
        denominator = int(p.sum() + t.sum())
        result[int(label)] = 1.0 if denominator == 0 else float(2.0 * np.logical_and(p, t).sum() / denominator)
    return result


def mean_dice(per_lobe: dict[int, float], labels: Sequence[int]) -> float:
    return float(np.mean([per_lobe[int(label)] for label in labels]))


def signed_distance_mm(mask: np.ndarray, spacing_mm: Sequence[float]) -> np.ndarray:
    binary = np.asarray(mask, dtype=bool)
    if not binary.any() or binary.all():
        raise ValueError("Signed distance requires a non-empty, non-full mask")
    inside = distance_transform_edt(binary, sampling=tuple(float(x) for x in spacing_mm))
    outside = distance_transform_edt(~binary, sampling=tuple(float(x) for x in spacing_mm))
    return (inside - outside).astype(np.float32, copy=False)


def apply_right_lobe_biases(
    pseudo: np.ndarray,
    spacing_mm: Sequence[float],
    biases_mm: dict[int, float],
    right_labels: Sequence[int] = RIGHT_LABELS,
) -> np.ndarray:
    """Repartition the existing right-lung union with biased lobe SDF scores.

    score(label) = signed_distance_mm(label) + bias_mm(label). Positive bias
    expands a lobe at the expense of adjacent right lobes. The right-lung union,
    background, and both left lobes are preserved exactly.
    """
    arr = np.asarray(pseudo)
    labels = tuple(int(x) for x in right_labels)
    union = np.isin(arr, labels)
    if not union.any():
        raise ValueError("Right-lung pseudo-label union is empty")
    scores = np.stack(
        [signed_distance_mm(arr == label, spacing_mm) + float(biases_mm.get(label, 0.0)) for label in labels],
        axis=0,
    )
    winner = np.argmax(scores[:, union], axis=0)
    corrected = arr.copy()
    corrected[union] = np.asarray(labels, dtype=corrected.dtype)[winner]
    return corrected


@dataclass
class PreparedCase:
    case_id: str
    phase: str
    pseudo_path: Path
    gt_path: Path
    spacing_mm: tuple[float, float, float]
    scores_at_union: np.ndarray
    gt_at_union: np.ndarray
    gt_counts: dict[int, int]
    baseline_per_lobe: dict[int, float]
    diagnostics: dict[str, Any]


def _prepare_right_scores(
    pseudo: np.ndarray,
    target: np.ndarray,
    spacing_mm: Sequence[float],
    right_labels: Sequence[int],
) -> tuple[np.ndarray, np.ndarray, dict[int, int]]:
    labels = tuple(int(x) for x in right_labels)
    union = np.isin(pseudo, labels)
    if not union.any():
        raise ValueError("Right-lung pseudo-label union is empty")
    indices = np.flatnonzero(union.ravel())
    scores = np.stack(
        [signed_distance_mm(pseudo == label, spacing_mm).ravel()[indices] for label in labels],
        axis=0,
    ).astype(np.float32, copy=False)
    gt_flat = np.asarray(target).ravel()
    gt_at_union = gt_flat[indices].astype(np.int16, copy=False)
    gt_counts = {label: int(np.sum(target == label)) for label in labels}
    return scores, gt_at_union, gt_counts


def evaluate_prepared_bias(
    case: PreparedCase,
    biases_mm: dict[int, float],
    right_labels: Sequence[int],
    objective_weights: dict[int, float],
) -> tuple[float, dict[int, float]]:
    labels = tuple(int(x) for x in right_labels)
    bias = np.asarray([float(biases_mm.get(label, 0.0)) for label in labels], dtype=np.float32)[:, None]
    winners = np.argmax(case.scores_at_union + bias, axis=0)
    per: dict[int, float] = {}
    weighted_sum = 0.0
    weight_sum = 0.0
    for channel, label in enumerate(labels):
        predicted = winners == channel
        pred_count = int(predicted.sum())
        intersection = int(np.count_nonzero(case.gt_at_union[predicted] == label))
        denominator = pred_count + int(case.gt_counts[label])
        value = 1.0 if denominator == 0 else float(2.0 * intersection / denominator)
        per[label] = value
        weight = float(objective_weights.get(label, 1.0))
        weighted_sum += weight * value
        weight_sum += weight
    return weighted_sum / max(weight_sum, 1e-8), per


def generate_bias_candidates(
    right_labels: Sequence[int],
    reference_label: int,
    bias_min_mm: float,
    bias_max_mm: float,
    bias_step_mm: float,
) -> list[dict[int, float]]:
    labels = tuple(int(x) for x in right_labels)
    reference = int(reference_label)
    if reference not in labels:
        raise ValueError(f"reference_label {reference} is not in right_labels {labels}")
    if bias_step_mm <= 0 or bias_max_mm < bias_min_mm:
        raise ValueError("Invalid C8C bias grid")
    count = int(math.floor((bias_max_mm - bias_min_mm) / bias_step_mm + 0.5)) + 1
    values = [round(float(bias_min_mm + i * bias_step_mm), 8) for i in range(count)]
    non_reference = [label for label in labels if label != reference]
    candidates: list[dict[int, float]] = []
    for combination in itertools.product(values, repeat=len(non_reference)):
        bias = {label: 0.0 for label in labels}
        for label, value in zip(non_reference, combination):
            bias[label] = float(value)
        candidates.append(bias)
    return candidates


def _bias_norm(candidate: dict[int, float]) -> float:
    return float(sum(float(v) ** 2 for v in candidate.values()))


def select_candidate_index(mean_scores: np.ndarray, candidates: Sequence[dict[int, float]]) -> int:
    scores = np.asarray(mean_scores, dtype=np.float64)
    best_score = float(np.max(scores))
    tied = np.flatnonzero(np.isclose(scores, best_score, rtol=0.0, atol=1e-12)).tolist()
    return int(min(tied, key=lambda idx: (_bias_norm(candidates[idx]), tuple(candidates[idx].values()))))


def _spacing_from_affine(affine: np.ndarray) -> tuple[float, float, float]:
    spacing = tuple(float(v) for v in np.sqrt(np.sum(np.asarray(affine, dtype=np.float64)[:3, :3] ** 2, axis=0)))
    if any((not np.isfinite(v)) or v <= 0 for v in spacing):
        raise ValueError(f"Invalid spacing from affine: {spacing}")
    return spacing


def _centroid_world(mask: np.ndarray, affine: np.ndarray) -> np.ndarray | None:
    coords = np.argwhere(mask)
    if coords.size == 0:
        return None
    center = coords.mean(axis=0)
    return (np.asarray(affine, dtype=np.float64) @ np.r_[center, 1.0])[:3]


def _pair_interface(labels: np.ndarray, group_a: Sequence[int], group_b: Sequence[int], iterations: int) -> np.ndarray:
    a = np.isin(labels, tuple(int(x) for x in group_a))
    b = np.isin(labels, tuple(int(x) for x in group_b))
    da = binary_dilation(a, iterations=max(1, int(iterations)))
    db = binary_dilation(b, iterations=max(1, int(iterations)))
    return np.logical_and(da, db)


def _interface_diagnostic(
    pseudo: np.ndarray,
    target: np.ndarray,
    spacing_mm: Sequence[float],
    group_a: Sequence[int],
    group_b: Sequence[int],
    iterations: int,
) -> dict[str, float | None]:
    pseudo_surface = _pair_interface(pseudo, group_a, group_b, iterations)
    target_surface = _pair_interface(target, group_a, group_b, iterations)
    if not pseudo_surface.any() or not target_surface.any():
        return {"signed_offset_to_target_group_b_mm": None, "symmetric_surface_mean_mm": None, "symmetric_surface_p95_mm": None}
    target_b_sdf = signed_distance_mm(np.isin(target, tuple(group_b)), spacing_mm)
    signed = target_b_sdf[pseudo_surface]
    to_target = distance_transform_edt(~target_surface, sampling=tuple(spacing_mm))[pseudo_surface]
    to_pseudo = distance_transform_edt(~pseudo_surface, sampling=tuple(spacing_mm))[target_surface]
    both = np.concatenate([to_target, to_pseudo])
    return {
        "signed_offset_to_target_group_b_mm": float(np.median(signed)),
        "symmetric_surface_mean_mm": float(np.mean(both)),
        "symmetric_surface_p95_mm": float(np.percentile(both, 95.0)),
    }


def _case_diagnostics(
    pseudo: np.ndarray,
    target: np.ndarray,
    affine: np.ndarray,
    spacing_mm: Sequence[float],
    labels: Sequence[int],
    interface_iterations: int,
    compute_interfaces: bool,
) -> dict[str, Any]:
    out: dict[str, Any] = {"lobes": {}}
    for label in labels:
        p = pseudo == int(label)
        t = target == int(label)
        p_count = int(p.sum())
        t_count = int(t.sum())
        pc = _centroid_world(p, affine)
        tc = _centroid_world(t, affine)
        out["lobes"][str(label)] = {
            "pseudo_voxels": p_count,
            "gt_voxels": t_count,
            "pseudo_to_gt_volume_ratio": float(p_count / max(t_count, 1)),
            "centroid_distance_mm": None if pc is None or tc is None else float(np.linalg.norm(pc - tc)),
        }
    if compute_interfaces:
        out["interfaces"] = {
            "left_oblique": _interface_diagnostic(pseudo, target, spacing_mm, (8,), (16,), interface_iterations),
            "right_horizontal": _interface_diagnostic(pseudo, target, spacing_mm, (32,), (64,), interface_iterations),
            "right_oblique": _interface_diagnostic(pseudo, target, spacing_mm, (32, 64), (128,), interface_iterations),
        }
        out["interface_sign_convention"] = (
            "Positive signed offset means the pseudo interface lies on the GT group-B side; "
            "negative means it lies on the GT group-A side."
        )
    return out


def discover_gt_cases(raw_data_root: str | Path, phases: Sequence[str]) -> dict[str, dict[str, Path]]:
    validation = Path(raw_data_root) / "validation"
    if not validation.exists():
        raise FileNotFoundError(f"Validation directory not found: {validation}")
    requested = {str(p).upper() for p in phases}
    found: dict[str, dict[str, Path]] = {}
    for path in sorted(validation.rglob("NLST_*_lobe.nii.gz")):
        match = CASE_RE.match(path.name)
        if match is None:
            continue
        case_id, phase = match.groups()
        phase = phase.upper()
        if phase in requested:
            found.setdefault(case_id.upper(), {})[phase] = path
    complete = {case: assets for case, assets in found.items() if requested.issubset(assets)}
    if not complete:
        raise FileNotFoundError(f"No complete validation GT lobe cases found under {validation}")
    return dict(sorted(complete.items()))


def pseudo_lobe_path(root: str | Path, case_id: str, phase: str) -> Path:
    path = Path(root) / "lobes" / "validation" / f"{case_id}_{phase}_lobes.nii.gz"
    if not path.exists():
        raise FileNotFoundError(f"Missing pseudo lobe label: {path}")
    return path


def prepare_case(
    case_id: str,
    phase: str,
    pseudo_path: Path,
    gt_path: Path,
    cfg: dict[str, Any],
) -> PreparedCase:
    if nib is None:
        raise RuntimeError("nibabel is required to run the C8C geometry audit")
    pseudo_img = nib.load(str(pseudo_path))
    gt_img = nib.load(str(gt_path))
    pseudo = np.asanyarray(pseudo_img.dataobj).astype(np.int16, copy=False)
    target = np.asanyarray(gt_img.dataobj).astype(np.int16, copy=False)
    if pseudo.shape != target.shape:
        raise ValueError(f"{case_id} {phase}: shape mismatch {pseudo.shape} vs {target.shape}")
    affine_diff = float(np.max(np.abs(np.asarray(pseudo_img.affine) - np.asarray(gt_img.affine))))
    if affine_diff > float(cfg["affine_atol"]):
        raise ValueError(f"{case_id} {phase}: affine mismatch max_abs_diff={affine_diff:.6g}")
    labels = [int(x) for x in cfg["labels"]]
    right_labels = [int(x) for x in cfg["right_labels"]]
    expected = {0, *labels}
    unexpected_pseudo = sorted(set(int(x) for x in np.unique(pseudo)) - expected)
    unexpected_gt = sorted(set(int(x) for x in np.unique(target)) - expected)
    if unexpected_pseudo or unexpected_gt:
        raise ValueError(f"{case_id} {phase}: unexpected labels pseudo={unexpected_pseudo}, GT={unexpected_gt}")
    spacing = _spacing_from_affine(gt_img.affine)
    baseline = dice_by_lobe(pseudo, target, labels)
    scores, gt_at_union, gt_counts = _prepare_right_scores(pseudo, target, spacing, right_labels)
    diagnostics = _case_diagnostics(
        pseudo,
        target,
        gt_img.affine,
        spacing,
        labels,
        int(cfg["interface_dilation_iterations"]),
        bool(cfg["compute_interface_diagnostics"]),
    )
    diagnostics["affine_max_abs_diff"] = affine_diff
    return PreparedCase(
        case_id=case_id,
        phase=phase,
        pseudo_path=pseudo_path,
        gt_path=gt_path,
        spacing_mm=spacing,
        scores_at_union=scores,
        gt_at_union=gt_at_union,
        gt_counts=gt_counts,
        baseline_per_lobe=baseline,
        diagnostics=diagnostics,
    )


def calibrate_prepared_cases(
    cases: Sequence[PreparedCase],
    candidates: Sequence[dict[int, float]],
    labels: Sequence[int],
    right_labels: Sequence[int],
    objective_weights: dict[int, float],
) -> dict[str, Any]:
    if not cases:
        raise ValueError("No cases supplied to C8C calibration")
    matrix = np.empty((len(cases), len(candidates)), dtype=np.float64)
    for row, case in enumerate(cases):
        for col, candidate in enumerate(candidates):
            matrix[row, col] = evaluate_prepared_bias(case, candidate, right_labels, objective_weights)[0]

    global_index = select_candidate_index(matrix.mean(axis=0), candidates)
    global_bias = candidates[global_index]
    records: list[dict[str, Any]] = []
    for row, case in enumerate(cases):
        if len(cases) > 1:
            train_rows = [idx for idx in range(len(cases)) if idx != row]
            loo_index = select_candidate_index(matrix[train_rows].mean(axis=0), candidates)
        else:
            loo_index = global_index
        loo_bias = candidates[loo_index]
        _, global_right = evaluate_prepared_bias(case, global_bias, right_labels, objective_weights)
        _, loo_right = evaluate_prepared_bias(case, loo_bias, right_labels, objective_weights)
        baseline = case.baseline_per_lobe
        global_per = dict(baseline); global_per.update(global_right)
        loo_per = dict(baseline); loo_per.update(loo_right)
        baseline_mean = mean_dice(baseline, labels)
        global_mean = mean_dice(global_per, labels)
        loo_mean = mean_dice(loo_per, labels)
        records.append({
            "case_id": case.case_id,
            "phase": case.phase,
            "pseudo_path": str(case.pseudo_path),
            "gt_path": str(case.gt_path),
            "spacing_mm": list(case.spacing_mm),
            "baseline_mean_dice": baseline_mean,
            "global_corrected_mean_dice": global_mean,
            "global_minus_baseline_mean_dice": global_mean - baseline_mean,
            "loo_corrected_mean_dice": loo_mean,
            "loo_minus_baseline_mean_dice": loo_mean - baseline_mean,
            "global_biases_mm": global_bias,
            "loo_biases_mm": loo_bias,
            "baseline_per_lobe": baseline,
            "global_corrected_per_lobe": global_per,
            "loo_corrected_per_lobe": loo_per,
            "diagnostics": case.diagnostics,
        })

    baseline_values = np.asarray([r["baseline_mean_dice"] for r in records], dtype=np.float64)
    global_values = np.asarray([r["global_corrected_mean_dice"] for r in records], dtype=np.float64)
    loo_values = np.asarray([r["loo_corrected_mean_dice"] for r in records], dtype=np.float64)
    loo_gains = loo_values - baseline_values
    top_indices = sorted(
        range(len(candidates)),
        key=lambda idx: (-float(matrix[:, idx].mean()), _bias_norm(candidates[idx])),
    )[:10]
    return {
        "global_candidate_index": global_index,
        "global_biases_mm": global_bias,
        "mean_baseline_five_lobe_dice": float(baseline_values.mean()),
        "mean_global_corrected_five_lobe_dice": float(global_values.mean()),
        "global_minus_baseline_five_lobe_dice": float(global_values.mean() - baseline_values.mean()),
        "mean_loo_corrected_five_lobe_dice": float(loo_values.mean()),
        "loo_minus_baseline_five_lobe_dice": float(loo_values.mean() - baseline_values.mean()),
        "loo_improved_case_fraction": float(np.mean(loo_gains > 0.0)),
        "loo_worst_case_gain": float(np.min(loo_gains)),
        "top_global_candidates": [
            {"biases_mm": candidates[idx], "mean_weighted_right_lobe_dice": float(matrix[:, idx].mean())}
            for idx in top_indices
        ],
        "records": records,
    }


def _write_records_csv(path: Path, records: Sequence[dict[str, Any]], labels: Sequence[int]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "case_id", "phase", "baseline_mean_dice", "global_corrected_mean_dice",
        "global_minus_baseline_mean_dice", "loo_corrected_mean_dice", "loo_minus_baseline_mean_dice",
        "global_bias_32_mm", "global_bias_64_mm", "global_bias_128_mm",
        "loo_bias_32_mm", "loo_bias_64_mm", "loo_bias_128_mm",
    ]
    for label in labels:
        fields.extend([f"baseline_dice_{label}", f"global_dice_{label}", f"loo_dice_{label}"])
    fields.extend([
        "right_horizontal_signed_offset_mm", "right_horizontal_surface_mean_mm", "right_horizontal_surface_p95_mm",
        "right_oblique_signed_offset_mm", "right_oblique_surface_mean_mm", "right_oblique_surface_p95_mm",
    ])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for record in records:
            row: dict[str, Any] = {
                "case_id": record["case_id"],
                "phase": record["phase"],
                "baseline_mean_dice": record["baseline_mean_dice"],
                "global_corrected_mean_dice": record["global_corrected_mean_dice"],
                "global_minus_baseline_mean_dice": record["global_minus_baseline_mean_dice"],
                "loo_corrected_mean_dice": record["loo_corrected_mean_dice"],
                "loo_minus_baseline_mean_dice": record["loo_minus_baseline_mean_dice"],
            }
            for label in RIGHT_LABELS:
                row[f"global_bias_{label}_mm"] = record["global_biases_mm"].get(label)
                row[f"loo_bias_{label}_mm"] = record["loo_biases_mm"].get(label)
            for label in labels:
                row[f"baseline_dice_{label}"] = record["baseline_per_lobe"].get(label)
                row[f"global_dice_{label}"] = record["global_corrected_per_lobe"].get(label)
                row[f"loo_dice_{label}"] = record["loo_corrected_per_lobe"].get(label)
            interfaces = record.get("diagnostics", {}).get("interfaces", {})
            horizontal = interfaces.get("right_horizontal", {})
            oblique = interfaces.get("right_oblique", {})
            row.update({
                "right_horizontal_signed_offset_mm": horizontal.get("signed_offset_to_target_group_b_mm"),
                "right_horizontal_surface_mean_mm": horizontal.get("symmetric_surface_mean_mm"),
                "right_horizontal_surface_p95_mm": horizontal.get("symmetric_surface_p95_mm"),
                "right_oblique_signed_offset_mm": oblique.get("signed_offset_to_target_group_b_mm"),
                "right_oblique_surface_mean_mm": oblique.get("symmetric_surface_mean_mm"),
                "right_oblique_surface_p95_mm": oblique.get("symmetric_surface_p95_mm"),
            })
            writer.writerow(row)


def run_audit(cfg: dict[str, Any]) -> dict[str, Any]:
    started = time.time()
    phases = [str(x).upper() for x in cfg["phases"]]
    labels = [int(x) for x in cfg["labels"]]
    right_labels = [int(x) for x in cfg["right_labels"]]
    objective_weights = {int(k): float(v) for k, v in cfg["objective_weights"].items()}
    candidates = generate_bias_candidates(
        right_labels,
        int(cfg["reference_label"]),
        float(cfg["bias_min_mm"]),
        float(cfg["bias_max_mm"]),
        float(cfg["bias_step_mm"]),
    )
    gt_cases = discover_gt_cases(cfg["raw_data_root"], phases)
    by_phase: dict[str, Any] = {}
    all_records: list[dict[str, Any]] = []
    for phase in phases:
        prepared: list[PreparedCase] = []
        for case_id, assets in gt_cases.items():
            prepared.append(prepare_case(
                case_id,
                phase,
                pseudo_lobe_path(cfg["pseudo_segmentation_root"], case_id, phase),
                assets[phase],
                cfg,
            ))
        result = calibrate_prepared_cases(prepared, candidates, labels, right_labels, objective_weights)
        by_phase[phase] = result
        all_records.extend(result["records"])

    gains = np.asarray([r["loo_minus_baseline_mean_dice"] for r in all_records], dtype=np.float64)
    mean_gain = float(gains.mean())
    improved_fraction = float(np.mean(gains > 0.0))
    worst_gain = float(gains.min())
    proceed = (
        mean_gain >= float(cfg["minimum_loo_five_lobe_gain"])
        and improved_fraction >= float(cfg["minimum_loo_improved_fraction"])
        and worst_gain >= -float(cfg["max_allowed_loo_case_loss"])
    )
    case_ids = sorted({record["case_id"] for record in all_records})
    calibration = {
        "schema_version": 1,
        "method": "C8C phase-specific right-lobe signed-distance bias calibration",
        "validation_gt_used_for_calibration": True,
        "case_specific_gt_required_at_inference": False,
        "bias_semantics": (
            "score(label)=signed_distance_mm(pseudo_label)+bias_mm(label); positive bias expands that right lobe; "
            "the original right-lung union and all non-right-lobe voxels are preserved"
        ),
        "reference_label": int(cfg["reference_label"]),
        "global_biases_mm": {phase: by_phase[phase]["global_biases_mm"] for phase in phases},
        "leave_one_case_out_biases_mm": {
            case_id: {
                phase: next(r["loo_biases_mm"] for r in all_records if r["case_id"] == case_id and r["phase"] == phase)
                for phase in phases
            }
            for case_id in case_ids
        },
        "grid": {
            "minimum_mm": float(cfg["bias_min_mm"]),
            "maximum_mm": float(cfg["bias_max_mm"]),
            "step_mm": float(cfg["bias_step_mm"]),
            "candidate_count": len(candidates),
        },
    }
    summary = {
        "schema_version": 1,
        "status": "PASS",
        "experiment": "SGR-FM C8C pseudo-label geometry calibration audit",
        "case_count": len(gt_cases),
        "phase_count": len(phases),
        "candidate_count_per_phase": len(candidates),
        "phase_results": {
            phase: {k: v for k, v in by_phase[phase].items() if k != "records"}
            for phase in phases
        },
        "combined_loo_mean_five_lobe_gain": mean_gain,
        "combined_loo_improved_case_phase_fraction": improved_fraction,
        "combined_loo_worst_case_phase_gain": worst_gain,
        "decision": "PROCEED_TO_C8C_GEOMETRY_TTO" if proceed else "DO_NOT_APPLY_GLOBAL_GEOMETRY_BIAS_YET",
        "decision_thresholds": {
            "minimum_loo_five_lobe_gain": float(cfg["minimum_loo_five_lobe_gain"]),
            "minimum_loo_improved_fraction": float(cfg["minimum_loo_improved_fraction"]),
            "max_allowed_loo_case_loss": float(cfg["max_allowed_loo_case_loss"]),
        },
        "calibration": calibration,
        "records": all_records,
        "elapsed_sec": float(time.time() - started),
    }
    out = Path(cfg["output_root"])
    write_json(out / "run_config_resolved.json", cfg)
    write_json(out / "c8c_geometry_calibration.json", calibration)
    write_json(out / "c8c_geometry_audit_summary.json", summary)
    _write_records_csv(out / "c8c_geometry_audit_per_case_phase.csv", all_records, labels)
    return summary
