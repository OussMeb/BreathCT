#!/usr/bin/env python3
"""Measure phase-specific pseudo-lobe geometry bias before C8C registration.

This validation-only audit uses GT labels to estimate global calibration and a
leave-one-case-out generalization check. It does not generate submission DVFs.
"""

import argparse
import json

from utils.sgr_fm_c8c_geometry_audit import load_config, run_audit


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the SGR-FM C8C pseudo-label geometry audit.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    cfg = load_config(args.config)
    if args.dry_run:
        print(json.dumps({
            "status": "DRY_RUN",
            "experiment": "SGR-FM C8C pseudo-label geometry calibration audit",
            "raw_data_root": cfg["raw_data_root"],
            "pseudo_segmentation_root": cfg["pseudo_segmentation_root"],
            "output_root": cfg["output_root"],
            "phases": cfg["phases"],
            "warning": "Validation GT is used only to estimate and cross-validate global geometry biases.",
        }, indent=2))
        return 0
    summary = run_audit(cfg)
    compact = {
        "status": summary["status"],
        "case_count": summary["case_count"],
        "combined_loo_mean_five_lobe_gain": summary["combined_loo_mean_five_lobe_gain"],
        "combined_loo_improved_case_phase_fraction": summary["combined_loo_improved_case_phase_fraction"],
        "combined_loo_worst_case_phase_gain": summary["combined_loo_worst_case_phase_gain"],
        "decision": summary["decision"],
        "global_biases_mm": summary["calibration"]["global_biases_mm"],
    }
    print(json.dumps(compact, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

