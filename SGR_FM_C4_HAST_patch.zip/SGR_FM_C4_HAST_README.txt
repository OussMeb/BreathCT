SGR-FM C4-HAST PATCH
====================

C4-HAST = Hierarchical Anatomical Surface Test-time optimization.

Purpose
-------
C4 is a new method branch, not a longer C2 run and not a learned residual refiner.
It starts from the frozen C2-LONG initializer and applies three sequential small
residual SVFs with exact pull composition:

  A_coarse_anatomy
    raw CT LNCC + CT gradient structure + lobes/support + weak SDF/surface terms

  B_lobe_sdf
    five-lobe signed-distance-field refinement in a narrow anatomical band

  C_fissure_surface
    explicit predicted interfaces:
      1) LUL vs LLL
      2) RUL vs RML
      3) RLL vs (RUL|RML)

Each stage has its own residual SVF, topology guard, and no-op scale fallback.
The final transform is a sequence of exact pull compositions, not vector addition.

Important data rule
-------------------
Optimization uses only:
  * raw EXP/INSP CT
  * predicted TotalSegmentator lobe masks
  * predicted support masks
  * SDF/interface maps derived from those predictions

Validation GT is used only by evaluate_validation.py after DVFs are written.

Initializer lock
----------------
Default initializer:
  outputs/sgr_fm/c2_long_tto

Expected method fingerprint:
  fdc2c0a64374aee658b647b55ae673f50faf2d08aed79ea7e0d6dd3d17fadcd3

The runner refuses a different initializer when fingerprint verification is enabled.

Files in this patch
-------------------
  utils/sgr_fm_c4_hast.py
  run_sgr_fm_c4_hast_validation.py
  configs/sgr_fm_c4_hast.yaml
  smoke_sgr_fm_c4_hast_synthetic.py
  main.py
  SGR_FM_C4_HAST_README.txt
  PATCH_MANIFEST.json

Install / overlay
-----------------
From:
  /home/oussama/Desktop/MICCAI FRANCE

Run:
  unzip -o SGR_FM_C4_HAST_patch.zip -d .

1) Compile check
----------------
  python -m py_compile \
    main.py \
    run_sgr_fm_c4_hast_validation.py \
    utils/sgr_fm_c4_hast.py

2) CPU synthetic smoke
----------------------
  python smoke_sgr_fm_c4_hast_synthetic.py

Expected:
  C4-HAST SYNTHETIC SMOKE: PASS

3) Asset / fingerprint dry-run
------------------------------
  python main.py c4-hast \
    --config configs/sgr_fm_c4_hast.yaml \
    --dry-run

This checks all 10 validation asset paths and the frozen C2-LONG fingerprint.

4) Real smoke case NLST_0006
----------------------------
  python main.py c4-hast \
    --config configs/sgr_fm_c4_hast.yaml \
    --case-ids NLST_0006 \
    --skip-evaluation

5) Real smoke case NLST_0009
----------------------------
  python main.py c4-hast \
    --config configs/sgr_fm_c4_hast.yaml \
    --case-ids NLST_0009 \
    --skip-evaluation

Inspect / upload:
  outputs/sgr_fm/c4_hast/case_manifests/NLST_0006.json
  outputs/sgr_fm/c4_hast/case_manifests/NLST_0009.json

Do not change parameters before these two manifests are reviewed.

6) Full 10-case run after smoke review
--------------------------------------
  python main.py c4-hast \
    --config configs/sgr_fm_c4_hast.yaml

Main outputs
------------
  outputs/sgr_fm/c4_hast/eval/validation_metrics.json
  outputs/sgr_fm/c4_hast/comparison/INIT_vs_C4_HAST_summary.json
  outputs/sgr_fm/c4_hast/comparison/INIT_vs_C4_HAST_per_case.csv
  outputs/sgr_fm/c4_hast/c4_hast_summary.json
  outputs/sgr_fm/c4_hast/run_config_resolved.json

Dependencies
------------
  torch
  nibabel
  numpy
  scipy

Safety
------
  * separate output directory: outputs/sgr_fm/c4_hast
  * never overwrites C1, C2, or C2-LONG
  * initializer fingerprint lock
  * stagewise full-resolution topology guard
  * each stage includes scale 0.0 no-op
  * exact initializer byte copy if all three stages no-op
  * no validation GT inside optimization
