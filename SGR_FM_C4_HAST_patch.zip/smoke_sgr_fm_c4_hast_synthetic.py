#!/usr/bin/env python3
"""Small CPU-only synthetic smoke test for the C4-HAST patch."""
from __future__ import annotations

import numpy as np
import torch

from utils.sgr_fm_c3 import labels_to_one_hot, support_to_tensor
from utils.sgr_fm_c4_hast import (
    build_stage_residual,
    channels_to_tensor,
    compute_proxy_metrics,
    default_config,
    explicit_interface_surfaces,
    interface_distance_channels,
    make_stage_parameter,
    objective_terms,
    signed_distance_channels,
    volume_to_tensor,
)


def main() -> int:
    shape = (16, 14, 16)
    labels = np.zeros(shape, dtype=np.int16)
    x, y, z = np.indices(shape)
    left = x < 7
    right = x >= 9
    labels[left & (z < 8)] = 8
    labels[left & (z >= 8)] = 16
    labels[right & (z >= 10)] = 128
    labels[right & (z < 10) & (y < 7)] = 32
    labels[right & (z < 10) & (y >= 7)] = 64

    spacing = (1.5, 1.5, 1.5)
    sdf = signed_distance_channels(labels, spacing_mm=spacing, band_mm=12.0)
    surfaces = explicit_interface_surfaces(labels, dilation_iterations=1)
    distances = interface_distance_channels(surfaces, spacing_mm=spacing, band_mm=10.0)

    device = torch.device("cpu")
    ct = np.random.default_rng(2026).normal(size=shape).astype(np.float32)
    support = (labels > 0).astype(np.float32)
    state = {
        "moving_ct": volume_to_tensor(ct, device=device),
        "fixed_ct": volume_to_tensor(ct, device=device),
        "moving_lobes": labels_to_one_hot(labels, device=device),
        "fixed_lobes": labels_to_one_hot(labels, device=device),
        "moving_support": support_to_tensor(support, device=device),
        "fixed_support": support_to_tensor(support, device=device),
        "moving_sdf": channels_to_tensor(sdf, device=device),
        "fixed_sdf": channels_to_tensor(sdf, device=device),
        "moving_interface_surface": channels_to_tensor(surfaces, device=device),
        "fixed_interface_surface": channels_to_tensor(surfaces, device=device),
        "moving_interface_dist": channels_to_tensor(distances, device=device),
        "fixed_interface_dist": channels_to_tensor(distances, device=device),
    }

    cfg = default_config()
    ct_cfg = dict(cfg["ct"])
    ct_cfg["lncc_window"] = 5
    anatomy_cfg = cfg["anatomy"]
    stage = dict(cfg["stages"][0])
    zero = torch.zeros((1, 3, *shape), dtype=torch.float32)

    metrics = compute_proxy_metrics(state=state, dvf=zero, ct_cfg=ct_cfg, anatomy_cfg=anatomy_cfg)
    if not all(np.isfinite(v) for v in metrics.values()):
        raise RuntimeError(f"Non-finite proxy metrics: {metrics}")

    param = make_stage_parameter(shape, stage_cfg=stage, device=device, dtype=torch.float32)
    residual = build_stage_residual(param, target_shape=shape, full_shape=shape, stage_cfg=stage)
    total, _ = objective_terms(
        state=state,
        init_dvf=zero,
        residual_dvf=residual,
        weights=stage["weights"],
        ct_cfg=ct_cfg,
        anatomy_cfg=anatomy_cfg,
    )
    if not torch.isfinite(total):
        raise RuntimeError("Non-finite C4 objective")
    total.backward()
    if param.grad is None or not torch.isfinite(param.grad).all():
        raise RuntimeError("Non-finite C4 gradient")

    print("C4-HAST SYNTHETIC SMOKE: PASS")
    print("SDF shape:", sdf.shape)
    print("Interface surface voxels:", surfaces.sum(axis=(1, 2, 3)).tolist())
    print("Identity proxy lobe Dice:", metrics["proxy_lobe_dice"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
