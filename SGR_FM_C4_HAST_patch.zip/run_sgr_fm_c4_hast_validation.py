#!/usr/bin/env python3
"""Run SGR-FM C4-HAST on Learn2Breath validation cases.

C4-HAST performs three sequential, exact-composition residual SVF stages on top
of the frozen C2-LONG initializer:
  A) coarse anatomy + CT structure,
  B) five-lobe signed-distance refinement,
  C) explicit fissure/interface surface refinement.

Only raw CT and predicted segmentations are used by optimization. Validation GT
is accessed only by the existing evaluator after all DVFs have been written.
"""
from __future__ import annotations

import argparse
import csv
import json
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.data import discover_validation_cases
from utils.dvf_io import canonical_ras_cxyz_to_original_dvf_xyzc, save_dvf_xyzc
from utils.sgr_fm_c3 import atomic_save_nifti_xyzc, compose_pull, dvf_tensor_to_xyzc
from utils.sgr_fm_c4_hast import (
    build_config,
    build_stage_residual,
    candidate_score,
    clone_parameter_state,
    compute_proxy_metrics,
    load_case_tensors,
    make_lowres_state,
    make_stage_parameter,
    objective_terms,
    passes_acceptance,
    restore_parameter_state,
    sha256_json,
    tensor_terms_to_float,
    topology_stats,
    validation_asset_paths,
)
from utils.sgr_fm_segmentation import assert_safe_output_dir, atomic_write_json, write_csv
from utils.sgr_fm_training_assets import resolve_under_project


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="SGR-FM C4-HAST hierarchical anatomical surface TTO.")
    p.add_argument("--config", default="configs/sgr_fm_c4_hast.yaml")
    p.add_argument("--case-ids", nargs="*", default=None)
    p.add_argument("--output-dir", default=None)
    p.add_argument("--device", default=None)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--skip-evaluation", action="store_true")
    return p.parse_args()


def _resolve_config(args: argparse.Namespace) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    if args.case_ids is not None:
        overrides["case_ids"] = list(args.case_ids)
    if args.output_dir is not None:
        overrides["output_dir"] = args.output_dir
    if args.device is not None:
        overrides["device"] = args.device
    if args.overwrite:
        overrides["overwrite"] = True
    config = build_config(args.config, overrides)
    for key in ("raw_data_root", "segmentation_dir", "initializer_dir", "output_dir"):
        config[key] = str(resolve_under_project(PROJECT_ROOT, config[key]))
    return config


def _optimize_stage(
    *,
    stage_cfg: dict[str, Any],
    param: torch.nn.Parameter,
    low: dict[str, torch.Tensor],
    full_shape: tuple[int, int, int],
    ct_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
    trace: list[dict[str, Any]],
) -> dict[str, Any]:
    stage_name = str(stage_cfg["name"])
    iterations = int(stage_cfg.get("iterations", 100))
    optimizer = torch.optim.Adam([param], lr=float(stage_cfg.get("lr", 0.02)))
    patience = int(stage_cfg.get("early_stop_patience", 35))
    min_improvement = float(stage_cfg.get("min_objective_improvement", 1e-6))
    grad_clip = float(stage_cfg.get("grad_clip", 1.0))
    weights = dict(stage_cfg.get("weights", {}))

    best_value = float("inf")
    best_state = clone_parameter_state([param])
    best_iter = 0
    stale = 0
    completed = 0

    for iteration in range(1, iterations + 1):
        completed = iteration
        optimizer.zero_grad(set_to_none=True)
        residual = build_stage_residual(
            param,
            target_shape=low["init_dvf"].shape[-3:],
            full_shape=full_shape,
            stage_cfg=stage_cfg,
            scale=1.0,
        )
        total, terms = objective_terms(
            state=low,
            init_dvf=low["init_dvf"],
            residual_dvf=residual,
            weights=weights,
            ct_cfg=ct_cfg,
            anatomy_cfg=anatomy_cfg,
        )
        if not torch.isfinite(total):
            raise RuntimeError(f"{stage_name}: non-finite objective at iteration {iteration}")
        total.backward()
        if grad_clip > 0.0:
            torch.nn.utils.clip_grad_norm_([param], max_norm=grad_clip)

        value = float(total.detach().item())
        trace.append({"stage": stage_name, "iteration": iteration, **tensor_terms_to_float(terms)})
        state_at_value = clone_parameter_state([param])
        if value < best_value - min_improvement:
            best_value = value
            best_state = state_at_value
            best_iter = iteration
            stale = 0
        else:
            stale += 1

        optimizer.step()
        if stale >= patience:
            break

    restore_parameter_state([param], best_state)
    return {
        "stage": stage_name,
        "requested_iterations": iterations,
        "completed_iterations": completed,
        "best_iteration": int(best_iter),
        "best_objective": float(best_value),
        "early_stopped": bool(stale >= patience),
        "reduce_factor": int(stage_cfg.get("reduce_factor", 2)),
        "control_factor": int(stage_cfg.get("control_factor", 4)),
        "max_residual_fullres_voxels": float(stage_cfg.get("max_residual_fullres_voxels", 1.0)),
    }


def _compare_metrics(init_json: Path, c4_json: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    init = json.loads(init_json.read_text(encoding="utf-8"))
    c4 = json.loads(c4_json.read_text(encoding="utf-8"))
    init_rows = {str(r["case_id"]): r for r in init.get("case_metrics", [])}
    c4_rows = {str(r["case_id"]): r for r in c4.get("case_metrics", [])}
    common = sorted(set(init_rows) & set(c4_rows))
    rows: list[dict[str, Any]] = []
    for case_id in common:
        a, b = init_rows[case_id], c4_rows[case_id]
        rows.append({
            "case_id": case_id,
            "initializer_mean_lobe_dice": float(a["mean_lobe_dice"]),
            "C4_mean_lobe_dice": float(b["mean_lobe_dice"]),
            "delta_dice": float(b["mean_lobe_dice"] - a["mean_lobe_dice"]),
            "initializer_folding_percentage": float(a["folding_percentage"]),
            "C4_folding_percentage": float(b["folding_percentage"]),
            "delta_folding_percentage": float(b["folding_percentage"] - a["folding_percentage"]),
        })
    deltas = np.asarray([r["delta_dice"] for r in rows], dtype=np.float64)
    summary = {
        "common_case_count": len(rows),
        "initializer_mean_lobe_dice": float(init["mean_lobe_dice"]),
        "C4_mean_lobe_dice": float(c4["mean_lobe_dice"]),
        "delta_mean_lobe_dice": float(c4["mean_lobe_dice"] - init["mean_lobe_dice"]),
        "initializer_mean_folding_percentage": float(init["mean_folding_percentage"]),
        "C4_mean_folding_percentage": float(c4["mean_folding_percentage"]),
        "delta_mean_folding_percentage": float(c4["mean_folding_percentage"] - init["mean_folding_percentage"]),
        "improved_cases": int(np.sum(deltas > 0)) if len(deltas) else 0,
        "unchanged_cases": int(np.sum(np.isclose(deltas, 0.0, atol=1e-12))) if len(deltas) else 0,
        "worsened_cases": int(np.sum(deltas < 0)) if len(deltas) else 0,
        "min_paired_dice_delta": float(deltas.min()) if len(deltas) else None,
        "max_paired_dice_delta": float(deltas.max()) if len(deltas) else None,
    }
    return summary, rows


def main() -> int:
    args = parse_args()
    config = _resolve_config(args)
    raw_root = Path(config["raw_data_root"])
    segmentation_dir = Path(config["segmentation_dir"])
    initializer_dir = Path(config["initializer_dir"])
    output_dir = Path(config["output_dir"])
    assert_safe_output_dir(output_dir, PROJECT_ROOT)

    init_run_config = initializer_dir / "run_config_resolved.json"
    if not init_run_config.exists():
        raise FileNotFoundError(f"Missing initializer run config: {init_run_config}")
    init_meta = json.loads(init_run_config.read_text(encoding="utf-8"))
    init_fingerprint = str(init_meta.get("method_fingerprint_sha256", ""))
    accepted_init = str(config.get("accepted_initializer_method_fingerprint", ""))
    if bool(config.get("require_initializer_fingerprint", True)) and init_fingerprint != accepted_init:
        raise RuntimeError(
            "Initializer fingerprint mismatch; refusing C4-HAST on an unaccepted base. "
            f"expected={accepted_init} actual={init_fingerprint}"
        )

    method_fingerprint = sha256_json({
        "ct": config["ct"],
        "anatomy": config["anatomy"],
        "stages": config["stages"],
        "selection": config["selection"],
        "initializer_fingerprint": init_fingerprint,
    })
    previous_run_config = output_dir / "run_config_resolved.json"
    if previous_run_config.exists() and not bool(config.get("overwrite", False)):
        previous = json.loads(previous_run_config.read_text(encoding="utf-8"))
        previous_fp = previous.get("method_fingerprint_sha256")
        if previous_fp and previous_fp != method_fingerprint:
            raise RuntimeError(
                "C4 output directory contains a different method configuration. "
                "Use a new --output-dir or --overwrite. "
                f"existing={previous_fp} current={method_fingerprint}"
            )

    cases = discover_validation_cases(raw_root)
    requested = {str(v) for v in config.get("case_ids", [])}
    if requested:
        cases = [case for case in cases if case.case_id in requested]
        missing = sorted(requested - {case.case_id for case in cases})
        if missing:
            raise FileNotFoundError(f"Requested cases not found: {missing}")
    if not cases:
        raise RuntimeError("No validation cases selected")

    device_name = str(config.get("device", "cuda"))
    if device_name.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    device = torch.device(device_name)

    for sub in ("dvfs", "dvfs_canonical_ras", "case_manifests", "traces", "eval", "comparison"):
        (output_dir / sub).mkdir(parents=True, exist_ok=True)

    atomic_write_json(output_dir / "run_config_resolved.json", {
        "schema_version": 1,
        "experiment": "SGR-FM C4-HAST hierarchical anatomical surface TTO",
        "config": config,
        "case_count": len(cases),
        "dry_run": bool(args.dry_run),
        "method_fingerprint_sha256": method_fingerprint,
        "verified_initializer_method_fingerprint": init_fingerprint,
        "critical_note": "Optimization uses raw CT and predicted segmentations only; validation GT is evaluation-only.",
    })

    ct_cfg = config["ct"]
    anatomy_cfg = config["anatomy"]
    selection_cfg = config["selection"]
    stage_cfgs = list(config.get("stages", []))
    if len(stage_cfgs) != 3:
        raise ValueError(f"C4-HAST expects exactly 3 sequential stages, got {len(stage_cfgs)}")

    records: list[dict[str, Any]] = []

    for idx, case in enumerate(cases, start=1):
        started = time.time()
        print(f"[{idx:02d}/{len(cases):02d}] {case.case_id}", flush=True)
        assets = validation_asset_paths(segmentation_dir, initializer_dir, case.case_id)
        out_original = output_dir / "dvfs" / f"{case.case_id}_DVF.nii.gz"
        out_canonical = output_dir / "dvfs_canonical_ras" / f"{case.case_id}_DVF_RAS_XYZC_voxel.nii.gz"
        manifest_path = output_dir / "case_manifests" / f"{case.case_id}.json"
        trace_path = output_dir / "traces" / f"{case.case_id}.csv"

        record: dict[str, Any] = {
            "case_id": case.case_id,
            "status": "started",
            "EXP": str(case.exp_ct),
            "INSP": str(case.insp_ct),
            "assets": {k: str(v) for k, v in assets.items()},
            "output_dvf": str(out_original),
            "output_canonical_dvf": str(out_canonical),
        }

        try:
            if out_original.exists() and out_canonical.exists() and not bool(config.get("overwrite", False)):
                record["status"] = "reused"
                record["elapsed_sec"] = float(time.time() - started)
                records.append(record)
                continue

            if args.dry_run:
                for name, path in assets.items():
                    if not path.exists():
                        raise FileNotFoundError(f"Missing {name}: {path}")
                record["status"] = "dry_run"
                record["elapsed_sec"] = 0.0
                records.append(record)
                atomic_write_json(manifest_path, record)
                continue

            full = load_case_tensors(
                exp_ct_path=case.exp_ct,
                insp_ct_path=case.insp_ct,
                assets=assets,
                device=device,
                ct_cfg=ct_cfg,
                anatomy_cfg=anatomy_cfg,
            )
            current_full = full["init_dvf"].detach().clone()
            initializer_topology = topology_stats(current_full)
            record["initializer_topology_fullres"] = initializer_topology
            record["stages"] = []
            trace: list[dict[str, Any]] = []
            any_applied = False

            for stage_index, stage_cfg in enumerate(stage_cfgs, start=1):
                stage_name = str(stage_cfg["name"])
                reduce_factor = int(stage_cfg.get("reduce_factor", 2))
                low = make_lowres_state(full, reduce_factor=reduce_factor, current_dvf_full=current_full)
                baseline_proxy = compute_proxy_metrics(
                    state=low,
                    dvf=low["init_dvf"],
                    ct_cfg=ct_cfg,
                    anatomy_cfg=anatomy_cfg,
                )
                baseline_topology = topology_stats(current_full)

                param = make_stage_parameter(
                    low["init_dvf"].shape[-3:],
                    stage_cfg=stage_cfg,
                    device=device,
                    dtype=low["init_dvf"].dtype,
                )
                optimization = _optimize_stage(
                    stage_cfg=stage_cfg,
                    param=param,
                    low=low,
                    full_shape=full["full_shape"],
                    ct_cfg=ct_cfg,
                    anatomy_cfg=anatomy_cfg,
                    trace=trace,
                )

                candidate_rows: list[dict[str, Any]] = []
                accepted: list[tuple[float, dict[str, Any], torch.Tensor]] = []
                scales = [float(v) for v in stage_cfg.get("selection_scales", [1.0, 0.75, 0.5, 0.25, 0.125, 0.0])]
                if 0.0 not in scales:
                    raise ValueError(f"{stage_name}: selection_scales must include 0.0")

                for scale in scales:
                    with torch.no_grad():
                        residual_low = build_stage_residual(
                            param,
                            target_shape=low["init_dvf"].shape[-3:],
                            full_shape=full["full_shape"],
                            stage_cfg=stage_cfg,
                            scale=scale,
                        )
                        final_low = compose_pull(low["init_dvf"], residual_low)
                        proxy = compute_proxy_metrics(
                            state=low,
                            dvf=final_low,
                            ct_cfg=ct_cfg,
                            anatomy_cfg=anatomy_cfg,
                        )
                        residual_full = build_stage_residual(
                            param,
                            target_shape=current_full.shape[-3:],
                            full_shape=full["full_shape"],
                            stage_cfg=stage_cfg,
                            scale=scale,
                        )
                        final_full = compose_pull(current_full, residual_full)
                        topo = topology_stats(final_full)
                        metrics = {**proxy, **topo}
                        ok, reasons, fold_limit, score = passes_acceptance(
                            metrics,
                            baseline_proxy,
                            baseline_folding_pct=float(baseline_topology["folding_pct"]),
                            selection=selection_cfg,
                        )
                        row: dict[str, Any] = {
                            "scale": float(scale),
                            "score": float(score),
                            "accepted": bool(ok),
                            "rejection_reasons": reasons,
                            "folding_limit_pct": float(fold_limit),
                            **metrics,
                        }
                        candidate_rows.append(row)
                        if ok:
                            accepted.append((float(score), row, final_full.detach().clone()))

                if accepted:
                    accepted.sort(key=lambda item: item[0], reverse=True)
                    _, selected_row, selected_full = accepted[0]
                    current_full = selected_full
                    decision = "apply"
                    any_applied = True
                else:
                    selected_row = next(r for r in candidate_rows if float(r["scale"]) == 0.0)
                    decision = "noop"

                stage_record = {
                    "index": stage_index,
                    "name": stage_name,
                    "baseline_proxy": baseline_proxy,
                    "baseline_topology_fullres": baseline_topology,
                    "optimization": optimization,
                    "selection_candidates": candidate_rows,
                    "decision": decision,
                    "selected": selected_row,
                    "output_topology_fullres": topology_stats(current_full),
                }
                record["stages"].append(stage_record)
                print(
                    f"  {stage_name}: decision={decision} scale={selected_row['scale']} "
                    f"score={selected_row['score']:+.6f} fold={selected_row['folding_pct']:.6g}%",
                    flush=True,
                )

                del low, param
                if device.type == "cuda":
                    torch.cuda.empty_cache()

            if trace:
                write_csv(trace_path, trace)

            final_topology = topology_stats(current_full)
            record["final_topology_fullres"] = final_topology
            record["any_stage_applied"] = bool(any_applied)

            if not any_applied:
                shutil.copy2(assets["initializer_canonical"], out_canonical)
                shutil.copy2(assets["initializer_original"], out_original)
                record["fallback_exact_initializer_copy"] = True
            else:
                canonical_xyzc = dvf_tensor_to_xyzc(current_full)
                if not np.isfinite(canonical_xyzc).all():
                    raise RuntimeError("Final canonical DVF contains NaN/Inf")
                atomic_save_nifti_xyzc(canonical_xyzc, full["canonical_reference"], out_canonical)
                canonical_cxyz = np.moveaxis(canonical_xyzc, -1, 0)
                original_xyzc = canonical_ras_cxyz_to_original_dvf_xyzc(canonical_cxyz, case.insp_ct)
                save_dvf_xyzc(original_xyzc, case.insp_ct, out_original)
                record["fallback_exact_initializer_copy"] = False

            record["status"] = "ok"
            record["elapsed_sec"] = float(time.time() - started)
            atomic_write_json(manifest_path, record)
            records.append(record)

            del full, current_full
            if device.type == "cuda":
                torch.cuda.empty_cache()

        except Exception as exc:
            record["status"] = "failed"
            record["error"] = f"{type(exc).__name__}: {exc}"
            record["traceback"] = traceback.format_exc()
            record["elapsed_sec"] = float(time.time() - started)
            records.append(record)
            atomic_write_json(manifest_path, record)
            print(record["error"], file=sys.stderr, flush=True)
            if bool(config.get("stop_on_error", True)):
                break

    ok_count = sum(r["status"] in {"ok", "reused", "dry_run"} for r in records)
    failed_count = sum(r["status"] == "failed" for r in records)
    summary: dict[str, Any] = {
        "schema_version": 1,
        "experiment": "SGR-FM C4-HAST hierarchical anatomical surface TTO",
        "status": "PASS" if failed_count == 0 and ok_count == len(cases) else "FAIL",
        "case_count": len(cases),
        "processed_count": ok_count,
        "failed_count": failed_count,
        "output_dir": str(output_dir),
        "initializer_dir": str(initializer_dir),
        "records": records,
    }

    eval_enabled = bool(config.get("evaluation", {}).get("enabled", True)) and not args.skip_evaluation and not args.dry_run
    if summary["status"] == "PASS" and eval_enabled and len(cases) == 10:
        eval_dir = output_dir / "eval"
        command = [
            sys.executable,
            str(PROJECT_ROOT / "evaluate_validation.py"),
            "--raw-data-root", str(raw_root),
            "--dvf-dir", str(output_dir / "dvfs"),
            "--output-dir", str(eval_dir),
            "--device", str(config.get("evaluation", {}).get("device", config.get("device", "cuda"))),
        ]
        proc = subprocess.run(command, cwd=str(PROJECT_ROOT), check=False)
        summary["evaluation"] = {"command": command, "exit_code": int(proc.returncode)}
        if proc.returncode != 0:
            summary["status"] = "FAIL"
        else:
            init_json = resolve_under_project(PROJECT_ROOT, config["evaluation"]["initializer_metrics_json"])
            c4_json = eval_dir / "validation_metrics.json"
            if init_json.exists() and c4_json.exists():
                comparison, comparison_rows = _compare_metrics(init_json, c4_json)
                atomic_write_json(output_dir / "comparison" / "INIT_vs_C4_HAST_summary.json", comparison)
                write_csv(output_dir / "comparison" / "INIT_vs_C4_HAST_per_case.csv", comparison_rows)
                summary["comparison"] = comparison
            else:
                summary["comparison_warning"] = f"Missing metrics: INIT={init_json.exists()} C4={c4_json.exists()}"

    atomic_write_json(output_dir / "c4_hast_summary.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k != "records"}, indent=2))
    return 0 if summary["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
