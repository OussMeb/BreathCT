#!/usr/bin/env python3
"""Core helpers for SGR-FM C4-HAST.

C4-HAST = Hierarchical Anatomical Surface Test-time optimization.

The method starts from a frozen C2-LONG pull DVF and applies three sequential,
small residual SVFs using only test-time available signals:
  * raw EXP/INSP CT,
  * predicted five-lobe masks,
  * predicted support masks,
  * lobe signed-distance fields (SDFs),
  * explicit predicted fissure/interface surfaces,
  * structural CT gradient orientation.

Validation ground truth is never loaded in this module.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable, Sequence

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F

try:
    from scipy.ndimage import binary_dilation, distance_transform_edt
except Exception as exc:  # pragma: no cover - explicit runtime diagnostic
    raise RuntimeError(
        "C4-HAST requires scipy.ndimage for SDF/interface construction. "
        "Install scipy in the active environment."
    ) from exc

from utils.refine_spatial import downsample_dvf_5d, integrate_svf, resize_volume_5d, warp_volume
from utils.sgr_fm_c3 import (
    LOBE_LABELS,
    assert_same_canonical_grid,
    canonical_image,
    compose_pull,
    dvf_tensor_to_xyzc,
    dvf_xyzc_to_tensor,
    labels_to_one_hot,
    load_canonical_dvf,
    load_canonical_label,
    load_canonical_support,
    soft_boundary_union,
    soft_dice_per_lobe,
    support_to_tensor,
)
from utils.sgr_fm_training_assets import load_yaml_or_json, recursive_update, resolve_under_project
from utils.sgr_fm_tto import (
    bending_energy,
    binary_soft_dice,
    build_residual_dvf,
    jacobian_barrier,
    lobe_soft_dice,
    make_control_parameter,
    masked_local_ncc_loss,
    topology_stats,
    volume_to_tensor,
)


def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "initializer_dir": "outputs/sgr_fm/c2_long_tto",
        "output_dir": "outputs/sgr_fm/c4_hast",
        "case_ids": [],
        "overwrite": False,
        "stop_on_error": True,
        "device": "cuda",
        "require_initializer_fingerprint": True,
        "accepted_initializer_method_fingerprint": "fdc2c0a64374aee658b647b55ae673f50faf2d08aed79ea7e0d6dd3d17fadcd3",
        "ct": {
            "clip_min_hu": -1000.0,
            "clip_max_hu": 400.0,
            "lncc_window": 9,
            "lncc_min_valid_fraction": 0.25,
            "gradient_min_magnitude": 0.03,
        },
        "anatomy": {
            "sdf_band_mm": 12.0,
            "sdf_loss_band_fraction": 0.85,
            "interface_band_mm": 10.0,
            "interface_dilation_iterations": 1,
            "charbonnier_eps": 1e-3,
        },
        "stages": [
            {
                "name": "A_coarse_anatomy",
                "reduce_factor": 4,
                "control_factor": 4,
                "iterations": 80,
                "lr": 0.05,
                "max_residual_fullres_voxels": 2.0,
                "integration_steps": 5,
                "early_stop_patience": 30,
                "min_objective_improvement": 1e-6,
                "grad_clip": 1.0,
                "weights": {
                    "image_lncc": 1.0,
                    "structural_gradient": 0.20,
                    "lobe": 0.50,
                    "lobe_sdf": 0.20,
                    "interface_overlap": 0.10,
                    "fissure_surface": 0.08,
                    "support": 0.05,
                    "bending": 0.04,
                    "residual_magnitude": 0.01,
                    "jacobian": 20.0,
                    "jacobian_margin": 0.02,
                },
                "selection_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            },
            {
                "name": "B_lobe_sdf",
                "reduce_factor": 2,
                "control_factor": 4,
                "iterations": 100,
                "lr": 0.025,
                "max_residual_fullres_voxels": 1.25,
                "integration_steps": 5,
                "early_stop_patience": 35,
                "min_objective_improvement": 1e-6,
                "grad_clip": 1.0,
                "weights": {
                    "image_lncc": 0.55,
                    "structural_gradient": 0.20,
                    "lobe": 0.60,
                    "lobe_sdf": 0.90,
                    "interface_overlap": 0.20,
                    "fissure_surface": 0.25,
                    "support": 0.04,
                    "bending": 0.05,
                    "residual_magnitude": 0.015,
                    "jacobian": 25.0,
                    "jacobian_margin": 0.02,
                },
                "selection_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            },
            {
                "name": "C_fissure_surface",
                "reduce_factor": 2,
                "control_factor": 3,
                "iterations": 120,
                "lr": 0.015,
                "max_residual_fullres_voxels": 0.75,
                "integration_steps": 6,
                "early_stop_patience": 40,
                "min_objective_improvement": 1e-6,
                "grad_clip": 1.0,
                "weights": {
                    "image_lncc": 0.35,
                    "structural_gradient": 0.25,
                    "lobe": 0.45,
                    "lobe_sdf": 0.65,
                    "interface_overlap": 0.30,
                    "fissure_surface": 1.10,
                    "support": 0.03,
                    "bending": 0.06,
                    "residual_magnitude": 0.02,
                    "jacobian": 30.0,
                    "jacobian_margin": 0.025,
                },
                "selection_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            },
        ],
        "selection": {
            "min_composite_score_gain": 1e-4,
            "max_proxy_lobe_drop": 5e-4,
            "max_lncc_loss_increase": 7.5e-4,
            "max_support_dice_drop": 0.0015,
            "topology_guard_mode": "relative_to_stage_input",
            "max_folding_increase_pct": 5e-5,
            "max_absolute_folding_pct": 0.001,
            "score_lobe_gain": 1.0,
            "score_lncc_gain": 0.45,
            "score_interface_gain": 0.20,
            "score_support_gain": 0.03,
            "score_sdf_gain": 0.45,
            "score_fissure_gain": 0.50,
            "score_gradient_gain": 0.15,
        },
        "evaluation": {
            "enabled": True,
            "device": "cuda",
            "initializer_metrics_json": "outputs/sgr_fm/c2_long_tto/eval/validation_metrics.json",
        },
    }


def build_config(config_path: str | Path | None, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = default_config()
    if config_path is not None:
        recursive_update(cfg, load_yaml_or_json(config_path, root_key="sgr_fm_c4_hast"))
    if overrides:
        recursive_update(cfg, overrides)
    return cfg


def validation_asset_paths(segmentation_dir: Path, initializer_dir: Path, case_id: str) -> dict[str, Path]:
    return {
        "exp_support": segmentation_dir / "support" / "validation" / f"{case_id}_EXP_support.nii.gz",
        "insp_support": segmentation_dir / "support" / "validation" / f"{case_id}_INSP_support.nii.gz",
        "exp_lobes": segmentation_dir / "lobes" / "validation" / f"{case_id}_EXP_lobes.nii.gz",
        "insp_lobes": segmentation_dir / "lobes" / "validation" / f"{case_id}_INSP_lobes.nii.gz",
        "initializer_canonical": initializer_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz",
        "initializer_original": initializer_dir / "dvfs" / f"{case_id}_DVF.nii.gz",
    }


def load_canonical_ct(path: str | Path, *, clip_min_hu: float, clip_max_hu: float) -> tuple[np.ndarray, nib.Nifti1Image]:
    image = canonical_image(path)
    data = np.asanyarray(image.dataobj).astype(np.float32)
    if data.ndim != 3 or not np.isfinite(data).all():
        raise ValueError(f"Invalid CT {data.shape}: {path}")
    if clip_max_hu <= clip_min_hu:
        raise ValueError("clip_max_hu must be > clip_min_hu")
    data = np.clip(data, float(clip_min_hu), float(clip_max_hu))
    data = 2.0 * (data - float(clip_min_hu)) / float(clip_max_hu - clip_min_hu) - 1.0
    return data.astype(np.float32, copy=False), image


def _voxel_spacing_mm(image: nib.Nifti1Image) -> tuple[float, float, float]:
    zooms = tuple(float(v) for v in image.header.get_zooms()[:3])
    if any((not np.isfinite(v)) or v <= 0.0 for v in zooms):
        raise ValueError(f"Invalid voxel spacing {zooms}")
    return zooms


def signed_distance_channels(
    labels: np.ndarray,
    *,
    spacing_mm: Sequence[float],
    band_mm: float,
) -> np.ndarray:
    if band_mm <= 0.0:
        raise ValueError("band_mm must be positive")
    channels: list[np.ndarray] = []
    for label in LOBE_LABELS:
        mask = np.asarray(labels == int(label), dtype=bool)
        if not mask.any():
            raise ValueError(f"Missing lobe label {label} while constructing SDF")
        outside = distance_transform_edt(~mask, sampling=tuple(spacing_mm))
        inside = distance_transform_edt(mask, sampling=tuple(spacing_mm))
        sdf = outside - inside
        sdf = np.clip(sdf, -float(band_mm), float(band_mm)) / float(band_mm)
        channels.append(sdf.astype(np.float32, copy=False))
    return np.stack(channels, axis=0)  # [5,X,Y,Z]


def _connectivity6() -> np.ndarray:
    st = np.zeros((3, 3, 3), dtype=bool)
    st[1, 1, 1] = True
    st[0, 1, 1] = st[2, 1, 1] = True
    st[1, 0, 1] = st[1, 2, 1] = True
    st[1, 1, 0] = st[1, 1, 2] = True
    return st


def explicit_interface_surfaces(labels: np.ndarray, *, dilation_iterations: int = 1) -> np.ndarray:
    """Return three predicted anatomical interfaces [3,X,Y,Z].

    Channels:
      0: left oblique  (LUL vs LLL)
      1: right horizontal (RUL vs RML)
      2: right oblique (RLL vs RUL|RML)
    """
    masks = {int(label): np.asarray(labels == int(label), dtype=bool) for label in LOBE_LABELS}
    structure = _connectivity6()
    iterations = max(1, int(dilation_iterations))

    pairs = [
        (masks[8], masks[16]),
        (masks[32], masks[64]),
        (masks[128], masks[32] | masks[64]),
    ]
    surfaces: list[np.ndarray] = []
    for idx, (a, b) in enumerate(pairs):
        da = binary_dilation(a, structure=structure, iterations=iterations)
        db = binary_dilation(b, structure=structure, iterations=iterations)
        surface = da & db
        if not surface.any():
            raise ValueError(f"Predicted interface channel {idx} is empty")
        surfaces.append(surface.astype(np.float32))
    return np.stack(surfaces, axis=0)


def interface_distance_channels(
    surfaces: np.ndarray,
    *,
    spacing_mm: Sequence[float],
    band_mm: float,
) -> np.ndarray:
    if surfaces.ndim != 4 or surfaces.shape[0] != 3:
        raise ValueError(f"Expected [3,X,Y,Z] surfaces, got {surfaces.shape}")
    if band_mm <= 0.0:
        raise ValueError("interface band_mm must be positive")
    distances: list[np.ndarray] = []
    for ch in range(3):
        surface = surfaces[ch] > 0.5
        if not surface.any():
            raise ValueError(f"Empty interface surface channel {ch}")
        dist = distance_transform_edt(~surface, sampling=tuple(spacing_mm))
        dist = np.clip(dist, 0.0, float(band_mm)) / float(band_mm)
        distances.append(dist.astype(np.float32, copy=False))
    return np.stack(distances, axis=0)


def channels_to_tensor(array: np.ndarray, *, device: torch.device) -> torch.Tensor:
    arr = np.asarray(array, dtype=np.float32)
    if arr.ndim != 4:
        raise ValueError(f"Expected [C,X,Y,Z], got {arr.shape}")
    return torch.as_tensor(arr, device=device).unsqueeze(0)


def load_case_tensors(
    *,
    exp_ct_path: Path,
    insp_ct_path: Path,
    assets: dict[str, Path],
    device: torch.device,
    ct_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
    affine_atol: float = 1e-5,
) -> dict[str, Any]:
    for name, path in assets.items():
        if not path.exists():
            raise FileNotFoundError(f"Missing {name}: {path}")

    moving_ct_np, moving_ct_img = load_canonical_ct(
        exp_ct_path,
        clip_min_hu=float(ct_cfg.get("clip_min_hu", -1000.0)),
        clip_max_hu=float(ct_cfg.get("clip_max_hu", 400.0)),
    )
    fixed_ct_np, fixed_ct_img = load_canonical_ct(
        insp_ct_path,
        clip_min_hu=float(ct_cfg.get("clip_min_hu", -1000.0)),
        clip_max_hu=float(ct_cfg.get("clip_max_hu", 400.0)),
    )
    assert_same_canonical_grid(moving_ct_img, fixed_ct_img, name="EXP/INSP CT", affine_atol=affine_atol)

    moving_labels, _ = load_canonical_label(assets["exp_lobes"], exp_ct_path, affine_atol=affine_atol)
    fixed_labels, _ = load_canonical_label(assets["insp_lobes"], insp_ct_path, affine_atol=affine_atol)
    moving_support_np, _ = load_canonical_support(assets["exp_support"], exp_ct_path, affine_atol=affine_atol)
    fixed_support_np, _ = load_canonical_support(assets["insp_support"], insp_ct_path, affine_atol=affine_atol)
    init_np, init_img = load_canonical_dvf(assets["initializer_canonical"], insp_ct_path, affine_atol=affine_atol)

    spacing = _voxel_spacing_mm(fixed_ct_img)
    sdf_band = float(anatomy_cfg.get("sdf_band_mm", 12.0))
    interface_band = float(anatomy_cfg.get("interface_band_mm", 10.0))
    dilation_iterations = int(anatomy_cfg.get("interface_dilation_iterations", 1))

    moving_sdf = signed_distance_channels(moving_labels, spacing_mm=spacing, band_mm=sdf_band)
    fixed_sdf = signed_distance_channels(fixed_labels, spacing_mm=spacing, band_mm=sdf_band)
    moving_surfaces = explicit_interface_surfaces(moving_labels, dilation_iterations=dilation_iterations)
    fixed_surfaces = explicit_interface_surfaces(fixed_labels, dilation_iterations=dilation_iterations)
    moving_interface_dist = interface_distance_channels(moving_surfaces, spacing_mm=spacing, band_mm=interface_band)
    fixed_interface_dist = interface_distance_channels(fixed_surfaces, spacing_mm=spacing, band_mm=interface_band)

    return {
        "moving_ct": volume_to_tensor(moving_ct_np, device=device),
        "fixed_ct": volume_to_tensor(fixed_ct_np, device=device),
        "moving_lobes": labels_to_one_hot(moving_labels, device=device),
        "fixed_lobes": labels_to_one_hot(fixed_labels, device=device),
        "moving_support": support_to_tensor(moving_support_np, device=device),
        "fixed_support": support_to_tensor(fixed_support_np, device=device),
        "moving_sdf": channels_to_tensor(moving_sdf, device=device),
        "fixed_sdf": channels_to_tensor(fixed_sdf, device=device),
        "moving_interface_surface": channels_to_tensor(moving_surfaces, device=device),
        "fixed_interface_surface": channels_to_tensor(fixed_surfaces, device=device),
        "moving_interface_dist": channels_to_tensor(moving_interface_dist, device=device),
        "fixed_interface_dist": channels_to_tensor(fixed_interface_dist, device=device),
        "init_dvf": dvf_xyzc_to_tensor(init_np, device=device),
        "canonical_reference": init_img,
        "full_shape": tuple(int(v) for v in init_np.shape[:3]),
        "spacing_mm": spacing,
    }


def make_lowres_state(full: dict[str, Any], *, reduce_factor: int, current_dvf_full: torch.Tensor) -> dict[str, torch.Tensor]:
    factor = int(reduce_factor)
    if factor < 1:
        raise ValueError(f"reduce_factor must be >=1, got {factor}")

    def rs(x: torch.Tensor, mode: str) -> torch.Tensor:
        return x if factor == 1 else resize_volume_5d(x, factor, mode=mode)

    return {
        "moving_ct": rs(full["moving_ct"], "trilinear"),
        "fixed_ct": rs(full["fixed_ct"], "trilinear"),
        "moving_lobes": rs(full["moving_lobes"], "nearest"),
        "fixed_lobes": rs(full["fixed_lobes"], "nearest"),
        "moving_support": rs(full["moving_support"], "nearest"),
        "fixed_support": rs(full["fixed_support"], "nearest"),
        "moving_sdf": rs(full["moving_sdf"], "trilinear"),
        "fixed_sdf": rs(full["fixed_sdf"], "trilinear"),
        "moving_interface_surface": rs(full["moving_interface_surface"], "trilinear"),
        "fixed_interface_surface": rs(full["fixed_interface_surface"], "trilinear"),
        "moving_interface_dist": rs(full["moving_interface_dist"], "trilinear"),
        "fixed_interface_dist": rs(full["fixed_interface_dist"], "trilinear"),
        "init_dvf": current_dvf_full if factor == 1 else downsample_dvf_5d(current_dvf_full, factor),
    }


def _gradient3d(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if x.ndim != 5:
        raise ValueError(f"Expected [B,C,X,Y,Z], got {tuple(x.shape)}")
    gx = torch.zeros_like(x)
    gy = torch.zeros_like(x)
    gz = torch.zeros_like(x)
    gx[:, :, 1:-1, :, :] = 0.5 * (x[:, :, 2:, :, :] - x[:, :, :-2, :, :])
    gy[:, :, :, 1:-1, :] = 0.5 * (x[:, :, :, 2:, :] - x[:, :, :, :-2, :])
    gz[:, :, :, :, 1:-1] = 0.5 * (x[:, :, :, :, 2:] - x[:, :, :, :, :-2])
    gx[:, :, 0, :, :] = x[:, :, 1, :, :] - x[:, :, 0, :, :]
    gx[:, :, -1, :, :] = x[:, :, -1, :, :] - x[:, :, -2, :, :]
    gy[:, :, :, 0, :] = x[:, :, :, 1, :] - x[:, :, :, 0, :]
    gy[:, :, :, -1, :] = x[:, :, :, -1, :] - x[:, :, :, -2, :]
    gz[:, :, :, :, 0] = x[:, :, :, :, 1] - x[:, :, :, :, 0]
    gz[:, :, :, :, -1] = x[:, :, :, :, -1] - x[:, :, :, :, -2]
    return gx, gy, gz


def structural_gradient_loss(
    fixed: torch.Tensor,
    moving_warped: torch.Tensor,
    mask: torch.Tensor,
    *,
    min_magnitude: float,
    eps: float = 1e-6,
) -> torch.Tensor:
    fg = _gradient3d(fixed)
    mg = _gradient3d(moving_warped)
    fvec = torch.cat(fg, dim=1)
    mvec = torch.cat(mg, dim=1)
    fmag = torch.sqrt(fvec.square().sum(dim=1, keepdim=True) + eps)
    mmag = torch.sqrt(mvec.square().sum(dim=1, keepdim=True) + eps)
    fdir = fvec / fmag
    mdir = mvec / mmag
    cosine = (fdir * mdir).sum(dim=1, keepdim=True).clamp(-1.0, 1.0)
    edge_weight = (fmag / max(float(min_magnitude), eps)).clamp(0.0, 1.0)
    weight = mask.clamp(0.0, 1.0) * edge_weight
    denom = weight.sum().clamp_min(eps)
    return ((1.0 - cosine) * weight).sum() / denom


def lobe_sdf_loss(
    warped_moving_sdf: torch.Tensor,
    fixed_sdf: torch.Tensor,
    *,
    band_fraction: float,
    charbonnier_eps: float,
) -> torch.Tensor:
    if warped_moving_sdf.shape != fixed_sdf.shape:
        raise ValueError("SDF shape mismatch")
    threshold = float(band_fraction)
    if threshold <= 0.0 or threshold > 1.0:
        raise ValueError("sdf_loss_band_fraction must be in (0,1]")
    band = ((fixed_sdf.abs() <= threshold) | (warped_moving_sdf.abs() <= threshold)).float()
    diff = warped_moving_sdf - fixed_sdf
    robust = torch.sqrt(diff.square() + float(charbonnier_eps) ** 2)
    denom = band.sum().clamp_min(1.0)
    return (robust * band).sum() / denom


def fissure_surface_loss(
    *,
    warped_moving_dist: torch.Tensor,
    fixed_dist: torch.Tensor,
    warped_moving_surface: torch.Tensor,
    fixed_surface: torch.Tensor,
    eps: float = 1e-6,
) -> torch.Tensor:
    """Symmetric differentiable surface-to-distance loss for three interfaces."""
    a_num = (fixed_surface * warped_moving_dist).sum()
    a_den = fixed_surface.sum().clamp_min(eps)
    b_num = (warped_moving_surface * fixed_dist).sum()
    b_den = warped_moving_surface.sum().clamp_min(eps)
    return 0.5 * (a_num / a_den + b_num / b_den)


def interface_overlap_dice(pred_lobes: torch.Tensor, target_lobes: torch.Tensor) -> torch.Tensor:
    pred = soft_boundary_union(pred_lobes, dilation_voxels=1)
    target = soft_boundary_union(target_lobes, dilation_voxels=1)
    return binary_soft_dice(pred, target)


def compute_proxy_metrics(
    *,
    state: dict[str, torch.Tensor],
    dvf: torch.Tensor,
    ct_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> dict[str, float]:
    warped_ct = warp_volume(state["moving_ct"], dvf, mode="bilinear")
    warped_lobes = warp_volume(state["moving_lobes"], dvf, mode="bilinear")
    warped_support = warp_volume(state["moving_support"], dvf, mode="bilinear")
    warped_sdf = warp_volume(state["moving_sdf"], dvf, mode="bilinear")
    warped_iface_dist = warp_volume(state["moving_interface_dist"], dvf, mode="bilinear")
    warped_iface_surface = warp_volume(state["moving_interface_surface"], dvf, mode="bilinear")

    lobe = lobe_soft_dice(warped_lobes, state["fixed_lobes"])
    interface = interface_overlap_dice(warped_lobes, state["fixed_lobes"])
    support = binary_soft_dice(warped_support, state["fixed_support"])
    lncc = masked_local_ncc_loss(
        state["fixed_ct"], warped_ct, state["fixed_support"],
        window=int(ct_cfg.get("lncc_window", 9)),
        min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
    )
    grad = structural_gradient_loss(
        state["fixed_ct"], warped_ct, state["fixed_support"],
        min_magnitude=float(ct_cfg.get("gradient_min_magnitude", 0.03)),
    )
    sdf = lobe_sdf_loss(
        warped_sdf, state["fixed_sdf"],
        band_fraction=float(anatomy_cfg.get("sdf_loss_band_fraction", 0.85)),
        charbonnier_eps=float(anatomy_cfg.get("charbonnier_eps", 1e-3)),
    )
    fissure = fissure_surface_loss(
        warped_moving_dist=warped_iface_dist,
        fixed_dist=state["fixed_interface_dist"],
        warped_moving_surface=warped_iface_surface,
        fixed_surface=state["fixed_interface_surface"],
    )
    return {
        "proxy_lobe_dice": float(lobe.item()),
        "proxy_interface_dice": float(interface.item()),
        "proxy_support_dice": float(support.item()),
        "lncc_loss": float(lncc.item()),
        "structural_gradient_loss": float(grad.item()),
        "lobe_sdf_loss": float(sdf.item()),
        "fissure_surface_loss": float(fissure.item()),
    }


def objective_terms(
    *,
    state: dict[str, torch.Tensor],
    init_dvf: torch.Tensor,
    residual_dvf: torch.Tensor,
    weights: dict[str, Any],
    ct_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    final_dvf = compose_pull(init_dvf, residual_dvf)
    warped_ct = warp_volume(state["moving_ct"], final_dvf, mode="bilinear")
    warped_lobes = warp_volume(state["moving_lobes"], final_dvf, mode="bilinear")
    warped_support = warp_volume(state["moving_support"], final_dvf, mode="bilinear")
    warped_sdf = warp_volume(state["moving_sdf"], final_dvf, mode="bilinear")
    warped_iface_dist = warp_volume(state["moving_interface_dist"], final_dvf, mode="bilinear")
    warped_iface_surface = warp_volume(state["moving_interface_surface"], final_dvf, mode="bilinear")

    lobe_dice = lobe_soft_dice(warped_lobes, state["fixed_lobes"])
    interface_dice = interface_overlap_dice(warped_lobes, state["fixed_lobes"])
    support_dice = binary_soft_dice(warped_support, state["fixed_support"])
    lncc = masked_local_ncc_loss(
        state["fixed_ct"], warped_ct, state["fixed_support"],
        window=int(ct_cfg.get("lncc_window", 9)),
        min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
    )
    gradient = structural_gradient_loss(
        state["fixed_ct"], warped_ct, state["fixed_support"],
        min_magnitude=float(ct_cfg.get("gradient_min_magnitude", 0.03)),
    )
    sdf = lobe_sdf_loss(
        warped_sdf, state["fixed_sdf"],
        band_fraction=float(anatomy_cfg.get("sdf_loss_band_fraction", 0.85)),
        charbonnier_eps=float(anatomy_cfg.get("charbonnier_eps", 1e-3)),
    )
    fissure = fissure_surface_loss(
        warped_moving_dist=warped_iface_dist,
        fixed_dist=state["fixed_interface_dist"],
        warped_moving_surface=warped_iface_surface,
        fixed_surface=state["fixed_interface_surface"],
    )
    bend = bending_energy(residual_dvf)
    magnitude = residual_dvf.square().mean()
    jac, folding_pct, min_det = jacobian_barrier(
        final_dvf,
        margin=float(weights.get("jacobian_margin", 0.02)),
    )

    total = (
        float(weights.get("image_lncc", 0.0)) * lncc
        + float(weights.get("structural_gradient", 0.0)) * gradient
        + float(weights.get("lobe", 0.0)) * (1.0 - lobe_dice)
        + float(weights.get("lobe_sdf", 0.0)) * sdf
        + float(weights.get("interface_overlap", 0.0)) * (1.0 - interface_dice)
        + float(weights.get("fissure_surface", 0.0)) * fissure
        + float(weights.get("support", 0.0)) * (1.0 - support_dice)
        + float(weights.get("bending", 0.0)) * bend
        + float(weights.get("residual_magnitude", 0.0)) * magnitude
        + float(weights.get("jacobian", 0.0)) * jac
    )
    return total, {
        "total": total,
        "lncc_loss": lncc,
        "structural_gradient_loss": gradient,
        "proxy_lobe_dice": lobe_dice,
        "proxy_interface_dice": interface_dice,
        "proxy_support_dice": support_dice,
        "lobe_sdf_loss": sdf,
        "fissure_surface_loss": fissure,
        "bending": bend,
        "residual_magnitude": magnitude,
        "jacobian_loss": jac,
        "folding_pct": folding_pct,
        "min_det": min_det,
    }


def tensor_terms_to_float(terms: dict[str, torch.Tensor]) -> dict[str, float]:
    return {key: float(value.detach().float().item()) for key, value in terms.items()}


def candidate_score(candidate: dict[str, float], baseline: dict[str, float], selection: dict[str, Any]) -> float:
    lobe_gain = candidate["proxy_lobe_dice"] - baseline["proxy_lobe_dice"]
    lncc_gain = baseline["lncc_loss"] - candidate["lncc_loss"]
    interface_gain = candidate["proxy_interface_dice"] - baseline["proxy_interface_dice"]
    support_gain = candidate["proxy_support_dice"] - baseline["proxy_support_dice"]
    sdf_gain = baseline["lobe_sdf_loss"] - candidate["lobe_sdf_loss"]
    fissure_gain = baseline["fissure_surface_loss"] - candidate["fissure_surface_loss"]
    gradient_gain = baseline["structural_gradient_loss"] - candidate["structural_gradient_loss"]
    return (
        float(selection.get("score_lobe_gain", 1.0)) * lobe_gain
        + float(selection.get("score_lncc_gain", 0.45)) * lncc_gain
        + float(selection.get("score_interface_gain", 0.20)) * interface_gain
        + float(selection.get("score_support_gain", 0.03)) * support_gain
        + float(selection.get("score_sdf_gain", 0.45)) * sdf_gain
        + float(selection.get("score_fissure_gain", 0.50)) * fissure_gain
        + float(selection.get("score_gradient_gain", 0.15)) * gradient_gain
    )


def topology_folding_limit(*, baseline_folding_pct: float, selection: dict[str, Any]) -> float:
    mode = str(selection.get("topology_guard_mode", "relative_to_stage_input")).strip().lower()
    max_absolute = float(selection.get("max_absolute_folding_pct", 1e-3))
    max_increase = float(selection.get("max_folding_increase_pct", 5e-5))
    if max_absolute < 0.0 or max_increase < 0.0:
        raise ValueError("Folding guard limits must be non-negative")
    if mode in {"relative_to_stage_input", "relative_to_initializer"}:
        return min(max_absolute, float(baseline_folding_pct) + max_increase)
    if mode == "absolute":
        return max_absolute
    raise ValueError(f"Unsupported topology_guard_mode={mode!r}")


def passes_acceptance(
    candidate: dict[str, float],
    baseline: dict[str, float],
    *,
    baseline_folding_pct: float,
    selection: dict[str, Any],
) -> tuple[bool, list[str], float, float]:
    reasons: list[str] = []
    score = candidate_score(candidate, baseline, selection)
    lobe_drop = baseline["proxy_lobe_dice"] - candidate["proxy_lobe_dice"]
    lncc_increase = candidate["lncc_loss"] - baseline["lncc_loss"]
    support_drop = baseline["proxy_support_dice"] - candidate["proxy_support_dice"]
    fold_limit = topology_folding_limit(
        baseline_folding_pct=baseline_folding_pct,
        selection=selection,
    )
    if score < float(selection.get("min_composite_score_gain", 1e-4)):
        reasons.append(f"composite_score_gain={score:.6g} below minimum")
    if lobe_drop > float(selection.get("max_proxy_lobe_drop", 5e-4)):
        reasons.append(f"proxy_lobe_drop={lobe_drop:.6g} above maximum")
    if lncc_increase > float(selection.get("max_lncc_loss_increase", 7.5e-4)):
        reasons.append(f"lncc_loss_increase={lncc_increase:.6g} above maximum")
    if support_drop > float(selection.get("max_support_dice_drop", 0.0015)):
        reasons.append(f"support_dice_drop={support_drop:.6g} above maximum")
    if candidate["folding_pct"] > fold_limit + 1e-12:
        reasons.append(f"folding_pct={candidate['folding_pct']:.6g} above limit={fold_limit:.6g}")
    return (len(reasons) == 0), reasons, fold_limit, float(score)


def clone_parameter_state(params: Iterable[torch.Tensor]) -> list[torch.Tensor]:
    return [p.detach().clone() for p in params]


def restore_parameter_state(params: Sequence[torch.Tensor], state: Sequence[torch.Tensor]) -> None:
    if len(params) != len(state):
        raise ValueError("Parameter state length mismatch")
    with torch.no_grad():
        for param, value in zip(params, state):
            param.copy_(value)


def build_stage_residual(
    param: torch.Tensor,
    *,
    target_shape: Sequence[int],
    full_shape: Sequence[int],
    stage_cfg: dict[str, Any],
    scale: float = 1.0,
) -> torch.Tensor:
    return build_residual_dvf(
        param,
        None,
        target_shape=target_shape,
        full_shape=full_shape,
        max_fullres_voxels=float(stage_cfg.get("max_residual_fullres_voxels", 1.0)),
        integration_steps=int(stage_cfg.get("integration_steps", 5)),
        scale=float(scale),
    )


def make_stage_parameter(
    target_shape: Sequence[int],
    *,
    stage_cfg: dict[str, Any],
    device: torch.device,
    dtype: torch.dtype,
) -> torch.nn.Parameter:
    return make_control_parameter(
        target_shape,
        int(stage_cfg.get("control_factor", 4)),
        device=device,
        dtype=dtype,
    )
