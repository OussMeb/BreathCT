SGR-FM C4.1-HAST-PCF PATCH
===========================

Purpose
-------
Add a new, separate C4.1 branch on top of the frozen C4-HAST champion.
C4 itself is never overwritten.

C4.1-HAST-PCF = Hierarchical Anatomical Surface TTO with:
  * Paired Consensus from direct INSP lobes + EXP lobes transported by C4 + EXP lobes transported by C2-LONG
  * confidence-weighted pseudo-label guidance
  * class-balanced five-lobe Dice/SDF losses (small lobes are not drowned out)
  * separate right-horizontal and right-oblique fissure losses
  * uncertainty-weighted CT structural-gradient guidance
  * one localized Stage-D residual SVF around the right fissure complex
  * exact pull composition with the frozen C4 initializer
  * full-resolution topology guard
  * exact C4 byte-copy fallback if no candidate passes

No validation GT is loaded by optimization. GT is used only by the existing evaluator after a complete 10-case run.

Install
-------
cd "/home/oussama/Desktop/MICCAI FRANCE"
unzip -o SGR_FM_C4_1_HAST_PCF_patch.zip -d .

Compile
-------
python -m py_compile \
  main.py \
  run_sgr_fm_c4_1_hast_pcf_validation.py \
  utils/sgr_fm_c4_1_hast_pcf.py

Synthetic smoke
---------------
python smoke_sgr_fm_c4_1_hast_pcf_synthetic.py

Expected final line:
C4.1-HAST-PCF SYNTHETIC SMOKE: PASS

Dry-run / asset audit
---------------------
python main.py c4.1-hast-pcf \
  --config configs/sgr_fm_c4_1_hast_pcf.yaml \
  --dry-run

Recommended real smoke tests
----------------------------
# hard RML case
python main.py c4.1-hast-pcf \
  --config configs/sgr_fm_c4_1_hast_pcf.yaml \
  --case-ids NLST_0006 \
  --skip-evaluation

# difficult right-fissure case
python main.py c4.1-hast-pcf \
  --config configs/sgr_fm_c4_1_hast_pcf.yaml \
  --case-ids NLST_0007 \
  --skip-evaluation

# already-strong safety case
python main.py c4.1-hast-pcf \
  --config configs/sgr_fm_c4_1_hast_pcf.yaml \
  --case-ids NLST_0009 \
  --skip-evaluation

Full 10-case run
----------------
python main.py c4.1-hast-pcf \
  --config configs/sgr_fm_c4_1_hast_pcf.yaml

Outputs
-------
outputs/sgr_fm/c4_1_hast_pcf/
  dvfs/
  dvfs_canonical_ras/
  case_manifests/
  traces/
  eval/validation_metrics.json
  comparison/C4_vs_C4_1_HAST_PCF_summary.json
  comparison/C4_vs_C4_1_HAST_PCF_per_case.csv
  c4_1_hast_pcf_summary.json
  run_config_resolved.json

Critical safety behavior
------------------------
The C4 initializer and C2-LONG secondary view are fingerprint checked.
The output directory is separate from C4.
If Stage D has no accepted candidate, the C4 original and canonical DVFs are copied byte-for-byte.
