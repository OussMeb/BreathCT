#!/usr/bin/env python3
"""Small CPU synthetic smoke test for C4.1-HAST-PCF core mechanics."""
from __future__ import annotations

import sys
from pathlib import Path

import torch

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.sgr_fm_c4_1_hast_pcf import (
    balanced_consensus_lobe_dice,
    build_localized_residual_dvf,
    build_paired_consensus,
    class_balance_weights,
    default_config,
    objective_terms,
    right_localization_mask,
)


def plane_distance(shape: tuple[int, int, int], axis: int, pos: float) -> torch.Tensor:
    coords = torch.linspace(0.0, 1.0, shape[axis])
    view = [1, 1, 1]
    view[axis] = shape[axis]
    grid = coords.view(*view).expand(*shape)
    return (grid - pos).abs().clamp(0.0, 1.0)


def main() -> int:
    torch.manual_seed(2026)
    device = torch.device("cpu")
    shape = (24, 24, 24)

    target = torch.zeros((1, 5, *shape), dtype=torch.float32, device=device)
    target[:, 0, 3:12, 3:12, 3:12] = 1.0
    target[:, 1, 12:21, 3:12, 3:12] = 1.0
    target[:, 2, 3:12, 12:21, 3:12] = 1.0
    # Small RML by design: class-balance weight should be > 1.
    target[:, 3, 12:17, 12:18, 3:10] = 1.0
    target[:, 4, 12:21, 12:21, 12:21] = 1.0
    moving = torch.roll(target, shifts=1, dims=2)

    moving_sdf = 1.0 - 2.0 * moving
    fixed_sdf = 1.0 - 2.0 * target

    fixed_surface = torch.zeros((1, 3, *shape), dtype=torch.float32)
    moving_surface = torch.zeros_like(fixed_surface)
    fixed_surface[:, 0, 11:13, 3:12, 3:12] = 1.0
    fixed_surface[:, 1, 11:13, 12:18, 3:10] = 1.0
    fixed_surface[:, 2, 12:21, 11:13, 10:14] = 1.0
    moving_surface.copy_(torch.roll(fixed_surface, shifts=1, dims=2))

    fixed_dist = torch.stack([
        plane_distance(shape, 0, 0.50),
        plane_distance(shape, 0, 0.50),
        plane_distance(shape, 1, 0.50),
    ], dim=0).unsqueeze(0)
    moving_dist = torch.roll(fixed_dist, shifts=1, dims=2)

    zero_dvf = torch.zeros((1, 3, *shape), dtype=torch.float32)
    c2_dvf = zero_dvf.clone()
    c4_dvf = zero_dvf.clone()

    cfg = default_config()
    consensus = build_paired_consensus(
        fixed_direct_lobes=target,
        moving_lobes=moving,
        moving_sdf=moving_sdf,
        fixed_sdf=fixed_sdf,
        moving_interface_surface=moving_surface,
        fixed_interface_surface=fixed_surface,
        moving_interface_dist=moving_dist,
        fixed_interface_dist=fixed_dist,
        c4_dvf=c4_dvf,
        c2_dvf=c2_dvf,
        cfg=cfg["consensus"],
    )

    if not torch.isfinite(consensus["consensus_lobes"]).all():
        raise RuntimeError("non-finite consensus")
    if consensus["consensus_lobes"].min() < 0 or consensus["consensus_lobes"].max() > 1.000001:
        raise RuntimeError("consensus probability range failure")

    weights = class_balance_weights(consensus["consensus_lobes"], cfg["consensus"])
    if not float(weights[3]) > 1.0:
        raise RuntimeError(f"expected small RML class upweight, got {weights.tolist()}")

    x = torch.linspace(-1.0, 1.0, shape[0]).view(1, 1, shape[0], 1, 1)
    y = torch.linspace(-1.0, 1.0, shape[1]).view(1, 1, 1, shape[1], 1)
    z = torch.linspace(-1.0, 1.0, shape[2]).view(1, 1, 1, 1, shape[2])
    fixed_ct = torch.exp(-3.0 * (x.square() + y.square() + z.square()))
    moving_ct = torch.roll(fixed_ct, shifts=1, dims=2)
    support = (target.sum(dim=1, keepdim=True) > 0).float()

    state = {
        "moving_ct": moving_ct,
        "fixed_ct": fixed_ct,
        "moving_lobes": moving,
        "fixed_direct_lobes": target,
        "consensus_lobes": consensus["consensus_lobes"],
        "confidence_lobes": consensus["confidence_lobes"],
        "moving_support": support,
        "fixed_support": support,
        "moving_sdf": moving_sdf,
        "consensus_sdf": consensus["consensus_sdf"],
        "moving_interface_surface": moving_surface,
        "moving_interface_dist": moving_dist,
        "consensus_interface_surface": consensus["consensus_interface_surface"],
        "consensus_interface_dist": consensus["consensus_interface_dist"],
        "confidence_interfaces": consensus["confidence_interfaces"],
        "right_confidence": consensus["right_confidence"],
        "right_distance": consensus["right_distance"],
        "init_dvf": zero_dvf,
    }

    stage = cfg["stage_d"].copy()
    stage["control_factor"] = 4
    stage["integration_steps"] = 3
    stage["max_residual_fullres_voxels"] = 0.5
    param = torch.nn.Parameter(torch.zeros((1, 3, 6, 6, 6), dtype=torch.float32))
    local = right_localization_mask(state, stage)
    residual = build_localized_residual_dvf(
        param,
        target_shape=shape,
        full_shape=shape,
        stage_cfg=stage,
        localization_mask=local,
        scale=1.0,
    )
    total, terms = objective_terms(
        state=state,
        residual_dvf=residual,
        weights=stage["weights"],
        ct_cfg=cfg["ct"],
        consensus_cfg=cfg["consensus"],
        stage_cfg=stage,
        anatomy_cfg=cfg["anatomy"],
    )
    if not torch.isfinite(total):
        raise RuntimeError("non-finite objective")
    total.backward()
    grad_norm = float(param.grad.norm().item())
    if not grad_norm > 0.0:
        raise RuntimeError("zero optimization gradient")

    score, _, _ = balanced_consensus_lobe_dice(moving, consensus["consensus_lobes"], cfg["consensus"])
    print("consensus_shape", tuple(consensus["consensus_lobes"].shape))
    print("class_weights", [round(float(v), 4) for v in weights])
    print("initial_balanced_consensus_dice", float(score.item()))
    print("objective", float(total.item()))
    print("gradient_norm", grad_norm)
    print("C4.1-HAST-PCF SYNTHETIC SMOKE: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
