#!/usr/bin/env python3
"""Core helpers for SGR-FM C4.1-HAST-PCF.

C4.1-HAST-PCF = C4-HAST with Paired Consensus and confidence-weighted
Fissure refinement.

The method starts from the frozen C4-HAST pull DVF and performs one additional
small, localized residual-SVF stage (Stage D). Optimization uses only signals
available at inference time:
  * raw EXP/INSP CT,
  * predicted five-lobe masks,
  * predicted support masks,
  * frozen C4-HAST initializer,
  * frozen C2-LONG secondary transport view.

Validation ground truth is never loaded by this module.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Sequence

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F

from utils.refine_spatial import downsample_dvf_5d, integrate_svf, resize_volume_5d, warp_volume
from utils.sgr_fm_c3 import (
    LOBE_LABELS,
    assert_same_canonical_grid,
    canonical_image,
    compose_pull,
    dvf_xyzc_to_tensor,
    labels_to_one_hot,
    load_canonical_dvf,
    load_canonical_label,
    load_canonical_support,
    soft_dice_per_lobe,
    support_to_tensor,
)
from utils.sgr_fm_c4_hast import (
    channels_to_tensor,
    explicit_interface_surfaces,
    interface_distance_channels,
    load_canonical_ct,
    signed_distance_channels,
    structural_gradient_loss,
)
from utils.sgr_fm_training_assets import load_yaml_or_json, recursive_update
from utils.sgr_fm_tto import (
    bending_energy,
    binary_soft_dice,
    build_residual_svf,
    jacobian_barrier,
    make_control_parameter,
    masked_local_ncc_loss,
    topology_stats,
    volume_to_tensor,
)


def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "initializer_dir": "outputs/sgr_fm/c4_hast",
        "secondary_initializer_dir": "outputs/sgr_fm/c2_long_tto",
        "output_dir": "outputs/sgr_fm/c4_1_hast_pcf",
        "case_ids": [],
        "overwrite": False,
        "stop_on_error": True,
        "device": "cuda",
        "require_initializer_fingerprint": True,
        "accepted_initializer_method_fingerprint": "79a39af64f3a4678983c56c7edf9b5796c8dd349dc078ef11b10e32d349a8c7c",
        "require_secondary_fingerprint": True,
        "accepted_secondary_method_fingerprint": "fdc2c0a64374aee658b647b55ae673f50faf2d08aed79ea7e0d6dd3d17fadcd3",
        "ct": {
            "clip_min_hu": -1000.0,
            "clip_max_hu": 400.0,
            "lncc_window": 9,
            "lncc_min_valid_fraction": 0.25,
            "gradient_min_magnitude": 0.03,
        },
        "anatomy": {
            "sdf_band_mm": 12.0,
            "interface_band_mm": 10.0,
            "interface_dilation_iterations": 1,
            "charbonnier_eps": 1e-3,
        },
        "consensus": {
            "direct_weight": 1.0,
            "c4_transport_weight": 0.85,
            "c2_transport_weight": 0.35,
            "direct_transport_sigma": 0.30,
            "cross_transport_sigma": 0.25,
            "confidence_floor": 0.05,
            "normalize_lobe_sum": True,
            "size_weight_power": 0.5,
            "size_weight_min": 0.75,
            "size_weight_max": 2.5,
            "sdf_band_fraction": 0.85,
            "interface_confidence_sigma": 0.30,
        },
        "stage_d": {
            "name": "D_paired_consensus_right_fissure",
            "reduce_factor": 2,
            "control_factor": 3,
            "iterations": 180,
            "lr": 0.012,
            "max_residual_fullres_voxels": 0.70,
            "integration_steps": 6,
            "early_stop_patience": 50,
            "min_objective_improvement": 1e-6,
            "grad_clip": 1.0,
            "localization_sigma": 0.35,
            "localization_floor": 0.02,
            "structural_uncertainty_floor": 0.15,
            "structural_uncertainty_gain": 0.85,
            "selection_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            "weights": {
                "image_lncc": 0.20,
                "structural_uncertain": 0.45,
                "balanced_consensus_lobe": 0.55,
                "confidence_sdf": 1.00,
                "right_horizontal": 1.50,
                "right_oblique": 1.25,
                "support": 0.03,
                "bending": 0.07,
                "residual_magnitude": 0.025,
                "jacobian": 35.0,
                "jacobian_margin": 0.025,
            },
        },
        "selection": {
            "min_composite_score_gain": 1e-4,
            "max_direct_proxy_lobe_drop": 5e-4,
            "max_lncc_loss_increase": 7.5e-4,
            "max_support_dice_drop": 0.0015,
            "topology_guard_mode": "relative_to_initializer",
            "max_folding_increase_pct": 5e-5,
            "max_absolute_folding_pct": 0.001,
            "score_consensus_lobe_gain": 1.00,
            "score_direct_lobe_gain": 0.35,
            "score_lncc_gain": 0.25,
            "score_support_gain": 0.03,
            "score_sdf_gain": 0.55,
            "score_right_horizontal_gain": 0.80,
            "score_right_oblique_gain": 0.70,
            "score_structural_gain": 0.25,
        },
        "evaluation": {
            "enabled": True,
            "device": "cuda",
            "initializer_metrics_json": "outputs/sgr_fm/c4_hast/eval/validation_metrics.json",
        },
    }


def build_config(config_path: str | Path | None, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = default_config()
    if config_path is not None:
        recursive_update(cfg, load_yaml_or_json(config_path, root_key="sgr_fm_c4_1_hast_pcf"))
    if overrides:
        recursive_update(cfg, overrides)
    return cfg


def validation_asset_paths(
    segmentation_dir: Path,
    initializer_dir: Path,
    secondary_initializer_dir: Path,
    case_id: str,
) -> dict[str, Path]:
    return {
        "exp_support": segmentation_dir / "support" / "validation" / f"{case_id}_EXP_support.nii.gz",
        "insp_support": segmentation_dir / "support" / "validation" / f"{case_id}_INSP_support.nii.gz",
        "exp_lobes": segmentation_dir / "lobes" / "validation" / f"{case_id}_EXP_lobes.nii.gz",
        "insp_lobes": segmentation_dir / "lobes" / "validation" / f"{case_id}_INSP_lobes.nii.gz",
        "initializer_canonical": initializer_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz",
        "initializer_original": initializer_dir / "dvfs" / f"{case_id}_DVF.nii.gz",
        "secondary_canonical": secondary_initializer_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz",
    }


def _voxel_spacing_mm(image: nib.Nifti1Image) -> tuple[float, float, float]:
    zooms = tuple(float(v) for v in image.header.get_zooms()[:3])
    if any((not np.isfinite(v)) or v <= 0.0 for v in zooms):
        raise ValueError(f"Invalid voxel spacing {zooms}")
    return zooms


def _normalize_lobe_probabilities(prob: torch.Tensor) -> torch.Tensor:
    if prob.ndim != 5 or prob.shape[1] != len(LOBE_LABELS):
        raise ValueError(f"Expected [B,5,X,Y,Z], got {tuple(prob.shape)}")
    total = prob.sum(dim=1, keepdim=True)
    return prob / torch.maximum(total, torch.ones_like(total))


def build_paired_consensus(
    *,
    fixed_direct_lobes: torch.Tensor,
    moving_lobes: torch.Tensor,
    moving_sdf: torch.Tensor,
    fixed_sdf: torch.Tensor,
    moving_interface_surface: torch.Tensor,
    fixed_interface_surface: torch.Tensor,
    moving_interface_dist: torch.Tensor,
    fixed_interface_dist: torch.Tensor,
    c4_dvf: torch.Tensor,
    c2_dvf: torch.Tensor,
    cfg: dict[str, Any],
) -> dict[str, torch.Tensor]:
    """Construct a fixed-frame paired consensus from direct and transported views."""
    with torch.no_grad():
        c4_lobes = warp_volume(moving_lobes, c4_dvf, mode="bilinear").clamp(0.0, 1.0)
        c2_lobes = warp_volume(moving_lobes, c2_dvf, mode="bilinear").clamp(0.0, 1.0)

        sigma_direct = max(float(cfg.get("direct_transport_sigma", 0.30)), 1e-6)
        sigma_cross = max(float(cfg.get("cross_transport_sigma", 0.25)), 1e-6)
        floor = float(cfg.get("confidence_floor", 0.05))
        if not 0.0 <= floor <= 1.0:
            raise ValueError("confidence_floor must be in [0,1]")

        conf_c4 = torch.exp(-torch.abs(fixed_direct_lobes - c4_lobes) / sigma_direct)
        conf_c2 = torch.exp(-torch.abs(fixed_direct_lobes - c2_lobes) / sigma_direct)
        cross = torch.exp(-torch.abs(c4_lobes - c2_lobes) / sigma_cross)
        conf_c4 = (conf_c4 * cross).clamp(min=floor, max=1.0)
        conf_c2 = (conf_c2 * cross).clamp(min=floor, max=1.0)

        wd = float(cfg.get("direct_weight", 1.0))
        w4 = float(cfg.get("c4_transport_weight", 0.85)) * conf_c4
        w2 = float(cfg.get("c2_transport_weight", 0.35)) * conf_c2
        denom = wd + w4 + w2
        consensus_lobes = (wd * fixed_direct_lobes + w4 * c4_lobes + w2 * c2_lobes) / denom.clamp_min(1e-6)
        if bool(cfg.get("normalize_lobe_sum", True)):
            consensus_lobes = _normalize_lobe_probabilities(consensus_lobes)

        c4_sdf = warp_volume(moving_sdf, c4_dvf, mode="bilinear")
        c2_sdf = warp_volume(moving_sdf, c2_dvf, mode="bilinear")
        consensus_sdf = (wd * fixed_sdf + w4 * c4_sdf + w2 * c2_sdf) / denom.clamp_min(1e-6)

        c4_iface_surface = warp_volume(moving_interface_surface, c4_dvf, mode="bilinear").clamp(0.0, 1.0)
        c2_iface_surface = warp_volume(moving_interface_surface, c2_dvf, mode="bilinear").clamp(0.0, 1.0)
        c4_iface_dist = warp_volume(moving_interface_dist, c4_dvf, mode="bilinear").clamp(0.0, 1.0)
        c2_iface_dist = warp_volume(moving_interface_dist, c2_dvf, mode="bilinear").clamp(0.0, 1.0)

        iface_sigma = max(float(cfg.get("interface_confidence_sigma", 0.30)), 1e-6)
        iface_conf4 = torch.exp(-torch.abs(fixed_interface_dist - c4_iface_dist) / iface_sigma)
        iface_conf2 = torch.exp(-torch.abs(fixed_interface_dist - c2_iface_dist) / iface_sigma)
        iface_cross = torch.exp(-torch.abs(c4_iface_dist - c2_iface_dist) / iface_sigma)
        iface_conf4 = (iface_conf4 * iface_cross).clamp(min=floor, max=1.0)
        iface_conf2 = (iface_conf2 * iface_cross).clamp(min=floor, max=1.0)
        idenom = wd + float(cfg.get("c4_transport_weight", 0.85)) * iface_conf4 + float(cfg.get("c2_transport_weight", 0.35)) * iface_conf2
        consensus_iface_dist = (
            wd * fixed_interface_dist
            + float(cfg.get("c4_transport_weight", 0.85)) * iface_conf4 * c4_iface_dist
            + float(cfg.get("c2_transport_weight", 0.35)) * iface_conf2 * c2_iface_dist
        ) / idenom.clamp_min(1e-6)
        consensus_iface_surface = (
            wd * fixed_interface_surface
            + float(cfg.get("c4_transport_weight", 0.85)) * iface_conf4 * c4_iface_surface
            + float(cfg.get("c2_transport_weight", 0.35)) * iface_conf2 * c2_iface_surface
        ) / idenom.clamp_min(1e-6)
        consensus_iface_surface = consensus_iface_surface.clamp(0.0, 1.0)

        confidence_lobes = (0.5 * conf_c4 + 0.5 * conf_c2).clamp(floor, 1.0)
        confidence_interfaces = (0.5 * iface_conf4 + 0.5 * iface_conf2).clamp(floor, 1.0)

        # Right-lung confidence: RUL, RML, RLL channels are indices 2,3,4.
        right_conf = confidence_lobes[:, 2:5].mean(dim=1, keepdim=True)
        # Localize around right-horizontal (1) and right-oblique (2) interface distances.
        right_dist = torch.minimum(consensus_iface_dist[:, 1:2], consensus_iface_dist[:, 2:3])

    return {
        "direct_fixed_lobes": fixed_direct_lobes,
        "c4_transport_lobes": c4_lobes,
        "c2_transport_lobes": c2_lobes,
        "consensus_lobes": consensus_lobes,
        "confidence_lobes": confidence_lobes,
        "consensus_sdf": consensus_sdf,
        "consensus_interface_dist": consensus_iface_dist,
        "consensus_interface_surface": consensus_iface_surface,
        "confidence_interfaces": confidence_interfaces,
        "right_confidence": right_conf,
        "right_distance": right_dist,
    }


def load_case_tensors(
    *,
    exp_ct_path: Path,
    insp_ct_path: Path,
    assets: dict[str, Path],
    device: torch.device,
    ct_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
    consensus_cfg: dict[str, Any],
    affine_atol: float = 1e-5,
) -> dict[str, Any]:
    for name, path in assets.items():
        if not path.exists():
            raise FileNotFoundError(f"Missing {name}: {path}")

    moving_ct_np, moving_ct_img = load_canonical_ct(
        exp_ct_path,
        clip_min_hu=float(ct_cfg.get("clip_min_hu", -1000.0)),
        clip_max_hu=float(ct_cfg.get("clip_max_hu", 400.0)),
    )
    fixed_ct_np, fixed_ct_img = load_canonical_ct(
        insp_ct_path,
        clip_min_hu=float(ct_cfg.get("clip_min_hu", -1000.0)),
        clip_max_hu=float(ct_cfg.get("clip_max_hu", 400.0)),
    )
    assert_same_canonical_grid(moving_ct_img, fixed_ct_img, name="EXP/INSP CT", affine_atol=affine_atol)

    moving_labels, _ = load_canonical_label(assets["exp_lobes"], exp_ct_path, affine_atol=affine_atol)
    fixed_labels, _ = load_canonical_label(assets["insp_lobes"], insp_ct_path, affine_atol=affine_atol)
    moving_support_np, _ = load_canonical_support(assets["exp_support"], exp_ct_path, affine_atol=affine_atol)
    fixed_support_np, _ = load_canonical_support(assets["insp_support"], insp_ct_path, affine_atol=affine_atol)
    c4_np, c4_img = load_canonical_dvf(assets["initializer_canonical"], insp_ct_path, affine_atol=affine_atol)
    c2_np, _ = load_canonical_dvf(assets["secondary_canonical"], insp_ct_path, affine_atol=affine_atol)

    spacing = _voxel_spacing_mm(fixed_ct_img)
    sdf_band = float(anatomy_cfg.get("sdf_band_mm", 12.0))
    iface_band = float(anatomy_cfg.get("interface_band_mm", 10.0))
    dilation = int(anatomy_cfg.get("interface_dilation_iterations", 1))

    moving_sdf_np = signed_distance_channels(moving_labels, spacing_mm=spacing, band_mm=sdf_band)
    fixed_sdf_np = signed_distance_channels(fixed_labels, spacing_mm=spacing, band_mm=sdf_band)
    moving_surfaces_np = explicit_interface_surfaces(moving_labels, dilation_iterations=dilation)
    fixed_surfaces_np = explicit_interface_surfaces(fixed_labels, dilation_iterations=dilation)
    moving_iface_dist_np = interface_distance_channels(moving_surfaces_np, spacing_mm=spacing, band_mm=iface_band)
    fixed_iface_dist_np = interface_distance_channels(fixed_surfaces_np, spacing_mm=spacing, band_mm=iface_band)

    tensors: dict[str, Any] = {
        "moving_ct": volume_to_tensor(moving_ct_np, device=device),
        "fixed_ct": volume_to_tensor(fixed_ct_np, device=device),
        "moving_lobes": labels_to_one_hot(moving_labels, device=device),
        "fixed_direct_lobes": labels_to_one_hot(fixed_labels, device=device),
        "moving_support": support_to_tensor(moving_support_np, device=device),
        "fixed_support": support_to_tensor(fixed_support_np, device=device),
        "moving_sdf": channels_to_tensor(moving_sdf_np, device=device),
        "fixed_sdf": channels_to_tensor(fixed_sdf_np, device=device),
        "moving_interface_surface": channels_to_tensor(moving_surfaces_np, device=device),
        "fixed_interface_surface": channels_to_tensor(fixed_surfaces_np, device=device),
        "moving_interface_dist": channels_to_tensor(moving_iface_dist_np, device=device),
        "fixed_interface_dist": channels_to_tensor(fixed_iface_dist_np, device=device),
        "init_dvf": dvf_xyzc_to_tensor(c4_np, device=device),
        "secondary_dvf": dvf_xyzc_to_tensor(c2_np, device=device),
        "canonical_reference": c4_img,
        "full_shape": tuple(int(v) for v in c4_np.shape[:3]),
        "spacing_mm": spacing,
    }
    tensors.update(build_paired_consensus(
        fixed_direct_lobes=tensors["fixed_direct_lobes"],
        moving_lobes=tensors["moving_lobes"],
        moving_sdf=tensors["moving_sdf"],
        fixed_sdf=tensors["fixed_sdf"],
        moving_interface_surface=tensors["moving_interface_surface"],
        fixed_interface_surface=tensors["fixed_interface_surface"],
        moving_interface_dist=tensors["moving_interface_dist"],
        fixed_interface_dist=tensors["fixed_interface_dist"],
        c4_dvf=tensors["init_dvf"],
        c2_dvf=tensors["secondary_dvf"],
        cfg=consensus_cfg,
    ))
    return tensors


def make_lowres_state(full: dict[str, Any], *, reduce_factor: int) -> dict[str, torch.Tensor]:
    factor = int(reduce_factor)
    if factor < 1:
        raise ValueError("reduce_factor must be >= 1")

    def rs(x: torch.Tensor, mode: str) -> torch.Tensor:
        return x if factor == 1 else resize_volume_5d(x, factor, mode=mode)

    state = {
        "moving_ct": rs(full["moving_ct"], "trilinear"),
        "fixed_ct": rs(full["fixed_ct"], "trilinear"),
        "moving_lobes": rs(full["moving_lobes"], "nearest"),
        "fixed_direct_lobes": rs(full["fixed_direct_lobes"], "nearest"),
        "consensus_lobes": rs(full["consensus_lobes"], "trilinear"),
        "confidence_lobes": rs(full["confidence_lobes"], "trilinear"),
        "moving_support": rs(full["moving_support"], "nearest"),
        "fixed_support": rs(full["fixed_support"], "nearest"),
        "moving_sdf": rs(full["moving_sdf"], "trilinear"),
        "consensus_sdf": rs(full["consensus_sdf"], "trilinear"),
        "moving_interface_surface": rs(full["moving_interface_surface"], "trilinear"),
        "moving_interface_dist": rs(full["moving_interface_dist"], "trilinear"),
        "consensus_interface_surface": rs(full["consensus_interface_surface"], "trilinear"),
        "consensus_interface_dist": rs(full["consensus_interface_dist"], "trilinear"),
        "confidence_interfaces": rs(full["confidence_interfaces"], "trilinear"),
        "right_confidence": rs(full["right_confidence"], "trilinear"),
        "right_distance": rs(full["right_distance"], "trilinear"),
        "init_dvf": full["init_dvf"] if factor == 1 else downsample_dvf_5d(full["init_dvf"], factor),
    }
    return state


def class_balance_weights(target_lobes: torch.Tensor, cfg: dict[str, Any], eps: float = 1e-6) -> torch.Tensor:
    if target_lobes.ndim != 5 or target_lobes.shape[1] != len(LOBE_LABELS):
        raise ValueError(f"Expected [B,5,X,Y,Z], got {tuple(target_lobes.shape)}")
    volumes = target_lobes.sum(dim=(0, 2, 3, 4)).clamp_min(eps)
    mean_volume = volumes.mean()
    power = float(cfg.get("size_weight_power", 0.5))
    weights = (mean_volume / volumes).pow(power)
    weights = weights.clamp(
        min=float(cfg.get("size_weight_min", 0.75)),
        max=float(cfg.get("size_weight_max", 2.5)),
    )
    return weights / weights.mean().clamp_min(eps)


def balanced_consensus_lobe_dice(
    pred: torch.Tensor,
    target: torch.Tensor,
    cfg: dict[str, Any],
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    per_lobe = soft_dice_per_lobe(pred, target)
    weights = class_balance_weights(target, cfg)
    score = (weights * per_lobe).sum() / weights.sum().clamp_min(1e-6)
    return score, per_lobe, weights


def confidence_weighted_sdf_loss(
    warped_moving_sdf: torch.Tensor,
    target_sdf: torch.Tensor,
    confidence_lobes: torch.Tensor,
    target_lobes: torch.Tensor,
    cfg: dict[str, Any],
    *,
    charbonnier_eps: float,
) -> torch.Tensor:
    if warped_moving_sdf.shape != target_sdf.shape:
        raise ValueError("SDF shape mismatch")
    threshold = float(cfg.get("sdf_band_fraction", 0.85))
    if not 0.0 < threshold <= 1.0:
        raise ValueError("sdf_band_fraction must be in (0,1]")
    band = ((target_sdf.abs() <= threshold) | (warped_moving_sdf.abs() <= threshold)).float()
    robust = torch.sqrt((warped_moving_sdf - target_sdf).square() + float(charbonnier_eps) ** 2)
    class_weights = class_balance_weights(target_lobes, cfg).view(1, -1, 1, 1, 1)
    weight = band * confidence_lobes.clamp(0.0, 1.0) * class_weights
    return (robust * weight).sum() / weight.sum().clamp_min(1.0)


def _surface_distance_channel_loss(
    *,
    warped_moving_dist: torch.Tensor,
    target_dist: torch.Tensor,
    warped_moving_surface: torch.Tensor,
    target_surface: torch.Tensor,
    confidence: torch.Tensor,
    channel: int,
    eps: float = 1e-6,
) -> torch.Tensor:
    wd = warped_moving_dist[:, channel:channel + 1]
    td = target_dist[:, channel:channel + 1]
    ws = warped_moving_surface[:, channel:channel + 1]
    ts = target_surface[:, channel:channel + 1]
    cf = confidence[:, channel:channel + 1].clamp(0.0, 1.0)
    a_weight = ts * cf
    b_weight = ws * cf
    a = (a_weight * wd).sum() / a_weight.sum().clamp_min(eps)
    b = (b_weight * td).sum() / b_weight.sum().clamp_min(eps)
    return 0.5 * (a + b)


def right_localization_mask(state: dict[str, torch.Tensor], stage_cfg: dict[str, Any]) -> torch.Tensor:
    sigma = max(float(stage_cfg.get("localization_sigma", 0.35)), 1e-6)
    floor = float(stage_cfg.get("localization_floor", 0.02))
    mask = torch.exp(-state["right_distance"].clamp_min(0.0) / sigma)
    # High-confidence regions use the anatomical band directly; uncertain regions
    # remain reachable through a small floor so CT structure can correct them.
    mask = mask * (0.35 + 0.65 * state["right_confidence"].clamp(0.0, 1.0))
    return mask.clamp(min=floor, max=1.0)


def structural_uncertainty_mask(state: dict[str, torch.Tensor], stage_cfg: dict[str, Any]) -> torch.Tensor:
    floor = float(stage_cfg.get("structural_uncertainty_floor", 0.15))
    gain = float(stage_cfg.get("structural_uncertainty_gain", 0.85))
    local = torch.exp(-state["right_distance"].clamp_min(0.0) / max(float(stage_cfg.get("localization_sigma", 0.35)), 1e-6))
    uncertainty = 1.0 - state["right_confidence"].clamp(0.0, 1.0)
    return (state["fixed_support"].clamp(0.0, 1.0) * local * (floor + gain * uncertainty)).clamp(0.0, 1.0)


def build_localized_residual_dvf(
    param: torch.Tensor,
    *,
    target_shape: Sequence[int],
    full_shape: Sequence[int],
    stage_cfg: dict[str, Any],
    localization_mask: torch.Tensor,
    scale: float = 1.0,
) -> torch.Tensor:
    svf = build_residual_svf(
        param,
        None,
        target_shape=target_shape,
        full_shape=full_shape,
        max_fullres_voxels=float(stage_cfg.get("max_residual_fullres_voxels", 0.7)),
        scale=float(scale),
    )
    if tuple(localization_mask.shape[-3:]) != tuple(int(v) for v in target_shape):
        localization_mask = F.interpolate(localization_mask, size=tuple(int(v) for v in target_shape), mode="trilinear", align_corners=True)
    svf = svf * localization_mask.clamp(0.0, 1.0)
    return integrate_svf(svf, int(stage_cfg.get("integration_steps", 6)))


def make_stage_parameter(
    target_shape: Sequence[int],
    *,
    stage_cfg: dict[str, Any],
    device: torch.device,
    dtype: torch.dtype,
) -> torch.nn.Parameter:
    return make_control_parameter(
        target_shape,
        int(stage_cfg.get("control_factor", 3)),
        device=device,
        dtype=dtype,
    )


def compute_proxy_metrics(
    *,
    state: dict[str, torch.Tensor],
    dvf: torch.Tensor,
    ct_cfg: dict[str, Any],
    consensus_cfg: dict[str, Any],
    stage_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> dict[str, float]:
    warped_ct = warp_volume(state["moving_ct"], dvf, mode="bilinear")
    warped_lobes = warp_volume(state["moving_lobes"], dvf, mode="bilinear")
    warped_support = warp_volume(state["moving_support"], dvf, mode="bilinear")
    warped_sdf = warp_volume(state["moving_sdf"], dvf, mode="bilinear")
    warped_iface_dist = warp_volume(state["moving_interface_dist"], dvf, mode="bilinear")
    warped_iface_surface = warp_volume(state["moving_interface_surface"], dvf, mode="bilinear")

    direct_dice = soft_dice_per_lobe(warped_lobes, state["fixed_direct_lobes"]).mean()
    consensus_dice, _, _ = balanced_consensus_lobe_dice(warped_lobes, state["consensus_lobes"], consensus_cfg)
    support = binary_soft_dice(warped_support, state["fixed_support"])
    lncc = masked_local_ncc_loss(
        state["fixed_ct"], warped_ct, state["fixed_support"],
        window=int(ct_cfg.get("lncc_window", 9)),
        min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
    )
    structural = structural_gradient_loss(
        state["fixed_ct"], warped_ct, structural_uncertainty_mask(state, stage_cfg),
        min_magnitude=float(ct_cfg.get("gradient_min_magnitude", 0.03)),
    )
    sdf = confidence_weighted_sdf_loss(
        warped_sdf,
        state["consensus_sdf"],
        state["confidence_lobes"],
        state["consensus_lobes"],
        consensus_cfg,
        charbonnier_eps=float(anatomy_cfg.get("charbonnier_eps", 1e-3)),
    )
    rh = _surface_distance_channel_loss(
        warped_moving_dist=warped_iface_dist,
        target_dist=state["consensus_interface_dist"],
        warped_moving_surface=warped_iface_surface,
        target_surface=state["consensus_interface_surface"],
        confidence=state["confidence_interfaces"],
        channel=1,
    )
    ro = _surface_distance_channel_loss(
        warped_moving_dist=warped_iface_dist,
        target_dist=state["consensus_interface_dist"],
        warped_moving_surface=warped_iface_surface,
        target_surface=state["consensus_interface_surface"],
        confidence=state["confidence_interfaces"],
        channel=2,
    )
    return {
        "direct_proxy_lobe_dice": float(direct_dice.item()),
        "consensus_balanced_lobe_dice": float(consensus_dice.item()),
        "proxy_support_dice": float(support.item()),
        "lncc_loss": float(lncc.item()),
        "structural_uncertain_loss": float(structural.item()),
        "confidence_sdf_loss": float(sdf.item()),
        "right_horizontal_loss": float(rh.item()),
        "right_oblique_loss": float(ro.item()),
    }


def objective_terms(
    *,
    state: dict[str, torch.Tensor],
    residual_dvf: torch.Tensor,
    weights: dict[str, Any],
    ct_cfg: dict[str, Any],
    consensus_cfg: dict[str, Any],
    stage_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    final_dvf = compose_pull(state["init_dvf"], residual_dvf)
    warped_ct = warp_volume(state["moving_ct"], final_dvf, mode="bilinear")
    warped_lobes = warp_volume(state["moving_lobes"], final_dvf, mode="bilinear")
    warped_support = warp_volume(state["moving_support"], final_dvf, mode="bilinear")
    warped_sdf = warp_volume(state["moving_sdf"], final_dvf, mode="bilinear")
    warped_iface_dist = warp_volume(state["moving_interface_dist"], final_dvf, mode="bilinear")
    warped_iface_surface = warp_volume(state["moving_interface_surface"], final_dvf, mode="bilinear")

    direct_dice = soft_dice_per_lobe(warped_lobes, state["fixed_direct_lobes"]).mean()
    consensus_dice, per_lobe, class_weights = balanced_consensus_lobe_dice(
        warped_lobes, state["consensus_lobes"], consensus_cfg
    )
    support_dice = binary_soft_dice(warped_support, state["fixed_support"])
    lncc = masked_local_ncc_loss(
        state["fixed_ct"], warped_ct, state["fixed_support"],
        window=int(ct_cfg.get("lncc_window", 9)),
        min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
    )
    structural = structural_gradient_loss(
        state["fixed_ct"], warped_ct, structural_uncertainty_mask(state, stage_cfg),
        min_magnitude=float(ct_cfg.get("gradient_min_magnitude", 0.03)),
    )
    sdf = confidence_weighted_sdf_loss(
        warped_sdf,
        state["consensus_sdf"],
        state["confidence_lobes"],
        state["consensus_lobes"],
        consensus_cfg,
        charbonnier_eps=float(anatomy_cfg.get("charbonnier_eps", 1e-3)),
    )
    rh = _surface_distance_channel_loss(
        warped_moving_dist=warped_iface_dist,
        target_dist=state["consensus_interface_dist"],
        warped_moving_surface=warped_iface_surface,
        target_surface=state["consensus_interface_surface"],
        confidence=state["confidence_interfaces"],
        channel=1,
    )
    ro = _surface_distance_channel_loss(
        warped_moving_dist=warped_iface_dist,
        target_dist=state["consensus_interface_dist"],
        warped_moving_surface=warped_iface_surface,
        target_surface=state["consensus_interface_surface"],
        confidence=state["confidence_interfaces"],
        channel=2,
    )
    bend = bending_energy(residual_dvf)
    magnitude = residual_dvf.square().mean()
    jac, folding_pct, min_det = jacobian_barrier(
        final_dvf,
        margin=float(weights.get("jacobian_margin", 0.025)),
    )

    total = (
        float(weights.get("image_lncc", 0.0)) * lncc
        + float(weights.get("structural_uncertain", 0.0)) * structural
        + float(weights.get("balanced_consensus_lobe", 0.0)) * (1.0 - consensus_dice)
        + float(weights.get("confidence_sdf", 0.0)) * sdf
        + float(weights.get("right_horizontal", 0.0)) * rh
        + float(weights.get("right_oblique", 0.0)) * ro
        + float(weights.get("support", 0.0)) * (1.0 - support_dice)
        + float(weights.get("bending", 0.0)) * bend
        + float(weights.get("residual_magnitude", 0.0)) * magnitude
        + float(weights.get("jacobian", 0.0)) * jac
    )
    terms: dict[str, torch.Tensor] = {
        "total": total,
        "direct_proxy_lobe_dice": direct_dice,
        "consensus_balanced_lobe_dice": consensus_dice,
        "proxy_support_dice": support_dice,
        "lncc_loss": lncc,
        "structural_uncertain_loss": structural,
        "confidence_sdf_loss": sdf,
        "right_horizontal_loss": rh,
        "right_oblique_loss": ro,
        "bending": bend,
        "residual_magnitude": magnitude,
        "jacobian_loss": jac,
        "folding_pct": folding_pct,
        "min_det": min_det,
    }
    for idx, label in enumerate(LOBE_LABELS):
        terms[f"consensus_dice_label_{int(label)}"] = per_lobe[idx]
        terms[f"class_weight_label_{int(label)}"] = class_weights[idx]
    return total, terms


def tensor_terms_to_float(terms: dict[str, torch.Tensor]) -> dict[str, float]:
    return {key: float(value.detach().float().item()) for key, value in terms.items()}


def candidate_score(candidate: dict[str, float], baseline: dict[str, float], selection: dict[str, Any]) -> float:
    return (
        float(selection.get("score_consensus_lobe_gain", 1.0))
        * (candidate["consensus_balanced_lobe_dice"] - baseline["consensus_balanced_lobe_dice"])
        + float(selection.get("score_direct_lobe_gain", 0.35))
        * (candidate["direct_proxy_lobe_dice"] - baseline["direct_proxy_lobe_dice"])
        + float(selection.get("score_lncc_gain", 0.25))
        * (baseline["lncc_loss"] - candidate["lncc_loss"])
        + float(selection.get("score_support_gain", 0.03))
        * (candidate["proxy_support_dice"] - baseline["proxy_support_dice"])
        + float(selection.get("score_sdf_gain", 0.55))
        * (baseline["confidence_sdf_loss"] - candidate["confidence_sdf_loss"])
        + float(selection.get("score_right_horizontal_gain", 0.80))
        * (baseline["right_horizontal_loss"] - candidate["right_horizontal_loss"])
        + float(selection.get("score_right_oblique_gain", 0.70))
        * (baseline["right_oblique_loss"] - candidate["right_oblique_loss"])
        + float(selection.get("score_structural_gain", 0.25))
        * (baseline["structural_uncertain_loss"] - candidate["structural_uncertain_loss"])
    )


def topology_folding_limit(*, baseline_folding_pct: float, selection: dict[str, Any]) -> float:
    mode = str(selection.get("topology_guard_mode", "relative_to_initializer")).strip().lower()
    max_absolute = float(selection.get("max_absolute_folding_pct", 1e-3))
    max_increase = float(selection.get("max_folding_increase_pct", 5e-5))
    if max_absolute < 0.0 or max_increase < 0.0:
        raise ValueError("Folding guard limits must be non-negative")
    if mode in {"relative_to_initializer", "relative_to_stage_input"}:
        return min(max_absolute, float(baseline_folding_pct) + max_increase)
    if mode == "absolute":
        return max_absolute
    raise ValueError(f"Unsupported topology_guard_mode={mode!r}")


def passes_acceptance(
    candidate: dict[str, float],
    baseline: dict[str, float],
    *,
    baseline_folding_pct: float,
    selection: dict[str, Any],
) -> tuple[bool, list[str], float, float]:
    reasons: list[str] = []
    score = candidate_score(candidate, baseline, selection)
    direct_drop = baseline["direct_proxy_lobe_dice"] - candidate["direct_proxy_lobe_dice"]
    lncc_increase = candidate["lncc_loss"] - baseline["lncc_loss"]
    support_drop = baseline["proxy_support_dice"] - candidate["proxy_support_dice"]
    fold_limit = topology_folding_limit(baseline_folding_pct=baseline_folding_pct, selection=selection)

    if score < float(selection.get("min_composite_score_gain", 1e-4)):
        reasons.append(f"composite_score_gain={score:.6g} below minimum")
    if direct_drop > float(selection.get("max_direct_proxy_lobe_drop", 5e-4)):
        reasons.append(f"direct_proxy_lobe_drop={direct_drop:.6g} above maximum")
    if lncc_increase > float(selection.get("max_lncc_loss_increase", 7.5e-4)):
        reasons.append(f"lncc_loss_increase={lncc_increase:.6g} above maximum")
    if support_drop > float(selection.get("max_support_dice_drop", 0.0015)):
        reasons.append(f"support_dice_drop={support_drop:.6g} above maximum")
    if candidate["folding_pct"] > fold_limit + 1e-12:
        reasons.append(f"folding_pct={candidate['folding_pct']:.6g} above limit={fold_limit:.6g}")
    return len(reasons) == 0, reasons, float(fold_limit), float(score)


def clone_parameter_state(params: Sequence[torch.Tensor]) -> list[torch.Tensor]:
    return [p.detach().clone() for p in params]


def restore_parameter_state(params: Sequence[torch.Tensor], state: Sequence[torch.Tensor]) -> None:
    if len(params) != len(state):
        raise ValueError("Parameter state length mismatch")
    with torch.no_grad():
        for param, value in zip(params, state):
            param.copy_(value)
