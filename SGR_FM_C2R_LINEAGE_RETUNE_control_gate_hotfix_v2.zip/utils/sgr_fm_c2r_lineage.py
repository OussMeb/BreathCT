#!/usr/bin/env python3
"""Utilities for C2R-LRT: isolated C2-LONG lineage retuning.

This module never loads validation GT during optimization. GT metrics are read
only after a variant has completed evaluation and are labeled diagnostic.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from utils.sgr_fm_training_assets import load_yaml_or_json, recursive_update, resolve_under_project
from utils.sgr_fm_tto import sha256_json


PROTECTED_OUTPUT_SUFFIXES = (
    "outputs/sgr_fm/c2_long_tto",
    "outputs/sgr_fm/c4_hast",
    "outputs/sgr_fm/c4_1_hast_pcf",
    "outputs/sgr_fm/c5b_lmind_residual",
)


def load_sweep_config(path: str | Path) -> dict[str, Any]:
    cfg = load_yaml_or_json(path, root_key="c2r_lineage_retune")
    if "base_c2_tto" not in cfg or "variants" not in cfg:
        raise ValueError("C2R config requires base_c2_tto and variants")
    if not isinstance(cfg["base_c2_tto"], dict) or not isinstance(cfg["variants"], dict):
        raise ValueError("base_c2_tto and variants must be mappings")
    return cfg


def deep_merged(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(base)
    recursive_update(out, copy.deepcopy(patch))
    return out


def c2_method_fingerprint(config: dict[str, Any], *, c1_fingerprint: str | None = None) -> str:
    fp = c1_fingerprint if c1_fingerprint is not None else str(config.get("accepted_c1_fingerprint", ""))
    return sha256_json({
        "optimization": config["optimization"],
        "ct": config["ct"],
        "loss": config["loss"],
        "selection": config["selection"],
        "c1_fingerprint": fp,
    })


def resolve_variants(
    sweep_cfg: dict[str, Any],
    *,
    project_root: Path,
    selected_names: Iterable[str] | None = None,
    device_override: str | None = None,
    case_ids_override: list[str] | None = None,
) -> list[dict[str, Any]]:
    variants = sweep_cfg["variants"]
    selected = set(str(v) for v in selected_names) if selected_names is not None else None
    unknown = sorted(selected - set(variants)) if selected is not None else []
    if unknown:
        raise KeyError(f"Unknown C2R variants: {unknown}")

    output_root = resolve_under_project(project_root, sweep_cfg["output_root"])
    base = copy.deepcopy(sweep_cfg["base_c2_tto"])
    resolved: list[dict[str, Any]] = []
    seen_outputs: set[Path] = set()

    for name, meta in variants.items():
        if selected is not None and name not in selected:
            continue
        if not bool(meta.get("enabled", True)):
            continue
        patch = meta.get("patch", {}) or {}
        if not isinstance(patch, dict):
            raise ValueError(f"Variant {name}: patch must be a mapping")
        cfg = deep_merged(base, patch)
        subdir = str(meta.get("output_subdir", name)).strip()
        if not subdir or Path(subdir).is_absolute() or ".." in Path(subdir).parts:
            raise ValueError(f"Variant {name}: unsafe output_subdir={subdir!r}")
        out_dir = (output_root / subdir).resolve()
        try:
            out_dir.relative_to(output_root.resolve())
        except ValueError as exc:
            raise ValueError(f"Variant {name}: output escapes output_root: {out_dir}") from exc
        if out_dir in seen_outputs:
            raise ValueError(f"Duplicate output directory: {out_dir}")
        seen_outputs.add(out_dir)

        cfg["output_dir"] = str(out_dir)
        cfg["overwrite"] = False
        if device_override is not None:
            cfg["device"] = str(device_override)
            cfg.setdefault("evaluation", {})["device"] = str(device_override)
        if case_ids_override is not None:
            cfg["case_ids"] = list(case_ids_override)

        resolved.append({
            "name": str(name),
            "description": str(meta.get("description", "")),
            "output_dir": str(out_dir),
            "config": cfg,
            "method_fingerprint_sha256": c2_method_fingerprint(cfg),
        })
    if not resolved:
        raise RuntimeError("No enabled C2R variants selected")
    return resolved


def assert_output_isolation(project_root: Path, sweep_cfg: dict[str, Any], variants: list[dict[str, Any]]) -> None:
    output_root = resolve_under_project(project_root, sweep_cfg["output_root"])
    protected = {resolve_under_project(project_root, p) for p in PROTECTED_OUTPUT_SUFFIXES}
    for item in variants:
        out = Path(item["output_dir"]).resolve()
        if out in protected:
            raise RuntimeError(f"Variant output collides with protected champion: {out}")
        try:
            out.relative_to(output_root.resolve())
        except ValueError as exc:
            raise RuntimeError(f"Variant output is outside isolated C2R root: {out}") from exc


def write_child_config(path: Path, config: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"sgr_fm_tto": config}
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_metrics(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    required = ("mean_lobe_dice", "mean_folding_percentage", "case_metrics")
    missing = [k for k in required if k not in data]
    if missing:
        raise ValueError(f"Metrics missing keys {missing}: {path}")
    return data


def compare_metrics(reference: dict[str, Any], candidate: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    a_rows = {str(r["case_id"]): r for r in reference.get("case_metrics", [])}
    b_rows = {str(r["case_id"]): r for r in candidate.get("case_metrics", [])}
    common = sorted(set(a_rows) & set(b_rows))
    rows: list[dict[str, Any]] = []
    for case_id in common:
        a = a_rows[case_id]
        b = b_rows[case_id]
        rows.append({
            "case_id": case_id,
            "reference_mean_lobe_dice": float(a["mean_lobe_dice"]),
            "candidate_mean_lobe_dice": float(b["mean_lobe_dice"]),
            "delta_dice": float(b["mean_lobe_dice"] - a["mean_lobe_dice"]),
            "reference_folding_percentage": float(a["folding_percentage"]),
            "candidate_folding_percentage": float(b["folding_percentage"]),
            "delta_folding_percentage": float(b["folding_percentage"] - a["folding_percentage"]),
        })
    deltas = np.asarray([r["delta_dice"] for r in rows], dtype=np.float64)
    summary = {
        "common_case_count": len(rows),
        "reference_mean_lobe_dice": float(reference["mean_lobe_dice"]),
        "candidate_mean_lobe_dice": float(candidate["mean_lobe_dice"]),
        "delta_mean_lobe_dice": float(candidate["mean_lobe_dice"] - reference["mean_lobe_dice"]),
        "reference_mean_folding_percentage": float(reference["mean_folding_percentage"]),
        "candidate_mean_folding_percentage": float(candidate["mean_folding_percentage"]),
        "delta_mean_folding_percentage": float(candidate["mean_folding_percentage"] - reference["mean_folding_percentage"]),
        "improved_cases": int(np.sum(deltas > 0.0)) if len(deltas) else 0,
        "unchanged_cases": int(np.sum(np.isclose(deltas, 0.0, atol=1e-12))) if len(deltas) else 0,
        "worsened_cases": int(np.sum(deltas < 0.0)) if len(deltas) else 0,
        "min_paired_dice_delta": float(deltas.min()) if len(deltas) else None,
        "max_paired_dice_delta": float(deltas.max()) if len(deltas) else None,
    }
    return summary, rows


def baseline_reproduction_check(
    reference: dict[str, Any],
    reproduced: dict[str, Any],
    tolerance: dict[str, Any],
) -> dict[str, Any]:
    comparison, rows = compare_metrics(reference, reproduced)
    mean_tol = float(tolerance.get("mean_lobe_dice_abs", 5e-6))
    case_tol = float(tolerance.get("per_case_lobe_dice_abs", 1e-5))
    fold_tol = float(tolerance.get("mean_folding_percentage_abs", 5e-6))
    max_case_abs = max((abs(float(r["delta_dice"])) for r in rows), default=float("inf"))
    checks = {
        "mean_lobe_dice": abs(float(comparison["delta_mean_lobe_dice"])) <= mean_tol,
        "per_case_lobe_dice": max_case_abs <= case_tol,
        "mean_folding_percentage": abs(float(comparison["delta_mean_folding_percentage"])) <= fold_tol,
        "case_count": int(comparison["common_case_count"]) == len(reference.get("case_metrics", [])),
    }
    return {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "tolerance": {
            "mean_lobe_dice_abs": mean_tol,
            "per_case_lobe_dice_abs": case_tol,
            "mean_folding_percentage_abs": fold_tol,
        },
        "max_per_case_lobe_dice_abs": float(max_case_abs),
        "comparison": comparison,
    }


def baseline_control_admissibility_check(
    reference: dict[str, Any],
    control: dict[str, Any],
    *,
    exact_reproduction: dict[str, Any],
    reference_fingerprint_ok: bool,
    max_mean_folding_increase_pct: float,
) -> dict[str, Any]:
    """Admit a same-config B0 rerun as the in-environment sweep control.

    Exact metric equality to a historical C2-LONG run is retained as a
    diagnostic, not as the sweep gate. The sweep gate requires the same frozen
    method fingerprint, the same evaluated case inventory, finite metrics, and
    no unsafe aggregate topology drift beyond the already-declared C2 folding
    increase tolerance.

    All tuning variants are compared against this B0 control generated in the
    same current software/hardware environment.
    """
    comparison, _ = compare_metrics(reference, control)
    finite_checks = {
        "control_mean_lobe_dice_finite": bool(np.isfinite(float(control["mean_lobe_dice"]))),
        "control_mean_folding_finite": bool(np.isfinite(float(control["mean_folding_percentage"]))),
    }
    ref_case_count = len(reference.get("case_metrics", []))
    control_case_count = len(control.get("case_metrics", []))
    case_count_ok = (
        int(comparison["common_case_count"]) == ref_case_count
        and control_case_count == ref_case_count
    )
    fold_delta = float(comparison["delta_mean_folding_percentage"])
    fold_limit = float(max_mean_folding_increase_pct)
    checks = {
        "reference_fingerprint_ok": bool(reference_fingerprint_ok),
        "case_inventory_match": bool(case_count_ok),
        **finite_checks,
        "mean_folding_drift_within_control_limit": bool(fold_delta <= fold_limit + 1e-12),
    }
    exact_status = str(exact_reproduction.get("status", "UNKNOWN"))
    return {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "gate_semantics": "same_config_current_environment_control",
        "checks": checks,
        "max_mean_folding_increase_pct": fold_limit,
        "comparison_to_frozen_reference": comparison,
        "exact_reproduction_status": exact_status,
        "exact_reproduction": exact_reproduction,
        "note": (
            "Exact equality to the historical frozen C2-LONG metrics is diagnostic only. "
            "Variants must be compared against this B0 control from the same current environment."
        ),
    }


def collect_proxy_stats(output_dir: Path) -> dict[str, Any]:
    manifest_dir = output_dir / "case_manifests"
    rows: list[dict[str, float]] = []
    decisions: dict[str, int] = {}
    if not manifest_dir.exists():
        return {"case_count": 0}
    for path in sorted(manifest_dir.glob("NLST_*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        baseline = data.get("baseline_proxy")
        selected = data.get("selected")
        decision = str(data.get("decision", ""))
        if decision:
            decisions[decision] = decisions.get(decision, 0) + 1
        if not isinstance(baseline, dict) or not isinstance(selected, dict):
            continue
        rows.append({
            "selected_score": float(selected.get("score", 0.0)),
            "proxy_lobe_gain": float(selected.get("proxy_lobe_dice", baseline.get("proxy_lobe_dice", 0.0))) - float(baseline.get("proxy_lobe_dice", 0.0)),
            "proxy_interface_gain": float(selected.get("proxy_interface_dice", baseline.get("proxy_interface_dice", 0.0))) - float(baseline.get("proxy_interface_dice", 0.0)),
            "lncc_gain": float(baseline.get("lncc_loss", 0.0)) - float(selected.get("lncc_loss", baseline.get("lncc_loss", 0.0))),
            "support_gain": float(selected.get("proxy_support_dice", baseline.get("proxy_support_dice", 0.0))) - float(baseline.get("proxy_support_dice", 0.0)),
        })
    if not rows:
        return {"case_count": 0, "decision_counts": decisions}
    return {
        "case_count": len(rows),
        "decision_counts": decisions,
        "mean_selected_score": float(np.mean([r["selected_score"] for r in rows])),
        "mean_proxy_lobe_gain": float(np.mean([r["proxy_lobe_gain"] for r in rows])),
        "mean_proxy_interface_gain": float(np.mean([r["proxy_interface_gain"] for r in rows])),
        "mean_lncc_gain": float(np.mean([r["lncc_gain"] for r in rows])),
        "mean_support_gain": float(np.mean([r["support_gain"] for r in rows])),
    }


def build_rankings(rows: list[dict[str, Any]], top_k: int) -> dict[str, Any]:
    eligible = [r for r in rows if r.get("run_status") == "PASS" and r.get("mean_lobe_dice") is not None]
    gt_sorted = sorted(
        eligible,
        key=lambda r: (-float(r["mean_lobe_dice"]), float(r.get("mean_folding_percentage", float("inf")))),
    )
    proxy_sorted = sorted(
        eligible,
        key=lambda r: (
            -float(r.get("mean_selected_score") if r.get("mean_selected_score") is not None else -1e9),
            -float(r.get("mean_proxy_lobe_gain") if r.get("mean_proxy_lobe_gain") is not None else -1e9),
        ),
    )
    gt_rank = {r["variant"]: i + 1 for i, r in enumerate(gt_sorted)}
    proxy_rank = {r["variant"]: i + 1 for i, r in enumerate(proxy_sorted)}
    rank_sum = sorted(
        eligible,
        key=lambda r: (gt_rank[r["variant"]] + proxy_rank[r["variant"]], gt_rank[r["variant"]]),
    )
    k = max(1, int(top_k))
    return {
        "note": "GT ranking is diagnostic only. No downstream promotion is automatic.",
        "gt_diagnostic_rank": [r["variant"] for r in gt_sorted],
        "proxy_rank": [r["variant"] for r in proxy_sorted],
        "rank_sum_shortlist": [r["variant"] for r in rank_sum[:k]],
        "rank_details": {
            r["variant"]: {
                "gt_rank": gt_rank[r["variant"]],
                "proxy_rank": proxy_rank[r["variant"]],
                "rank_sum": gt_rank[r["variant"]] + proxy_rank[r["variant"]],
            }
            for r in eligible
        },
    }
