#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from utils.sgr_fm_c8c_geometry_corrected import load_config, fit_geometry_calibration


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    ap.add_argument('--output-json', default='outputs/sgr_fm/c8c_geometry_corrected/calibration/c8c_full_validation_calibration.json')
    args = ap.parse_args()
    cfg = load_config(args.config)
    calibration = fit_geometry_calibration(cfg, exclude_case=None)
    out = Path(args.output_json)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(calibration, indent=2))
    print(json.dumps({'status': 'PASS', 'output_json': str(out), 'fit_case_count': calibration['fit_case_count']}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
