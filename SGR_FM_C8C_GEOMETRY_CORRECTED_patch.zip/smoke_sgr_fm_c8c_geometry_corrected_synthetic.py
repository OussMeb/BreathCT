#!/usr/bin/env python3
import tempfile
from pathlib import Path

import nibabel as nib
import numpy as np

from utils.sgr_fm_c8c_geometry_corrected import fit_geometry_calibration, load_config, run_case


def save(path: Path, arr):
    path.parent.mkdir(parents=True, exist_ok=True)
    nib.Nifti1Image(arr.astype(np.float32), np.eye(4)).to_filename(str(path))


def make_case(root: Path, case_id: str, shift: int):
    shape = (20, 18, 16)
    pin = np.zeros(shape, np.int16)
    pex = np.zeros(shape, np.int16)
    gin = np.zeros(shape, np.int16)
    gex = np.zeros(shape, np.int16)

    pin[3:9, 3:9, 3:9] = 8
    pex[2:8, 3:9, 3:9] = 8
    gin[3+shift:9+shift, 3:9, 3:9] = 8
    gex[2+shift:8+shift, 3:9, 3:9] = 8

    pin[11:17, 8:14, 6:12] = 64
    pex[10:16, 8:14, 6:12] = 64
    gin[11+shift:17+shift, 8:14, 6:12] = 64
    gex[10+shift:16+shift, 8:14, 6:12] = 64

    pseudo = root / 'outputs/sgr_fm/segmentation_phase1_totalsegmentator/lobes/validation'
    gt = root / 'Learn2Breath_train_val_data/validation/seg_net'
    save(pseudo / f'{case_id}_INSP_lobes.nii.gz', pin)
    save(pseudo / f'{case_id}_EXP_lobes.nii.gz', pex)
    save(gt / f'{case_id}_INSP_lobe.nii.gz', gin)
    save(gt / f'{case_id}_EXP_lobe.nii.gz', gex)
    save(root / 'outputs/sgr_fm/c8b_pseudolabel_calibrated/dvfs' / f'{case_id}_DVF.nii.gz', np.zeros(shape + (3,), np.float32))


def main():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        for idx in range(1, 7):
            make_case(root, f'NLST_{idx:04d}', 1)

        cfgp = root / 'cfg.yaml'
        cfgp.write_text(f'''
output_root: "{root / 'outputs/sgr_fm/c8c_geometry_corrected'}"
parent_dir: "{root / 'outputs/sgr_fm/c8b_pseudolabel_calibrated'}"
fallback_parent_dir: "{root / 'outputs/sgr_fm/c7b_multi_init_semantic'}"
raw_data_root: "{root / 'Learn2Breath_train_val_data'}"
validation_gt_root: "{root / 'Learn2Breath_train_val_data/validation'}"
pseudo_segmentation_root: "{root / 'outputs/sgr_fm/segmentation_phase1_totalsegmentator'}"
device: cpu
labels: [8, 16, 32, 64, 128]
calibration_mode: leave_one_case_out
minimum_fit_cases: 5
minimum_corrected_proxy_gain: 0.0
stages:
  - name: smoke
    reduce_factor: 2
    control_factor: 3
    iterations: 3
    lr: 0.03
    max_residual_vox: 0.25
''')
        cfg = load_config(str(cfgp))
        cal = fit_geometry_calibration(cfg, exclude_case='NLST_0001')
        assert 'NLST_0001' not in cal['fit_cases']
        rec = run_case('NLST_0001', cfg)
        assert rec['current_case_excluded_from_calibration'] is True
        assert (Path(cfg['output_root']) / 'dvfs' / 'NLST_0001_DVF.nii.gz').exists()
        print('SGR-FM C8C GEOMETRY-CORRECTED SYNTHETIC SMOKE: PASS')
        print({'mode': rec['mode'], 'folding': rec['final_folding_pct']})


if __name__ == '__main__':
    main()
