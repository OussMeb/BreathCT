#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

try:
    import nibabel as nib
except Exception:
    nib = None

try:
    import torch
    import torch.nn.functional as F
except Exception:
    torch = None
    F = None

try:
    from scipy.ndimage import affine_transform, binary_dilation, distance_transform_edt, map_coordinates
except Exception:
    affine_transform = binary_dilation = distance_transform_edt = map_coordinates = None

DEFAULT_LABELS = [8, 16, 32, 64, 128]


def load_config(path: str) -> Dict:
    p = Path(path)
    text = p.read_text()
    if p.suffix.lower() == ".json":
        cfg = json.loads(text)
    else:
        try:
            import yaml
            cfg = yaml.safe_load(text)
        except Exception as exc:
            raise RuntimeError("PyYAML is required for the C8C YAML config") from exc

    cfg.setdefault("output_root", "outputs/sgr_fm/c8c_geometry_corrected")
    cfg.setdefault("parent_dir", "outputs/sgr_fm/c8b_pseudolabel_calibrated")
    cfg.setdefault("fallback_parent_dir", "outputs/sgr_fm/c7b_multi_init_semantic")
    cfg.setdefault("raw_data_root", "Learn2Breath_train_val_data")
    cfg.setdefault("validation_gt_root", "Learn2Breath_train_val_data/validation")
    cfg.setdefault("pseudo_segmentation_root", "outputs/sgr_fm/segmentation_phase1_totalsegmentator")
    cfg.setdefault("evaluate_script", "evaluate_validation.py")
    cfg.setdefault("labels", DEFAULT_LABELS)
    cfg.setdefault("device", "cuda")
    cfg.setdefault("continue_on_error", False)

    cfg.setdefault("calibration_mode", "leave_one_case_out")
    cfg.setdefault("saved_calibration_json", None)
    cfg.setdefault("translation_shrinkage", 0.40)
    cfg.setdefault("scale_shrinkage", 0.35)
    cfg.setdefault("max_translation_vox", 1.50)
    cfg.setdefault("min_isotropic_scale", 0.97)
    cfg.setdefault("max_isotropic_scale", 1.03)
    cfg.setdefault("score_blend_strength", 0.40)
    cfg.setdefault("max_support_expansion_vox", 2)
    cfg.setdefault("max_lobe_volume_change_fraction", 0.06)
    cfg.setdefault("minimum_fit_cases", 5)

    cfg.setdefault("soft_folding_start_pct", 0.25)
    cfg.setdefault("soft_folding_full_pct", 0.30)
    cfg.setdefault("hard_reject_folding_pct", 0.50)
    cfg.setdefault("candidate_scales", [1.0, 0.75, 0.5, 0.25, 0.125, 0.0])

    cfg.setdefault("minimum_corrected_proxy_gain", 0.00015)
    cfg.setdefault("maximum_original_proxy_loss", 0.00060)
    cfg.setdefault("maximum_original_non_rml_loss", 0.00125)
    cfg.setdefault("minimum_rml_corrected_gain_hard_case", 0.00005)
    cfg.setdefault("hard_case_rml_threshold", 0.955)

    cfg.setdefault("lobe_weights", {"8": 1.00, "16": 1.10, "32": 1.20, "64": 2.20, "128": 1.25})
    cfg.setdefault("loss_weights", {"dice": 1.0, "smooth": 0.055, "magnitude": 0.025})
    cfg.setdefault("stages", [
        {"name": "G1_corrected_global", "reduce_factor": 4, "control_factor": 5, "iterations": 90, "lr": 0.042, "max_residual_vox": 0.95},
        {"name": "G2_corrected_rml_refine", "reduce_factor": 2, "control_factor": 4, "iterations": 120, "lr": 0.024, "max_residual_vox": 0.60},
        {"name": "G3_corrected_micro", "reduce_factor": 2, "control_factor": 3, "iterations": 70, "lr": 0.014, "max_residual_vox": 0.30},
    ])
    return cfg


def discover_cases(cfg: Dict) -> List[str]:
    cases = set()
    for p in (Path(cfg["parent_dir"]) / "dvfs").glob("NLST_*_DVF.nii.gz"):
        cases.add(p.name.split("_DVF")[0])
    if not cases:
        for p in Path(cfg["pseudo_segmentation_root"]).rglob("NLST_*_INSP*lob*.nii*"):
            m = re.search(r"(NLST_\d+)", p.name)
            if m:
                cases.add(m.group(1))
    return sorted(cases)


def _load(path: Path):
    if nib is None:
        raise RuntimeError("nibabel is required")
    img = nib.load(str(path))
    return img, img.get_fdata(dtype=np.float32)


def _save_like(ref_img, data: np.ndarray, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    nib.Nifti1Image(data.astype(np.float32), ref_img.affine, ref_img.header).to_filename(str(path))


def _find_parent(case_id: str, cfg: Dict) -> Path:
    for key in ["parent_dir", "fallback_parent_dir"]:
        p = Path(cfg[key]) / "dvfs" / f"{case_id}_DVF.nii.gz"
        if p.exists():
            return p
    raise FileNotFoundError(f"No parent DVF for {case_id}")


def _find_lobe(root: Path, case_id: str, phase: str, *, gt: bool) -> Optional[Path]:
    if not root.exists():
        return None
    case_l, phase_l = case_id.lower(), phase.lower()
    scored = []
    for p in root.rglob("*.nii*"):
        n = p.name.lower()
        if case_l not in n or phase_l not in n:
            continue
        score = 0
        if "lobe" in n or "lobes" in n:
            score += 30
        if any(x in n for x in ["seg", "label", "mask"]):
            score += 5
        if any(x in n for x in ["fissure", "interface", "support", "body"]):
            score -= 100
        if not gt and "gt" in n:
            score -= 50
        if score > 0:
            scored.append((score, p))
    if not scored:
        return None
    scored.sort(key=lambda x: (x[0], -len(str(x[1]))), reverse=True)
    return scored[0][1]


def _centroid(mask: np.ndarray) -> Optional[np.ndarray]:
    pts = np.argwhere(mask)
    return None if pts.size == 0 else np.mean(pts, axis=0).astype(np.float64)


def _robust_median(values: List[np.ndarray]) -> np.ndarray:
    a = np.stack(values, axis=0)
    med = np.median(a, axis=0)
    mad = np.median(np.abs(a - med), axis=0) + 1e-6
    keep = np.all(np.abs(a - med) <= 3.5 * mad + 0.25, axis=1)
    return np.median(a[keep], axis=0) if np.any(keep) else med


def _robust_scalar(values: List[float]) -> float:
    a = np.asarray(values, dtype=np.float64)
    med = float(np.median(a))
    mad = float(np.median(np.abs(a - med)) + 1e-6)
    keep = np.abs(a - med) <= 3.5 * mad + 1e-3
    return float(np.median(a[keep])) if np.any(keep) else med


def fit_geometry_calibration(cfg: Dict, exclude_case: Optional[str]) -> Dict:
    labels = [int(x) for x in cfg["labels"]]
    pseudo_root = Path(cfg["pseudo_segmentation_root"])
    gt_root = Path(cfg["validation_gt_root"])

    case_ids = sorted({m.group(1) for p in gt_root.rglob("*.nii*") if (m := re.search(r"(NLST_\d+)", p.name))})
    if exclude_case:
        case_ids = [c for c in case_ids if c != exclude_case]

    samples = {phase: {lab: {"shift": [], "scale": [], "pseudo_dice": []} for lab in labels} for phase in ["INSP", "EXP"]}
    used_cases = []

    for case_id in case_ids:
        case_ok = False
        for phase in ["INSP", "EXP"]:
            pp = _find_lobe(pseudo_root, case_id, phase, gt=False)
            gp = _find_lobe(gt_root, case_id, phase, gt=True)
            if pp is None or gp is None:
                continue
            _, pseudo = _load(pp)
            _, gt = _load(gp)
            pseudo, gt = pseudo.astype(np.int16), gt.astype(np.int16)
            if pseudo.shape != gt.shape:
                continue
            case_ok = True
            for lab in labels:
                pm, gm = pseudo == lab, gt == lab
                pc, gc = _centroid(pm), _centroid(gm)
                pv, gv = int(pm.sum()), int(gm.sum())
                if pc is None or gc is None or pv < 10 or gv < 10:
                    continue
                shift = gc - pc
                scale = (gv / max(pv, 1)) ** (1.0 / 3.0)
                den = pv + gv
                dice = float(2.0 * np.logical_and(pm, gm).sum() / den) if den else float("nan")
                samples[phase][lab]["shift"].append(shift)
                samples[phase][lab]["scale"].append(float(scale))
                samples[phase][lab]["pseudo_dice"].append(dice)
        if case_ok:
            used_cases.append(case_id)

    if len(used_cases) < int(cfg["minimum_fit_cases"]):
        raise RuntimeError(f"Only {len(used_cases)} calibration cases found; need {cfg['minimum_fit_cases']}")

    calibration = {
        "schema_version": 1,
        "method": "robust per-phase/per-lobe centroid and isotropic-scale calibration",
        "exclude_case": exclude_case,
        "fit_case_count": len(used_cases),
        "fit_cases": used_cases,
        "parameters": {},
    }

    for phase in ["INSP", "EXP"]:
        calibration["parameters"][phase] = {}
        for lab in labels:
            s = samples[phase][lab]
            if not s["shift"]:
                raw_shift, raw_scale, med_dice, count = np.zeros(3), 1.0, None, 0
            else:
                raw_shift = _robust_median(s["shift"])
                raw_scale = _robust_scalar(s["scale"])
                med_dice = _robust_scalar(s["pseudo_dice"])
                count = len(s["shift"])

            reliability = 1.0 if med_dice is None else float(np.clip((0.992 - med_dice) / 0.045, 0.45, 1.35))
            shift = raw_shift * float(cfg["translation_shrinkage"]) * reliability
            shift = np.clip(shift, -float(cfg["max_translation_vox"]), float(cfg["max_translation_vox"]))
            corrected_scale = math.exp(math.log(max(raw_scale, 1e-6)) * float(cfg["scale_shrinkage"]) * reliability)
            corrected_scale = float(np.clip(corrected_scale, float(cfg["min_isotropic_scale"]), float(cfg["max_isotropic_scale"])))

            calibration["parameters"][phase][str(lab)] = {
                "sample_count": count,
                "median_pseudo_gt_dice": med_dice,
                "raw_median_shift_xyz_vox": raw_shift.tolist(),
                "applied_shift_xyz_vox": shift.tolist(),
                "raw_median_isotropic_scale": raw_scale,
                "applied_isotropic_scale": corrected_scale,
                "reliability_factor": reliability,
            }
    return calibration


def _signed_distance(mask: np.ndarray) -> np.ndarray:
    if distance_transform_edt is None:
        raise RuntimeError("scipy is required")
    return distance_transform_edt(mask).astype(np.float32) - distance_transform_edt(~mask).astype(np.float32)


def _transform_score(score: np.ndarray, center: np.ndarray, shift: np.ndarray, scale: float) -> np.ndarray:
    if affine_transform is None:
        raise RuntimeError("scipy is required")
    inv_scale = 1.0 / max(scale, 1e-6)
    matrix = np.eye(3, dtype=np.float64) * inv_scale
    offset = center - (center + shift) * inv_scale
    return affine_transform(score, matrix=matrix, offset=offset, output_shape=score.shape, order=1, mode="constant", cval=float(np.min(score)), prefilter=False).astype(np.float32)


def correct_pseudo_labels(pseudo: np.ndarray, phase: str, calibration: Dict, cfg: Dict) -> Tuple[np.ndarray, Dict]:
    labels = [int(x) for x in cfg["labels"]]
    support = pseudo > 0
    if not np.any(support):
        return pseudo.copy(), {"status": "empty_support_fallback"}
    if binary_dilation is None:
        raise RuntimeError("scipy is required")

    allowed = binary_dilation(support, iterations=int(cfg["max_support_expansion_vox"]))
    score_stack, audit = [], {}
    blend = float(cfg["score_blend_strength"])

    for lab in labels:
        mask = pseudo == lab
        center = _centroid(mask)
        if center is None:
            score_stack.append(np.full(pseudo.shape, -1e3, dtype=np.float32))
            audit[str(lab)] = {"status": "missing_lobe"}
            continue
        prm = calibration["parameters"][phase][str(lab)]
        shift = np.asarray(prm["applied_shift_xyz_vox"], dtype=np.float64)
        scale = float(prm["applied_isotropic_scale"])
        orig_score = _signed_distance(mask)
        transformed = _transform_score(orig_score, center, shift, scale)
        score_stack.append((1.0 - blend) * orig_score + blend * transformed)
        audit[str(lab)] = {
            "status": "ok",
            "center_xyz": center.tolist(),
            "shift_xyz_vox": shift.tolist(),
            "scale": scale,
            "original_volume": int(mask.sum()),
        }

    scores = np.stack(score_stack, axis=0)
    winner, max_score = np.argmax(scores, axis=0), np.max(scores, axis=0)
    corrected = np.zeros_like(pseudo, dtype=np.int16)
    corrected_support = support | ((max_score > 0.0) & allowed)
    for i, lab in enumerate(labels):
        corrected[(winner == i) & corrected_support] = lab

    max_frac = float(cfg["max_lobe_volume_change_fraction"])
    for lab in labels:
        old, new = int(np.sum(pseudo == lab)), int(np.sum(corrected == lab))
        frac = abs(new - old) / max(old, 1)
        audit[str(lab)]["corrected_volume"] = new
        audit[str(lab)]["volume_change_fraction"] = frac
        if old > 0 and frac > max_frac:
            corrected[corrected == lab] = 0
            corrected[pseudo == lab] = lab
            audit[str(lab)]["volume_safety_rollback"] = True
        else:
            audit[str(lab)]["volume_safety_rollback"] = False

    holes = support & (corrected == 0)
    for i, lab in enumerate(labels):
        corrected[holes & (winner == i)] = lab

    return corrected, {
        "status": "ok",
        "phase": phase,
        "changed_voxel_fraction": float(np.mean(corrected != pseudo)),
        "lobes": audit,
    }


def _dice(a: np.ndarray, b: np.ndarray, labels: List[int]):
    per, vals = {}, []
    for lab in labels:
        aa, bb = a == lab, b == lab
        den = int(aa.sum() + bb.sum())
        val = float("nan") if den == 0 else float(2.0 * np.logical_and(aa, bb).sum() / den)
        if not math.isnan(val):
            vals.append(val)
        per[f"dice_{lab}"] = val
    return float(np.mean(vals)) if vals else float("nan"), per


def _weighted_mean(per: Dict[str, float], weights: Dict[int, float]) -> float:
    num = den = 0.0
    for lab, w in weights.items():
        val = per.get(f"dice_{lab}")
        if val is None or math.isnan(val):
            continue
        num += w * val
        den += w
    return num / max(den, 1e-8)


def _warp_label(moving: np.ndarray, dvf: np.ndarray) -> np.ndarray:
    if map_coordinates is None:
        raise RuntimeError("scipy is required")
    X, Y, Z = moving.shape
    xx, yy, zz = np.meshgrid(np.arange(X), np.arange(Y), np.arange(Z), indexing="ij")
    coords = [xx + dvf[..., 0], yy + dvf[..., 1], zz + dvf[..., 2]]
    return map_coordinates(moving.astype(np.float32), coords, order=0, mode="nearest").round().astype(np.int16)


def _folding_pct(dvf: np.ndarray) -> float:
    ux, uy, uz = dvf[..., 0], dvf[..., 1], dvf[..., 2]
    dux_dx, dux_dy, dux_dz = np.gradient(ux)
    duy_dx, duy_dy, duy_dz = np.gradient(uy)
    duz_dx, duz_dy, duz_dz = np.gradient(uz)
    J00, J01, J02 = 1 + dux_dx, dux_dy, dux_dz
    J10, J11, J12 = duy_dx, 1 + duy_dy, duy_dz
    J20, J21, J22 = duz_dx, duz_dy, 1 + duz_dz
    det = J00 * (J11 * J22 - J12 * J21) - J01 * (J10 * J22 - J12 * J20) + J02 * (J10 * J21 - J11 * J20)
    return float(100.0 * np.mean(det < 0))


def _down_label(arr: np.ndarray, r: int) -> np.ndarray:
    return arr.astype(np.int16) if r <= 1 else arr[::r, ::r, ::r].astype(np.int16)


def _down_dvf(dvf: np.ndarray, r: int) -> np.ndarray:
    return dvf.astype(np.float32) if r <= 1 else (dvf[::r, ::r, ::r, :] / float(r)).astype(np.float32)


def _onehot(label_xyz: np.ndarray, labels: List[int], device: str):
    arr = np.stack([(label_xyz == lab).astype(np.float32).transpose(2, 1, 0) for lab in labels], axis=0)[None]
    return torch.from_numpy(arr).to(device)


def _weight_tensor(labels: List[int], weights: Dict[int, float], device: str):
    arr = np.asarray([weights[lab] for lab in labels], dtype=np.float32)
    arr /= max(float(np.mean(arr)), 1e-6)
    return torch.from_numpy(arr).to(device)


def _dvf_to_torch(dvf_xyz: np.ndarray, device: str):
    arr = np.stack([
        dvf_xyz[..., 0].transpose(2, 1, 0),
        dvf_xyz[..., 1].transpose(2, 1, 0),
        dvf_xyz[..., 2].transpose(2, 1, 0),
    ], axis=0)[None].astype(np.float32)
    return torch.from_numpy(arr).to(device)


def _torch_to_dvf(t) -> np.ndarray:
    a = t.detach().cpu().numpy()[0]
    return np.stack([
        a[0].transpose(2, 1, 0),
        a[1].transpose(2, 1, 0),
        a[2].transpose(2, 1, 0),
    ], axis=-1).astype(np.float32)


def _warp_onehot(moving, dvf):
    _, _, D, H, W = moving.shape
    z = torch.linspace(0, D - 1, D, device=moving.device)
    y = torch.linspace(0, H - 1, H, device=moving.device)
    x = torch.linspace(0, W - 1, W, device=moving.device)
    zz, yy, xx = torch.meshgrid(z, y, x, indexing="ij")
    gx = 2.0 * (xx + dvf[:, 0]) / max(W - 1, 1) - 1.0
    gy = 2.0 * (yy + dvf[:, 1]) / max(H - 1, 1) - 1.0
    gz = 2.0 * (zz + dvf[:, 2]) / max(D - 1, 1) - 1.0
    grid = torch.stack([gx[0], gy[0], gz[0]], dim=-1)[None]
    return F.grid_sample(moving, grid, mode="bilinear", padding_mode="border", align_corners=True)


def _weighted_dice_loss(warped, fixed, weights, eps=1e-5):
    dims = (0, 2, 3, 4)
    inter = torch.sum(warped * fixed, dim=dims)
    den = torch.sum(warped + fixed, dim=dims)
    dice = (2.0 * inter + eps) / (den + eps)
    return torch.sum(weights * (1.0 - dice)) / torch.sum(weights)


def _smoothness(res):
    return (
        torch.mean((res[:, :, 1:] - res[:, :, :-1]) ** 2)
        + torch.mean((res[:, :, :, 1:] - res[:, :, :, :-1]) ** 2)
        + torch.mean((res[:, :, :, :, 1:] - res[:, :, :, :, :-1]) ** 2)
    ) / 3.0


def _control_shape(shape_xyz, factor):
    X, Y, Z = shape_xyz
    return max(2, int(np.ceil(Z / factor))), max(2, int(np.ceil(Y / factor))), max(2, int(np.ceil(X / factor)))


def _optimize_stage(fixed, moving, base_dvf, labels, weights, cfg, stage, device):
    r = int(stage["reduce_factor"])
    fix_r, mov_r, base_r = _down_label(fixed, r), _down_label(moving, r), _down_dvf(base_dvf, r)
    fix_oh, mov_oh = _onehot(fix_r, labels, device), _onehot(mov_r, labels, device)
    base_t, w_t = _dvf_to_torch(base_r, device), _weight_tensor(labels, weights, device)
    D, H, W = fix_oh.shape[-3:]
    cd, ch, cw = _control_shape(fix_r.shape, int(stage["control_factor"]))
    control = torch.zeros((1, 3, cd, ch, cw), device=device, requires_grad=True)
    optimizer = torch.optim.Adam([control], lr=float(stage["lr"]))
    max_res, lw = float(stage["max_residual_vox"]), cfg["loss_weights"]
    best = {"loss": float("inf"), "iter": -1, "control": None}

    for it in range(1, int(stage["iterations"]) + 1):
        optimizer.zero_grad(set_to_none=True)
        res = F.interpolate(control, size=(D, H, W), mode="trilinear", align_corners=True)
        res = max_res * torch.tanh(res)
        warped = _warp_onehot(mov_oh, base_t + res)
        loss = (
            float(lw["dice"]) * _weighted_dice_loss(warped, fix_oh, w_t)
            + float(lw["smooth"]) * _smoothness(res)
            + float(lw["magnitude"]) * torch.mean(res * res)
        )
        loss.backward()
        optimizer.step()
        value = float(loss.detach().cpu())
        if value < best["loss"]:
            best = {"loss": value, "iter": it, "control": control.detach().clone()}

    with torch.no_grad():
        res = F.interpolate(best["control"], size=(D, H, W), mode="trilinear", align_corners=True)
        res = max_res * torch.tanh(res)
    return _torch_to_dvf(res), best


def _upsample_residual(residual_r: np.ndarray, full_shape, r: int) -> np.ndarray:
    t = _dvf_to_torch(residual_r, "cpu")
    X, Y, Z = full_shape
    up = F.interpolate(t, size=(Z, Y, X), mode="trilinear", align_corners=True)
    return (_torch_to_dvf(up) * float(r)).astype(np.float32)


def _select_candidate(current, residual, original_fixed, original_moving, corrected_fixed, corrected_moving, labels, weights, reference, cfg):
    best, details = None, []
    hard_case = reference["original_per"]["dice_64"] < float(cfg["hard_case_rml_threshold"])

    for scale in cfg["candidate_scales"]:
        candidate = current + float(scale) * residual
        folding = _folding_pct(candidate)
        original_mean, original_per = _dice(original_fixed, _warp_label(original_moving, candidate), labels)
        corrected_mean, corrected_per = _dice(corrected_fixed, _warp_label(corrected_moving, candidate), labels)
        corrected_weighted = _weighted_mean(corrected_per, weights)
        corrected_gain = corrected_mean - reference["corrected_mean"]
        original_loss = reference["original_mean"] - original_mean
        rml_gain = corrected_per["dice_64"] - reference["corrected_per"]["dice_64"]
        non_rml_losses = [reference["original_per"][f"dice_{lab}"] - original_per[f"dice_{lab}"] for lab in labels if lab != 64]
        max_non_rml_loss = max(non_rml_losses) if non_rml_losses else 0.0

        rejected, reasons = False, []
        if folding > float(cfg["hard_reject_folding_pct"]):
            rejected, reasons = True, ["hard_folding"]
        if float(scale) > 0.0:
            hard_exception = hard_case and rml_gain >= float(cfg["minimum_rml_corrected_gain_hard_case"]) and original_loss <= float(cfg["maximum_original_proxy_loss"])
            if corrected_gain < float(cfg["minimum_corrected_proxy_gain"]) and not hard_exception:
                rejected, reasons = True, reasons + ["insufficient_corrected_proxy_gain"]
            if original_loss > float(cfg["maximum_original_proxy_loss"]):
                rejected, reasons = True, reasons + ["original_proxy_loss"]
            if max_non_rml_loss > float(cfg["maximum_original_non_rml_loss"]):
                rejected, reasons = True, reasons + ["original_non_rml_loss"]

        score = corrected_weighted + 0.35 * original_mean + (0.25 * max(0.0, rml_gain) if hard_case else 0.0)
        if folding > float(cfg["soft_folding_start_pct"]):
            if folding <= float(cfg["soft_folding_full_pct"]):
                score -= 0.004 * (folding - float(cfg["soft_folding_start_pct"])) / max(1e-6, float(cfg["soft_folding_full_pct"]) - float(cfg["soft_folding_start_pct"]))
            else:
                score -= 0.004 + 0.030 * min(1.0, (folding - float(cfg["soft_folding_full_pct"])) / max(1e-6, float(cfg["hard_reject_folding_pct"]) - float(cfg["soft_folding_full_pct"])))

        rec = {
            "scale": float(scale), "score": float(score), "folding_pct": folding,
            "original_pseudo_mean_dice": original_mean, "corrected_pseudo_mean_dice": corrected_mean,
            "corrected_weighted_dice": corrected_weighted, "corrected_gain": corrected_gain,
            "original_loss": original_loss, "rml_corrected_gain": rml_gain,
            "max_original_non_rml_loss": max_non_rml_loss, "rejected": rejected,
            "reject_reasons": reasons, "original_per_lobe": original_per, "corrected_per_lobe": corrected_per,
        }
        details.append(rec)
        if not rejected and (best is None or rec["score"] > best["score"]):
            best = rec

    return (best if best is not None else next(x for x in details if x["scale"] == 0.0)), details


def _load_or_fit_calibration(case_id: str, cfg: Dict) -> Dict:
    mode = cfg["calibration_mode"]
    if mode == "saved_global":
        p = Path(cfg["saved_calibration_json"])
        if not p.exists():
            raise FileNotFoundError(f"saved calibration not found: {p}")
        return json.loads(p.read_text())
    if mode == "fit_all_validation":
        return fit_geometry_calibration(cfg, exclude_case=None)
    if mode == "leave_one_case_out":
        return fit_geometry_calibration(cfg, exclude_case=case_id)
    raise ValueError(f"Unknown calibration_mode: {mode}")


def run_case(case_id: str, cfg: Dict) -> Dict:
    if nib is None or torch is None:
        raise RuntimeError("nibabel and torch are required")
    t0 = time.time()
    labels = [int(x) for x in cfg["labels"]]
    weights = {lab: float(cfg["lobe_weights"][str(lab)]) for lab in labels}
    device = cfg["device"] if cfg["device"] != "cuda" or torch.cuda.is_available() else "cpu"

    parent_path = _find_parent(case_id, cfg)
    parent_img, parent_dvf = _load(parent_path)
    parent_dvf = parent_dvf.astype(np.float32)

    pseudo_root = Path(cfg["pseudo_segmentation_root"])
    fixed_path = _find_lobe(pseudo_root, case_id, "INSP", gt=False)
    moving_path = _find_lobe(pseudo_root, case_id, "EXP", gt=False)
    if fixed_path is None or moving_path is None:
        raise FileNotFoundError(f"Pseudo lobe labels missing for {case_id}")

    fixed_img, fixed_original = _load(fixed_path)
    moving_img, moving_original = _load(moving_path)
    fixed_original, moving_original = fixed_original.astype(np.int16), moving_original.astype(np.int16)

    calibration = _load_or_fit_calibration(case_id, cfg)
    fixed_corrected, fixed_audit = correct_pseudo_labels(fixed_original, "INSP", calibration, cfg)
    moving_corrected, moving_audit = correct_pseudo_labels(moving_original, "EXP", calibration, cfg)

    out_root = Path(cfg["output_root"])
    _save_like(fixed_img, fixed_corrected, out_root / "corrected_pseudolabels" / f"{case_id}_INSP_lobes_corrected.nii.gz")
    _save_like(moving_img, moving_corrected, out_root / "corrected_pseudolabels" / f"{case_id}_EXP_lobes_corrected.nii.gz")

    parent_original_mean, parent_original_per = _dice(fixed_original, _warp_label(moving_original, parent_dvf), labels)
    parent_corrected_mean, parent_corrected_per = _dice(fixed_corrected, _warp_label(moving_corrected, parent_dvf), labels)

    current = parent_dvf.copy()
    reference = {
        "original_mean": parent_original_mean, "original_per": parent_original_per,
        "corrected_mean": parent_corrected_mean, "corrected_per": parent_corrected_per,
    }
    stage_records = []

    for stage in cfg["stages"]:
        residual_r, opt = _optimize_stage(fixed_corrected, moving_corrected, current, labels, weights, cfg, stage, device)
        residual = _upsample_residual(residual_r, current.shape[:3], int(stage["reduce_factor"]))
        selected, candidates = _select_candidate(current, residual, fixed_original, moving_original, fixed_corrected, moving_corrected, labels, weights, reference, cfg)
        current = current + float(selected["scale"]) * residual
        new_original_mean, new_original_per = _dice(fixed_original, _warp_label(moving_original, current), labels)
        new_corrected_mean, new_corrected_per = _dice(fixed_corrected, _warp_label(moving_corrected, current), labels)
        reference = {
            "original_mean": new_original_mean, "original_per": new_original_per,
            "corrected_mean": new_corrected_mean, "corrected_per": new_corrected_per,
        }
        stage_records.append({
            "stage": stage["name"], "optimizer_best_loss": opt["loss"], "optimizer_best_iter": opt["iter"],
            "selected": selected, "candidates": candidates,
        })

    final_original_mean, final_original_per = _dice(fixed_original, _warp_label(moving_original, current), labels)
    final_corrected_mean, final_corrected_per = _dice(fixed_corrected, _warp_label(moving_corrected, current), labels)
    final_folding = _folding_pct(current)
    mode = "geometry_corrected_pseudo_tto"
    final_corrected_gain = final_corrected_mean - parent_corrected_mean
    final_original_loss = parent_original_mean - final_original_mean

    if final_corrected_gain < float(cfg["minimum_corrected_proxy_gain"]) or final_original_loss > float(cfg["maximum_original_proxy_loss"]) or final_folding > float(cfg["hard_reject_folding_pct"]):
        current = parent_dvf
        final_original_mean, final_original_per = parent_original_mean, parent_original_per
        final_corrected_mean, final_corrected_per = parent_corrected_mean, parent_corrected_per
        final_folding, final_corrected_gain, final_original_loss = _folding_pct(parent_dvf), 0.0, 0.0
        mode = "exact_parent_fallback_final_guard"

    _save_like(parent_img, current, out_root / "dvfs" / f"{case_id}_DVF.nii.gz")
    _save_like(parent_img, current, out_root / "dvfs_canonical_ras" / f"{case_id}_DVF.nii.gz")
    (out_root / "calibration" / f"{case_id}_calibration.json").write_text(json.dumps(calibration, indent=2))

    rec = {
        "case_id": case_id, "status": "ok", "mode": mode, "device": device,
        "parent_dvf": str(parent_path), "original_fixed_pseudo": str(fixed_path), "original_moving_pseudo": str(moving_path),
        "calibration_mode": cfg["calibration_mode"], "calibration_fit_cases": calibration["fit_cases"],
        "current_case_excluded_from_calibration": case_id not in calibration["fit_cases"],
        "uses_current_case_gt_in_optimizer": False,
        "fixed_correction_audit": fixed_audit, "moving_correction_audit": moving_audit,
        "parent_original_pseudo_mean_dice": parent_original_mean,
        "final_original_pseudo_mean_dice": final_original_mean,
        "final_minus_parent_original_pseudo_mean_dice": final_original_mean - parent_original_mean,
        "parent_corrected_pseudo_mean_dice": parent_corrected_mean,
        "final_corrected_pseudo_mean_dice": final_corrected_mean,
        "final_minus_parent_corrected_pseudo_mean_dice": final_corrected_gain,
        "parent_folding_pct": _folding_pct(parent_dvf), "final_folding_pct": final_folding,
        "final_original_per_lobe": final_original_per, "final_corrected_per_lobe": final_corrected_per,
        "stages": stage_records, "elapsed_sec": time.time() - t0,
    }
    (out_root / "case_manifests" / f"{case_id}_manifest.json").write_text(json.dumps(rec, indent=2))
    return rec


def summarize_run(cfg: Dict, records: List[Dict], failed: List[Dict]) -> Dict:
    modes = {}
    for r in records:
        modes[r["mode"]] = modes.get(r["mode"], 0) + 1
    po = [r["parent_original_pseudo_mean_dice"] for r in records]
    fo = [r["final_original_pseudo_mean_dice"] for r in records]
    pc = [r["parent_corrected_pseudo_mean_dice"] for r in records]
    fc = [r["final_corrected_pseudo_mean_dice"] for r in records]
    folds = [r["final_folding_pct"] for r in records]
    return {
        "status": "PASS" if not failed else "PARTIAL_FAIL",
        "method": "SGR-FM C8C geometry-corrected pseudo-label registration",
        "case_count": len(records), "failure_count": len(failed), "mode_histogram": modes,
        "calibration_mode": cfg["calibration_mode"], "uses_current_case_gt_in_optimizer": False,
        "parent_mean_original_pseudo_dice": float(np.mean(po)) if po else None,
        "final_mean_original_pseudo_dice": float(np.mean(fo)) if fo else None,
        "delta_mean_original_pseudo_dice": float(np.mean(fo) - np.mean(po)) if fo else None,
        "parent_mean_corrected_pseudo_dice": float(np.mean(pc)) if pc else None,
        "final_mean_corrected_pseudo_dice": float(np.mean(fc)) if fc else None,
        "delta_mean_corrected_pseudo_dice": float(np.mean(fc) - np.mean(pc)) if fc else None,
        "mean_final_folding_pct": float(np.mean(folds)) if folds else None,
        "max_final_folding_pct": float(np.max(folds)) if folds else None,
        "failed_cases": failed, "output_root": cfg["output_root"], "parent_dir": cfg["parent_dir"],
    }


def write_run_csv(cfg: Dict, records: List[Dict]):
    out = Path(cfg["output_root"]) / "calibration"
    out.mkdir(parents=True, exist_ok=True)
    path = out / "c8c_geometry_corrected_per_case.csv"
    fields = [
        "case_id", "mode", "current_case_excluded_from_calibration",
        "parent_original_pseudo_mean_dice", "final_original_pseudo_mean_dice",
        "final_minus_parent_original_pseudo_mean_dice", "parent_corrected_pseudo_mean_dice",
        "final_corrected_pseudo_mean_dice", "final_minus_parent_corrected_pseudo_mean_dice",
        "parent_folding_pct", "final_folding_pct",
    ]
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in records:
            w.writerow({k: r.get(k) for k in fields})
