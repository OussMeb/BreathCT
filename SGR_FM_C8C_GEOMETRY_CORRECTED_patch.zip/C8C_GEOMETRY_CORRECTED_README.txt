SGR-FM C8C — geometry-corrected pseudo-label registration
=========================================================

C8C corrects pseudo-label geometry before registration rather than only changing
lobe weights. Validation uses leave-one-case-out calibration by default:
for each validation case, its own GT labels are excluded from calibration and no
GT labels are used in its registration optimizer.

Correction model:
- robust phase/lobe centroid shift;
- robust isotropic scale correction;
- signed-distance blending;
- conservative caps and lobe-volume rollback;
- original pseudo labels retained as a secondary safety target;
- exact parent fallback when guards fail.

Install:
cd "/home/oussama/Desktop/MICCAI FRANCE"
unzip -o SGR_FM_C8C_GEOMETRY_CORRECTED_patch.zip -d .

Compile:
python -m py_compile \
  run_sgr_fm_c8c_geometry_corrected_validation.py \
  fit_sgr_fm_c8c_geometry_calibration.py \
  utils/sgr_fm_c8c_geometry_corrected.py \
  smoke_sgr_fm_c8c_geometry_corrected_synthetic.py

Smoke:
python smoke_sgr_fm_c8c_geometry_corrected_synthetic.py

Dry run:
python run_sgr_fm_c8c_geometry_corrected_validation.py \
  --config configs/sgr_fm_c8c_geometry_corrected.yaml \
  --dry-run

Hard cases first:
python run_sgr_fm_c8c_geometry_corrected_validation.py \
  --config configs/sgr_fm_c8c_geometry_corrected.yaml \
  --cases NLST_0006 NLST_0007 NLST_0008 NLST_0009

Full validation:
python run_sgr_fm_c8c_geometry_corrected_validation.py \
  --config configs/sgr_fm_c8c_geometry_corrected.yaml

Fit deployable calibration for train/test after validation:
python fit_sgr_fm_c8c_geometry_calibration.py \
  --config configs/sgr_fm_c8c_geometry_corrected.yaml

Then use:
calibration_mode: saved_global
saved_calibration_json: outputs/sgr_fm/c8c_geometry_corrected/calibration/c8c_full_validation_calibration.json

Upload after full validation:
outputs/sgr_fm/c8c_geometry_corrected/c8c_geometry_corrected_summary.json
outputs/sgr_fm/c8c_geometry_corrected/eval/validation_metrics.json
outputs/sgr_fm/c8c_geometry_corrected/calibration/c8c_geometry_corrected_per_case.csv
outputs/sgr_fm/c8c_geometry_corrected/case_manifests/NLST_0006_manifest.json
outputs/sgr_fm/c8c_geometry_corrected/case_manifests/NLST_0007_manifest.json
