#!/usr/bin/env python3
import argparse
import json
import subprocess
import sys
from pathlib import Path

from utils.sgr_fm_c8c_geometry_corrected import load_config, discover_cases, run_case, summarize_run, write_run_csv


def main() -> int:
    ap = argparse.ArgumentParser(description='Run C8C geometry-corrected pseudo-label registration.')
    ap.add_argument('--config', required=True)
    ap.add_argument('--cases', nargs='*', default=None)
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    cfg = load_config(args.config)
    out_root = Path(cfg['output_root'])
    for sub in ['dvfs', 'dvfs_canonical_ras', 'corrected_pseudolabels', 'case_manifests', 'calibration', 'eval', 'traces']:
        (out_root / sub).mkdir(parents=True, exist_ok=True)

    cases = args.cases or discover_cases(cfg)
    if args.dry_run:
        print(json.dumps({
            'status': 'DRY_RUN',
            'method': 'SGR-FM C8C geometry-corrected pseudo-label registration',
            'cases': cases,
            'output_root': cfg['output_root'],
            'parent_dir': cfg['parent_dir'],
            'calibration_mode': cfg['calibration_mode'],
            'uses_current_case_gt_in_optimizer': False,
            'uses_current_case_gt_for_calibration': cfg['calibration_mode'] != 'leave_one_case_out',
        }, indent=2))
        return 0

    records, failed = [], []
    for case_id in cases:
        try:
            rec = run_case(case_id, cfg)
            records.append(rec)
            print(
                f"PASS {case_id} mode={rec['mode']} "
                f"orig_proxy={rec['final_original_pseudo_mean_dice']:.6f} "
                f"corr_gain={rec['final_minus_parent_corrected_pseudo_mean_dice']:+.6f} "
                f"fold={rec['final_folding_pct']:.6f}%"
            )
        except Exception as exc:
            failed.append({'case_id': case_id, 'error': repr(exc)})
            print(f'FAIL {case_id}: {exc!r}', file=sys.stderr)
            if not cfg.get('continue_on_error', False):
                break

    summary = summarize_run(cfg, records, failed)
    (out_root / 'c8c_geometry_corrected_summary.json').write_text(json.dumps(summary, indent=2))
    write_run_csv(cfg, records)

    eval_script = Path(cfg.get('evaluate_script', 'evaluate_validation.py'))
    if len(records) == 10 and not failed and eval_script.exists():
        subprocess.run([
            sys.executable, str(eval_script),
            '--raw-data-root', str(cfg['raw_data_root']),
            '--dvf-dir', str(out_root / 'dvfs'),
            '--output-dir', str(out_root / 'eval'),
        ], check=False)

    print(json.dumps(summary, indent=2))
    return 0 if not failed else 1


if __name__ == '__main__':
    raise SystemExit(main())
