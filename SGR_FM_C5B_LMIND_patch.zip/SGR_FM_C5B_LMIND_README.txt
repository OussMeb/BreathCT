SGR-FM C5b-LMIND PATCH
======================

Purpose
-------
C5b-LMIND performs one small localized MIND-SSC residual-SVF refinement on
frozen C4.1-HAST-PCF. It is the planned final image-driven residual test after
C5a FireANTs showed image/anatomy objective conflict.

Core design
-----------
1. Frozen initializer: outputs/sgr_fm/c4_1_hast_pcf
2. Secondary paired-consensus view: outputs/sgr_fm/c2_long_tto
3. Primary descriptor: 12-channel 3D MIND-SSC local self-similarity
4. Detached soft priority map from:
   - paired-consensus uncertainty,
   - baseline MIND mismatch,
   - all predicted fissure/interface proximities,
   - predicted lung support.
5. Residual SVF capacity is softly gated by that map.
6. Objective:
   - MIND primary,
   - weak LNCC,
   - weak structural gradient,
   - weak confidence-weighted SDF anatomy stabilization,
   - support, bending, magnitude, Jacobian terms.
7. Exact pull composition with C4.1; DVFs are never added.
8. Candidate scales: 1, .75, .5, .25, .125, 0.
9. Scale 0 is reserved for exact byte-copy C4.1 fallback.
10. Validation GT is not loaded by optimization or selection. The existing
    evaluator is called only after a complete 10-case run.

Output isolation
----------------
outputs/sgr_fm/c5b_lmind_residual

Install patch
-------------
cd "/home/oussama/Desktop/MICCAI FRANCE"
unzip -o SGR_FM_C5B_LMIND_patch.zip -d .

Compile
-------
python -m py_compile \
  main.py \
  run_sgr_fm_c5b_lmind_validation.py \
  utils/sgr_fm_c5b_lmind.py \
  smoke_sgr_fm_c5b_lmind_synthetic.py

Synthetic smoke
---------------
python smoke_sgr_fm_c5b_lmind_synthetic.py

Expected final line:
C5b-LMIND SYNTHETIC SMOKE: PASS

Asset/fingerprint audit
-----------------------
python main.py c5-mind \
  --config configs/sgr_fm_c5b_lmind.yaml \
  --dry-run

Recommended real smoke set
--------------------------
python main.py c5-mind --config configs/sgr_fm_c5b_lmind.yaml --case-ids NLST_0006 --skip-evaluation
python main.py c5-mind --config configs/sgr_fm_c5b_lmind.yaml --case-ids NLST_0007 --skip-evaluation
python main.py c5-mind --config configs/sgr_fm_c5b_lmind.yaml --case-ids NLST_0003 --skip-evaluation
python main.py c5-mind --config configs/sgr_fm_c5b_lmind.yaml --case-ids NLST_0009 --skip-evaluation

Smoke decision rule agreed before results
-----------------------------------------
Continue only if at least one hard case (0006 or 0007) accepts a non-zero
candidate and at least two of four smoke cases show coherent positive
structural evidence with topology preserved. Safety cases may fallback.

Abort this image-driven residual family if:
- 0/4 cases accept, or
- MIND improves while anatomy systematically worsens, or
- both 0006 and 0007 fallback, or
- only negligible 0.125-scale candidates survive.

Locked fingerprints
-------------------
C4.1-HAST-PCF:
0b7e49fee00fd2ef84db9abf3121b82d971ea7b9b01a5b3b28b5005b6cd636b2

C2-LONG secondary:
fdc2c0a64374aee658b647b55ae673f50faf2d08aed79ea7e0d6dd3d17fadcd3

No new external registration dependency
---------------------------------------
C5b uses the existing PyTorch/scipy/nibabel project environment. FireANTs is
not used by this branch.
