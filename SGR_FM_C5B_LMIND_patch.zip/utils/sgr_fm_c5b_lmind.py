#!/usr/bin/env python3
"""Core helpers for SGR-FM C5b-LMIND.

C5b-LMIND = Localized MIND residual refinement on top of the frozen
C4.1-HAST-PCF champion.

The method is deliberately different from C5a FireANTs:
  * C4.1 remains the immutable initializer and exact fallback.
  * a standard 3D MIND-SSC descriptor provides the primary image signal;
  * residual capacity is softly gated by an inference-only priority map built
    from paired-consensus uncertainty, baseline MIND mismatch, predicted
    fissure proximity, and predicted lung support;
  * one small residual SVF is optimized and composed exactly with C4.1;
  * validation GT is never loaded here.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch
import torch.nn.functional as F

from utils.refine_spatial import downsample_dvf_5d, integrate_svf, warp_volume
from utils.sgr_fm_c3 import compose_pull, soft_dice_per_lobe
from utils.sgr_fm_c4_1_hast_pcf import (
    balanced_consensus_lobe_dice,
    confidence_weighted_sdf_loss,
    load_case_tensors as load_c41_case_tensors,
    make_lowres_state as make_c41_lowres_state,
    validation_asset_paths as c41_validation_asset_paths,
)
from utils.sgr_fm_c4_hast import structural_gradient_loss
from utils.sgr_fm_training_assets import load_yaml_or_json, recursive_update
from utils.sgr_fm_tto import (
    bending_energy,
    binary_soft_dice,
    build_residual_svf,
    jacobian_barrier,
    make_control_parameter,
    masked_local_ncc_loss,
    topology_stats,
)


def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "initializer_dir": "outputs/sgr_fm/c4_1_hast_pcf",
        "secondary_initializer_dir": "outputs/sgr_fm/c2_long_tto",
        "output_dir": "outputs/sgr_fm/c5b_lmind_residual",
        "case_ids": [],
        "overwrite": False,
        "stop_on_error": True,
        "device": "cuda",
        "require_initializer_fingerprint": True,
        "accepted_initializer_method_fingerprint": "0b7e49fee00fd2ef84db9abf3121b82d971ea7b9b01a5b3b28b5005b6cd636b2",
        "require_secondary_fingerprint": True,
        "accepted_secondary_method_fingerprint": "fdc2c0a64374aee658b647b55ae673f50faf2d08aed79ea7e0d6dd3d17fadcd3",
        "ct": {
            "clip_min_hu": -1000.0,
            "clip_max_hu": 400.0,
            "lncc_window": 9,
            "lncc_min_valid_fraction": 0.25,
            "gradient_min_magnitude": 0.03,
        },
        "anatomy": {
            "sdf_band_mm": 12.0,
            "interface_band_mm": 10.0,
            "interface_dilation_iterations": 1,
            "charbonnier_eps": 1.0e-3,
        },
        "consensus": {
            "direct_weight": 1.0,
            "c4_transport_weight": 0.85,
            "c2_transport_weight": 0.35,
            "direct_transport_sigma": 0.30,
            "cross_transport_sigma": 0.25,
            "confidence_floor": 0.05,
            "normalize_lobe_sum": True,
            "size_weight_power": 0.5,
            "size_weight_min": 0.75,
            "size_weight_max": 2.5,
            "sdf_band_fraction": 0.85,
            "interface_confidence_sigma": 0.30,
        },
        "mind": {
            "descriptor": "MIND-SSC-3D-12ch",
            "delta": 1,
            "patch_radius": 1,
            "variance_floor_fraction": 1.0e-3,
            "variance_ceiling_fraction": 1.0e3,
            "loss": "charbonnier",
            "charbonnier_eps": 1.0e-3,
        },
        "priority": {
            "uncertainty_weight": 0.45,
            "mind_mismatch_weight": 0.45,
            "fissure_weight": 0.35,
            "mind_quantile_low": 0.50,
            "mind_quantile_high": 0.95,
            "sigmoid_center": 0.42,
            "sigmoid_temperature": 0.10,
            "gate_floor": 0.05,
            "support_dilation_kernel": 5,
            "smooth_kernel": 3,
            "fissure_sigma": 0.30,
            "lncc_mask_floor": 0.30,
        },
        "stage_e": {
            "name": "E_localized_MIND",
            "reduce_factor": 2,
            "control_factor": 3,
            "iterations": 180,
            "lr": 0.020,
            "max_residual_fullres_voxels": 0.75,
            "integration_steps": 6,
            "early_stop_patience": 50,
            "min_objective_improvement": 1.0e-6,
            "grad_clip": 1.0,
            "selection_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            "weights": {
                "mind": 1.00,
                "image_lncc": 0.15,
                "structural_gradient": 0.10,
                "confidence_sdf": 0.15,
                "support": 0.03,
                "bending": 0.05,
                "residual_magnitude": 0.02,
                "jacobian": 30.0,
                "jacobian_margin": 0.025,
            },
        },
        "selection": {
            "min_composite_score_gain": 1.0e-4,
            "max_direct_proxy_lobe_drop": 5.0e-4,
            "max_consensus_lobe_drop": 4.0e-4,
            "max_mind_loss_increase": 0.0,
            "max_lncc_loss_increase": 1.0e-3,
            "max_support_dice_drop": 1.5e-3,
            "max_residual_p99_voxels": 1.5,
            "max_residual_max_voxels": 5.0,
            "topology_guard_mode": "relative_to_initializer",
            "max_folding_increase_pct": 5.0e-5,
            "max_absolute_folding_pct": 1.0e-3,
            "score_mind_gain": 1.00,
            "score_consensus_lobe_gain": 0.30,
            "score_direct_lobe_gain": 0.10,
            "score_lncc_gain": 0.25,
            "score_structural_gain": 0.20,
            "score_sdf_gain": 0.25,
            "score_support_gain": 0.03,
        },
        "evaluation": {
            "enabled": True,
            "device": "cuda",
            "initializer_metrics_json": "outputs/sgr_fm/c4_1_hast_pcf/eval/validation_metrics.json",
        },
    }


def build_config(config_path: str | Path | None, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = default_config()
    if config_path is not None:
        recursive_update(cfg, load_yaml_or_json(config_path, root_key="sgr_fm_c5b_lmind"))
    if overrides:
        recursive_update(cfg, overrides)
    return cfg


def validation_asset_paths(
    segmentation_dir: Path,
    initializer_dir: Path,
    secondary_initializer_dir: Path,
    case_id: str,
) -> dict[str, Path]:
    return c41_validation_asset_paths(
        segmentation_dir=segmentation_dir,
        initializer_dir=initializer_dir,
        secondary_initializer_dir=secondary_initializer_dir,
        case_id=case_id,
    )


def load_case_tensors(
    *,
    exp_ct_path: Path,
    insp_ct_path: Path,
    assets: dict[str, Path],
    device: torch.device,
    ct_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
    consensus_cfg: dict[str, Any],
    affine_atol: float = 1e-5,
) -> dict[str, Any]:
    # The C4.1 loader is reused with C4.1 itself as the primary transport view.
    # This gives direct INSP + C4.1-transported EXP + C2-LONG-transported EXP.
    return load_c41_case_tensors(
        exp_ct_path=exp_ct_path,
        insp_ct_path=insp_ct_path,
        assets=assets,
        device=device,
        ct_cfg=ct_cfg,
        anatomy_cfg=anatomy_cfg,
        consensus_cfg=consensus_cfg,
        affine_atol=affine_atol,
    )


def make_lowres_state(full: dict[str, Any], *, reduce_factor: int) -> dict[str, torch.Tensor]:
    return make_c41_lowres_state(full, reduce_factor=reduce_factor)


def _mind_pair_offsets(device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    """Return the 12 standard MIND-SSC offset pairs from a 6-neighbourhood."""
    # Six axial neighbours (+/- each spatial axis). Among the 15 unordered
    # pairs, excluding the three opposite pairs leaves the 12 MIND-SSC
    # comparisons at squared distance 2.
    six = torch.tensor(
        [
            [1, 0, 0],
            [-1, 0, 0],
            [0, 1, 0],
            [0, -1, 0],
            [0, 0, 1],
            [0, 0, -1],
        ],
        dtype=torch.long,
        device=device,
    )
    dist = ((six[:, None, :] - six[None, :, :]) ** 2).sum(dim=-1)
    ii, jj = torch.meshgrid(
        torch.arange(6, device=device),
        torch.arange(6, device=device),
        indexing="ij",
    )
    mask = (ii > jj) & (dist == 2)
    a = six[ii[mask]]
    b = six[jj[mask]]
    if a.shape[0] != 12:
        raise RuntimeError(f"Expected 12 MIND-SSC offset pairs, got {a.shape[0]}")
    return a, b


def _shift_kernel(offsets: torch.Tensor, *, delta: int, dtype: torch.dtype) -> torch.Tensor:
    k = 2 * int(delta) + 1
    kernels = torch.zeros((offsets.shape[0], 1, k, k, k), device=offsets.device, dtype=dtype)
    center = int(delta)
    for idx, off in enumerate(offsets.tolist()):
        pos = [center + int(off[0]), center + int(off[1]), center + int(off[2])]
        if any(v < 0 or v >= k for v in pos):
            raise ValueError(f"MIND offset {off} exceeds delta={delta}")
        kernels[idx, 0, pos[0], pos[1], pos[2]] = 1.0
    return kernels


def mind_ssc_3d(image: torch.Tensor, cfg: dict[str, Any]) -> torch.Tensor:
    """Compute a 12-channel 3D MIND-SSC descriptor.

    Input/output convention follows this project: [B,C,X,Y,Z]. PyTorch's
    conv3d treats the last three axes generically, so the descriptor remains
    consistent with project geometry.
    """
    if image.ndim != 5 or image.shape[1] != 1:
        raise ValueError(f"MIND expects [B,1,X,Y,Z], got {tuple(image.shape)}")
    delta = int(cfg.get("delta", 1))
    radius = int(cfg.get("patch_radius", 1))
    if delta < 1 or radius < 0:
        raise ValueError("MIND delta must be >=1 and patch_radius >=0")

    off_a, off_b = _mind_pair_offsets(image.device)
    off_a = off_a * delta
    off_b = off_b * delta
    k_a = _shift_kernel(off_a, delta=delta, dtype=image.dtype)
    k_b = _shift_kernel(off_b, delta=delta, dtype=image.dtype)

    padded = F.pad(image, (delta, delta, delta, delta, delta, delta), mode="replicate")
    a = F.conv3d(padded, k_a)
    b = F.conv3d(padded, k_b)
    ssd = (a - b).square()
    if radius > 0:
        patch = 2 * radius + 1
        ssd = F.avg_pool3d(ssd, kernel_size=patch, stride=1, padding=radius)

    mind = ssd - ssd.amin(dim=1, keepdim=True)
    local_var = mind.mean(dim=1, keepdim=True)
    global_mean = local_var.detach().mean().clamp_min(torch.finfo(image.dtype).eps)
    lo = global_mean * float(cfg.get("variance_floor_fraction", 1.0e-3))
    hi = global_mean * float(cfg.get("variance_ceiling_fraction", 1.0e3))
    local_var = local_var.clamp(min=float(lo.item()), max=float(hi.item()))
    descriptor = torch.exp(-mind / local_var.clamp_min(torch.finfo(image.dtype).eps))

    # Standard channel permutation used by common MIND-SSC implementations.
    perm = torch.tensor([6, 8, 1, 11, 2, 10, 0, 7, 9, 4, 5, 3], device=image.device)
    descriptor = descriptor.index_select(1, perm)
    if not torch.isfinite(descriptor).all():
        raise RuntimeError("MIND descriptor contains NaN/Inf")
    return descriptor


def mind_voxel_mismatch(fixed_mind: torch.Tensor, moving_mind: torch.Tensor) -> torch.Tensor:
    if fixed_mind.shape != moving_mind.shape:
        raise ValueError(f"MIND shape mismatch: {fixed_mind.shape} vs {moving_mind.shape}")
    return (fixed_mind - moving_mind).abs().mean(dim=1, keepdim=True)


def _robust_unit_normalize(
    value: torch.Tensor,
    support: torch.Tensor,
    *,
    q_low: float,
    q_high: float,
) -> tuple[torch.Tensor, float, float]:
    if not (0.0 <= q_low < q_high <= 1.0):
        raise ValueError("Priority MIND quantiles must satisfy 0<=low<high<=1")
    valid = value.detach()[support.detach() > 0.05]
    if valid.numel() < 16:
        lo = value.detach().amin()
        hi = value.detach().amax()
    else:
        lo = torch.quantile(valid.float(), q_low).to(value.dtype)
        hi = torch.quantile(valid.float(), q_high).to(value.dtype)
    denom = (hi - lo).clamp_min(torch.finfo(value.dtype).eps)
    out = ((value - lo) / denom).clamp(0.0, 1.0)
    return out, float(lo.item()), float(hi.item())


def build_priority_map(
    *,
    state: dict[str, torch.Tensor],
    fixed_mind: torch.Tensor,
    prewarped_moving_mind: torch.Tensor,
    cfg: dict[str, Any],
) -> tuple[torch.Tensor, dict[str, float], dict[str, torch.Tensor]]:
    """Build a detached soft residual-capacity map in the fixed frame."""
    mismatch = mind_voxel_mismatch(fixed_mind, prewarped_moving_mind).detach()
    support = state["fixed_support"].detach().clamp(0.0, 1.0)
    mismatch_norm, qlo, qhi = _robust_unit_normalize(
        mismatch,
        support,
        q_low=float(cfg.get("mind_quantile_low", 0.50)),
        q_high=float(cfg.get("mind_quantile_high", 0.95)),
    )

    # Min confidence across lobe channels captures uncertainty at any lobe boundary.
    uncertainty = 1.0 - state["confidence_lobes"].detach().clamp(0.0, 1.0).amin(dim=1, keepdim=True)

    # All three predicted fissure/interface systems contribute.
    min_dist = state["consensus_interface_dist"].detach().clamp_min(0.0).amin(dim=1, keepdim=True)
    fissure_sigma = max(float(cfg.get("fissure_sigma", 0.30)), 1.0e-6)
    fissure = torch.exp(-min_dist / fissure_sigma)

    wu = float(cfg.get("uncertainty_weight", 0.45))
    wm = float(cfg.get("mind_mismatch_weight", 0.45))
    wf = float(cfg.get("fissure_weight", 0.35))
    denom = max(wu + wm + wf, 1.0e-6)
    raw = (wu * uncertainty + wm * mismatch_norm + wf * fissure) / denom

    center = float(cfg.get("sigmoid_center", 0.42))
    temp = max(float(cfg.get("sigmoid_temperature", 0.10)), 1.0e-6)
    active = torch.sigmoid((raw - center) / temp)

    dilate_k = int(cfg.get("support_dilation_kernel", 5))
    if dilate_k < 1 or dilate_k % 2 == 0:
        raise ValueError("support_dilation_kernel must be positive odd")
    support_band = F.max_pool3d(support, kernel_size=dilate_k, stride=1, padding=dilate_k // 2)

    smooth_k = int(cfg.get("smooth_kernel", 3))
    if smooth_k < 1 or smooth_k % 2 == 0:
        raise ValueError("smooth_kernel must be positive odd")
    if smooth_k > 1:
        active = F.avg_pool3d(active, kernel_size=smooth_k, stride=1, padding=smooth_k // 2)

    floor = float(cfg.get("gate_floor", 0.05))
    if not 0.0 <= floor < 1.0:
        raise ValueError("gate_floor must be in [0,1)")
    gate = support_band * (floor + (1.0 - floor) * active.clamp(0.0, 1.0))
    gate = gate.detach().clamp(0.0, 1.0)

    diag = {
        "mind_mismatch_quantile_low": qlo,
        "mind_mismatch_quantile_high": qhi,
        "priority_mean": float(gate.mean().item()),
        "priority_p50": float(torch.quantile(gate.flatten().float(), 0.50).item()),
        "priority_p90": float(torch.quantile(gate.flatten().float(), 0.90).item()),
        "priority_p99": float(torch.quantile(gate.flatten().float(), 0.99).item()),
        "priority_fraction_gt_0_5": float((gate > 0.5).float().mean().item()),
        "priority_fraction_gt_0_75": float((gate > 0.75).float().mean().item()),
        "uncertainty_mean": float(uncertainty.mean().item()),
        "mind_mismatch_norm_mean": float(mismatch_norm.mean().item()),
        "fissure_proximity_mean": float(fissure.mean().item()),
    }
    components = {
        "mind_mismatch": mismatch,
        "mind_mismatch_norm": mismatch_norm,
        "uncertainty": uncertainty,
        "fissure_proximity": fissure,
        "support_band": support_band,
    }
    return gate, diag, components


def prepare_mind_state(
    state: dict[str, torch.Tensor],
    *,
    mind_cfg: dict[str, Any],
    priority_cfg: dict[str, Any],
) -> dict[str, Any]:
    """Precompute baseline descriptors and the detached priority map."""
    with torch.no_grad():
        prewarped_ct = warp_volume(state["moving_ct"], state["init_dvf"], mode="bilinear")
        fixed_mind = mind_ssc_3d(state["fixed_ct"], mind_cfg)
        prewarped_mind = mind_ssc_3d(prewarped_ct, mind_cfg)
        gate, diag, components = build_priority_map(
            state=state,
            fixed_mind=fixed_mind,
            prewarped_moving_mind=prewarped_mind,
            cfg=priority_cfg,
        )
    out: dict[str, Any] = dict(state)
    lncc_floor = float(priority_cfg.get("lncc_mask_floor", 0.30))
    if not 0.0 <= lncc_floor <= 1.0:
        raise ValueError("lncc_mask_floor must be in [0,1]")
    lncc_mask = state["fixed_support"].detach().clamp(0.0, 1.0) * (
        lncc_floor + (1.0 - lncc_floor) * gate.detach()
    )
    out.update({
        "fixed_mind": fixed_mind.detach(),
        "prewarped_mind": prewarped_mind.detach(),
        "priority_map": gate.detach(),
        "priority_lncc_mask": lncc_mask.detach(),
        "priority_diagnostics": diag,
    })
    return out


def make_stage_parameter(
    target_shape: Sequence[int],
    *,
    stage_cfg: dict[str, Any],
    device: torch.device,
    dtype: torch.dtype,
) -> torch.nn.Parameter:
    return make_control_parameter(
        target_shape,
        int(stage_cfg.get("control_factor", 3)),
        device=device,
        dtype=dtype,
    )


def build_localized_residual_dvf(
    param: torch.Tensor,
    *,
    target_shape: Sequence[int],
    full_shape: Sequence[int],
    stage_cfg: dict[str, Any],
    priority_map: torch.Tensor,
    scale: float = 1.0,
) -> torch.Tensor:
    svf = build_residual_svf(
        param,
        None,
        target_shape=target_shape,
        full_shape=full_shape,
        max_fullres_voxels=float(stage_cfg.get("max_residual_fullres_voxels", 0.75)),
        scale=float(scale),
    )
    if tuple(priority_map.shape[-3:]) != tuple(int(v) for v in target_shape):
        priority_map = F.interpolate(
            priority_map,
            size=tuple(int(v) for v in target_shape),
            mode="trilinear",
            align_corners=True,
        )
    gated_svf = svf * priority_map.clamp(0.0, 1.0)
    return integrate_svf(gated_svf, int(stage_cfg.get("integration_steps", 6)))


def mind_weighted_loss(
    *,
    fixed_mind: torch.Tensor,
    prewarped_moving_mind: torch.Tensor,
    residual_dvf: torch.Tensor,
    priority_map: torch.Tensor,
    mind_cfg: dict[str, Any],
) -> torch.Tensor:
    warped = warp_volume(prewarped_moving_mind, residual_dvf, mode="bilinear")
    diff = warped - fixed_mind
    loss_name = str(mind_cfg.get("loss", "charbonnier")).lower()
    if loss_name == "charbonnier":
        eps = float(mind_cfg.get("charbonnier_eps", 1.0e-3))
        voxel = torch.sqrt(diff.square() + eps * eps).mean(dim=1, keepdim=True)
    elif loss_name in {"l1", "mae"}:
        voxel = diff.abs().mean(dim=1, keepdim=True)
    elif loss_name in {"l2", "mse"}:
        voxel = diff.square().mean(dim=1, keepdim=True)
    else:
        raise ValueError(f"Unsupported MIND loss={loss_name!r}")
    weight = priority_map.clamp(0.0, 1.0)
    return (voxel * weight).sum() / weight.sum().clamp_min(1.0)


def compute_proxy_metrics(
    *,
    state: dict[str, Any],
    residual_dvf: torch.Tensor,
    ct_cfg: dict[str, Any],
    mind_cfg: dict[str, Any],
    consensus_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> dict[str, float]:
    with torch.no_grad():
        final_dvf = compose_pull(state["init_dvf"], residual_dvf)
        warped_ct = warp_volume(state["moving_ct"], final_dvf, mode="bilinear")
        warped_lobes = warp_volume(state["moving_lobes"], final_dvf, mode="bilinear")
        warped_support = warp_volume(state["moving_support"], final_dvf, mode="bilinear")
        warped_sdf = warp_volume(state["moving_sdf"], final_dvf, mode="bilinear")

        direct = soft_dice_per_lobe(warped_lobes, state["fixed_direct_lobes"]).mean()
        consensus, _, _ = balanced_consensus_lobe_dice(
            warped_lobes, state["consensus_lobes"], consensus_cfg
        )
        support = binary_soft_dice(warped_support, state["fixed_support"])
        lncc = masked_local_ncc_loss(
            state["fixed_ct"],
            warped_ct,
            state["priority_lncc_mask"],
            window=int(ct_cfg.get("lncc_window", 9)),
            min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
        )
        structural = structural_gradient_loss(
            state["fixed_ct"],
            warped_ct,
            state["priority_map"],
            min_magnitude=float(ct_cfg.get("gradient_min_magnitude", 0.03)),
        )
        sdf = confidence_weighted_sdf_loss(
            warped_sdf,
            state["consensus_sdf"],
            state["confidence_lobes"],
            state["consensus_lobes"],
            consensus_cfg,
            charbonnier_eps=float(anatomy_cfg.get("charbonnier_eps", 1.0e-3)),
        )
        mind = mind_weighted_loss(
            fixed_mind=state["fixed_mind"],
            prewarped_moving_mind=state["prewarped_mind"],
            residual_dvf=residual_dvf,
            priority_map=state["priority_map"],
            mind_cfg=mind_cfg,
        )
        return {
            "mind_loss": float(mind.item()),
            "direct_proxy_lobe_dice": float(direct.item()),
            "consensus_balanced_lobe_dice": float(consensus.item()),
            "proxy_support_dice": float(support.item()),
            "lncc_loss": float(lncc.item()),
            "structural_gradient_loss": float(structural.item()),
            "confidence_sdf_loss": float(sdf.item()),
        }


def objective_terms(
    *,
    state: dict[str, Any],
    residual_dvf: torch.Tensor,
    weights: dict[str, Any],
    ct_cfg: dict[str, Any],
    mind_cfg: dict[str, Any],
    consensus_cfg: dict[str, Any],
    anatomy_cfg: dict[str, Any],
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    final_dvf = compose_pull(state["init_dvf"], residual_dvf)
    warped_ct = warp_volume(state["moving_ct"], final_dvf, mode="bilinear")
    warped_support = warp_volume(state["moving_support"], final_dvf, mode="bilinear")
    warped_sdf = warp_volume(state["moving_sdf"], final_dvf, mode="bilinear")

    mind = mind_weighted_loss(
        fixed_mind=state["fixed_mind"],
        prewarped_moving_mind=state["prewarped_mind"],
        residual_dvf=residual_dvf,
        priority_map=state["priority_map"],
        mind_cfg=mind_cfg,
    )
    lncc = masked_local_ncc_loss(
        state["fixed_ct"],
        warped_ct,
        state["priority_lncc_mask"],
        window=int(ct_cfg.get("lncc_window", 9)),
        min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
    )
    structural = structural_gradient_loss(
        state["fixed_ct"],
        warped_ct,
        state["priority_map"],
        min_magnitude=float(ct_cfg.get("gradient_min_magnitude", 0.03)),
    )
    sdf = confidence_weighted_sdf_loss(
        warped_sdf,
        state["consensus_sdf"],
        state["confidence_lobes"],
        state["consensus_lobes"],
        consensus_cfg,
        charbonnier_eps=float(anatomy_cfg.get("charbonnier_eps", 1.0e-3)),
    )
    support = binary_soft_dice(warped_support, state["fixed_support"])
    bend = bending_energy(residual_dvf)
    magnitude = residual_dvf.square().mean()
    jac, folding_pct, min_det = jacobian_barrier(
        final_dvf,
        margin=float(weights.get("jacobian_margin", 0.025)),
    )

    total = (
        float(weights.get("mind", 0.0)) * mind
        + float(weights.get("image_lncc", 0.0)) * lncc
        + float(weights.get("structural_gradient", 0.0)) * structural
        + float(weights.get("confidence_sdf", 0.0)) * sdf
        + float(weights.get("support", 0.0)) * (1.0 - support)
        + float(weights.get("bending", 0.0)) * bend
        + float(weights.get("residual_magnitude", 0.0)) * magnitude
        + float(weights.get("jacobian", 0.0)) * jac
    )
    return total, {
        "total": total,
        "mind_loss": mind,
        "lncc_loss": lncc,
        "structural_gradient_loss": structural,
        "confidence_sdf_loss": sdf,
        "proxy_support_dice": support,
        "bending": bend,
        "residual_magnitude": magnitude,
        "jacobian_loss": jac,
        "folding_pct": folding_pct,
        "min_det": min_det,
    }


def tensor_terms_to_float(terms: dict[str, torch.Tensor]) -> dict[str, float]:
    return {key: float(value.detach().float().item()) for key, value in terms.items()}


def residual_norm_stats(residual_dvf: torch.Tensor) -> dict[str, float]:
    if residual_dvf.ndim != 5 or residual_dvf.shape[1] != 3:
        raise ValueError(f"Expected residual [B,3,X,Y,Z], got {tuple(residual_dvf.shape)}")
    norm = torch.linalg.vector_norm(residual_dvf.detach().float(), dim=1).flatten()
    return {
        "residual_norm_mean_vox": float(norm.mean().item()),
        "residual_norm_p50_vox": float(torch.quantile(norm, 0.50).item()),
        "residual_norm_p95_vox": float(torch.quantile(norm, 0.95).item()),
        "residual_norm_p99_vox": float(torch.quantile(norm, 0.99).item()),
        "residual_norm_max_vox": float(norm.max().item()),
    }


def candidate_score(candidate: dict[str, float], baseline: dict[str, float], selection: dict[str, Any]) -> float:
    return (
        float(selection.get("score_mind_gain", 1.0)) * (baseline["mind_loss"] - candidate["mind_loss"])
        + float(selection.get("score_consensus_lobe_gain", 0.30))
        * (candidate["consensus_balanced_lobe_dice"] - baseline["consensus_balanced_lobe_dice"])
        + float(selection.get("score_direct_lobe_gain", 0.10))
        * (candidate["direct_proxy_lobe_dice"] - baseline["direct_proxy_lobe_dice"])
        + float(selection.get("score_lncc_gain", 0.25)) * (baseline["lncc_loss"] - candidate["lncc_loss"])
        + float(selection.get("score_structural_gain", 0.20))
        * (baseline["structural_gradient_loss"] - candidate["structural_gradient_loss"])
        + float(selection.get("score_sdf_gain", 0.25))
        * (baseline["confidence_sdf_loss"] - candidate["confidence_sdf_loss"])
        + float(selection.get("score_support_gain", 0.03))
        * (candidate["proxy_support_dice"] - baseline["proxy_support_dice"])
    )


def topology_folding_limit(*, baseline_folding_pct: float, selection: dict[str, Any]) -> float:
    mode = str(selection.get("topology_guard_mode", "relative_to_initializer")).strip().lower()
    max_absolute = float(selection.get("max_absolute_folding_pct", 1.0e-3))
    max_increase = float(selection.get("max_folding_increase_pct", 5.0e-5))
    if max_absolute < 0.0 or max_increase < 0.0:
        raise ValueError("Folding guard limits must be non-negative")
    if mode in {"relative_to_initializer", "relative_to_stage_input"}:
        return min(max_absolute, float(baseline_folding_pct) + max_increase)
    if mode == "absolute":
        return max_absolute
    raise ValueError(f"Unsupported topology_guard_mode={mode!r}")


def passes_acceptance(
    candidate: dict[str, float],
    baseline: dict[str, float],
    *,
    baseline_folding_pct: float,
    selection: dict[str, Any],
) -> tuple[bool, list[str], float, float]:
    reasons: list[str] = []
    score = candidate_score(candidate, baseline, selection)
    direct_drop = baseline["direct_proxy_lobe_dice"] - candidate["direct_proxy_lobe_dice"]
    consensus_drop = baseline["consensus_balanced_lobe_dice"] - candidate["consensus_balanced_lobe_dice"]
    mind_increase = candidate["mind_loss"] - baseline["mind_loss"]
    lncc_increase = candidate["lncc_loss"] - baseline["lncc_loss"]
    support_drop = baseline["proxy_support_dice"] - candidate["proxy_support_dice"]
    fold_limit = topology_folding_limit(
        baseline_folding_pct=baseline_folding_pct,
        selection=selection,
    )

    if score < float(selection.get("min_composite_score_gain", 1.0e-4)):
        reasons.append(f"composite_score_gain={score:.6g} below minimum")
    if direct_drop > float(selection.get("max_direct_proxy_lobe_drop", 5.0e-4)):
        reasons.append(f"direct_proxy_lobe_drop={direct_drop:.6g} above maximum")
    if consensus_drop > float(selection.get("max_consensus_lobe_drop", 4.0e-4)):
        reasons.append(f"consensus_lobe_drop={consensus_drop:.6g} above maximum")
    if mind_increase > float(selection.get("max_mind_loss_increase", 0.0)) + 1.0e-12:
        reasons.append(f"mind_loss_increase={mind_increase:.6g} above maximum")
    if lncc_increase > float(selection.get("max_lncc_loss_increase", 1.0e-3)):
        reasons.append(f"lncc_loss_increase={lncc_increase:.6g} above maximum")
    if support_drop > float(selection.get("max_support_dice_drop", 1.5e-3)):
        reasons.append(f"support_dice_drop={support_drop:.6g} above maximum")
    if candidate["residual_norm_p99_vox"] > float(selection.get("max_residual_p99_voxels", 1.5)):
        reasons.append(
            f"residual_p99={candidate['residual_norm_p99_vox']:.6g} above maximum"
        )
    if candidate["residual_norm_max_vox"] > float(selection.get("max_residual_max_voxels", 5.0)):
        reasons.append(
            f"residual_max={candidate['residual_norm_max_vox']:.6g} above maximum"
        )
    if candidate["folding_pct"] > fold_limit + 1.0e-12:
        reasons.append(
            f"folding_pct={candidate['folding_pct']:.6g} above limit={fold_limit:.6g}"
        )
    return len(reasons) == 0, reasons, float(fold_limit), float(score)


def clone_parameter_state(params: Sequence[torch.Tensor]) -> list[torch.Tensor]:
    return [p.detach().clone() for p in params]


def restore_parameter_state(params: Sequence[torch.Tensor], state: Sequence[torch.Tensor]) -> None:
    if len(params) != len(state):
        raise ValueError("Parameter state length mismatch")
    with torch.no_grad():
        for param, value in zip(params, state):
            param.copy_(value)
