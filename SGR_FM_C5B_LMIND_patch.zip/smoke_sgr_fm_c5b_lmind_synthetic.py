#!/usr/bin/env python3
"""Synthetic smoke tests for C5b-LMIND; no Learn2Breath data required."""
from __future__ import annotations

import torch
import torch.nn.functional as F

from utils.sgr_fm_c3 import compose_pull
from utils.sgr_fm_c5b_lmind import (
    build_localized_residual_dvf,
    build_priority_map,
    default_config,
    make_stage_parameter,
    mind_ssc_3d,
    mind_weighted_loss,
    objective_terms,
    passes_acceptance,
    prepare_mind_state,
)


def _sphere(shape: tuple[int, int, int], center: tuple[float, float, float], radius: float) -> torch.Tensor:
    x = torch.arange(shape[0]).view(-1, 1, 1)
    y = torch.arange(shape[1]).view(1, -1, 1)
    z = torch.arange(shape[2]).view(1, 1, -1)
    d2 = (x - center[0]) ** 2 + (y - center[1]) ** 2 + (z - center[2]) ** 2
    return (d2 <= radius * radius).float()


def main() -> int:
    torch.manual_seed(7)
    cfg = default_config()
    mind_cfg = cfg["mind"]
    priority_cfg = cfg["priority"]
    stage_cfg = dict(cfg["stage_e"])
    stage_cfg["iterations"] = 2

    shape = (24, 22, 20)
    base = torch.randn(1, 1, *shape)
    base = F.avg_pool3d(F.pad(base, (1, 1, 1, 1, 1, 1), mode="replicate"), 3, stride=1)
    shifted = torch.roll(base, shifts=1, dims=2)

    d0 = mind_ssc_3d(base, mind_cfg)
    d1 = mind_ssc_3d(shifted, mind_cfg)
    assert d0.shape == (1, 12, *shape)
    assert torch.isfinite(d0).all() and torch.isfinite(d1).all()

    zero = torch.zeros(1, 3, *shape)
    ones = torch.ones(1, 1, *shape)
    identity_loss = mind_weighted_loss(
        fixed_mind=d0,
        prewarped_moving_mind=d0,
        residual_dvf=zero,
        priority_map=ones,
        mind_cfg=mind_cfg,
    )
    shifted_loss = mind_weighted_loss(
        fixed_mind=d0,
        prewarped_moving_mind=d1,
        residual_dvf=zero,
        priority_map=ones,
        mind_cfg=mind_cfg,
    )
    assert float(shifted_loss) > float(identity_loss) + 1e-4

    # The known +1 X pull correction must reduce the descriptor mismatch.
    correction = torch.zeros_like(zero)
    correction[:, 0] = 1.0
    corrected_loss = mind_weighted_loss(
        fixed_mind=d0,
        prewarped_moving_mind=d1,
        residual_dvf=correction,
        priority_map=ones,
        mind_cfg=mind_cfg,
    )
    assert float(corrected_loss) < float(shifted_loss) * 0.5

    support = _sphere(shape, (12, 11, 10), 8).unsqueeze(0).unsqueeze(0)
    confidence = torch.ones(1, 5, *shape)
    confidence[:, :, 10:15, 8:14, 7:13] = 0.15
    iface_dist = torch.ones(1, 3, *shape)
    iface_dist[:, 1, 11:13, :, :] = 0.0
    state_priority = {
        "fixed_support": support,
        "confidence_lobes": confidence,
        "consensus_interface_dist": iface_dist,
    }
    gate, diag, _ = build_priority_map(
        state=state_priority,
        fixed_mind=d0,
        prewarped_moving_mind=d1,
        cfg=priority_cfg,
    )
    assert gate.shape == (1, 1, *shape)
    assert torch.isfinite(gate).all()
    assert 0.0 <= float(gate.min()) <= float(gate.max()) <= 1.0
    assert diag["priority_fraction_gt_0_5"] > 0.0

    # Build a complete tiny state for objective/backward.
    lobes = torch.zeros(1, 5, *shape)
    bounds = [0, 5, 10, 15, 19, shape[0]]
    for c in range(5):
        lobes[:, c, bounds[c]:bounds[c + 1], :, :] = 1.0
    moving_lobes = torch.roll(lobes, shifts=1, dims=2)
    sdf = torch.tanh(torch.randn(1, 5, *shape) * 0.2)
    low = {
        "moving_ct": shifted,
        "fixed_ct": base,
        "moving_lobes": moving_lobes,
        "fixed_direct_lobes": lobes,
        "consensus_lobes": lobes.clone(),
        "confidence_lobes": confidence,
        "moving_support": support,
        "fixed_support": support,
        "moving_sdf": sdf,
        "consensus_sdf": sdf.clone(),
        "consensus_interface_dist": iface_dist,
        "init_dvf": zero,
    }
    low = prepare_mind_state(low, mind_cfg=mind_cfg, priority_cfg=priority_cfg)

    param = make_stage_parameter(shape, stage_cfg=stage_cfg, device=base.device, dtype=base.dtype)
    residual = build_localized_residual_dvf(
        param,
        target_shape=shape,
        full_shape=shape,
        stage_cfg=stage_cfg,
        priority_map=low["priority_map"],
        scale=1.0,
    )
    assert torch.allclose(residual, torch.zeros_like(residual), atol=1e-6)
    assert torch.allclose(compose_pull(zero, residual), zero, atol=1e-6)

    total, terms = objective_terms(
        state=low,
        residual_dvf=residual,
        weights=stage_cfg["weights"],
        ct_cfg=cfg["ct"],
        mind_cfg=mind_cfg,
        consensus_cfg=cfg["consensus"],
        anatomy_cfg=cfg["anatomy"],
    )
    assert torch.isfinite(total)
    total.backward()
    assert param.grad is not None and torch.isfinite(param.grad).all()

    baseline = {
        "mind_loss": 0.10,
        "direct_proxy_lobe_dice": 0.97,
        "consensus_balanced_lobe_dice": 0.96,
        "proxy_support_dice": 0.99,
        "lncc_loss": 0.15,
        "structural_gradient_loss": 0.30,
        "confidence_sdf_loss": 0.04,
    }
    good = {
        **baseline,
        "mind_loss": 0.09,
        "direct_proxy_lobe_dice": 0.9701,
        "consensus_balanced_lobe_dice": 0.9601,
        "lncc_loss": 0.149,
        "structural_gradient_loss": 0.299,
        "confidence_sdf_loss": 0.039,
        "folding_pct": 0.0,
        "residual_norm_p99_vox": 0.5,
        "residual_norm_max_vox": 1.0,
    }
    ok, reasons, _, score = passes_acceptance(
        good,
        baseline,
        baseline_folding_pct=0.0,
        selection=cfg["selection"],
    )
    assert ok, reasons
    assert score > 0.0

    bad = dict(good)
    bad["direct_proxy_lobe_dice"] = 0.968
    ok_bad, reasons_bad, _, _ = passes_acceptance(
        bad,
        baseline,
        baseline_folding_pct=0.0,
        selection=cfg["selection"],
    )
    assert not ok_bad and any("direct_proxy_lobe_drop" in r for r in reasons_bad)

    print("C5b-LMIND SYNTHETIC SMOKE: PASS")
    print(f"  descriptor_shape={tuple(d0.shape)}")
    print(f"  identity_mind_loss={float(identity_loss):.6f}")
    print(f"  shifted_mind_loss={float(shifted_loss):.6f}")
    print(f"  corrected_mind_loss={float(corrected_loss):.6f}")
    print(f"  priority_mean={diag['priority_mean']:.6f}")
    print("  objective_backward=PASS")
    print("  selector_guards=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
