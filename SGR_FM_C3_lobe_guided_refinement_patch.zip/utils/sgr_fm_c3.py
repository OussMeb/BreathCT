#!/usr/bin/env python3
"""Core geometry, loss, and asset helpers for SGR-FM C3.

C3 is intentionally segmentation-only: the refiner sees predicted support and
five-lobe masks after the accepted C1 initializer. No validation GT enters the
network inputs or optimization.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import random
import tempfile
from pathlib import Path
from typing import Any, Sequence

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F
from nibabel.orientations import aff2axcodes

from utils.refine_spatial import (
    downsample_dvf_5d,
    integrate_svf,
    jacobian_determinant,
    resize_volume_5d,
    upsample_dvf_5d,
    warp_volume,
)
from utils.sgr_fm_segmentation import atomic_write_json
from utils.sgr_fm_training_assets import load_yaml_or_json, recursive_update, resolve_under_project


LOBE_LABELS: tuple[int, ...] = (8, 16, 32, 64, 128)
EXPECTED_LABELS = {0, *LOBE_LABELS}
PHASE2_FREEZE_MARKER = ".sgr_fm_phase2_frozen.json"


def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def canonical_image(path: str | Path) -> nib.Nifti1Image:
    return nib.as_closest_canonical(nib.load(str(path)))


def _grid_tuple(image: nib.Nifti1Image) -> tuple[tuple[int, ...], np.ndarray, tuple[str, ...]]:
    return (
        tuple(int(v) for v in image.shape[:3]),
        np.asarray(image.affine, dtype=np.float64),
        tuple(str(v) for v in aff2axcodes(image.affine)),
    )


def assert_same_canonical_grid(
    candidate: nib.Nifti1Image,
    reference: nib.Nifti1Image,
    *,
    name: str,
    affine_atol: float = 1e-5,
) -> None:
    cshape, caff, cax = _grid_tuple(candidate)
    rshape, raff, rax = _grid_tuple(reference)
    if cshape != rshape or not np.allclose(caff, raff, atol=affine_atol, rtol=0.0):
        raise RuntimeError(
            f"{name}: canonical grid mismatch shape={cshape} vs {rshape}, "
            f"axcodes={cax} vs {rax}, max_affine_diff={float(np.max(np.abs(caff-raff))):.6g}"
        )
    if cax != ("R", "A", "S") or rax != ("R", "A", "S"):
        raise RuntimeError(f"{name}: expected canonical RAS grids, got {cax} and {rax}")


def load_canonical_label(
    label_path: str | Path,
    reference_ct_path: str | Path,
    *,
    affine_atol: float = 1e-5,
) -> tuple[np.ndarray, nib.Nifti1Image]:
    label_img = canonical_image(label_path)
    ref_img = canonical_image(reference_ct_path)
    assert_same_canonical_grid(label_img, ref_img, name=f"label {label_path}", affine_atol=affine_atol)
    data = np.asanyarray(label_img.dataobj)
    if data.ndim != 3 or not np.isfinite(data).all():
        raise ValueError(f"Invalid label array {data.shape}: {label_path}")
    rounded = np.rint(data).astype(np.int16, copy=False)
    labels = set(int(v) for v in np.unique(rounded))
    if not labels.issubset(EXPECTED_LABELS):
        raise ValueError(f"Unexpected lobe labels {sorted(labels)}: {label_path}")
    return rounded, label_img


def load_canonical_support(
    support_path: str | Path,
    reference_ct_path: str | Path,
    *,
    affine_atol: float = 1e-5,
) -> tuple[np.ndarray, nib.Nifti1Image]:
    support_img = canonical_image(support_path)
    ref_img = canonical_image(reference_ct_path)
    assert_same_canonical_grid(support_img, ref_img, name=f"support {support_path}", affine_atol=affine_atol)
    data = np.asanyarray(support_img.dataobj)
    if data.ndim != 3 or not np.isfinite(data).all():
        raise ValueError(f"Invalid support array {data.shape}: {support_path}")
    return (data > 0).astype(np.float32), support_img


def load_canonical_dvf(
    dvf_path: str | Path,
    fixed_ct_path: str | Path,
    *,
    affine_atol: float = 1e-5,
) -> tuple[np.ndarray, nib.Nifti1Image]:
    image = nib.load(str(dvf_path))
    fixed = canonical_image(fixed_ct_path)
    if image.ndim != 4 or image.shape[-1] != 3:
        raise ValueError(f"Expected XYZC DVF, got {image.shape}: {dvf_path}")
    assert_same_canonical_grid(image, fixed, name=f"C1 DVF {dvf_path}", affine_atol=affine_atol)
    data = np.asanyarray(image.dataobj).astype(np.float32)
    if not np.isfinite(data).all():
        raise ValueError(f"Non-finite DVF: {dvf_path}")
    return data, image


def labels_to_one_hot(labels: np.ndarray, *, device: torch.device | None = None) -> torch.Tensor:
    array = torch.as_tensor(np.asarray(labels, dtype=np.int16), dtype=torch.int64, device=device)
    channels = [(array == int(label)).float() for label in LOBE_LABELS]
    return torch.stack(channels, dim=0).unsqueeze(0)  # [1,5,X,Y,Z]


def support_to_tensor(support: np.ndarray, *, device: torch.device | None = None) -> torch.Tensor:
    return torch.as_tensor(np.asarray(support, dtype=np.float32), device=device).unsqueeze(0).unsqueeze(0)


def dvf_xyzc_to_tensor(dvf: np.ndarray, *, device: torch.device | None = None) -> torch.Tensor:
    if dvf.ndim != 4 or dvf.shape[-1] != 3:
        raise ValueError(f"Expected XYZC DVF, got {dvf.shape}")
    return torch.as_tensor(np.moveaxis(dvf.astype(np.float32, copy=False), -1, 0), device=device).unsqueeze(0)


def dvf_tensor_to_xyzc(dvf: torch.Tensor) -> np.ndarray:
    if dvf.ndim != 5 or dvf.shape[0] != 1 or dvf.shape[1] != 3:
        raise ValueError(f"Expected [1,3,X,Y,Z], got {tuple(dvf.shape)}")
    return dvf.detach().cpu().squeeze(0).permute(1, 2, 3, 0).numpy().astype(np.float32, copy=False)


def compose_pull(init_dvf: torch.Tensor, residual_dvf: torch.Tensor) -> torch.Tensor:
    """Exact pull composition for residual refinement in the fixed frame.

    Initial pull: T0(x)=x+u0(x).
    Residual pull on the C1-warped image: R(x)=x+r(x).
    Final pull: T0(R(x)) = x + r(x) + u0(x+r(x)).
    """
    if init_dvf.shape != residual_dvf.shape:
        raise ValueError(f"Composition shape mismatch {tuple(init_dvf.shape)} vs {tuple(residual_dvf.shape)}")
    return residual_dvf + warp_volume(init_dvf, residual_dvf, mode="bilinear")


def residual_bound_lowres(
    full_shape: Sequence[int],
    low_shape: Sequence[int],
    max_fullres_voxels: float,
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    bounds: list[float] = []
    for full_dim, low_dim in zip(full_shape, low_shape):
        if int(full_dim) <= 1 or int(low_dim) <= 1:
            bounds.append(float(max_fullres_voxels))
        else:
            full_per_low = (float(full_dim) - 1.0) / (float(low_dim) - 1.0)
            bounds.append(float(max_fullres_voxels) / full_per_low)
    return torch.tensor(bounds, device=device, dtype=dtype).view(1, 3, 1, 1, 1)



def downsample_label_one_hot(
    labels: np.ndarray,
    *,
    reduce_factor: int,
    device: torch.device,
) -> torch.Tensor:
    """Nearest-downsample an integer lobe map, then expand to five channels."""
    tensor = torch.as_tensor(np.asarray(labels, dtype=np.float32), device=device).unsqueeze(0).unsqueeze(0)
    low = resize_volume_5d(tensor, int(reduce_factor), mode="nearest")[:, 0].to(dtype=torch.int64)
    return torch.stack([(low == int(label)).float() for label in LOBE_LABELS], dim=1)


def downsample_support_tensor(
    support: np.ndarray,
    *,
    reduce_factor: int,
    device: torch.device,
) -> torch.Tensor:
    tensor = torch.as_tensor(np.asarray(support, dtype=np.float32), device=device).unsqueeze(0).unsqueeze(0)
    return resize_volume_5d(tensor, int(reduce_factor), mode="nearest")


def build_lowres_state(
    moving_lobes_low: torch.Tensor,
    fixed_lobes_low: torch.Tensor,
    moving_support_low: torch.Tensor,
    fixed_support_low: torch.Tensor,
    init_dvf_low: torch.Tensor,
) -> dict[str, torch.Tensor]:
    warped_lobes0 = warp_volume(moving_lobes_low, init_dvf_low, mode="bilinear")
    warped_support0 = warp_volume(moving_support_low, init_dvf_low, mode="bilinear")
    mismatch = (fixed_lobes_low - warped_lobes0).abs()
    inputs = torch.cat([fixed_lobes_low, warped_lobes0, mismatch, fixed_support_low, warped_support0], dim=1)
    return {
        "moving_lobes": moving_lobes_low,
        "fixed_lobes": fixed_lobes_low,
        "moving_support": moving_support_low,
        "fixed_support": fixed_support_low,
        "init_dvf": init_dvf_low,
        "warped_lobes0": warped_lobes0,
        "warped_support0": warped_support0,
        "inputs": inputs,
    }

def prepare_lowres_state(
    moving_lobes: torch.Tensor,
    fixed_lobes: torch.Tensor,
    moving_support: torch.Tensor,
    fixed_support: torch.Tensor,
    init_dvf: torch.Tensor,
    *,
    reduce_factor: int,
) -> dict[str, torch.Tensor]:
    if reduce_factor < 1:
        raise ValueError(f"reduce_factor must be >=1, got {reduce_factor}")
    moving_low = resize_volume_5d(moving_lobes, reduce_factor, mode="nearest")
    fixed_low = resize_volume_5d(fixed_lobes, reduce_factor, mode="nearest")
    moving_support_low = resize_volume_5d(moving_support, reduce_factor, mode="nearest")
    fixed_support_low = resize_volume_5d(fixed_support, reduce_factor, mode="nearest")
    init_low = downsample_dvf_5d(init_dvf, reduce_factor)
    return build_lowres_state(
        moving_low, fixed_low, moving_support_low, fixed_support_low, init_low
    )


def bounded_residual_svf(
    unit_svf: torch.Tensor,
    *,
    full_shape: Sequence[int],
    max_fullres_voxels: float,
    integration_steps: int,
) -> torch.Tensor:
    bound = residual_bound_lowres(
        full_shape,
        unit_svf.shape[-3:],
        max_fullres_voxels,
        device=unit_svf.device,
        dtype=unit_svf.dtype,
    )
    svf = unit_svf * bound
    return integrate_svf(svf, int(integration_steps))


def soft_dice_per_lobe(pred: torch.Tensor, target: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    if pred.shape != target.shape or pred.ndim != 5 or pred.shape[1] != len(LOBE_LABELS):
        raise ValueError(f"Expected matching [B,5,X,Y,Z], got {tuple(pred.shape)} and {tuple(target.shape)}")
    dims = (0, 2, 3, 4)
    intersection = (pred * target).sum(dim=dims)
    denom = pred.sum(dim=dims) + target.sum(dim=dims)
    return (2.0 * intersection + eps) / (denom + eps)


def soft_lobe_dice_loss(pred: torch.Tensor, target: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    dice = soft_dice_per_lobe(pred, target)
    return 1.0 - dice.mean(), dice


def soft_boundary_union(prob: torch.Tensor, dilation_voxels: int = 1) -> torch.Tensor:
    if prob.ndim != 5:
        raise ValueError(f"Expected [B,C,X,Y,Z], got {tuple(prob.shape)}")
    local_max = F.max_pool3d(prob, kernel_size=3, stride=1, padding=1)
    local_min = -F.max_pool3d(-prob, kernel_size=3, stride=1, padding=1)
    boundary = (local_max - local_min).clamp(0.0, 1.0).amax(dim=1, keepdim=True)
    for _ in range(max(0, int(dilation_voxels))):
        boundary = F.max_pool3d(boundary, kernel_size=3, stride=1, padding=1)
    return boundary.clamp(0.0, 1.0)


def binary_soft_dice_loss(pred: torch.Tensor, target: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    dims = tuple(range(1, pred.ndim))
    inter = (pred * target).sum(dim=dims)
    denom = pred.sum(dim=dims) + target.sum(dim=dims)
    dice = (2.0 * inter + eps) / (denom + eps)
    return 1.0 - dice.mean()


def bending_energy(field: torch.Tensor) -> torch.Tensor:
    def diff(x: torch.Tensor, dim: int) -> torch.Tensor:
        return torch.diff(x, dim=dim)
    terms: list[torch.Tensor] = []
    for dim in (-3, -2, -1):
        first = diff(field, dim)
        if first.shape[dim] > 1:
            second = diff(first, dim)
            terms.append(second.square().mean())
    if not terms:
        return field.square().mean() * 0.0
    return torch.stack(terms).sum()


def jacobian_barrier(
    dvf: torch.Tensor,
    *,
    margin: float = 0.05,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    det = jacobian_determinant(dvf)
    loss = F.relu(float(margin) - det).square().mean()
    folding_pct = (det <= 0.0).float().mean() * 100.0
    min_det = det.amin()
    return loss, folding_pct, min_det


def hard_mean_lobe_dice(pred_prob: torch.Tensor, target: torch.Tensor, threshold: float = 0.5) -> torch.Tensor:
    if pred_prob.shape != target.shape:
        raise ValueError("pred/target shape mismatch")
    values: list[torch.Tensor] = []
    for channel in range(pred_prob.shape[1]):
        pred = pred_prob[:, channel] >= float(threshold)
        truth = target[:, channel] > 0.5
        inter = (pred & truth).sum(dtype=torch.float32)
        denom = pred.sum(dtype=torch.float32) + truth.sum(dtype=torch.float32)
        values.append(torch.where(denom > 0, 2.0 * inter / denom, torch.ones_like(denom)))
    return torch.stack(values).mean()


def deterministic_case_split(
    case_ids: Sequence[str],
    *,
    holdout_count: int,
    seed: int,
) -> tuple[list[str], list[str]]:
    ids = sorted({str(v) for v in case_ids})
    if holdout_count < 1 or holdout_count >= len(ids):
        raise ValueError(f"holdout_count must be in [1,{len(ids)-1}], got {holdout_count}")
    rng = random.Random(int(seed))
    shuffled = list(ids)
    rng.shuffle(shuffled)
    holdout = sorted(shuffled[: int(holdout_count)])
    train = sorted(shuffled[int(holdout_count) :])
    return train, holdout


def split_fingerprint(train_ids: Sequence[str], holdout_ids: Sequence[str], seed: int) -> str:
    return sha256_json({"seed": int(seed), "train": list(train_ids), "holdout": list(holdout_ids)})


def phase2_asset_paths(segmentation_dir: Path, c1_dir: Path, case_id: str, phase: str) -> dict[str, Path]:
    stem = f"{case_id}_{phase}"
    return {
        "support": segmentation_dir / "support" / "training" / f"{stem}_support.nii.gz",
        "lobes": segmentation_dir / "lobes" / "training" / f"{stem}_lobes.nii.gz",
        "interfaces": segmentation_dir / "interfaces" / "training" / f"{stem}_lobe_interfaces.nii.gz",
        "c1_dvf": c1_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz",
    }


def validation_asset_paths(segmentation_dir: Path, c1_dir: Path, case_id: str, phase: str) -> dict[str, Path]:
    stem = f"{case_id}_{phase}"
    return {
        "support": segmentation_dir / "support" / "validation" / f"{stem}_support.nii.gz",
        "lobes": segmentation_dir / "lobes" / "validation" / f"{stem}_lobes.nii.gz",
        "interfaces": segmentation_dir / "interfaces" / "validation" / f"{stem}_lobe_interfaces.nii.gz",
        "c1_dvf": c1_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz",
    }


def atomic_save_nifti_xyzc(data: np.ndarray, reference_img: nib.Nifti1Image, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=output_path.name + ".tmp.", suffix=".nii.gz", dir=output_path.parent, delete=False) as handle:
        tmp = Path(handle.name)
    try:
        image = nib.Nifti1Image(np.asarray(data, dtype=np.float32), reference_img.affine, header=reference_img.header.copy())
        image.header.set_data_dtype(np.float32)
        image.header.set_slope_inter(1.0, 0.0)
        _, qcode = reference_img.get_qform(coded=True)
        _, scode = reference_img.get_sform(coded=True)
        image.set_qform(reference_img.affine, code=int(qcode or 1))
        image.set_sform(reference_img.affine, code=int(scode or 1))
        nib.save(image, str(tmp))
        os.replace(tmp, output_path)
    finally:
        tmp.unlink(missing_ok=True)


def check_phase2_freeze(
    *,
    project_root: Path,
    manifest_value: str | Path,
    segmentation_dir: Path,
    c1_dir: Path,
    require: bool = True,
) -> dict[str, Any]:
    manifest = resolve_under_project(project_root, manifest_value)
    result: dict[str, Any] = {"manifest": str(manifest), "manifest_present": manifest.exists()}
    if not manifest.exists():
        if require:
            raise FileNotFoundError(f"Phase-2 freeze manifest required: {manifest}")
        result["ok"] = False
        return result
    payload = json.loads(manifest.read_text(encoding="utf-8"))
    marker_paths = [segmentation_dir / PHASE2_FREEZE_MARKER, c1_dir / PHASE2_FREEZE_MARKER]
    markers = {str(path): path.exists() for path in marker_paths}
    status_ok = str(payload.get("status", "")).lower() == "frozen"
    tracked = payload.get("tracked_file_count")
    count_ok = tracked in (None, 1400)
    result.update({"status": payload.get("status"), "tracked_file_count": tracked, "markers": markers})
    result["ok"] = bool(status_ok and count_ok and all(markers.values()))
    if require and not result["ok"]:
        raise RuntimeError(
            f"Phase-2 freeze check failed: status={payload.get('status')} "
            f"tracked_file_count={tracked} markers={markers}"
        )
    return result


def load_c3_config(config_path: str | Path, root_key: str = "sgr_fm_c3") -> dict[str, Any]:
    return load_yaml_or_json(config_path, root_key)


def compare_metric_jsons(baseline_path: Path, candidate_path: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    candidate = json.loads(candidate_path.read_text(encoding="utf-8"))
    bcases = {row["case_id"]: row for row in baseline.get("case_metrics", [])}
    ccases = {row["case_id"]: row for row in candidate.get("case_metrics", [])}
    common = sorted(set(bcases) & set(ccases))
    rows: list[dict[str, Any]] = []
    for case_id in common:
        b = bcases[case_id]
        c = ccases[case_id]
        rows.append({
            "case_id": case_id,
            "C1_mean_lobe_dice": float(b["mean_lobe_dice"]),
            "C3_mean_lobe_dice": float(c["mean_lobe_dice"]),
            "delta_mean_lobe_dice": float(c["mean_lobe_dice"] - b["mean_lobe_dice"]),
            "C1_folding_percentage": float(b["folding_percentage"]),
            "C3_folding_percentage": float(c["folding_percentage"]),
            "delta_folding_percentage": float(c["folding_percentage"] - b["folding_percentage"]),
        })
    deltas = [r["delta_mean_lobe_dice"] for r in rows]
    summary = {
        "common_case_count": len(rows),
        "C1_mean_lobe_dice": float(baseline["mean_lobe_dice"]),
        "C3_mean_lobe_dice": float(candidate["mean_lobe_dice"]),
        "delta_mean_lobe_dice": float(candidate["mean_lobe_dice"] - baseline["mean_lobe_dice"]),
        "C1_mean_folding_percentage": float(baseline["mean_folding_percentage"]),
        "C3_mean_folding_percentage": float(candidate["mean_folding_percentage"]),
        "delta_mean_folding_percentage": float(candidate["mean_folding_percentage"] - baseline["mean_folding_percentage"]),
        "improved_cases": int(sum(v > 0 for v in deltas)),
        "unchanged_cases": int(sum(math.isclose(v, 0.0, abs_tol=1e-12) for v in deltas)),
        "worsened_cases": int(sum(v < 0 for v in deltas)),
        "min_paired_dice_delta": float(min(deltas)) if deltas else None,
        "max_paired_dice_delta": float(max(deltas)) if deltas else None,
    }
    return summary, rows
