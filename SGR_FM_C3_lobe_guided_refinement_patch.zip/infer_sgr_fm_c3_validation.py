#!/usr/bin/env python3
"""Run frozen-checkpoint C3 refinement on validation using predicted masks only."""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.sgr_fm_lobe_refiner import SGRFMLobeRefiner3d
from utils.data import discover_validation_cases
from utils.dvf_io import canonical_ras_cxyz_to_original_dvf_xyzc, save_dvf_xyzc
from utils.metrics import jacobian_stats
from utils.refine_spatial import downsample_dvf_5d, upsample_dvf_5d
from utils.sgr_fm_c3 import (
    atomic_save_nifti_xyzc,
    bounded_residual_svf,
    build_lowres_state,
    compare_metric_jsons,
    compose_pull,
    dvf_tensor_to_xyzc,
    dvf_xyzc_to_tensor,
    downsample_label_one_hot,
    downsample_support_tensor,
    load_canonical_dvf,
    load_canonical_label,
    load_canonical_support,
    validation_asset_paths,
)
from utils.sgr_fm_segmentation import atomic_write_json, write_csv
from utils.sgr_fm_training_assets import resolve_under_project


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Infer SGR-FM C3 on validation")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--raw-data-root")
    p.add_argument("--segmentation-dir")
    p.add_argument("--c1-dir")
    p.add_argument("--output-dir")
    p.add_argument("--case-ids", nargs="*")
    p.add_argument("--device")
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--no-evaluate", action="store_true")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    checkpoint_path = Path(args.checkpoint).expanduser().resolve()
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    cfg: dict[str, Any] = checkpoint["config"]

    raw_root = resolve_under_project(PROJECT_ROOT, args.raw_data_root or cfg["raw_data_root"])
    seg_dir = resolve_under_project(
        PROJECT_ROOT,
        args.segmentation_dir or "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
    )
    c1_dir = resolve_under_project(
        PROJECT_ROOT,
        args.c1_dir or "outputs/sgr_fm/ablation_C1_support_guided_fm",
    )
    output_dir = resolve_under_project(
        PROJECT_ROOT,
        args.output_dir or "outputs/sgr_fm/c3_lobe_refinement/validation",
    )
    dvf_dir = output_dir / "dvfs"
    canonical_dir = output_dir / "dvfs_canonical_ras"
    dvf_dir.mkdir(parents=True, exist_ok=True)
    canonical_dir.mkdir(parents=True, exist_ok=True)

    requested_device = args.device or str(cfg["train"]["device"])
    device = torch.device(requested_device if requested_device == "cpu" or torch.cuda.is_available() else "cpu")
    model = SGRFMLobeRefiner3d(
        in_channels=int(cfg["model"]["input_channels"]),
        base_channels=int(cfg["model"]["base_channels"]),
        max_channels=int(cfg["model"]["max_channels"]),
    ).to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()

    cases = discover_validation_cases(raw_root)
    requested = set(args.case_ids or [])
    if requested:
        cases = [c for c in cases if c.case_id in requested]
        missing = sorted(requested - {c.case_id for c in cases})
        if missing:
            raise FileNotFoundError(f"Requested cases not found: {missing}")

    records: list[dict[str, Any]] = []
    started = time.time()
    with torch.no_grad():
        for index, case in enumerate(cases, 1):
            print(f"[{index:02d}/{len(cases):02d}] {case.case_id}", flush=True)
            output_path = dvf_dir / f"{case.case_id}_DVF.nii.gz"
            canonical_path = canonical_dir / f"{case.case_id}_DVF_RAS_XYZC_voxel.nii.gz"
            record: dict[str, Any] = {"case_id": case.case_id, "status": "started"}
            if output_path.exists() and canonical_path.exists() and not args.overwrite:
                record.update({"status": "exists", "dvf": str(output_path), "canonical_dvf": str(canonical_path)})
                records.append(record)
                continue

            exp = validation_asset_paths(seg_dir, c1_dir, case.case_id, "EXP")
            insp = validation_asset_paths(seg_dir, c1_dir, case.case_id, "INSP")
            moving_label, moving_img = load_canonical_label(exp["lobes"], case.exp_ct)
            fixed_label, fixed_img = load_canonical_label(insp["lobes"], case.insp_ct)
            moving_support, _ = load_canonical_support(exp["support"], case.exp_ct)
            fixed_support, _ = load_canonical_support(insp["support"], case.insp_ct)
            if moving_label.shape != fixed_label.shape or not np.allclose(moving_img.affine, fixed_img.affine, atol=1e-5, rtol=0.0):
                raise RuntimeError(f"{case.case_id}: canonical EXP/INSP segmentation grids differ")
            init_xyzc, _ = load_canonical_dvf(exp["c1_dvf"], case.insp_ct)

            reduce_factor = int(cfg["cache"]["reduce_factor"])
            moving_low = downsample_label_one_hot(moving_label, reduce_factor=reduce_factor, device=device)
            fixed_low = downsample_label_one_hot(fixed_label, reduce_factor=reduce_factor, device=device)
            moving_sup_low = downsample_support_tensor(moving_support, reduce_factor=reduce_factor, device=device)
            fixed_sup_low = downsample_support_tensor(fixed_support, reduce_factor=reduce_factor, device=device)
            init = dvf_xyzc_to_tensor(init_xyzc, device=device)
            init_low = downsample_dvf_5d(init, reduce_factor)
            state = build_lowres_state(moving_low, fixed_low, moving_sup_low, fixed_sup_low, init_low)
            unit_svf = model(state["inputs"])
            residual_low = bounded_residual_svf(
                unit_svf,
                full_shape=init.shape[-3:],
                max_fullres_voxels=float(cfg["model"]["max_residual_fullres_voxels"]),
                integration_steps=int(cfg["model"]["integration_steps"]),
            )
            residual_full = upsample_dvf_5d(residual_low, tuple(int(v) for v in init.shape[-3:]))
            final = compose_pull(init, residual_full)
            final_xyzc = dvf_tensor_to_xyzc(final)
            if not np.isfinite(final_xyzc).all():
                raise RuntimeError(f"{case.case_id}: non-finite C3 DVF")

            atomic_save_nifti_xyzc(final_xyzc, fixed_img, canonical_path)
            original_xyzc = canonical_ras_cxyz_to_original_dvf_xyzc(np.moveaxis(final_xyzc, -1, 0), case.insp_ct)
            save_dvf_xyzc(original_xyzc, case.insp_ct, output_path)

            topology = jacobian_stats(final.detach().cpu())
            record.update({
                "status": "ok",
                "dvf": str(output_path),
                "canonical_dvf": str(canonical_path),
                "checkpoint": str(checkpoint_path),
                "checkpoint_epoch": int(checkpoint.get("epoch", -1)),
                "residual_full_abs_max_vox": float(residual_full.abs().amax().cpu()),
                "jacobian": topology,
            })
            records.append(record)

    complete = len(cases) == 10 and all(r["status"] in {"ok", "exists"} for r in records)
    evaluation: dict[str, Any] = {"status": "skipped"}
    comparison: dict[str, Any] | None = None
    if complete and not args.no_evaluate:
        eval_dir = output_dir / "eval"
        cmd = [
            sys.executable,
            str(PROJECT_ROOT / "evaluate_validation.py"),
            "--raw-data-root", str(raw_root),
            "--dvf-dir", str(dvf_dir),
            "--output-dir", str(eval_dir),
            "--device", str(device),
        ]
        proc = subprocess.run(cmd, cwd=str(PROJECT_ROOT), capture_output=True, text=True)
        (output_dir / "evaluate_validation.log").write_text(
            "$ " + " ".join(cmd) + "\n\n" + proc.stdout + "\n[stderr]\n" + proc.stderr,
            encoding="utf-8",
        )
        if proc.returncode != 0:
            raise RuntimeError(f"Validation evaluator failed with exit code {proc.returncode}")
        metrics_path = eval_dir / "validation_metrics.json"
        evaluation = {"status": "PASS", "metrics_json": str(metrics_path), "exit_code": proc.returncode}

        c1_metrics = c1_dir / "eval" / "validation_metrics.json"
        if c1_metrics.exists():
            comparison_summary, comparison_rows = compare_metric_jsons(c1_metrics, metrics_path)
            comparison_dir = output_dir / "comparison"
            comparison_dir.mkdir(parents=True, exist_ok=True)
            atomic_write_json(comparison_dir / "C1_vs_C3_summary.json", comparison_summary)
            write_csv(comparison_dir / "C1_vs_C3_per_case.csv", comparison_rows)
            comparison = comparison_summary
        else:
            evaluation["comparison_warning"] = f"C1 metrics not found: {c1_metrics}"
    elif not complete:
        evaluation = {"status": "skipped_partial_run", "case_count": len(cases)}

    summary = {
        "schema_version": 1,
        "experiment": "SGR-FM C3 lobe-guided residual SVF validation",
        "status": "PASS" if all(r["status"] in {"ok", "exists"} for r in records) else "FAIL",
        "case_count": len(cases),
        "checkpoint": str(checkpoint_path),
        "checkpoint_epoch": int(checkpoint.get("epoch", -1)),
        "records": records,
        "evaluation": evaluation,
        "comparison": comparison,
        "elapsed_sec": time.time() - started,
        "output_dir": str(output_dir),
    }
    atomic_write_json(output_dir / "c3_validation_summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if summary["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
