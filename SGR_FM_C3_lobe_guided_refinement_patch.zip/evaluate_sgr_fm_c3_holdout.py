#!/usr/bin/env python3
"""Full-resolution C3 audit on the 40-case internal training holdout.

Uses predicted training lobes as proxy anatomy. No validation cases or GT labels
are touched. The purpose is checkpoint selection and topology verification
before any C3 validation run.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.sgr_fm_lobe_refiner import SGRFMLobeRefiner3d
from utils.data import discover_training_cases
from utils.metrics import jacobian_stats
from utils.refine_spatial import downsample_dvf_5d, upsample_dvf_5d, warp_volume
from utils.sgr_fm_c3 import (
    bounded_residual_svf,
    build_lowres_state,
    compose_pull,
    downsample_label_one_hot,
    downsample_support_tensor,
    dvf_xyzc_to_tensor,
    load_canonical_dvf,
    load_canonical_label,
    load_canonical_support,
    phase2_asset_paths,
)
from utils.sgr_fm_segmentation import atomic_write_json, write_csv
from utils.sgr_fm_training_assets import resolve_under_project


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Evaluate C3 on internal full-resolution holdout")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--raw-data-root")
    p.add_argument("--segmentation-dir")
    p.add_argument("--c1-dir")
    p.add_argument("--output-dir")
    p.add_argument("--device")
    return p.parse_args()


def mean_lobe_dice_torch(warped: torch.Tensor, fixed: torch.Tensor) -> float:
    values: list[torch.Tensor] = []
    for label in (8, 16, 32, 64, 128):
        pred = warped == float(label)
        truth = fixed == int(label)
        inter = (pred & truth).sum(dtype=torch.float32)
        denom = pred.sum(dtype=torch.float32) + truth.sum(dtype=torch.float32)
        values.append(torch.where(denom > 0, 2.0 * inter / denom, torch.ones_like(denom)))
    return float(torch.stack(values).mean().cpu())


def main() -> int:
    args = parse_args()
    checkpoint_path = Path(args.checkpoint).expanduser().resolve()
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    cfg: dict[str, Any] = checkpoint["config"]
    split = checkpoint.get("split")
    if not isinstance(split, dict) or not split.get("holdout_case_ids"):
        raise RuntimeError("Checkpoint does not contain the deterministic holdout split")
    holdout_ids = set(str(v) for v in split["holdout_case_ids"])

    raw_root = resolve_under_project(PROJECT_ROOT, args.raw_data_root or cfg["raw_data_root"])
    seg_dir = resolve_under_project(PROJECT_ROOT, args.segmentation_dir or cfg["segmentation_dir"])
    c1_dir = resolve_under_project(PROJECT_ROOT, args.c1_dir or cfg["c1_dir"])
    output_dir = resolve_under_project(
        PROJECT_ROOT,
        args.output_dir or f"outputs/sgr_fm/c3_lobe_refinement/holdout_epoch_{int(checkpoint.get('epoch', -1)):03d}",
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    requested_device = args.device or str(cfg["train"]["device"])
    device = torch.device(requested_device if requested_device == "cpu" or torch.cuda.is_available() else "cpu")
    model = SGRFMLobeRefiner3d(
        in_channels=int(cfg["model"]["input_channels"]),
        base_channels=int(cfg["model"]["base_channels"]),
        max_channels=int(cfg["model"]["max_channels"]),
    ).to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()

    cases = [c for c in discover_training_cases(raw_root) if c.case_id in holdout_ids]
    if len(cases) != len(holdout_ids):
        missing = sorted(holdout_ids - {c.case_id for c in cases})
        raise RuntimeError(f"Holdout discovery mismatch; missing={missing}")

    rows: list[dict[str, Any]] = []
    started = time.time()
    reduce_factor = int(cfg["cache"]["reduce_factor"])
    with torch.no_grad():
        for idx, case in enumerate(cases, 1):
            print(f"[{idx:02d}/{len(cases):02d}] {case.case_id}", flush=True)
            exp = phase2_asset_paths(seg_dir, c1_dir, case.case_id, "EXP")
            insp = phase2_asset_paths(seg_dir, c1_dir, case.case_id, "INSP")
            moving_label, moving_img = load_canonical_label(exp["lobes"], case.exp_ct)
            fixed_label, fixed_img = load_canonical_label(insp["lobes"], case.insp_ct)
            moving_support, _ = load_canonical_support(exp["support"], case.exp_ct)
            fixed_support, _ = load_canonical_support(insp["support"], case.insp_ct)
            if moving_label.shape != fixed_label.shape or not np.allclose(moving_img.affine, fixed_img.affine, atol=1e-5, rtol=0.0):
                raise RuntimeError(f"{case.case_id}: canonical EXP/INSP grids differ")
            init_xyzc, _ = load_canonical_dvf(exp["c1_dvf"], case.insp_ct)

            moving_low = downsample_label_one_hot(moving_label, reduce_factor=reduce_factor, device=device)
            fixed_low = downsample_label_one_hot(fixed_label, reduce_factor=reduce_factor, device=device)
            moving_sup_low = downsample_support_tensor(moving_support, reduce_factor=reduce_factor, device=device)
            fixed_sup_low = downsample_support_tensor(fixed_support, reduce_factor=reduce_factor, device=device)
            init = dvf_xyzc_to_tensor(init_xyzc, device=device)
            init_low = downsample_dvf_5d(init, reduce_factor)
            state = build_lowres_state(moving_low, fixed_low, moving_sup_low, fixed_sup_low, init_low)

            unit_svf = model(state["inputs"])
            residual_low = bounded_residual_svf(
                unit_svf,
                full_shape=init.shape[-3:],
                max_fullres_voxels=float(cfg["model"]["max_residual_fullres_voxels"]),
                integration_steps=int(cfg["model"]["integration_steps"]),
            )
            residual_full = upsample_dvf_5d(residual_low, tuple(int(v) for v in init.shape[-3:]))
            final = compose_pull(init, residual_full)

            moving_scalar = torch.as_tensor(moving_label.astype(np.float32), device=device).unsqueeze(0).unsqueeze(0)
            fixed_scalar = torch.as_tensor(fixed_label.astype(np.int64), device=device)
            warped_c1 = warp_volume(moving_scalar, init, mode="nearest")[0, 0]
            warped_c3 = warp_volume(moving_scalar, final, mode="nearest")[0, 0]
            c1_dice = mean_lobe_dice_torch(warped_c1, fixed_scalar)
            c3_dice = mean_lobe_dice_torch(warped_c3, fixed_scalar)
            jac = jacobian_stats(final.detach().cpu())
            rows.append({
                "case_id": case.case_id,
                "C1_proxy_mean_lobe_dice": c1_dice,
                "C3_proxy_mean_lobe_dice": c3_dice,
                "delta_proxy_mean_lobe_dice": c3_dice - c1_dice,
                "C3_folding_percentage": float(jac["folding_percentage"]),
                "C3_jac_min": float(jac["min"]),
                "residual_full_abs_max_vox": float(residual_full.abs().amax().cpu()),
            })

    c1_values = [r["C1_proxy_mean_lobe_dice"] for r in rows]
    c3_values = [r["C3_proxy_mean_lobe_dice"] for r in rows]
    deltas = [r["delta_proxy_mean_lobe_dice"] for r in rows]
    folds = [r["C3_folding_percentage"] for r in rows]
    summary = {
        "schema_version": 1,
        "experiment": "SGR-FM C3 full-resolution internal holdout audit",
        "status": "PASS",
        "case_count": len(rows),
        "checkpoint": str(checkpoint_path),
        "checkpoint_epoch": int(checkpoint.get("epoch", -1)),
        "C1_proxy_mean_lobe_dice": float(np.mean(c1_values)),
        "C3_proxy_mean_lobe_dice": float(np.mean(c3_values)),
        "delta_proxy_mean_lobe_dice": float(np.mean(deltas)),
        "improved_cases": int(sum(v > 0 for v in deltas)),
        "unchanged_cases": int(sum(abs(v) <= 1e-12 for v in deltas)),
        "worsened_cases": int(sum(v < 0 for v in deltas)),
        "min_case_delta": float(np.min(deltas)),
        "max_case_delta": float(np.max(deltas)),
        "mean_folding_percentage": float(np.mean(folds)),
        "max_folding_percentage": float(np.max(folds)),
        "elapsed_sec": time.time() - started,
        "output_dir": str(output_dir),
    }
    atomic_write_json(output_dir / "c3_holdout_summary.json", summary)
    atomic_write_json(output_dir / "c3_holdout_metrics.json", {"summary": summary, "rows": rows})
    write_csv(output_dir / "c3_holdout_per_case.csv", rows)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
