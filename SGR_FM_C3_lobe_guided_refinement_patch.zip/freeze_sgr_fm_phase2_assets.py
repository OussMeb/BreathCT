#!/usr/bin/env python3
"""Freeze and verify the accepted SGR-FM Phase-2 training assets.

Tracks 400 support masks, 400 five-lobe masks, 400 interface maps, and 200
canonical-RAS C1 DVFs. The manifest is written outside tracked repositories.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 1
MARKER_NAME = ".sgr_fm_phase2_frozen.json"
DEFAULT_MANIFEST = Path("outputs/sgr_fm/frozen_assets/phase2_assets_freeze_manifest.json")
DEFAULT_REPORT = Path("outputs/sgr_fm/frozen_assets/phase2_assets_verify_report.json")


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name + ".", suffix=".tmp", delete=False) as f:
        tmp = Path(f.name)
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def specs(project_root: Path) -> list[dict[str, Any]]:
    seg = project_root / "outputs/sgr_fm/segmentation_phase1_totalsegmentator_training"
    c1 = project_root / "outputs/sgr_fm/c1_support_guided_training"
    return [
        {"name": "support", "path": seg / "support/training", "pattern": "NLST_*_support.nii.gz", "expected": 400, "marker_root": seg},
        {"name": "lobes", "path": seg / "lobes/training", "pattern": "NLST_*_lobes.nii.gz", "expected": 400, "marker_root": seg},
        {"name": "interfaces", "path": seg / "interfaces/training", "pattern": "NLST_*_lobe_interfaces.nii.gz", "expected": 400, "marker_root": seg},
        {"name": "c1_canonical_dvfs", "path": c1 / "dvfs_canonical_ras", "pattern": "NLST_*_DVF_RAS_XYZC_voxel.nii.gz", "expected": 200, "marker_root": c1},
    ]


def collect(spec: dict[str, Any]) -> list[Path]:
    path = Path(spec["path"])
    if not path.is_dir():
        raise FileNotFoundError(f"Repository missing: {path}")
    files = sorted(p for p in path.glob(str(spec["pattern"])) if p.is_file())
    if len(files) != int(spec["expected"]):
        raise RuntimeError(f"{spec['name']}: expected {spec['expected']} files, found {len(files)}")
    return files


def make_read_only(path: Path) -> None:
    mode = stat.S_IMODE(path.stat().st_mode)
    path.chmod(mode & ~0o222)


def restore_write(path: Path) -> None:
    if path.exists():
        mode = stat.S_IMODE(path.stat().st_mode)
        path.chmod(mode | stat.S_IWUSR)


def freeze(args: argparse.Namespace) -> int:
    root = Path(args.project_root).expanduser().resolve()
    manifest_path = Path(args.manifest).expanduser().resolve() if args.manifest else (root / DEFAULT_MANIFEST).resolve()
    if manifest_path.exists() and not args.overwrite_manifest:
        raise FileExistsError(f"Manifest exists: {manifest_path}")

    repositories: list[dict[str, Any]] = []
    total = 0
    for spec in specs(root):
        files = collect(spec)
        records: list[dict[str, Any]] = []
        for idx, path in enumerate(files, 1):
            total += 1
            print(f"[{spec['name']}] hashing {idx:03d}/{len(files):03d} {path.name}", flush=True)
            st = path.stat()
            records.append({
                "relative_path": str(path.relative_to(Path(spec["path"]))),
                "size_bytes": int(st.st_size),
                "sha256": sha256_file(path),
            })
        repositories.append({
            "name": spec["name"],
            "path": str(Path(spec["path"]).resolve()),
            "pattern": spec["pattern"],
            "expected_count": spec["expected"],
            "actual_count": len(records),
            "marker_root": str(Path(spec["marker_root"]).resolve()),
            "files": records,
        })

    payload = {
        "schema_version": SCHEMA_VERSION,
        "status": "frozen",
        "frozen_utc": now(),
        "project_root": str(root),
        "hash_algorithm": "sha256",
        "read_only_requested": bool(args.make_read_only),
        "tracked_file_count": total,
        "repositories": repositories,
    }
    atomic_json(manifest_path, payload)

    marker_roots = sorted({Path(repo["marker_root"]) for repo in repositories})
    for marker_root in marker_roots:
        atomic_json(marker_root / MARKER_NAME, {
            "schema_version": SCHEMA_VERSION,
            "status": "frozen",
            "frozen_utc": payload["frozen_utc"],
            "manifest": str(manifest_path),
            "tracked_file_count": total,
        })

    if args.make_read_only:
        for repo in repositories:
            base = Path(repo["path"])
            for record in repo["files"]:
                make_read_only(base / record["relative_path"])

    print(json.dumps({"status": "frozen", "manifest": str(manifest_path), "tracked_file_count": total, "read_only_applied": bool(args.make_read_only)}, indent=2))
    return 0


def verify(args: argparse.Namespace) -> int:
    manifest_path = Path(args.manifest).expanduser().resolve()
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    failures: list[dict[str, Any]] = []
    checked = 0
    repos: list[dict[str, Any]] = []
    for repo in payload["repositories"]:
        base = Path(repo["path"])
        expected = {r["relative_path"] for r in repo["files"]}
        actual = {str(p.relative_to(base)) for p in base.glob(repo["pattern"]) if p.is_file()}
        for name in sorted(expected - actual):
            failures.append({"repository": repo["name"], "type": "missing", "relative_path": name})
        for name in sorted(actual - expected):
            failures.append({"repository": repo["name"], "type": "extra", "relative_path": name})
        for record in repo["files"]:
            path = base / record["relative_path"]
            if not path.exists():
                continue
            checked += 1
            if path.stat().st_size != int(record["size_bytes"]):
                failures.append({"repository": repo["name"], "type": "size_changed", "relative_path": record["relative_path"]})
                continue
            print(f"[{repo['name']}] verifying {checked:04d} {path.name}", flush=True)
            digest = sha256_file(path)
            if digest != record["sha256"]:
                failures.append({"repository": repo["name"], "type": "sha256_changed", "relative_path": record["relative_path"]})
            if args.require_read_only and (stat.S_IMODE(path.stat().st_mode) & 0o222):
                failures.append({"repository": repo["name"], "type": "writable", "relative_path": record["relative_path"]})
        marker = Path(repo["marker_root"]) / MARKER_NAME
        if not marker.exists():
            failures.append({"repository": repo["name"], "type": "marker_missing", "path": str(marker)})
        repos.append({"name": repo["name"], "expected_count": len(expected), "actual_count": len(actual), "marker_present": marker.exists()})

    report = {
        "schema_version": SCHEMA_VERSION,
        "verified_utc": now(),
        "manifest": str(manifest_path),
        "status": "PASS" if not failures else "FAIL",
        "checked_files": checked,
        "failure_count": len(failures),
        "repositories": repos,
        "failures": failures,
    }
    report_path = Path(args.report).expanduser().resolve() if args.report else Path(payload["project_root"]) / DEFAULT_REPORT
    atomic_json(report_path, report)
    print(json.dumps(report, indent=2))
    return 0 if not failures else 2


def unfreeze(args: argparse.Namespace) -> int:
    manifest_path = Path(args.manifest).expanduser().resolve()
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    for repo in payload["repositories"]:
        base = Path(repo["path"])
        for record in repo["files"]:
            restore_write(base / record["relative_path"])
    for marker_root in {Path(repo["marker_root"]) for repo in payload["repositories"]}:
        (marker_root / MARKER_NAME).unlink(missing_ok=True)
    print(json.dumps({"status": "unfrozen", "manifest": str(manifest_path)}, indent=2))
    return 0


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Freeze/verify SGR-FM Phase-2 training assets")
    sub = p.add_subparsers(dest="command", required=True)
    f = sub.add_parser("freeze")
    f.add_argument("--project-root", default="/home/oussama/Desktop/MICCAI FRANCE")
    f.add_argument("--manifest")
    f.add_argument("--make-read-only", action="store_true")
    f.add_argument("--overwrite-manifest", action="store_true")
    f.set_defaults(func=freeze)
    v = sub.add_parser("verify")
    v.add_argument("--manifest", required=True)
    v.add_argument("--report")
    v.add_argument("--require-read-only", action="store_true")
    v.set_defaults(func=verify)
    u = sub.add_parser("unfreeze")
    u.add_argument("--manifest", required=True)
    u.set_defaults(func=unfreeze)
    return p


def main() -> int:
    args = parser().parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
