#!/usr/bin/env python3
"""Train C3 segmentation-guided residual refinement on 160/40 training split."""
from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.sgr_fm_lobe_refiner import SGRFMLobeRefiner3d
from utils.data import discover_training_cases
from utils.sgr_fm_c3 import (
    bending_energy,
    binary_soft_dice_loss,
    bounded_residual_svf,
    check_phase2_freeze,
    compose_pull,
    deterministic_case_split,
    hard_mean_lobe_dice,
    jacobian_barrier,
    labels_to_one_hot,
    load_c3_config,
    soft_boundary_union,
    soft_lobe_dice_loss,
    split_fingerprint,
    warp_volume,
)
from utils.sgr_fm_segmentation import atomic_write_json
from utils.sgr_fm_training_assets import recursive_update, resolve_under_project


class C3CacheDataset(Dataset[dict[str, Any]]):
    def __init__(self, cache_dir: Path, case_ids: list[str], expected_fingerprint: str) -> None:
        self.cache_dir = cache_dir
        self.case_ids = list(case_ids)
        self.expected_fingerprint = str(expected_fingerprint)

    def __len__(self) -> int:
        return len(self.case_ids)

    def __getitem__(self, index: int) -> dict[str, Any]:
        case_id = self.case_ids[index]
        path = self.cache_dir / f"{case_id}.npz"
        if not path.exists():
            raise FileNotFoundError(path)
        with np.load(path, allow_pickle=False) as z:
            fp = str(z["cache_fingerprint"].item())
            if fp != self.expected_fingerprint:
                raise RuntimeError(f"{case_id}: cache fingerprint mismatch")
            return {
                "case_id": case_id,
                "moving_lobes": torch.from_numpy(z["moving_lobes"].astype(np.int64)),
                "fixed_lobes": torch.from_numpy(z["fixed_lobes"].astype(np.int64)),
                "moving_support": torch.from_numpy(z["moving_support"].astype(np.float32)),
                "fixed_support": torch.from_numpy(z["fixed_support"].astype(np.float32)),
                "init_dvf": torch.from_numpy(z["init_dvf"].astype(np.float32)),
                "full_shape": torch.from_numpy(z["full_shape"].astype(np.int64)),
            }


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator_training",
        "c1_dir": "outputs/sgr_fm/c1_support_guided_training",
        "phase2_freeze_manifest": "outputs/sgr_fm/frozen_assets/phase2_assets_freeze_manifest.json",
        "require_phase2_frozen": True,
        "accepted_c1_fingerprint": "152aae30403dbd1b8102e0eb7fa008e7749e0fadc7d55216133948c7096b163e",
        "expected_training_cases": 200,
        "cache": {
            "output_dir": "outputs/sgr_fm/c3_lobe_refinement/cache_lowres",
            "reduce_factor": 2,
        },
        "model": {
            "input_channels": 17,
            "base_channels": 4,
            "max_channels": 32,
            "max_residual_fullres_voxels": 0.75,
            "integration_steps": 4,
        },
        "loss": {
            "lobe": 1.0,
            "interface": 0.25,
            "bending": 0.05,
            "residual_magnitude": 0.02,
            "jacobian": 5.0,
            "jacobian_margin": 0.05,
            "boundary_dilation_voxels": 1,
        },
        "train": {
            "output_dir": "outputs/sgr_fm/c3_lobe_refinement/training",
            "epochs": 100,
            "batch_size": 1,
            "num_workers": 0,
            "lr": 1e-4,
            "weight_decay": 1e-6,
            "seed": 2026,
            "holdout_count": 40,
            "eval_every": 5,
            "save_every": 5,
            "grad_clip": 1.0,
            "amp": False,
            "device": "cuda",
            "topology_guard_mean_folding_pct": 0.01,
        },
    }


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train SGR-FM C3 lobe-guided refiner")
    p.add_argument("--config", default="configs/sgr_fm_c3_lobe_refiner.yaml")
    p.add_argument("--output-dir")
    p.add_argument("--epochs", type=int)
    p.add_argument("--resume")
    p.add_argument("--device")
    p.add_argument("--allow-unfrozen-phase2", action="store_true")
    return p.parse_args()


def build_config(args: argparse.Namespace) -> dict[str, Any]:
    cfg = default_config()
    path = Path(args.config).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    recursive_update(cfg, load_c3_config(path))
    if args.output_dir:
        cfg["train"]["output_dir"] = args.output_dir
    if args.epochs:
        cfg["train"]["epochs"] = int(args.epochs)
    if args.device:
        cfg["train"]["device"] = args.device
    if args.allow_unfrozen_phase2:
        cfg["require_phase2_frozen"] = False
    return cfg


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def one_hot_batch(labels: torch.Tensor, device: torch.device) -> torch.Tensor:
    labels = labels.to(device=device, dtype=torch.int64)
    channels = [(labels == value).float() for value in (8, 16, 32, 64, 128)]
    return torch.stack(channels, dim=1)


def forward_batch(
    model: SGRFMLobeRefiner3d,
    batch: dict[str, Any],
    cfg: dict[str, Any],
    device: torch.device,
) -> dict[str, torch.Tensor]:
    moving = one_hot_batch(batch["moving_lobes"], device)
    fixed = one_hot_batch(batch["fixed_lobes"], device)
    moving_support = batch["moving_support"].to(device=device, dtype=torch.float32).unsqueeze(1)
    fixed_support = batch["fixed_support"].to(device=device, dtype=torch.float32).unsqueeze(1)
    init = batch["init_dvf"].to(device=device, dtype=torch.float32).permute(0, 4, 1, 2, 3)
    full_shape = [int(v) for v in batch["full_shape"][0].tolist()]

    warped0 = warp_volume(moving, init, mode="bilinear")
    warped_support0 = warp_volume(moving_support, init, mode="bilinear")
    mismatch = (fixed - warped0).abs()
    inputs = torch.cat([fixed, warped0, mismatch, fixed_support, warped_support0], dim=1)
    if inputs.shape[1] != int(cfg["model"]["input_channels"]):
        raise RuntimeError(f"Configured input_channels={cfg['model']['input_channels']} but built {inputs.shape[1]}")

    unit_svf = model(inputs)
    residual = bounded_residual_svf(
        unit_svf,
        full_shape=full_shape,
        max_fullres_voxels=float(cfg["model"]["max_residual_fullres_voxels"]),
        integration_steps=int(cfg["model"]["integration_steps"]),
    )
    final = compose_pull(init, residual)
    warped = warp_volume(moving, final, mode="bilinear")

    lobe_loss, per_lobe_dice = soft_lobe_dice_loss(warped, fixed)
    pred_boundary = soft_boundary_union(warped, int(cfg["loss"]["boundary_dilation_voxels"]))
    fixed_boundary = soft_boundary_union(fixed, int(cfg["loss"]["boundary_dilation_voxels"]))
    interface_loss = binary_soft_dice_loss(pred_boundary, fixed_boundary)
    bend = bending_energy(residual)
    magnitude = residual.square().mean()
    jac_loss, folding_pct, min_det = jacobian_barrier(final, margin=float(cfg["loss"]["jacobian_margin"]))

    total = (
        float(cfg["loss"]["lobe"]) * lobe_loss
        + float(cfg["loss"]["interface"]) * interface_loss
        + float(cfg["loss"]["bending"]) * bend
        + float(cfg["loss"]["residual_magnitude"]) * magnitude
        + float(cfg["loss"]["jacobian"]) * jac_loss
    )
    hard_dice = hard_mean_lobe_dice(warped, fixed)
    c1_hard_dice = hard_mean_lobe_dice(warped0, fixed)
    return {
        "total": total,
        "lobe_loss": lobe_loss,
        "interface_loss": interface_loss,
        "bending": bend,
        "residual_magnitude": magnitude,
        "jacobian_loss": jac_loss,
        "folding_pct": folding_pct,
        "min_det": min_det,
        "soft_lobe_dice": per_lobe_dice.mean(),
        "hard_lobe_dice": hard_dice,
        "c1_hard_lobe_dice": c1_hard_dice,
        "residual_abs_max": residual.abs().amax(),
    }


def aggregate(records: list[dict[str, float]]) -> dict[str, float]:
    if not records:
        return {}
    keys = records[0].keys()
    return {key: float(np.mean([r[key] for r in records])) for key in keys}


def evaluate(model: SGRFMLobeRefiner3d, loader: DataLoader, cfg: dict[str, Any], device: torch.device) -> dict[str, float]:
    model.eval()
    rows: list[dict[str, float]] = []
    with torch.no_grad():
        for batch in loader:
            out = forward_batch(model, batch, cfg, device)
            rows.append({k: float(v.detach().cpu()) for k, v in out.items()})
    return aggregate(rows)


def save_checkpoint(
    path: Path,
    *,
    model: SGRFMLobeRefiner3d,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    cfg: dict[str, Any],
    split: dict[str, Any],
    history: list[dict[str, Any]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save({
        "schema_version": 1,
        "experiment": "SGR-FM C3 lobe-guided residual SVF",
        "epoch": int(epoch),
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "config": cfg,
        "split": split,
        "history": history,
    }, tmp)
    tmp.replace(path)


def main() -> int:
    args = parse_args()
    cfg = build_config(args)
    seed = int(cfg["train"]["seed"])
    seed_all(seed)

    raw_root = resolve_under_project(PROJECT_ROOT, cfg["raw_data_root"])
    seg_dir = resolve_under_project(PROJECT_ROOT, cfg["segmentation_dir"])
    c1_dir = resolve_under_project(PROJECT_ROOT, cfg["c1_dir"])
    cache_dir = resolve_under_project(PROJECT_ROOT, cfg["cache"]["output_dir"])
    out_dir = resolve_under_project(PROJECT_ROOT, cfg["train"]["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)

    freeze_status = check_phase2_freeze(
        project_root=PROJECT_ROOT,
        manifest_value=cfg["phase2_freeze_manifest"],
        segmentation_dir=seg_dir,
        c1_dir=c1_dir,
        require=bool(cfg.get("require_phase2_frozen", True)),
    )

    c1_summary_path = c1_dir / "c1_training_summary.json"
    c1_summary = json.loads(c1_summary_path.read_text(encoding="utf-8"))
    actual_c1_fp = str(c1_summary.get("config_fingerprint_sha256"))
    expected_c1_fp = str(cfg["accepted_c1_fingerprint"])
    if actual_c1_fp != expected_c1_fp:
        raise RuntimeError(f"C1 fingerprint drift: expected {expected_c1_fp}, got {actual_c1_fp}")

    cache_summary_path = cache_dir / "c3_cache_summary.json"
    cache_summary = json.loads(cache_summary_path.read_text(encoding="utf-8"))
    if cache_summary.get("status") != "PASS":
        raise RuntimeError(f"C3 cache is not PASS: {cache_summary_path}")
    expected_cases = int(cfg.get("expected_training_cases", 200))
    if int(cache_summary.get("case_count", -1)) != expected_cases or int(cache_summary.get("ok_count", -1)) != expected_cases:
        raise RuntimeError(
            f"C3 cache is partial: expected {expected_cases} PASS cases, "
            f"summary reports case_count={cache_summary.get('case_count')} ok_count={cache_summary.get('ok_count')}"
        )
    cache_fp = str(cache_summary["cache_fingerprint_sha256"])

    cases = discover_training_cases(raw_root)
    case_ids = [c.case_id for c in cases]
    if len(case_ids) != expected_cases:
        raise RuntimeError(f"Expected {expected_cases} training cases, found {len(case_ids)}")
    train_ids, holdout_ids = deterministic_case_split(
        case_ids,
        holdout_count=int(cfg["train"]["holdout_count"]),
        seed=seed,
    )
    split = {
        "schema_version": 1,
        "seed": seed,
        "train_count": len(train_ids),
        "holdout_count": len(holdout_ids),
        "train_case_ids": train_ids,
        "holdout_case_ids": holdout_ids,
        "split_fingerprint_sha256": split_fingerprint(train_ids, holdout_ids, seed),
    }
    atomic_write_json(out_dir / "split.json", split)

    cfg_resolved = dict(cfg)
    cfg_resolved["raw_data_root"] = str(raw_root)
    cfg_resolved["segmentation_dir"] = str(seg_dir)
    cfg_resolved["c1_dir"] = str(c1_dir)
    cfg_resolved["cache"]["output_dir"] = str(cache_dir)
    cfg_resolved["train"]["output_dir"] = str(out_dir)
    cfg_resolved["phase2_freeze"] = freeze_status
    cfg_resolved["c1_fingerprint_verified"] = True
    cfg_resolved["cache_fingerprint_sha256"] = cache_fp
    atomic_write_json(out_dir / "config_resolved.json", cfg_resolved)

    train_ds = C3CacheDataset(cache_dir, train_ids, cache_fp)
    holdout_ds = C3CacheDataset(cache_dir, holdout_ids, cache_fp)
    generator = torch.Generator().manual_seed(seed)
    train_loader = DataLoader(
        train_ds,
        batch_size=int(cfg["train"]["batch_size"]),
        shuffle=True,
        num_workers=int(cfg["train"]["num_workers"]),
        pin_memory=True,
        generator=generator,
    )
    holdout_loader = DataLoader(
        holdout_ds,
        batch_size=1,
        shuffle=False,
        num_workers=int(cfg["train"]["num_workers"]),
        pin_memory=True,
    )

    requested_device = str(cfg["train"]["device"])
    device = torch.device(requested_device if requested_device == "cpu" or torch.cuda.is_available() else "cpu")
    model = SGRFMLobeRefiner3d(
        in_channels=int(cfg["model"]["input_channels"]),
        base_channels=int(cfg["model"]["base_channels"]),
        max_channels=int(cfg["model"]["max_channels"]),
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(cfg["train"]["lr"]),
        weight_decay=float(cfg["train"]["weight_decay"]),
    )
    use_amp = bool(cfg["train"].get("amp", False)) and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=True) if use_amp else None

    start_epoch = 1
    history: list[dict[str, Any]] = []
    if args.resume:
        checkpoint = torch.load(args.resume, map_location="cpu")
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        history = list(checkpoint.get("history", []))
        start_epoch = int(checkpoint["epoch"]) + 1

    # Baseline holdout C1 proxy is recorded before learning.
    zero_model = SGRFMLobeRefiner3d(
        in_channels=int(cfg["model"]["input_channels"]),
        base_channels=int(cfg["model"]["base_channels"]),
        max_channels=int(cfg["model"]["max_channels"]),
    ).to(device)
    baseline = evaluate(zero_model, holdout_loader, cfg, device)
    atomic_write_json(out_dir / "holdout_c1_proxy_baseline.json", baseline)
    del zero_model

    best_dice = -float("inf")
    best_guarded = -float("inf")
    best_dice_epoch: int | None = None
    best_guarded_epoch: int | None = None
    total_epochs = int(cfg["train"]["epochs"])
    eval_every = int(cfg["train"]["eval_every"])
    save_every = int(cfg["train"]["save_every"])
    started = time.time()

    for epoch in range(start_epoch, total_epochs + 1):
        model.train()
        train_rows: list[dict[str, float]] = []
        epoch_start = time.time()
        for batch in train_loader:
            optimizer.zero_grad(set_to_none=True)
            if use_amp:
                with torch.autocast(device_type="cuda", dtype=torch.float16):
                    out = forward_batch(model, batch, cfg, device)
                    loss = out["total"]
                assert scaler is not None
                scaler.scale(loss).backward()
                if float(cfg["train"]["grad_clip"]) > 0:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), float(cfg["train"]["grad_clip"]))
                scaler.step(optimizer)
                scaler.update()
            else:
                out = forward_batch(model, batch, cfg, device)
                loss = out["total"]
                loss.backward()
                if float(cfg["train"]["grad_clip"]) > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), float(cfg["train"]["grad_clip"]))
                optimizer.step()
            train_rows.append({k: float(v.detach().cpu()) for k, v in out.items()})

        record: dict[str, Any] = {
            "epoch": epoch,
            "train": aggregate(train_rows),
            "elapsed_sec": time.time() - epoch_start,
        }
        do_eval = epoch == 1 or epoch % eval_every == 0 or epoch == total_epochs
        if do_eval:
            holdout = evaluate(model, holdout_loader, cfg, device)
            record["holdout"] = holdout
            score = float(holdout["hard_lobe_dice"])
            if score > best_dice:
                best_dice = score
                best_dice_epoch = epoch
                save_checkpoint(out_dir / "checkpoints/best_dice.pt", model=model, optimizer=optimizer, epoch=epoch, cfg=cfg_resolved, split=split, history=history + [record])
            guard = float(cfg["train"]["topology_guard_mean_folding_pct"])
            if float(holdout["folding_pct"]) <= guard and score > best_guarded:
                best_guarded = score
                best_guarded_epoch = epoch
                save_checkpoint(out_dir / "checkpoints/best_guarded.pt", model=model, optimizer=optimizer, epoch=epoch, cfg=cfg_resolved, split=split, history=history + [record])

        history.append(record)
        atomic_write_json(out_dir / "train_history.json", history)
        save_checkpoint(out_dir / "checkpoints/latest.pt", model=model, optimizer=optimizer, epoch=epoch, cfg=cfg_resolved, split=split, history=history)
        if epoch % save_every == 0 or epoch == total_epochs:
            save_checkpoint(out_dir / f"checkpoints/epoch_{epoch:03d}.pt", model=model, optimizer=optimizer, epoch=epoch, cfg=cfg_resolved, split=split, history=history)

        h = record.get("holdout", {})
        print(
            f"epoch={epoch:03d} train_total={record['train'].get('total', float('nan')):.6f} "
            f"train_dice={record['train'].get('hard_lobe_dice', float('nan')):.6f} "
            + (f"holdout_dice={h.get('hard_lobe_dice', float('nan')):.6f} holdout_fold={h.get('folding_pct', float('nan')):.6g}%" if h else ""),
            flush=True,
        )

    summary = {
        "schema_version": 1,
        "experiment": "SGR-FM C3 lobe-guided residual SVF",
        "status": "PASS",
        "epochs": total_epochs,
        "train_count": len(train_ids),
        "holdout_count": len(holdout_ids),
        "best_dice_epoch": best_dice_epoch,
        "best_dice_holdout": best_dice if best_dice_epoch is not None else None,
        "best_guarded_epoch": best_guarded_epoch,
        "best_guarded_holdout": best_guarded if best_guarded_epoch is not None else None,
        "topology_guard_mean_folding_pct": float(cfg["train"]["topology_guard_mean_folding_pct"]),
        "accepted_c1_fingerprint": expected_c1_fp,
        "cache_fingerprint_sha256": cache_fp,
        "split_fingerprint_sha256": split["split_fingerprint_sha256"],
        "elapsed_sec": time.time() - started,
        "output_dir": str(out_dir),
    }
    atomic_write_json(out_dir / "c3_training_summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
