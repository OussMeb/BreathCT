#!/usr/bin/env python3
"""Small segmentation-guided residual SVF network for SGR-FM C3."""
from __future__ import annotations

import torch
from torch import nn


class ConvBlock3d(nn.Module):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv3d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(out_channels, affine=True),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv3d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(out_channels, affine=True),
            nn.LeakyReLU(0.1, inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class SGRFMLobeRefiner3d(nn.Module):
    """Lightweight 3D U-Net predicting a unit-bounded residual SVF.

    The caller applies the physical residual bound in voxel units. Keeping the
    head unit-bounded allows the same checkpoint to be interpreted exactly from
    its saved configuration.
    """

    def __init__(
        self,
        in_channels: int = 17,
        base_channels: int = 4,
        max_channels: int = 32,
        out_channels: int = 3,
    ) -> None:
        super().__init__()
        c1 = int(base_channels)
        c2 = min(c1 * 2, int(max_channels))
        c3 = min(c1 * 4, int(max_channels))
        c4 = min(c1 * 8, int(max_channels))

        self.enc1 = ConvBlock3d(in_channels, c1)
        self.enc2 = ConvBlock3d(c1, c2)
        self.enc3 = ConvBlock3d(c2, c3)
        self.bottleneck = ConvBlock3d(c3, c4)

        self.pool = nn.MaxPool3d(2)
        self.up3 = nn.ConvTranspose3d(c4, c3, 2, stride=2)
        self.dec3 = ConvBlock3d(c3 + c3, c3)
        self.up2 = nn.ConvTranspose3d(c3, c2, 2, stride=2)
        self.dec2 = ConvBlock3d(c2 + c2, c2)
        self.up1 = nn.ConvTranspose3d(c2, c1, 2, stride=2)
        self.dec1 = ConvBlock3d(c1 + c1, c1)

        self.head = nn.Conv3d(c1, out_channels, 3, padding=1)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    @staticmethod
    def _match(x: torch.Tensor, ref: torch.Tensor) -> torch.Tensor:
        """Center-crop tiny odd-size mismatches from transpose convolutions."""
        if x.shape[-3:] == ref.shape[-3:]:
            return x
        target = ref.shape[-3:]
        slices = []
        for dim, wanted in zip(x.shape[-3:], target):
            if dim < wanted:
                raise RuntimeError(f"Decoder tensor {tuple(x.shape)} smaller than skip {tuple(ref.shape)}")
            start = (dim - wanted) // 2
            slices.append(slice(start, start + wanted))
        return x[..., slices[0], slices[1], slices[2]]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        b = self.bottleneck(self.pool(e3))

        d3 = self._match(self.up3(b), e3)
        d3 = self.dec3(torch.cat([d3, e3], dim=1))
        d2 = self._match(self.up2(d3), e2)
        d2 = self.dec2(torch.cat([d2, e2], dim=1))
        d1 = self._match(self.up1(d2), e1)
        d1 = self.dec1(torch.cat([d1, e1], dim=1))

        return torch.tanh(self.head(d1))
