#!/usr/bin/env python3
"""Prepare compact half-resolution C3 training cache from frozen Phase-2 assets."""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.data import discover_training_cases
from utils.refine_spatial import downsample_dvf_5d, resize_volume_5d
from utils.sgr_fm_c3 import (
    check_phase2_freeze,
    dvf_xyzc_to_tensor,
    load_c3_config,
    load_canonical_dvf,
    load_canonical_label,
    load_canonical_support,
    phase2_asset_paths,
    sha256_json,
)
from utils.sgr_fm_segmentation import atomic_write_json, write_csv
from utils.sgr_fm_training_assets import recursive_update, resolve_under_project


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator_training",
        "c1_dir": "outputs/sgr_fm/c1_support_guided_training",
        "output_dir": "outputs/sgr_fm/c3_lobe_refinement/cache_lowres",
        "phase2_freeze_manifest": "outputs/sgr_fm/frozen_assets/phase2_assets_freeze_manifest.json",
        "require_phase2_frozen": True,
        "expected_cases": 200,
        "reduce_factor": 2,
        "affine_atol": 1e-5,
        "overwrite": False,
    }


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Prepare SGR-FM C3 low-resolution cache")
    p.add_argument("--config", default="configs/sgr_fm_c3_lobe_refiner.yaml")
    p.add_argument("--case-ids", nargs="*")
    p.add_argument("--limit", type=int)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--allow-unfrozen-phase2", action="store_true")
    return p.parse_args()


def atomic_save_npz(path: Path, **arrays: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=path.name + ".", suffix=".tmp.npz", dir=path.parent, delete=False) as f:
        tmp = Path(f.name)
    try:
        np.savez_compressed(tmp, **arrays)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def main() -> int:
    args = parse_args()
    config_path = Path(args.config).expanduser()
    if not config_path.is_absolute():
        config_path = PROJECT_ROOT / config_path
    cfg = default_config()
    recursive_update(cfg, load_c3_config(config_path).get("cache", {}))
    # Top-level asset paths override cache-local defaults.
    top = load_c3_config(config_path)
    for key in ("raw_data_root", "segmentation_dir", "c1_dir", "phase2_freeze_manifest", "require_phase2_frozen"):
        if key in top:
            cfg[key] = top[key]
    if args.overwrite:
        cfg["overwrite"] = True
    if args.allow_unfrozen_phase2:
        cfg["require_phase2_frozen"] = False

    raw_root = resolve_under_project(PROJECT_ROOT, cfg["raw_data_root"])
    seg_dir = resolve_under_project(PROJECT_ROOT, cfg["segmentation_dir"])
    c1_dir = resolve_under_project(PROJECT_ROOT, cfg["c1_dir"])
    out_dir = resolve_under_project(PROJECT_ROOT, cfg["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)

    freeze_status = check_phase2_freeze(
        project_root=PROJECT_ROOT,
        manifest_value=cfg["phase2_freeze_manifest"],
        segmentation_dir=seg_dir,
        c1_dir=c1_dir,
        require=bool(cfg.get("require_phase2_frozen", True)),
    )

    cases = discover_training_cases(raw_root)
    requested = set(args.case_ids or [])
    if requested:
        cases = [c for c in cases if c.case_id in requested]
        missing = sorted(requested - {c.case_id for c in cases})
        if missing:
            raise FileNotFoundError(f"Requested cases not found: {missing}")
    elif len(cases) != int(cfg["expected_cases"]):
        raise RuntimeError(f"Expected {cfg['expected_cases']} cases, found {len(cases)}")
    if args.limit:
        cases = cases[: int(args.limit)]

    reduce_factor = int(cfg["reduce_factor"])
    fingerprint = sha256_json({
        "schema_version": 1,
        "reduce_factor": reduce_factor,
        "segmentation_dir": str(seg_dir),
        "c1_dir": str(c1_dir),
        "phase2_manifest": str(resolve_under_project(PROJECT_ROOT, cfg["phase2_freeze_manifest"])),
    })

    rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    started = time.time()
    for idx, case in enumerate(cases, 1):
        print(f"[{idx:03d}/{len(cases):03d}] {case.case_id}", flush=True)
        output = out_dir / f"{case.case_id}.npz"
        row: dict[str, Any] = {"case_id": case.case_id, "cache": str(output), "status": "started"}
        try:
            if output.exists() and not bool(cfg["overwrite"]):
                with np.load(output, allow_pickle=False) as z:
                    existing_fp = str(z["cache_fingerprint"].item())
                if existing_fp != fingerprint:
                    raise RuntimeError(f"Existing cache fingerprint mismatch for {case.case_id}")
                row["status"] = "exists"
                rows.append(row)
                continue

            exp = phase2_asset_paths(seg_dir, c1_dir, case.case_id, "EXP")
            insp = phase2_asset_paths(seg_dir, c1_dir, case.case_id, "INSP")
            moving_label, moving_img = load_canonical_label(exp["lobes"], case.exp_ct, affine_atol=float(cfg["affine_atol"]))
            fixed_label, fixed_img = load_canonical_label(insp["lobes"], case.insp_ct, affine_atol=float(cfg["affine_atol"]))
            moving_support, _ = load_canonical_support(exp["support"], case.exp_ct, affine_atol=float(cfg["affine_atol"]))
            fixed_support, _ = load_canonical_support(insp["support"], case.insp_ct, affine_atol=float(cfg["affine_atol"]))
            if moving_label.shape != fixed_label.shape or not np.allclose(moving_img.affine, fixed_img.affine, atol=float(cfg["affine_atol"]), rtol=0.0):
                raise RuntimeError(f"{case.case_id}: canonical EXP/INSP grids differ")
            init_xyzc, _ = load_canonical_dvf(exp["c1_dvf"], case.insp_ct, affine_atol=float(cfg["affine_atol"]))

            # Nearest downsampling for categorical assets; exact voxel-unit scaling for DVF.
            m_lab_t = torch.from_numpy(moving_label.astype(np.float32)).view(1, 1, *moving_label.shape)
            f_lab_t = torch.from_numpy(fixed_label.astype(np.float32)).view(1, 1, *fixed_label.shape)
            m_sup_t = torch.from_numpy(moving_support).view(1, 1, *moving_support.shape)
            f_sup_t = torch.from_numpy(fixed_support).view(1, 1, *fixed_support.shape)
            init_t = dvf_xyzc_to_tensor(init_xyzc)

            m_lab_low = resize_volume_5d(m_lab_t, reduce_factor, mode="nearest")[0, 0].numpy().astype(np.uint8)
            f_lab_low = resize_volume_5d(f_lab_t, reduce_factor, mode="nearest")[0, 0].numpy().astype(np.uint8)
            m_sup_low = (resize_volume_5d(m_sup_t, reduce_factor, mode="nearest")[0, 0].numpy() > 0.5).astype(np.uint8)
            f_sup_low = (resize_volume_5d(f_sup_t, reduce_factor, mode="nearest")[0, 0].numpy() > 0.5).astype(np.uint8)
            init_low = downsample_dvf_5d(init_t, reduce_factor)[0].permute(1, 2, 3, 0).numpy().astype(np.float32)

            atomic_save_npz(
                output,
                case_id=np.asarray(case.case_id),
                cache_fingerprint=np.asarray(fingerprint),
                moving_lobes=m_lab_low,
                fixed_lobes=f_lab_low,
                moving_support=m_sup_low,
                fixed_support=f_sup_low,
                init_dvf=init_low,
                full_shape=np.asarray(fixed_label.shape, dtype=np.int32),
            )
            row.update({"status": "ok", "low_shape": list(m_lab_low.shape), "full_shape": list(fixed_label.shape)})
        except Exception as exc:
            row.update({"status": "FAIL", "error_type": type(exc).__name__, "error": str(exc)})
            failures.append(dict(row))
        rows.append(row)

    expected_names = {f"{c.case_id}.npz" for c in cases}
    actual_names = {p.name for p in out_dir.glob("NLST_*.npz")}
    strict_extras = not requested and args.limit is None
    missing = sorted(expected_names - actual_names)
    extra = sorted(actual_names - expected_names) if strict_extras else []
    status = "PASS" if not failures and not missing and not extra else "FAIL"
    summary = {
        "schema_version": 1,
        "experiment": "SGR-FM C3 low-resolution cache",
        "status": status,
        "case_count": len(cases),
        "ok_count": sum(r["status"] in {"ok", "exists"} for r in rows),
        "failure_count": len(failures),
        "reduce_factor": reduce_factor,
        "cache_fingerprint_sha256": fingerprint,
        "phase2_freeze": freeze_status,
        "output_dir": str(out_dir),
        "missing": missing,
        "extra": extra,
        "elapsed_sec": time.time() - started,
        "failures": failures,
    }
    atomic_write_json(out_dir / "c3_cache_summary.json", summary)
    atomic_write_json(out_dir / "c3_cache_manifest.json", {"summary": summary, "rows": rows})
    write_csv(out_dir / "c3_cache_manifest.csv", rows)
    print(json.dumps(summary, indent=2))
    return 0 if status == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
