#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import re
import shutil
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

try:
    import nibabel as nib
except Exception:
    nib = None

try:
    import torch
    import torch.nn.functional as F
except Exception:
    torch = None
    F = None


DEFAULT_LABELS = [8, 16, 32, 64, 128]


def _parse_scalar(v: str):
    s = v.strip()
    if s.lower() in ("true", "false"):
        return s.lower() == "true"
    if s.startswith("[") and s.endswith("]"):
        return json.loads(s.replace("'", '"'))
    try:
        return json.loads(s)
    except Exception:
        return s.strip('"').strip("'")


def _simple_yaml(text: str) -> Dict:
    out: Dict = {}
    stack: List[Tuple[int, Dict]] = [(-1, out)]
    for raw in text.splitlines():
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        k, v = k.strip(), v.strip()
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if v == "":
            child = {}
            parent[k] = child
            stack.append((indent, child))
        else:
            parent[k] = _parse_scalar(v)
    return out


def load_config(path: str) -> Dict:
    p = Path(path)
    txt = p.read_text()
    if p.suffix.lower() == ".json":
        cfg = json.loads(txt)
    else:
        try:
            import yaml
            cfg = yaml.safe_load(txt)
        except Exception:
            cfg = _simple_yaml(txt)

    cfg.setdefault("output_root", "outputs/sgr_fm/c8b_pseudolabel_calibrated")
    cfg.setdefault("parent_dir", "outputs/sgr_fm/c7b_multi_init_semantic")
    cfg.setdefault("fallback_parent_dir", "outputs/sgr_fm/c7a_v2_relaxed_selector")
    cfg.setdefault("raw_data_root", "Learn2Breath_train_val_data")
    cfg.setdefault("pseudo_segmentation_root", "outputs/sgr_fm/segmentation_phase1_totalsegmentator")
    cfg.setdefault("evaluate_script", "evaluate_validation.py")
    cfg.setdefault("labels", DEFAULT_LABELS)
    cfg.setdefault("device", "cuda")
    cfg.setdefault("continue_on_error", False)
    cfg.setdefault("copy_parent_on_reject", True)

    # Competition-mode but not reckless.
    cfg.setdefault("soft_folding_start_pct", 0.25)
    cfg.setdefault("soft_folding_full_pct", 0.30)
    cfg.setdefault("hard_reject_folding_pct", 0.50)
    cfg.setdefault("candidate_scales", [1.0, 0.75, 0.5, 0.25, 0.125, 0.0])

    cfg.setdefault("minimum_proxy_gain", 0.00020)
    cfg.setdefault("minimum_rml_proxy_gain_for_hard_case", 0.00005)
    cfg.setdefault("hard_case_rml_parent_threshold", 0.955)
    cfg.setdefault("max_allowed_proxy_loss_non_rml", 0.0015)

    cfg.setdefault("loss_weights", {"dice": 1.0, "smooth": 0.05, "magnitude": 0.02})
    cfg.setdefault("default_lobe_weights", {"8": 1.00, "16": 1.05, "32": 1.20, "64": 2.50, "128": 1.25})
    cfg.setdefault("calibration_strength", 0.50)
    cfg.setdefault("c8a_per_case_csv", "outputs/sgr_fm/c8a_gt_oracle/gap_audit/c8a_gt_oracle_gap_per_case.csv")
    cfg.setdefault("c8a_per_lobe_csv", "outputs/sgr_fm/c8a_gt_oracle/gap_audit/c8a_gt_oracle_gap_per_lobe.csv")

    cfg.setdefault("stages", [
        {"name": "P1_pseudo_global_calibrated", "reduce_factor": 4, "control_factor": 5, "iterations": 100, "lr": 0.050, "max_residual_vox": 1.20},
        {"name": "P2_rml_right_fissure_refine", "reduce_factor": 2, "control_factor": 4, "iterations": 140, "lr": 0.028, "max_residual_vox": 0.75},
        {"name": "P3_boundary_micro_safe", "reduce_factor": 2, "control_factor": 3, "iterations": 80, "lr": 0.016, "max_residual_vox": 0.35},
    ])
    return cfg


def discover_cases(cfg: Dict) -> List[str]:
    cases = set()
    parent = Path(cfg["parent_dir"]) / "dvfs"
    for p in parent.glob("NLST_*_DVF.nii.gz"):
        cases.add(p.name.split("_DVF")[0])
    if not cases:
        pseudo = Path(cfg["pseudo_segmentation_root"])
        for p in pseudo.rglob("NLST_*_INSP*lob*.nii*"):
            m = re.search(r"(NLST_\d+)", p.name)
            if m:
                cases.add(m.group(1))
    return sorted(cases)


def _load_img(path: Path):
    if nib is None:
        raise RuntimeError("nibabel is required")
    img = nib.load(str(path))
    return img, img.get_fdata(dtype=np.float32)


def _save_like(ref_img, data: np.ndarray, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    nib.Nifti1Image(data.astype(np.float32), ref_img.affine, ref_img.header).to_filename(str(path))


def _find_parent_dvf(case_id: str, cfg: Dict) -> Path:
    for key in ["parent_dir", "fallback_parent_dir"]:
        p = Path(cfg[key]) / "dvfs" / f"{case_id}_DVF.nii.gz"
        if p.exists():
            return p
    raise FileNotFoundError(f"parent DVF not found for {case_id}")


def _find_pseudo_lobe(root: Path, case_id: str, phase: str) -> Optional[Path]:
    if not root.exists():
        return None
    case_l = case_id.lower()
    phase_l = phase.lower()
    scored = []
    for p in root.rglob("*.nii*"):
        n = p.name.lower()
        if case_l not in n or phase_l not in n:
            continue
        score = 0
        if "lobe" in n or "lobes" in n:
            score += 20
        if "seg" in n or "label" in n:
            score += 5
        if "interface" in n or "fissure" in n or "support" in n or "body" in n:
            score -= 80
        if score > 0:
            scored.append((score, p))
    if not scored:
        return None
    scored.sort(key=lambda x: (x[0], -len(str(x[1]))), reverse=True)
    return scored[0][1]


def _dice_np(a: np.ndarray, b: np.ndarray, labels: List[int]):
    per = {}
    vals = []
    for lab in labels:
        aa = a == lab
        bb = b == lab
        den = int(aa.sum() + bb.sum())
        if den == 0:
            val = float("nan")
        else:
            val = float(2.0 * np.logical_and(aa, bb).sum() / den)
            vals.append(val)
        per[f"dice_{lab}"] = val
    return float(np.nanmean(vals)) if vals else float("nan"), per


def _weighted_mean_dice(per: Dict[str, float], weights: Dict[int, float]) -> float:
    num = 0.0
    den = 0.0
    for lab, w in weights.items():
        val = per.get(f"dice_{lab}")
        if val is None or math.isnan(val):
            continue
        num += float(w) * float(val)
        den += float(w)
    return num / max(den, 1e-8)


def _warp_label_numpy(moving_lab: np.ndarray, dvf: np.ndarray) -> np.ndarray:
    try:
        from scipy.ndimage import map_coordinates
    except Exception as e:
        raise RuntimeError("scipy is required for label warping") from e
    X, Y, Z = moving_lab.shape
    xx, yy, zz = np.meshgrid(np.arange(X), np.arange(Y), np.arange(Z), indexing="ij")
    coords = [xx + dvf[..., 0], yy + dvf[..., 1], zz + dvf[..., 2]]
    return map_coordinates(moving_lab.astype(np.float32), coords, order=0, mode="nearest").round().astype(np.int16)


def _folding_pct(dvf: np.ndarray) -> float:
    ux, uy, uz = dvf[..., 0], dvf[..., 1], dvf[..., 2]
    dux_dx, dux_dy, dux_dz = np.gradient(ux)
    duy_dx, duy_dy, duy_dz = np.gradient(uy)
    duz_dx, duz_dy, duz_dz = np.gradient(uz)
    J00 = 1 + dux_dx; J01 = dux_dy; J02 = dux_dz
    J10 = duy_dx; J11 = 1 + duy_dy; J12 = duy_dz
    J20 = duz_dx; J21 = duz_dy; J22 = 1 + duz_dz
    det = J00 * (J11 * J22 - J12 * J21) - J01 * (J10 * J22 - J12 * J20) + J02 * (J10 * J21 - J11 * J20)
    return float(100.0 * np.mean(det < 0))


def _downsample_label(arr: np.ndarray, r: int) -> np.ndarray:
    return arr.astype(np.int16) if r <= 1 else arr[::r, ::r, ::r].astype(np.int16)


def _downsample_dvf(dvf: np.ndarray, r: int) -> np.ndarray:
    return dvf.astype(np.float32) if r <= 1 else (dvf[::r, ::r, ::r, :] / float(r)).astype(np.float32)


def _labels_to_onehot(label_xyz: np.ndarray, labels: List[int], device: str):
    vols = [(label_xyz == lab).astype(np.float32).transpose(2, 1, 0) for lab in labels]
    return torch.from_numpy(np.stack(vols, axis=0)[None]).to(device)


def _weights_to_torch(labels: List[int], weights: Dict[int, float], device: str):
    arr = np.array([weights.get(lab, 1.0) for lab in labels], dtype=np.float32)
    arr = arr / max(float(np.mean(arr)), 1e-6)
    return torch.from_numpy(arr).to(device)


def _dvf_xyz_to_torch(dvf_xyz: np.ndarray, device: str):
    comps = [
        dvf_xyz[..., 0].transpose(2, 1, 0),
        dvf_xyz[..., 1].transpose(2, 1, 0),
        dvf_xyz[..., 2].transpose(2, 1, 0),
    ]
    return torch.from_numpy(np.stack(comps, axis=0)[None].astype(np.float32)).to(device)


def _torch_dvf_to_xyz(dvf_t) -> np.ndarray:
    a = dvf_t.detach().cpu().numpy()[0]
    return np.stack([a[0].transpose(2, 1, 0), a[1].transpose(2, 1, 0), a[2].transpose(2, 1, 0)], axis=-1).astype(np.float32)


def _warp_onehot(mov_oh, dvf_t):
    _, _, D, H, W = mov_oh.shape
    z = torch.linspace(0, D - 1, D, device=mov_oh.device)
    y = torch.linspace(0, H - 1, H, device=mov_oh.device)
    x = torch.linspace(0, W - 1, W, device=mov_oh.device)
    zz, yy, xx = torch.meshgrid(z, y, x, indexing="ij")
    mx = xx + dvf_t[:, 0]
    my = yy + dvf_t[:, 1]
    mz = zz + dvf_t[:, 2]
    gx = 2 * mx / max(W - 1, 1) - 1
    gy = 2 * my / max(H - 1, 1) - 1
    gz = 2 * mz / max(D - 1, 1) - 1
    grid = torch.stack([gx[0], gy[0], gz[0]], dim=-1)[None]
    return F.grid_sample(mov_oh, grid, mode="bilinear", padding_mode="border", align_corners=True)


def _weighted_dice_loss(warped, fixed, w, eps=1e-5):
    dims = (0, 2, 3, 4)
    inter = torch.sum(warped * fixed, dim=dims)
    den = torch.sum(warped + fixed, dim=dims)
    dice = (2 * inter + eps) / (den + eps)
    loss = torch.sum(w * (1 - dice)) / torch.sum(w)
    return loss, dice.detach().cpu().numpy().tolist()


def _smoothness_loss(res):
    return (
        torch.mean((res[:, :, 1:, :, :] - res[:, :, :-1, :, :]) ** 2) +
        torch.mean((res[:, :, :, 1:, :] - res[:, :, :, :-1, :]) ** 2) +
        torch.mean((res[:, :, :, :, 1:] - res[:, :, :, :, :-1]) ** 2)
    ) / 3.0


def _control_shape(shape_xyz, cf):
    X, Y, Z = shape_xyz
    return max(2, int(np.ceil(Z / cf))), max(2, int(np.ceil(Y / cf))), max(2, int(np.ceil(X / cf)))


def _optimize_stage(fixed_lab, moving_lab, base_dvf, labels, weights, cfg, stage, device):
    r = int(stage["reduce_factor"])
    base_red = _downsample_dvf(base_dvf, r)
    fix_red = _downsample_label(fixed_lab, r)
    mov_red = _downsample_label(moving_lab, r)

    fixed_oh = _labels_to_onehot(fix_red, labels, device)
    moving_oh = _labels_to_onehot(mov_red, labels, device)
    w = _weights_to_torch(labels, weights, device)
    base_t = _dvf_xyz_to_torch(base_red, device)

    D, H, W = fixed_oh.shape[-3:]
    cd, ch, cw = _control_shape(fix_red.shape, int(stage["control_factor"]))
    ctrl = torch.zeros((1, 3, cd, ch, cw), device=device, requires_grad=True)
    opt = torch.optim.Adam([ctrl], lr=float(stage["lr"]))

    max_res = float(stage["max_residual_vox"])
    lw = cfg["loss_weights"]
    best = {"loss": float("inf"), "iter": -1, "ctrl": None, "dice": None}

    for it in range(1, int(stage["iterations"]) + 1):
        opt.zero_grad(set_to_none=True)
        res = F.interpolate(ctrl, size=(D, H, W), mode="trilinear", align_corners=True)
        res = max_res * torch.tanh(res)
        dvf = base_t + res
        warped = _warp_onehot(moving_oh, dvf)
        dloss, dice_vec = _weighted_dice_loss(warped, fixed_oh, w)
        smooth = _smoothness_loss(res)
        mag = torch.mean(res * res)
        loss = lw["dice"] * dloss + lw["smooth"] * smooth + lw["magnitude"] * mag
        loss.backward()
        opt.step()
        val = float(loss.detach().cpu())
        if val < best["loss"]:
            best = {"loss": val, "iter": it, "ctrl": ctrl.detach().clone(), "dice": dice_vec}

    with torch.no_grad():
        res = F.interpolate(best["ctrl"], size=(D, H, W), mode="trilinear", align_corners=True)
        res = max_res * torch.tanh(res)
        return _torch_dvf_to_xyz(res), best


def _upsample_residual(res_red, full_shape, r):
    t = _dvf_xyz_to_torch(res_red, "cpu")
    X, Y, Z = full_shape
    up = F.interpolate(t, size=(Z, Y, X), mode="trilinear", align_corners=True)
    return (_torch_dvf_to_xyz(up) * float(r)).astype(np.float32)


def _load_calibrated_weights(cfg: Dict) -> Dict[int, float]:
    labels = [int(x) for x in cfg["labels"]]
    weights = {lab: float(cfg["default_lobe_weights"].get(str(lab), 1.0)) for lab in labels}
    per_lobe = Path(cfg.get("c8a_per_lobe_csv", ""))
    strength = float(cfg.get("calibration_strength", 0.5))
    if not per_lobe.exists():
        return weights

    gains = {lab: [] for lab in labels}
    with per_lobe.open("r", newline="") as f:
        for row in csv.DictReader(f):
            try:
                lab = int(row["label"])
                delta = float(row["delta"])
            except Exception:
                continue
            if lab in gains and not math.isnan(delta):
                gains[lab].append(delta)
    for lab, vals in gains.items():
        if not vals:
            continue
        mean_gain = float(np.mean(vals))
        # Larger oracle gain means the pseudo registration missed that anatomy;
        # raise the lobe importance, but only moderately.
        weights[lab] *= (1.0 + strength * min(3.0, max(0.0, mean_gain * 100.0)))
    # normalize around mean 1-ish while preserving relative weights
    mean_w = float(np.mean(list(weights.values())))
    if mean_w > 0:
        weights = {k: v / mean_w * 1.35 for k, v in weights.items()}
    return weights


def _candidate_select(current, residual, fixed_lab, moving_lab, labels, weights, parent_per, cfg):
    best = None
    details = []
    parent_rml = parent_per.get("dice_64", float("nan"))
    hard_case = (not math.isnan(parent_rml)) and parent_rml < float(cfg["hard_case_rml_parent_threshold"])

    for sc in cfg["candidate_scales"]:
        cand = current + float(sc) * residual
        fold = _folding_pct(cand)
        warped = _warp_label_numpy(moving_lab, cand)
        mean_dice, per = _dice_np(fixed_lab, warped, labels)
        wmean = _weighted_mean_dice(per, weights)
        rml_gain = per.get("dice_64", 0.0) - parent_per.get("dice_64", 0.0)
        mean_gain = mean_dice - parent_per.get("mean", mean_dice)
        non_rml_losses = []
        for lab in labels:
            if lab == 64:
                continue
            before = parent_per.get(f"dice_{lab}", float("nan"))
            after = per.get(f"dice_{lab}", float("nan"))
            if not math.isnan(before) and not math.isnan(after):
                non_rml_losses.append(before - after)
        max_non_rml_loss = max(non_rml_losses) if non_rml_losses else 0.0

        rejected = False
        reasons = []
        if fold > float(cfg["hard_reject_folding_pct"]):
            rejected = True
            reasons.append(f"folding {fold:.6f} > hard {cfg['hard_reject_folding_pct']}")
        if float(sc) > 0:
            if mean_gain < float(cfg["minimum_proxy_gain"]) and not (hard_case and rml_gain > float(cfg["minimum_rml_proxy_gain_for_hard_case"])):
                rejected = True
                reasons.append(f"proxy mean gain {mean_gain:.6f} below minimum")
            if max_non_rml_loss > float(cfg["max_allowed_proxy_loss_non_rml"]):
                rejected = True
                reasons.append(f"max non-RML proxy loss {max_non_rml_loss:.6f} too large")

        score = wmean
        if hard_case:
            score += 0.30 * max(0.0, rml_gain)
        if fold > float(cfg["soft_folding_start_pct"]):
            if fold <= float(cfg["soft_folding_full_pct"]):
                score -= 0.005 * (fold - cfg["soft_folding_start_pct"]) / max(1e-6, cfg["soft_folding_full_pct"] - cfg["soft_folding_start_pct"])
            else:
                score -= 0.005 + 0.035 * min(1.0, (fold - cfg["soft_folding_full_pct"]) / max(1e-6, cfg["hard_reject_folding_pct"] - cfg["soft_folding_full_pct"]))

        rec = {
            "scale": float(sc),
            "mean_pseudo_dice": mean_dice,
            "weighted_pseudo_dice": wmean,
            "score": float(score),
            "folding_pct": fold,
            "rml_gain": rml_gain,
            "mean_gain": mean_gain,
            "max_non_rml_loss": max_non_rml_loss,
            "rejected": rejected,
            "reject_reasons": reasons,
            **per,
        }
        details.append(rec)
        if not rejected and (best is None or rec["score"] > best["score"]):
            best = rec

    if best is None:
        best = [x for x in details if x["scale"] == 0.0][0]
    return best, details


def run_case(case_id: str, cfg: Dict) -> Dict:
    if nib is None or torch is None:
        raise RuntimeError("nibabel and torch are required")
    t0 = time.time()
    labels = [int(x) for x in cfg["labels"]]
    weights = _load_calibrated_weights(cfg)
    device = cfg["device"]
    if device == "cuda" and not torch.cuda.is_available():
        device = "cpu"

    parent_p = _find_parent_dvf(case_id, cfg)
    parent_img, parent_dvf = _load_img(parent_p)
    parent_dvf = parent_dvf.astype(np.float32)

    pseudo_root = Path(cfg["pseudo_segmentation_root"])
    fixed_p = _find_pseudo_lobe(pseudo_root, case_id, "INSP")
    moving_p = _find_pseudo_lobe(pseudo_root, case_id, "EXP")
    out_root = Path(cfg["output_root"])

    if fixed_p is None or moving_p is None:
        out_dvf = out_root / "dvfs" / f"{case_id}_DVF.nii.gz"
        out_can = out_root / "dvfs_canonical_ras" / f"{case_id}_DVF.nii.gz"
        _save_like(parent_img, parent_dvf, out_dvf)
        _save_like(parent_img, parent_dvf, out_can)
        rec = {
            "case_id": case_id,
            "status": "fallback",
            "mode": "exact_parent_no_pseudo_labels",
            "parent_dvf": str(parent_p),
            "parent_pseudo_mean_dice": 0.0,
            "final_pseudo_mean_dice": 0.0,
            "final_minus_parent_pseudo_mean_dice": 0.0,
            "final_folding_pct": _folding_pct(parent_dvf),
            "elapsed_sec": time.time() - t0,
        }
        (out_root / "case_manifests" / f"{case_id}_manifest.json").write_text(json.dumps(rec, indent=2))
        return rec

    _, fixed_lab = _load_img(fixed_p)
    _, moving_lab = _load_img(moving_p)
    fixed_lab = fixed_lab.astype(np.int16)
    moving_lab = moving_lab.astype(np.int16)

    parent_warp = _warp_label_numpy(moving_lab, parent_dvf)
    parent_mean, parent_per = _dice_np(fixed_lab, parent_warp, labels)
    parent_per["mean"] = parent_mean
    current = parent_dvf.copy()
    stages = []

    for stage in cfg["stages"]:
        res_red, opt_info = _optimize_stage(fixed_lab, moving_lab, current, labels, weights, cfg, stage, device)
        residual_full = _upsample_residual(res_red, current.shape[:3], int(stage["reduce_factor"]))
        best, candidates = _candidate_select(current, residual_full, fixed_lab, moving_lab, labels, weights, parent_per, cfg)
        current = current + float(best["scale"]) * residual_full
        current_warp = _warp_label_numpy(moving_lab, current)
        cur_mean, cur_per = _dice_np(fixed_lab, current_warp, labels)
        cur_per["mean"] = cur_mean
        # Update parent_per for stage-local non-regression guard.
        parent_per = cur_per
        stages.append({
            "stage": stage["name"],
            "optimization": {"best_loss": opt_info["loss"], "best_iter": opt_info["iter"]},
            "selected": best,
            "candidates": candidates,
        })

    final_warp = _warp_label_numpy(moving_lab, current)
    final_mean, final_per = _dice_np(fixed_lab, final_warp, labels)
    final_fold = _folding_pct(current)

    # Final safety: exact parent fallback if no useful pseudo gain.
    mode = "calibrated_pseudo_tto"
    if final_mean < parent_mean + float(cfg["minimum_proxy_gain"]):
        if cfg.get("copy_parent_on_reject", True):
            current = parent_dvf
            final_mean, final_per = parent_mean, {k: v for k, v in parent_per.items() if k != "mean"}
            final_fold = _folding_pct(parent_dvf)
            mode = "exact_parent_fallback_no_proxy_gain"

    out_dvf = out_root / "dvfs" / f"{case_id}_DVF.nii.gz"
    out_can = out_root / "dvfs_canonical_ras" / f"{case_id}_DVF.nii.gz"
    _save_like(parent_img, current, out_dvf)
    _save_like(parent_img, current, out_can)

    rec = {
        "case_id": case_id,
        "status": "ok",
        "mode": mode,
        "note": "Uses pseudo labels only in optimizer; optional calibration is global from prior C8A gap audit.",
        "device": device,
        "parent_dvf": str(parent_p),
        "fixed_pseudo_lobe": str(fixed_p),
        "moving_pseudo_lobe": str(moving_p),
        "output_dvf": str(out_dvf),
        "calibrated_lobe_weights": {str(k): v for k, v in weights.items()},
        "parent_pseudo_mean_dice": parent_mean,
        "final_pseudo_mean_dice": final_mean,
        "final_minus_parent_pseudo_mean_dice": final_mean - parent_mean,
        "parent_folding_pct": _folding_pct(parent_dvf),
        "final_folding_pct": final_fold,
        "final_pseudo_lobe_dice": final_per,
        "stages": stages,
        "elapsed_sec": time.time() - t0,
    }
    (out_root / "case_manifests" / f"{case_id}_manifest.json").write_text(json.dumps(rec, indent=2))
    return rec


def summarize(cfg: Dict, records: List[Dict], failed: List[Dict]) -> Dict:
    vals = [r["final_pseudo_mean_dice"] for r in records]
    parents = [r["parent_pseudo_mean_dice"] for r in records]
    folds = [r["final_folding_pct"] for r in records]
    modes = {}
    for r in records:
        modes[r["mode"]] = modes.get(r["mode"], 0) + 1
    return {
        "status": "PASS" if not failed else "PARTIAL_FAIL",
        "method": "SGR-FM C8B calibrated pseudo-label registration",
        "case_count": len(records),
        "failure_count": len(failed),
        "mode_histogram": modes,
        "parent_mean_pseudo_dice": float(np.mean(parents)) if parents else None,
        "final_mean_pseudo_dice": float(np.mean(vals)) if vals else None,
        "final_minus_parent_mean_pseudo_dice": float(np.mean(vals) - np.mean(parents)) if vals else None,
        "mean_final_folding_pct": float(np.mean(folds)) if folds else None,
        "max_final_folding_pct": float(np.max(folds)) if folds else None,
        "failed_cases": failed,
        "output_root": cfg["output_root"],
        "parent_dir": cfg["parent_dir"],
        "uses_validation_gt_in_optimizer": False,
        "calibration_sources": {
            "c8a_per_case_csv": cfg.get("c8a_per_case_csv"),
            "c8a_per_lobe_csv": cfg.get("c8a_per_lobe_csv"),
        },
    }


def write_case_csv(cfg: Dict, records: List[Dict]):
    out = Path(cfg["output_root"]) / "calibration"
    out.mkdir(parents=True, exist_ok=True)
    path = out / "c8b_pseudolabel_calibrated_per_case.csv"
    fields = [
        "case_id", "mode", "parent_pseudo_mean_dice", "final_pseudo_mean_dice",
        "final_minus_parent_pseudo_mean_dice", "parent_folding_pct", "final_folding_pct",
    ]
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in records:
            w.writerow({k: r.get(k) for k in fields})
