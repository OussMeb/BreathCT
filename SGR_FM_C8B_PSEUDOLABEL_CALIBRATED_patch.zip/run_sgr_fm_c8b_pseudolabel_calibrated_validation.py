#!/usr/bin/env python3
"""
SGR-FM C8B: GT-gap-calibrated pseudo-label registration.

This is the generalizable branch after C8A. It does NOT use validation GT labels
inside the per-case optimizer. It uses pseudo lobe labels plus optional global
calibration statistics derived from the C8A gap audit.
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

from utils.sgr_fm_c8b_pseudolabel_calibrated import (
    load_config,
    discover_cases,
    run_case,
    summarize,
    write_case_csv,
)


def main() -> int:
    ap = argparse.ArgumentParser(description="Run SGR-FM C8B calibrated pseudo-label registration.")
    ap.add_argument("--config", required=True)
    ap.add_argument("--cases", nargs="*", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    out_root = Path(cfg["output_root"])
    for sub in ["dvfs", "dvfs_canonical_ras", "case_manifests", "eval", "calibration", "traces"]:
        (out_root / sub).mkdir(parents=True, exist_ok=True)

    cases = args.cases or discover_cases(cfg)

    if args.dry_run:
        payload = {
            "status": "DRY_RUN",
            "method": "SGR-FM C8B calibrated pseudo-label registration",
            "cases": cases,
            "output_root": cfg["output_root"],
            "parent_dir": cfg["parent_dir"],
            "pseudo_segmentation_root": cfg["pseudo_segmentation_root"],
            "calibration_sources": {
                "c8a_per_case_csv": cfg.get("c8a_per_case_csv"),
                "c8a_per_lobe_csv": cfg.get("c8a_per_lobe_csv"),
            },
            "note": "No validation GT labels are used during per-case optimization.",
        }
        print(json.dumps(payload, indent=2))
        return 0

    records = []
    failed = []
    for case_id in cases:
        try:
            rec = run_case(case_id, cfg)
            records.append(rec)
            print(
                f"PASS {case_id} "
                f"mode={rec['mode']} "
                f"parent_proxy={rec['parent_pseudo_mean_dice']:.6f} "
                f"final_proxy={rec['final_pseudo_mean_dice']:.6f} "
                f"proxy_gain={rec['final_minus_parent_pseudo_mean_dice']:+.6f} "
                f"fold={rec['final_folding_pct']:.6f}%"
            )
        except Exception as exc:
            failed.append({"case_id": case_id, "error": repr(exc)})
            print(f"FAIL {case_id}: {exc!r}", file=sys.stderr)
            if not cfg.get("continue_on_error", False):
                break

    summary = summarize(cfg, records, failed)
    (out_root / "c8b_pseudolabel_calibrated_summary.json").write_text(json.dumps(summary, indent=2))
    write_case_csv(cfg, records)

    eval_script = Path(cfg.get("evaluate_script", "evaluate_validation.py"))
    if len(records) == 10 and not failed and eval_script.exists():
        cmd = [
            sys.executable,
            str(eval_script),
            "--raw-data-root",
            str(cfg["raw_data_root"]),
            "--dvf-dir",
            str(out_root / "dvfs"),
            "--output-dir",
            str(out_root / "eval"),
        ]
        subprocess.run(cmd, check=False)

    print(json.dumps(summary, indent=2))
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
