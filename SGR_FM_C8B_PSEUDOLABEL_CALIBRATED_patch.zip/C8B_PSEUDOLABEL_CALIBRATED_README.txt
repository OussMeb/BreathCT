SGR-FM C8B calibrated pseudo-label registration
===============================================

Purpose
-------
C8B is the generalizable follow-up to C8A. C8A showed that using true
validation labels raises the score strongly, but those labels are not available
on hidden test.

C8B therefore uses:
- C7B as parent initializer
- pseudo INSP/EXP lobe labels
- optional global lobe calibration from the C8A gap audit
- conservative non-regression guards
- RML-aware weighting
- the requested folding policy:
  soft zone: 0.25% to 0.30%
  hard reject: 0.50%

It does not use validation GT labels inside per-case optimization.

Install
-------
cd "/home/oussama/Desktop/MICCAI FRANCE"
unzip -o SGR_FM_C8B_PSEUDOLABEL_CALIBRATED_patch.zip -d .

Compile
-------
python -m py_compile \
  run_sgr_fm_c8b_pseudolabel_calibrated_validation.py \
  utils/sgr_fm_c8b_pseudolabel_calibrated.py \
  smoke_sgr_fm_c8b_pseudolabel_calibrated_synthetic.py

Smoke
-----
python smoke_sgr_fm_c8b_pseudolabel_calibrated_synthetic.py

Dry run
-------
python run_sgr_fm_c8b_pseudolabel_calibrated_validation.py \
  --config configs/sgr_fm_c8b_pseudolabel_calibrated.yaml \
  --dry-run

Hard-case test
--------------
python run_sgr_fm_c8b_pseudolabel_calibrated_validation.py \
  --config configs/sgr_fm_c8b_pseudolabel_calibrated.yaml \
  --cases NLST_0006 NLST_0007 NLST_0008 NLST_0009

Full validation
---------------
python run_sgr_fm_c8b_pseudolabel_calibrated_validation.py \
  --config configs/sgr_fm_c8b_pseudolabel_calibrated.yaml

Upload after full run
---------------------
outputs/sgr_fm/c8b_pseudolabel_calibrated/c8b_pseudolabel_calibrated_summary.json
outputs/sgr_fm/c8b_pseudolabel_calibrated/eval/validation_metrics.json
outputs/sgr_fm/c8b_pseudolabel_calibrated/calibration/c8b_pseudolabel_calibrated_per_case.csv
outputs/sgr_fm/c8b_pseudolabel_calibrated/case_manifests/NLST_0006_manifest.json
outputs/sgr_fm/c8b_pseudolabel_calibrated/case_manifests/NLST_0007_manifest.json
outputs/sgr_fm/c8b_pseudolabel_calibrated/case_manifests/NLST_0008_manifest.json
