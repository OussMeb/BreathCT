#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.sgr_fm_c10_hybrid_label_aware import (
    discover_cases,
    evaluate_case,
    load_config,
    make_qc_figure,
    run_hybrid_case,
    summarize_run,
    write_evaluation,
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run C10 hybrid GT/pseudo-label registration.")
    p.add_argument("--config", default="configs/sgr_fm_c10_hybrid_label_aware.yaml")
    p.add_argument("--split", choices=("training", "validation", "both"), default="validation")
    p.add_argument("--label-policy", choices=("auto", "gt", "pseudo"), default=None)
    p.add_argument("--cases", nargs="*", default=None)
    p.add_argument("--limit", type=int, default=None)
    p.add_argument("--output-root", default=None)
    p.add_argument("--device", choices=("cuda", "cpu"), default=None)
    p.add_argument("--skip-existing", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--evaluate", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--visualize", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--visualize-limit", type=int, default=None)
    p.add_argument("--dry-run", action="store_true")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    cfg = load_config(args.config)
    if args.output_root:
        p = Path(args.output_root).expanduser()
        cfg["output_root"] = str(p if p.is_absolute() else Path(cfg["project_root"]) / p)
    if args.device:
        cfg["device"] = args.device
    if args.skip_existing is not None:
        cfg["skip_existing"] = args.skip_existing
    if args.evaluate is not None:
        cfg["evaluate_after_run"] = args.evaluate
    if args.visualize is not None:
        cfg["make_visualizations"] = args.visualize
    if args.visualize_limit is not None:
        cfg["visualization_limit"] = args.visualize_limit

    out_root = Path(cfg["output_root"])
    for sub in ["dvfs", "case_manifests", "evaluation", "qc", "branch_work"]:
        (out_root / sub).mkdir(parents=True, exist_ok=True)

    splits = ["training", "validation"] if args.split == "both" else [args.split]
    all_records = []
    all_failed = []
    per_split_eval = {}

    for split in splits:
        cases = discover_cases(cfg, split)
        if args.cases:
            wanted = set(args.cases)
            cases = [case for case in cases if case.case_id in wanted]
        if args.limit is not None:
            cases = cases[: args.limit]

        if args.dry_run:
            print(json.dumps({
                "status": "DRY_RUN",
                "split": split,
                "case_ids": [c.case_id for c in cases],
                "label_policy": args.label_policy or cfg.get("label_policy", "auto"),
                "output_root": str(out_root),
                "parent_candidates": cfg["parent_candidates"].get(split, {}),
            }, indent=2))
            continue

        split_records = []
        split_failed = []
        eval_rows = []
        visualized = 0

        for case in cases:
            final_dvf = out_root / "dvfs" / split / f"{case.case_id}_DVF.nii.gz"
            try:
                if cfg.get("skip_existing", False) and final_dvf.exists():
                    rec = {
                        "case_id": case.case_id,
                        "split": split,
                        "status": "reused",
                        "label_mode": "unknown_reused",
                        "output_dvf": str(final_dvf),
                    }
                else:
                    rec = run_hybrid_case(case, cfg, args.label_policy)
                split_records.append(rec)
                all_records.append(rec)

                if cfg.get("evaluate_after_run", True):
                    eval_rows.append(evaluate_case(case, final_dvf, cfg))
                if cfg.get("make_visualizations", True) and visualized < int(cfg.get("visualization_limit", 10)):
                    qc_path = out_root / "qc" / split / f"{case.case_id}_qc.png"
                    make_qc_figure(case, final_dvf, cfg, qc_path)
                    visualized += 1

                print(
                    f"PASS {case.case_id} split={split} "
                    f"mode={rec.get('label_mode')} output={final_dvf}"
                )
            except Exception as exc:
                err = {"case_id": case.case_id, "split": split, "error": repr(exc)}
                split_failed.append(err)
                all_failed.append(err)
                print(f"FAIL {case.case_id}: {exc!r}", file=sys.stderr)
                if not cfg.get("continue_on_error", False):
                    break

        if eval_rows:
            per_split_eval[split] = write_evaluation(cfg, split, eval_rows)
        split_summary = summarize_run(cfg, split_records, split_failed)
        (out_root / f"c10_{split}_summary.json").write_text(json.dumps(split_summary, indent=2))

    if args.dry_run:
        return 0

    summary = summarize_run(cfg, all_records, all_failed)
    summary["evaluation"] = per_split_eval
    (out_root / "c10_hybrid_summary.json").write_text(json.dumps(summary, indent=2))
    (out_root / "run_config_resolved.json").write_text(json.dumps(cfg, indent=2))
    print(json.dumps(summary, indent=2))
    return 0 if not all_failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
