#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.sgr_fm_c10_hybrid_label_aware import discover_cases, load_config, make_qc_figure


def main() -> int:
    p = argparse.ArgumentParser(description="Create C10 segmentation/registration QC figures.")
    p.add_argument("--config", default="configs/sgr_fm_c10_hybrid_label_aware.yaml")
    p.add_argument("--split", choices=("training", "validation"), required=True)
    p.add_argument("--case", required=True)
    p.add_argument("--dvf", default=None)
    p.add_argument("--output", default=None)
    args = p.parse_args()

    cfg = load_config(args.config)
    matches = [c for c in discover_cases(cfg, args.split) if c.case_id == args.case]
    if not matches:
        raise FileNotFoundError(f"Case not found: {args.case}")
    case = matches[0]
    dvf = Path(args.dvf) if args.dvf else Path(cfg["output_root"]) / "dvfs" / args.split / f"{args.case}_DVF.nii.gz"
    output = Path(args.output) if args.output else Path(cfg["output_root"]) / "qc" / args.split / f"{args.case}_qc.png"
    path = make_qc_figure(case, dvf, cfg, output)
    print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
