#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.sgr_fm_c10_hybrid_label_aware import discover_cases, evaluate_case, load_config, write_evaluation


def main() -> int:
    p = argparse.ArgumentParser(description="Evaluate C10 outputs quantitatively.")
    p.add_argument("--config", default="configs/sgr_fm_c10_hybrid_label_aware.yaml")
    p.add_argument("--split", choices=("training", "validation"), required=True)
    p.add_argument("--dvf-dir", default=None, help="Default: <output_root>/dvfs/<split>")
    p.add_argument("--cases", nargs="*", default=None)
    p.add_argument("--limit", type=int, default=None)
    args = p.parse_args()

    cfg = load_config(args.config)
    dvf_dir = Path(args.dvf_dir) if args.dvf_dir else Path(cfg["output_root"]) / "dvfs" / args.split
    cases = discover_cases(cfg, args.split)
    if args.cases:
        wanted = set(args.cases)
        cases = [c for c in cases if c.case_id in wanted]
    if args.limit is not None:
        cases = cases[: args.limit]

    rows = []
    for case in cases:
        dvf = dvf_dir / f"{case.case_id}_DVF.nii.gz"
        if not dvf.exists():
            raise FileNotFoundError(f"Missing DVF: {dvf}")
        row = evaluate_case(case, dvf, cfg)
        rows.append(row)
        print(
            f"{case.case_id}: gt={row.get('gt_mean_lobe_dice')} "
            f"pseudo={row.get('pseudo_mean_lobe_dice')} "
            f"dNCC={row.get('delta_ncc'):+.6f} fold={row.get('folding_percentage'):.6f}%"
        )

    summary = write_evaluation(cfg, args.split, rows)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
