#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.sgr_fm_c10_hybrid_label_aware import discover_cases, load_config


def main() -> int:
    p = argparse.ArgumentParser(description="Prepare pseudo labels and raw uniGradICON parents for C10.")
    p.add_argument("--config", default="configs/sgr_fm_c10_hybrid_label_aware.yaml")
    p.add_argument("--split", choices=("training", "validation"), default="training")
    p.add_argument("--cases", nargs="*", default=None)
    p.add_argument("--limit", type=int, default=None)
    p.add_argument("--run-segmentation", action="store_true")
    p.add_argument("--run-unigradicon", action="store_true")
    p.add_argument("--overwrite-parent", action="store_true")
    p.add_argument("--fast-segmentation", action="store_true")
    args = p.parse_args()

    cfg = load_config(args.config)
    cases = discover_cases(cfg, args.split)
    if args.cases:
        wanted = set(args.cases)
        cases = [c for c in cases if c.case_id in wanted]
    if args.limit is not None:
        cases = cases[: args.limit]
    case_ids = [c.case_id for c in cases]
    if not case_ids:
        raise RuntimeError("No cases selected")

    selection_path = Path(cfg["output_root"]) / "input_preparation" / f"{args.split}_selected_cases.json"
    selection_path.parent.mkdir(parents=True, exist_ok=True)
    selection_path.write_text(json.dumps({"split": args.split, "case_ids": case_ids}, indent=2))
    print(f"Selected {len(case_ids)} cases; manifest: {selection_path}")

    if args.run_segmentation:
        cmd = [
            sys.executable,
            str(PROJECT_ROOT / "run_sgr_fm_segmentation.py"),
            "--config", str(PROJECT_ROOT / "configs/sgr_fm_phase1_segmentation.yaml"),
            "--raw-data-root", cfg["raw_data_root"],
            "--output-dir", cfg["pseudo_segmentation_root"],
            "--splits", args.split,
            "--phases", "EXP", "INSP",
            "--case-ids", *case_ids,
            "--skip-support",
            "--skip-evaluation",
            "--allow-unfrozen-dvfs",
        ]
        if args.fast_segmentation:
            cmd.append("--fast")
        print("RUN:", " ".join(cmd))
        subprocess.run(cmd, check=True)

    if args.run_unigradicon:
        parent_dir = Path(cfg["project_root"]) / "outputs/unigradicon_raw_training_c10" if args.split == "training" else Path(cfg["project_root"]) / "outputs/unigradicon_raw_validation_c10"
        cmd = [
            sys.executable,
            str(PROJECT_ROOT / "run_unigradicon.py"),
            "--config", str(PROJECT_ROOT / "configs/unigradicon_baseline.yaml"),
            "--raw-data-root", cfg["raw_data_root"],
            "--split", args.split,
            "--output-dir", str(parent_dir),
            "--case-ids", *case_ids,
            "--no-make-zip",
            "--no-evaluate",
            "--save-canonical",
        ]
        if args.overwrite_parent:
            cmd.append("--overwrite")
        print("RUN:", " ".join(cmd))
        subprocess.run(cmd, check=True)

    if not args.run_segmentation and not args.run_unigradicon:
        print("No expensive preparation was launched. Add --run-segmentation and/or --run-unigradicon.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
