SGR-FM C10 Hybrid Label-Aware Registration
===========================================

Purpose
-------
C10 is a unified inference framework, not a new trained network.

- If paired GT lobe labels are physically available, C10 routes the case through
  the established C8A GT-assisted optimizer.
- If GT labels are absent, C10 routes the case through the established C8B
  pseudo-label optimizer.
- Each case records the selected label source and parent DVF.
- The final DVF still warps the complete EXP CT, not only the labels.

Install
-------
Extract this ZIP at the project root:

  cd "/home/oussama/Desktop/MICCAI FRANCE"
  unzip -o SGR_FM_C10_HYBRID_patch.zip

Verify
------

  python -m py_compile \
    utils/sgr_fm_c10_hybrid_label_aware.py \
    run_sgr_fm_c10_hybrid_inference.py \
    evaluate_sgr_fm_c10_hybrid.py \
    visualize_sgr_fm_c10_case.py \
    prepare_sgr_fm_c10_inputs.py \
    smoke_sgr_fm_c10_hybrid.py

  python smoke_sgr_fm_c10_hybrid.py

Validation: automatic GT mode on all 10 cases
---------------------------------------------
This should select GT mode because validation labels are present.

  python run_sgr_fm_c10_hybrid_inference.py \
    --config configs/sgr_fm_c10_hybrid_label_aware.yaml \
    --split validation \
    --label-policy auto \
    --limit 10 \
    --evaluate \
    --visualize

Validation: forced pseudo-label comparison
------------------------------------------
Use a separate output directory so the GT run is preserved.

  python run_sgr_fm_c10_hybrid_inference.py \
    --config configs/sgr_fm_c10_hybrid_label_aware.yaml \
    --split validation \
    --label-policy pseudo \
    --limit 10 \
    --output-root outputs/sgr_fm/c10_validation_pseudo \
    --evaluate \
    --visualize

Training: prepare a deterministic first 100-case subset
-------------------------------------------------------
This runs TotalSegmentator lobe inference and raw uniGradICON initialization.
It is expensive. The selected case list is saved before execution.

  python prepare_sgr_fm_c10_inputs.py \
    --config configs/sgr_fm_c10_hybrid_label_aware.yaml \
    --split training \
    --limit 100 \
    --run-segmentation \
    --run-unigradicon

Training: run pseudo-label mode on the same first 100 cases
----------------------------------------------------------

  python run_sgr_fm_c10_hybrid_inference.py \
    --config configs/sgr_fm_c10_hybrid_label_aware.yaml \
    --split training \
    --label-policy auto \
    --limit 100 \
    --evaluate \
    --visualize \
    --visualize-limit 10

Outputs
-------

  outputs/sgr_fm/c10_hybrid_label_aware/
  ├── dvfs/training/ and dvfs/validation/
  ├── case_manifests/<split>/
  ├── evaluation/<split>/<split>_metrics.csv/json
  ├── qc/<split>/<CASE>_qc.png
  ├── branch_work/<split>/gt or pseudo/
  ├── c10_<split>_summary.json
  └── c10_hybrid_summary.json

Quantitative interpretation
---------------------------
Validation:
- GT mean lobe Dice is a true anatomical metric.
- pseudo Dice is also reported for comparison.
- NCC, MAE, folding and displacement statistics are reported.

Training:
- GT lobe Dice cannot be reported because training labels are absent.
- pseudo Dice, NCC, MAE, folding and DVF statistics are robustness proxies only.
- High pseudo Dice does not prove high hidden-test GT Dice.

Visualization
-------------
Each QC PNG shows sagittal, coronal and axial views of:
- fixed INSP CT with label overlay;
- moving EXP CT with label overlay;
- warped EXP CT with warped-label overlay;
- absolute fixed-versus-warped CT difference.

Important limitation
--------------------
The validation GT branch is only usable in hidden testing if the submitted method
is actually given the hidden labels. Evaluator-only labels cannot be read by C10.

The training pseudo branch uses a raw uniGradICON parent by default because the
full C7B lineage was not regenerated for all 200 training pairs. Its training
results therefore test robustness of the unified framework, not exact replication
of the validation C8B lineage.
