#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import shutil
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import nibabel as nib
import numpy as np

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

try:
    from scipy.ndimage import map_coordinates
except Exception:  # pragma: no cover
    map_coordinates = None

from utils.data import CaseFiles, discover_training_cases, discover_validation_cases
from utils.sgr_fm_c8a_gt_oracle import load_config as load_c8a_config
from utils.sgr_fm_c8a_gt_oracle import run_case as run_c8a_case
from utils.sgr_fm_c8b_pseudolabel_calibrated import load_config as load_c8b_config
from utils.sgr_fm_c8b_pseudolabel_calibrated import run_case as run_c8b_case

LABELS = [8, 16, 32, 64, 128]


def _load_yaml_or_json(path: Path) -> Dict[str, Any]:
    text = path.read_text()
    if path.suffix.lower() == ".json":
        return json.loads(text)
    if yaml is None:
        raise RuntimeError("PyYAML is required for C10 configuration files")
    data = yaml.safe_load(text)
    return data or {}


def _resolve_path(value: str | Path, project_root: Path) -> Path:
    p = Path(value).expanduser()
    return p if p.is_absolute() else project_root / p


def load_config(path: str | Path) -> Dict[str, Any]:
    cfg_path = Path(path).expanduser().resolve()
    cfg = _load_yaml_or_json(cfg_path)
    project_root = cfg_path.parent.parent

    cfg.setdefault("project_root", str(project_root))
    project_root = _resolve_path(cfg["project_root"], project_root).resolve()
    cfg["project_root"] = str(project_root)

    cfg.setdefault("raw_data_root", "Learn2Breath_train_val_data")
    cfg.setdefault("pseudo_segmentation_root", "outputs/sgr_fm/segmentation_phase1_totalsegmentator")
    cfg.setdefault("output_root", "outputs/sgr_fm/c10_hybrid_label_aware")
    cfg.setdefault("c8a_config", "configs/sgr_fm_c8a_gt_oracle.yaml")
    cfg.setdefault("c8b_config", "configs/sgr_fm_c8b_pseudolabel_calibrated.yaml")
    cfg.setdefault("label_policy", "auto")
    cfg.setdefault("continue_on_error", False)
    cfg.setdefault("skip_existing", False)
    cfg.setdefault("make_visualizations", True)
    cfg.setdefault("visualization_limit", 10)
    cfg.setdefault("evaluate_after_run", True)
    cfg.setdefault("device", "cuda")
    cfg.setdefault("labels", LABELS)

    defaults = {
        "validation": {
            "gt": [
                "outputs/sgr_fm/c7b_multi_init_semantic",
                "outputs/sgr_fm/c7a_v2_relaxed_selector",
            ],
            "pseudo": [
                "outputs/sgr_fm/c7b_multi_init_semantic",
                "outputs/sgr_fm/c7a_v2_relaxed_selector",
            ],
        },
        "training": {
            "pseudo": [
                "outputs/unigradicon_raw_training_c10",
                "outputs/unigradicon_raw_training",
            ]
        },
    }
    cfg.setdefault("parent_candidates", defaults)

    for key in ["raw_data_root", "pseudo_segmentation_root", "output_root", "c8a_config", "c8b_config"]:
        cfg[key] = str(_resolve_path(cfg[key], project_root))

    resolved_parents: Dict[str, Dict[str, List[str]]] = {}
    for split, modes in cfg["parent_candidates"].items():
        resolved_parents[split] = {}
        for mode, values in modes.items():
            resolved_parents[split][mode] = [str(_resolve_path(v, project_root)) for v in values]
    cfg["parent_candidates"] = resolved_parents
    return cfg


def discover_cases(cfg: Dict[str, Any], split: str) -> List[CaseFiles]:
    root = cfg["raw_data_root"]
    if split == "validation":
        return discover_validation_cases(root)
    if split == "training":
        return discover_training_cases(root)
    raise ValueError(f"Unsupported split: {split}")


def _find_pseudo_lobe(root: Path, case_id: str, phase: str) -> Optional[Path]:
    if not root.exists():
        return None
    case_l = case_id.lower()
    phase_l = phase.lower()
    scored: List[Tuple[int, Path]] = []
    for p in root.rglob("*.nii*"):
        n = p.name.lower()
        if case_l not in n or phase_l not in n:
            continue
        score = 0
        if "lobe" in n or "lobes" in n:
            score += 30
        if any(x in n for x in ["seg", "label", "mask"]):
            score += 5
        if any(x in n for x in ["interface", "fissure", "support", "body"]):
            score -= 100
        if score > 0:
            scored.append((score, p))
    if not scored:
        return None
    scored.sort(key=lambda x: (x[0], -len(str(x[1]))), reverse=True)
    return scored[0][1]


def choose_label_mode(case: CaseFiles, cfg: Dict[str, Any], policy: Optional[str] = None) -> str:
    policy = (policy or cfg.get("label_policy", "auto")).lower()
    has_gt = case.exp_lobe is not None and case.insp_lobe is not None
    pseudo_root = Path(cfg["pseudo_segmentation_root"])
    has_pseudo = (
        _find_pseudo_lobe(pseudo_root, case.case_id, "EXP") is not None
        and _find_pseudo_lobe(pseudo_root, case.case_id, "INSP") is not None
    )

    if policy == "auto":
        if has_gt:
            return "gt"
        if has_pseudo:
            return "pseudo"
        raise FileNotFoundError(f"{case.case_id}: neither paired GT nor paired pseudo lobe labels are available")
    if policy == "gt":
        if not has_gt:
            raise FileNotFoundError(f"{case.case_id}: GT mode requested but paired GT lobe labels are unavailable")
        return "gt"
    if policy == "pseudo":
        if not has_pseudo:
            raise FileNotFoundError(f"{case.case_id}: pseudo mode requested but paired pseudo lobe labels are unavailable")
        return "pseudo"
    raise ValueError("label_policy must be one of: auto, gt, pseudo")


def resolve_parent_dir(case_id: str, split: str, mode: str, cfg: Dict[str, Any]) -> Path:
    candidates = cfg.get("parent_candidates", {}).get(split, {}).get(mode, [])
    for root_text in candidates:
        root = Path(root_text)
        if (root / "dvfs" / f"{case_id}_DVF.nii.gz").exists():
            return root
    raise FileNotFoundError(
        f"{case_id}: no parent DVF found for split={split}, mode={mode}. "
        f"Checked: {candidates}"
    )


def _ensure_branch_dirs(root: Path) -> None:
    for sub in ["dvfs", "dvfs_canonical_ras", "case_manifests", "eval", "gap_audit", "calibration", "traces"]:
        (root / sub).mkdir(parents=True, exist_ok=True)


def _copy_exact(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    if src.read_bytes() != dst.read_bytes():
        raise RuntimeError(f"Byte verification failed while copying {src} -> {dst}")


def run_hybrid_case(case: CaseFiles, cfg: Dict[str, Any], policy: Optional[str] = None) -> Dict[str, Any]:
    started = time.time()
    mode = choose_label_mode(case, cfg, policy)
    parent_dir = resolve_parent_dir(case.case_id, case.split, mode, cfg)
    output_root = Path(cfg["output_root"])
    branch_root = output_root / "branch_work" / case.split / mode
    _ensure_branch_dirs(branch_root)

    if mode == "gt":
        branch_cfg = load_c8a_config(cfg["c8a_config"])
        branch_cfg.update({
            "output_root": str(branch_root),
            "parent_dir": str(parent_dir),
            "fallback_parent_dir": str(parent_dir),
            "raw_data_root": cfg["raw_data_root"],
            "validation_root": str(Path(cfg["raw_data_root"]) / "validation"),
            "pseudo_segmentation_root": cfg["pseudo_segmentation_root"],
            "device": cfg.get("device", branch_cfg.get("device", "cuda")),
            "continue_on_error": False,
        })
        branch_record = run_c8a_case(case.case_id, branch_cfg)
        branch_dvf = branch_root / "dvfs" / f"{case.case_id}_DVF.nii.gz"
        primary_metric = branch_record.get("oracle_gt_mean_dice")
    else:
        branch_cfg = load_c8b_config(cfg["c8b_config"])
        branch_cfg.update({
            "output_root": str(branch_root),
            "parent_dir": str(parent_dir),
            "fallback_parent_dir": str(parent_dir),
            "raw_data_root": cfg["raw_data_root"],
            "pseudo_segmentation_root": cfg["pseudo_segmentation_root"],
            "device": cfg.get("device", branch_cfg.get("device", "cuda")),
            "continue_on_error": False,
        })
        branch_record = run_c8b_case(case.case_id, branch_cfg)
        branch_dvf = branch_root / "dvfs" / f"{case.case_id}_DVF.nii.gz"
        primary_metric = branch_record.get("final_pseudo_mean_dice")

    if not branch_dvf.exists():
        raise FileNotFoundError(f"Branch completed without expected DVF: {branch_dvf}")

    final_dvf = output_root / "dvfs" / case.split / f"{case.case_id}_DVF.nii.gz"
    _copy_exact(branch_dvf, final_dvf)

    rec = {
        "case_id": case.case_id,
        "split": case.split,
        "status": "ok",
        "label_mode": mode,
        "label_policy": policy or cfg.get("label_policy", "auto"),
        "parent_dir": str(parent_dir),
        "parent_dvf": str(parent_dir / "dvfs" / f"{case.case_id}_DVF.nii.gz"),
        "output_dvf": str(final_dvf),
        "fixed_ct": str(case.insp_ct),
        "moving_ct": str(case.exp_ct),
        "fixed_gt_lobe": str(case.insp_lobe) if case.insp_lobe else None,
        "moving_gt_lobe": str(case.exp_lobe) if case.exp_lobe else None,
        "uses_case_gt_in_optimizer": mode == "gt",
        "primary_branch_metric": primary_metric,
        "branch_record": branch_record,
        "elapsed_sec": time.time() - started,
    }
    manifest_path = output_root / "case_manifests" / case.split / f"{case.case_id}.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(rec, indent=2))
    return rec


def _load_array(path: Path, dtype: Optional[np.dtype] = None) -> np.ndarray:
    arr = np.asanyarray(nib.load(str(path)).dataobj)
    return arr.astype(dtype, copy=False) if dtype is not None else arr


def warp_volume(moving: np.ndarray, dvf: np.ndarray, *, order: int, mode: str = "nearest") -> np.ndarray:
    if map_coordinates is None:
        raise RuntimeError("scipy is required for C10 warping/evaluation")
    if moving.ndim != 3 or dvf.ndim != 4 or dvf.shape[-1] != 3:
        raise ValueError(f"Invalid moving/DVF shapes: {moving.shape}, {dvf.shape}")
    x, y, z = np.ogrid[: moving.shape[0], : moving.shape[1], : moving.shape[2]]
    coords = np.empty((3,) + moving.shape, dtype=np.float32)
    coords[0] = x + dvf[..., 0]
    coords[1] = y + dvf[..., 1]
    coords[2] = z + dvf[..., 2]
    return map_coordinates(moving, coords, order=order, mode=mode, prefilter=(order > 1))


def lobe_dice(fixed: np.ndarray, warped: np.ndarray, labels: Sequence[int] = LABELS) -> Tuple[float, Dict[str, float]]:
    per: Dict[str, float] = {}
    values: List[float] = []
    for lab in labels:
        a = fixed == lab
        b = warped == lab
        den = int(a.sum() + b.sum())
        value = float("nan") if den == 0 else float(2.0 * np.logical_and(a, b).sum() / den)
        per[f"dice_{lab}"] = value
        if not math.isnan(value):
            values.append(value)
    return (float(np.mean(values)) if values else float("nan")), per


def jacobian_metrics(dvf: np.ndarray) -> Dict[str, float]:
    ux, uy, uz = dvf[..., 0], dvf[..., 1], dvf[..., 2]
    dux_dx, dux_dy, dux_dz = np.gradient(ux)
    duy_dx, duy_dy, duy_dz = np.gradient(uy)
    duz_dx, duz_dy, duz_dz = np.gradient(uz)
    j00, j01, j02 = 1 + dux_dx, dux_dy, dux_dz
    j10, j11, j12 = duy_dx, 1 + duy_dy, duy_dz
    j20, j21, j22 = duz_dx, duz_dy, 1 + duz_dz
    det = (
        j00 * (j11 * j22 - j12 * j21)
        - j01 * (j10 * j22 - j12 * j20)
        + j02 * (j10 * j21 - j11 * j20)
    )
    return {
        "folding_percentage": float(100.0 * np.mean(det < 0)),
        "jacobian_min": float(np.min(det)),
        "jacobian_p01": float(np.percentile(det, 1)),
        "jacobian_median": float(np.median(det)),
        "jacobian_p99": float(np.percentile(det, 99)),
        "jacobian_max": float(np.max(det)),
    }


def _masked_ncc(a: np.ndarray, b: np.ndarray, mask: np.ndarray) -> float:
    aa = a[mask].astype(np.float64)
    bb = b[mask].astype(np.float64)
    if aa.size < 10:
        return float("nan")
    aa -= aa.mean()
    bb -= bb.mean()
    den = math.sqrt(float(np.sum(aa * aa) * np.sum(bb * bb)))
    return float(np.sum(aa * bb) / den) if den > 1e-12 else float("nan")


def _masked_mae(a: np.ndarray, b: np.ndarray, mask: np.ndarray) -> float:
    if np.count_nonzero(mask) < 10:
        return float("nan")
    return float(np.mean(np.abs(a[mask] - b[mask])))


def _pseudo_paths(case_id: str, cfg: Dict[str, Any]) -> Tuple[Optional[Path], Optional[Path]]:
    root = Path(cfg["pseudo_segmentation_root"])
    return _find_pseudo_lobe(root, case_id, "INSP"), _find_pseudo_lobe(root, case_id, "EXP")


def evaluate_case(case: CaseFiles, dvf_path: Path, cfg: Dict[str, Any]) -> Dict[str, Any]:
    fixed_ct = _load_array(case.insp_ct, np.float32)
    moving_ct = _load_array(case.exp_ct, np.float32)
    dvf = _load_array(dvf_path, np.float32)
    if dvf.shape[:3] != fixed_ct.shape or dvf.shape[-1] != 3:
        raise ValueError(f"{case.case_id}: DVF shape {dvf.shape} does not match fixed CT {fixed_ct.shape}")

    warped_ct = warp_volume(moving_ct, dvf, order=1, mode="nearest").astype(np.float32)
    fixed_norm = np.clip(fixed_ct, -1000.0, 400.0)
    moving_norm = np.clip(moving_ct, -1000.0, 400.0)
    warped_norm = np.clip(warped_ct, -1000.0, 400.0)

    pseudo_fixed_path, pseudo_moving_path = _pseudo_paths(case.case_id, cfg)
    gt_fixed = _load_array(case.insp_lobe, np.int16) if case.insp_lobe else None
    gt_moving = _load_array(case.exp_lobe, np.int16) if case.exp_lobe else None
    pseudo_fixed = _load_array(pseudo_fixed_path, np.int16) if pseudo_fixed_path else None
    pseudo_moving = _load_array(pseudo_moving_path, np.int16) if pseudo_moving_path else None

    support = None
    if gt_fixed is not None:
        support = gt_fixed > 0
    elif pseudo_fixed is not None:
        support = pseudo_fixed > 0
    else:
        support = fixed_ct > -900
    support = np.asarray(support, dtype=bool)

    row: Dict[str, Any] = {
        "case_id": case.case_id,
        "split": case.split,
        "dvf_path": str(dvf_path),
        "ncc_before": _masked_ncc(fixed_norm, moving_norm, support),
        "ncc_after": _masked_ncc(fixed_norm, warped_norm, support),
        "mae_hu_before": _masked_mae(fixed_norm, moving_norm, support),
        "mae_hu_after": _masked_mae(fixed_norm, warped_norm, support),
        **jacobian_metrics(dvf),
    }
    row["delta_ncc"] = row["ncc_after"] - row["ncc_before"]
    row["delta_mae_hu"] = row["mae_hu_after"] - row["mae_hu_before"]

    mag = np.linalg.norm(dvf, axis=-1)
    row.update({
        "dvf_mean_magnitude_vox": float(np.mean(mag)),
        "dvf_p95_magnitude_vox": float(np.percentile(mag, 95)),
        "dvf_max_magnitude_vox": float(np.max(mag)),
    })

    if gt_fixed is not None and gt_moving is not None:
        warped_gt = warp_volume(gt_moving.astype(np.float32), dvf, order=0, mode="nearest").round().astype(np.int16)
        gt_mean, gt_per = lobe_dice(gt_fixed, warped_gt, cfg.get("labels", LABELS))
        row["gt_mean_lobe_dice"] = gt_mean
        row.update({f"gt_{k}": v for k, v in gt_per.items()})
    else:
        row["gt_mean_lobe_dice"] = None

    if pseudo_fixed is not None and pseudo_moving is not None:
        warped_pseudo = warp_volume(pseudo_moving.astype(np.float32), dvf, order=0, mode="nearest").round().astype(np.int16)
        pseudo_mean, pseudo_per = lobe_dice(pseudo_fixed, warped_pseudo, cfg.get("labels", LABELS))
        row["pseudo_mean_lobe_dice"] = pseudo_mean
        row.update({f"pseudo_{k}": v for k, v in pseudo_per.items()})
    else:
        row["pseudo_mean_lobe_dice"] = None
    return row


def write_evaluation(cfg: Dict[str, Any], split: str, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    out_dir = Path(cfg["output_root"]) / "evaluation" / split
    out_dir.mkdir(parents=True, exist_ok=True)
    if not rows:
        summary = {"split": split, "case_count": 0, "status": "EMPTY"}
        (out_dir / f"{split}_metrics.json").write_text(json.dumps(summary, indent=2))
        return summary

    fields = sorted({key for row in rows for key in row.keys()})
    with (out_dir / f"{split}_metrics.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    def mean_key(key: str) -> Optional[float]:
        values = [float(r[key]) for r in rows if r.get(key) is not None and not math.isnan(float(r[key]))]
        return float(np.mean(values)) if values else None

    summary = {
        "status": "PASS",
        "split": split,
        "case_count": len(rows),
        "metric_interpretation": (
            "Validation GT Dice is anatomical evaluation. Training pseudo Dice and CT metrics are proxies because training GT lobes are unavailable."
        ),
        "mean_gt_lobe_dice": mean_key("gt_mean_lobe_dice"),
        "mean_pseudo_lobe_dice": mean_key("pseudo_mean_lobe_dice"),
        "mean_ncc_before": mean_key("ncc_before"),
        "mean_ncc_after": mean_key("ncc_after"),
        "mean_delta_ncc": mean_key("delta_ncc"),
        "mean_mae_hu_before": mean_key("mae_hu_before"),
        "mean_mae_hu_after": mean_key("mae_hu_after"),
        "mean_folding_percentage": mean_key("folding_percentage"),
        "max_folding_percentage": max(float(r["folding_percentage"]) for r in rows),
        "mean_dvf_p95_magnitude_vox": mean_key("dvf_p95_magnitude_vox"),
        "cases": rows,
    }
    (out_dir / f"{split}_metrics.json").write_text(json.dumps(summary, indent=2))
    return summary


def _slice_indices(mask: np.ndarray) -> Tuple[int, int, int]:
    if np.any(mask):
        coords = np.argwhere(mask)
        center = np.round(coords.mean(axis=0)).astype(int)
        return int(center[0]), int(center[1]), int(center[2])
    return tuple(int(s // 2) for s in mask.shape)


def make_qc_figure(case: CaseFiles, dvf_path: Path, cfg: Dict[str, Any], output_path: Path) -> Path:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fixed_ct = _load_array(case.insp_ct, np.float32)
    moving_ct = _load_array(case.exp_ct, np.float32)
    dvf = _load_array(dvf_path, np.float32)
    warped_ct = warp_volume(moving_ct, dvf, order=1, mode="nearest")

    pseudo_fixed_path, pseudo_moving_path = _pseudo_paths(case.case_id, cfg)
    if case.insp_lobe and case.exp_lobe:
        fixed_lab = _load_array(case.insp_lobe, np.int16)
        moving_lab = _load_array(case.exp_lobe, np.int16)
        source_name = "GT"
    elif pseudo_fixed_path and pseudo_moving_path:
        fixed_lab = _load_array(pseudo_fixed_path, np.int16)
        moving_lab = _load_array(pseudo_moving_path, np.int16)
        source_name = "pseudo"
    else:
        fixed_lab = np.zeros(fixed_ct.shape, dtype=np.int16)
        moving_lab = np.zeros(fixed_ct.shape, dtype=np.int16)
        source_name = "none"

    warped_lab = warp_volume(moving_lab.astype(np.float32), dvf, order=0, mode="nearest").round().astype(np.int16)
    ix, iy, iz = _slice_indices(fixed_lab > 0)

    views = [
        ("Sagittal", lambda a: np.rot90(a[ix, :, :])),
        ("Coronal", lambda a: np.rot90(a[:, iy, :])),
        ("Axial", lambda a: np.rot90(a[:, :, iz])),
    ]
    columns = ["Fixed INSP", "Moving EXP", "Warped EXP", "|Fixed−Warped|"]
    fig, axes = plt.subplots(3, 4, figsize=(15, 11), constrained_layout=True)
    for r, (view_name, slicer) in enumerate(views):
        fixed_s = slicer(fixed_ct)
        moving_s = slicer(moving_ct)
        warped_s = slicer(warped_ct)
        diff_s = np.abs(np.clip(fixed_s, -1000, 400) - np.clip(warped_s, -1000, 400))
        lab_slices = [slicer(fixed_lab), slicer(moving_lab), slicer(warped_lab)]
        ct_slices = [fixed_s, moving_s, warped_s]
        for c in range(3):
            axes[r, c].imshow(ct_slices[c], cmap="gray", vmin=-1000, vmax=400)
            overlay = np.ma.masked_where(lab_slices[c] == 0, lab_slices[c])
            axes[r, c].imshow(overlay, alpha=0.28, interpolation="nearest")
            axes[r, c].set_title(f"{view_name} — {columns[c]}")
            axes[r, c].axis("off")
        axes[r, 3].imshow(diff_s)
        axes[r, 3].set_title(f"{view_name} — {columns[3]}")
        axes[r, 3].axis("off")

    fig.suptitle(f"{case.case_id} | split={case.split} | label overlay={source_name}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def summarize_run(cfg: Dict[str, Any], records: List[Dict[str, Any]], failed: List[Dict[str, Any]]) -> Dict[str, Any]:
    hist: Dict[str, int] = {}
    for rec in records:
        hist[rec["label_mode"]] = hist.get(rec["label_mode"], 0) + 1
    return {
        "status": "PASS" if not failed else "PARTIAL_FAIL",
        "method": "SGR-FM C10 Hybrid Label-Aware Registration",
        "case_count": len(records),
        "failure_count": len(failed),
        "label_mode_histogram": hist,
        "output_root": cfg["output_root"],
        "failed_cases": failed,
        "note": "GT is used only when paired labels are physically available and the selected label policy permits it; otherwise pseudo labels are used.",
    }
