#!/usr/bin/env python3
from __future__ import annotations

import tempfile
from pathlib import Path

import nibabel as nib
import numpy as np

from utils.sgr_fm_c10_hybrid_label_aware import jacobian_metrics, lobe_dice, warp_volume


def main() -> int:
    shape = (20, 18, 16)
    fixed = np.zeros(shape, dtype=np.int16)
    moving = np.zeros(shape, dtype=np.int16)
    fixed[5:14, 5:13, 4:12] = 64
    moving[4:13, 5:13, 4:12] = 64

    dvf = np.zeros(shape + (3,), dtype=np.float32)
    dvf[..., 0] = -1.0  # pull: sample moving one voxel toward lower x
    warped = warp_volume(moving.astype(np.float32), dvf, order=0, mode="nearest").round().astype(np.int16)
    mean, per = lobe_dice(fixed, warped, [64])
    if mean < 0.999 or per["dice_64"] < 0.999:
        raise RuntimeError(f"Synthetic label warp failed: {mean}, {per}")

    jac = jacobian_metrics(np.zeros_like(dvf))
    if jac["folding_percentage"] != 0.0 or abs(jac["jacobian_min"] - 1.0) > 1e-6:
        raise RuntimeError(f"Synthetic Jacobian failed: {jac}")

    print("C10 HYBRID SYNTHETIC SMOKE: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
