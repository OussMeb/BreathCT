#!/usr/bin/env python3
"""Core helpers for SGR-FM C2 test-time optimization (TTO).

The optimizer starts from the frozen C1 pull DVF and optimizes a small,
case-specific residual SVF using only test-time available signals:
  * raw EXP/INSP CT evidence,
  * predicted five-lobe masks,
  * predicted anatomical support masks.

Challenge validation GT is never loaded here.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable, Sequence

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F

from utils.refine_spatial import (
    downsample_dvf_5d,
    integrate_svf,
    jacobian_determinant,
    resize_volume_5d,
    warp_volume,
)
from utils.sgr_fm_c3 import (
    LOBE_LABELS,
    assert_same_canonical_grid,
    canonical_image,
    compose_pull,
    dvf_tensor_to_xyzc,
    dvf_xyzc_to_tensor,
    labels_to_one_hot,
    load_canonical_dvf,
    load_canonical_label,
    load_canonical_support,
    soft_boundary_union,
    soft_dice_per_lobe,
    support_to_tensor,
)
from utils.sgr_fm_training_assets import load_yaml_or_json, recursive_update, resolve_under_project



def sha256_json(data: Any) -> str:
    payload = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()

def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "segmentation_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "c1_dir": "outputs/sgr_fm/ablation_C1_support_guided_fm",
        "output_dir": "outputs/sgr_fm/c2_segmentation_guided_tto",
        "case_ids": [],
        "overwrite": False,
        "require_c1_fingerprint": True,
        "accepted_c1_fingerprint": "152aae30403dbd1b8102e0eb7fa008e7749e0fadc7d55216133948c7096b163e",
        "stop_on_error": True,
        "device": "cuda",
        "optimization": {
            "reduce_factor": 2,
            "coarse_control_factor": 8,
            "fine_control_factor": 4,
            "coarse_iterations": 60,
            "fine_iterations": 80,
            "coarse_lr": 0.05,
            "fine_lr": 0.02,
            "max_residual_fullres_voxels": 1.5,
            "integration_steps": 5,
            "early_stop_patience": 25,
            "min_objective_improvement": 1e-6,
            "grad_clip": 1.0,
        },
        "ct": {
            "clip_min_hu": -1000.0,
            "clip_max_hu": 400.0,
            "lncc_window": 9,
            "lncc_min_valid_fraction": 0.25,
        },
        "loss": {
            "image_lncc": 1.0,
            "lobe": 0.6,
            "interface": 0.15,
            "support": 0.05,
            "bending": 0.03,
            "residual_magnitude": 0.01,
            "jacobian": 20.0,
            "jacobian_margin": 0.02,
        },
        "selection": {
            "residual_scales": [1.0, 0.75, 0.5, 0.25, 0.125, 0.0],
            "min_proxy_lobe_gain": 0.001,
            "max_lncc_loss_increase": 0.0005,
            "max_support_dice_drop": 0.001,
            "topology_guard_mode": "relative_to_c1",
            "max_folding_increase_pct": 5e-5,
            "max_absolute_folding_pct": 1e-3,
            "score_lobe_gain": 1.0,
            "score_lncc_gain": 0.5,
            "score_interface_gain": 0.15,
            "score_support_gain": 0.05,
        },
        "evaluation": {
            "enabled": True,
            "device": "cuda",
            "c1_metrics_json": "outputs/sgr_fm/ablation_C1_support_guided_fm/eval/validation_metrics.json",
        },
    }


def build_config(config_path: str | Path | None, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    config = default_config()
    if config_path is not None:
        recursive_update(config, load_yaml_or_json(config_path, root_key="sgr_fm_tto"))
    if overrides:
        recursive_update(config, overrides)
    return config


def validation_asset_paths(segmentation_dir: Path, c1_dir: Path, case_id: str) -> dict[str, Path]:
    return {
        "exp_support": segmentation_dir / "support" / "validation" / f"{case_id}_EXP_support.nii.gz",
        "insp_support": segmentation_dir / "support" / "validation" / f"{case_id}_INSP_support.nii.gz",
        "exp_lobes": segmentation_dir / "lobes" / "validation" / f"{case_id}_EXP_lobes.nii.gz",
        "insp_lobes": segmentation_dir / "lobes" / "validation" / f"{case_id}_INSP_lobes.nii.gz",
        "c1_canonical": c1_dir / "dvfs_canonical_ras" / f"{case_id}_DVF_RAS_XYZC_voxel.nii.gz",
        "c1_original": c1_dir / "dvfs" / f"{case_id}_DVF.nii.gz",
    }


def load_canonical_ct(
    path: str | Path,
    *,
    clip_min_hu: float,
    clip_max_hu: float,
) -> tuple[np.ndarray, nib.Nifti1Image]:
    image = canonical_image(path)
    data = np.asanyarray(image.dataobj).astype(np.float32)
    if data.ndim != 3 or not np.isfinite(data).all():
        raise ValueError(f"Invalid CT {data.shape}: {path}")
    if clip_max_hu <= clip_min_hu:
        raise ValueError("clip_max_hu must be > clip_min_hu")
    data = np.clip(data, float(clip_min_hu), float(clip_max_hu))
    data = 2.0 * (data - float(clip_min_hu)) / float(clip_max_hu - clip_min_hu) - 1.0
    return data.astype(np.float32, copy=False), image


def volume_to_tensor(array: np.ndarray, *, device: torch.device) -> torch.Tensor:
    return torch.as_tensor(np.asarray(array, dtype=np.float32), device=device).unsqueeze(0).unsqueeze(0)


def downsample_one_hot(prob: torch.Tensor, factor: int) -> torch.Tensor:
    if int(factor) == 1:
        return prob
    return resize_volume_5d(prob, int(factor), mode="nearest")


def _control_shape(target_shape: Sequence[int], control_factor: int) -> tuple[int, int, int]:
    factor = max(1, int(control_factor))
    return tuple(max(2, int(math.ceil(int(dim) / factor))) for dim in target_shape)  # type: ignore[return-value]


def make_control_parameter(
    target_shape: Sequence[int],
    control_factor: int,
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.nn.Parameter:
    shape = _control_shape(target_shape, int(control_factor))
    return torch.nn.Parameter(torch.zeros((1, 3, *shape), device=device, dtype=dtype))


def residual_bound_for_shape(
    *,
    full_shape: Sequence[int],
    target_shape: Sequence[int],
    max_fullres_voxels: float,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    values: list[float] = []
    for full_dim, target_dim in zip(full_shape, target_shape):
        if int(full_dim) <= 1 or int(target_dim) <= 1:
            values.append(float(max_fullres_voxels))
        else:
            full_per_target = (float(full_dim) - 1.0) / (float(target_dim) - 1.0)
            values.append(float(max_fullres_voxels) / full_per_target)
    return torch.tensor(values, device=device, dtype=dtype).view(1, 3, 1, 1, 1)


def build_residual_svf(
    coarse_param: torch.Tensor,
    fine_param: torch.Tensor | None,
    *,
    target_shape: Sequence[int],
    full_shape: Sequence[int],
    max_fullres_voxels: float,
    scale: float = 1.0,
) -> torch.Tensor:
    target = tuple(int(v) for v in target_shape)
    coarse = F.interpolate(coarse_param, size=target, mode="trilinear", align_corners=True)
    raw = coarse
    if fine_param is not None:
        fine = F.interpolate(fine_param, size=target, mode="trilinear", align_corners=True)
        raw = raw + fine
    unit = torch.tanh(raw)
    bound = residual_bound_for_shape(
        full_shape=full_shape,
        target_shape=target,
        max_fullres_voxels=float(max_fullres_voxels),
        device=unit.device,
        dtype=unit.dtype,
    )
    return unit * bound * float(scale)


def build_residual_dvf(
    coarse_param: torch.Tensor,
    fine_param: torch.Tensor | None,
    *,
    target_shape: Sequence[int],
    full_shape: Sequence[int],
    max_fullres_voxels: float,
    integration_steps: int,
    scale: float = 1.0,
) -> torch.Tensor:
    svf = build_residual_svf(
        coarse_param,
        fine_param,
        target_shape=target_shape,
        full_shape=full_shape,
        max_fullres_voxels=max_fullres_voxels,
        scale=scale,
    )
    return integrate_svf(svf, int(integration_steps))


def binary_soft_dice(pred: torch.Tensor, target: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    dims = tuple(range(1, pred.ndim))
    inter = (pred * target).sum(dim=dims)
    denom = pred.sum(dim=dims) + target.sum(dim=dims)
    return ((2.0 * inter + eps) / (denom + eps)).mean()


def lobe_soft_dice(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    return soft_dice_per_lobe(pred, target).mean()


def interface_soft_dice(pred_lobes: torch.Tensor, target_lobes: torch.Tensor) -> torch.Tensor:
    pred = soft_boundary_union(pred_lobes, dilation_voxels=1)
    target = soft_boundary_union(target_lobes, dilation_voxels=1)
    return binary_soft_dice(pred, target)


def masked_local_ncc_loss(
    fixed: torch.Tensor,
    moving_warped: torch.Tensor,
    mask: torch.Tensor,
    *,
    window: int,
    min_valid_fraction: float,
    eps: float = 1e-5,
) -> torch.Tensor:
    if fixed.shape != moving_warped.shape or fixed.ndim != 5 or fixed.shape[1] != 1:
        raise ValueError(f"Expected matching [B,1,X,Y,Z], got {fixed.shape} and {moving_warped.shape}")
    if mask.shape != fixed.shape:
        raise ValueError(f"Mask shape mismatch {mask.shape} vs {fixed.shape}")
    win = int(window)
    if win < 3 or win % 2 == 0:
        raise ValueError(f"LNCC window must be odd and >=3, got {window}")
    pad = win // 2
    kernel_volume = float(win ** 3)

    def pool(x: torch.Tensor) -> torch.Tensor:
        return F.avg_pool3d(x, kernel_size=win, stride=1, padding=pad) * kernel_volume

    w = mask.clamp(0.0, 1.0)
    count = pool(w).clamp_min(eps)
    sum_f = pool(fixed * w)
    sum_m = pool(moving_warped * w)
    sum_ff = pool(fixed.square() * w)
    sum_mm = pool(moving_warped.square() * w)
    sum_fm = pool(fixed * moving_warped * w)

    mean_f = sum_f / count
    mean_m = sum_m / count
    cov = sum_fm / count - mean_f * mean_m
    var_f = (sum_ff / count - mean_f.square()).clamp_min(eps)
    var_m = (sum_mm / count - mean_m.square()).clamp_min(eps)
    corr = cov / torch.sqrt(var_f * var_m + eps)
    corr = corr.clamp(-1.0, 1.0)

    valid = count >= float(min_valid_fraction) * kernel_volume
    if not torch.any(valid):
        raise RuntimeError("LNCC mask produced zero valid local windows")
    return 1.0 - corr[valid].mean()


def bending_energy(field: torch.Tensor) -> torch.Tensor:
    terms: list[torch.Tensor] = []
    for dim in (-3, -2, -1):
        first = torch.diff(field, dim=dim)
        if first.shape[dim] > 1:
            terms.append(torch.diff(first, dim=dim).square().mean())
    return torch.stack(terms).sum() if terms else field.square().mean() * 0.0


def jacobian_barrier(
    dvf: torch.Tensor,
    *,
    margin: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    det = jacobian_determinant(dvf)
    loss = F.relu(float(margin) - det).square().mean()
    folding_pct = (det <= 0.0).float().mean() * 100.0
    min_det = det.amin()
    return loss, folding_pct, min_det


def topology_stats(dvf: torch.Tensor) -> dict[str, float]:
    det = jacobian_determinant(dvf).detach().float()
    return {
        "folding_pct": float((det <= 0.0).float().mean().item() * 100.0),
        "min_det": float(det.amin().item()),
        "p0_1": float(torch.quantile(det.reshape(-1), 0.001).item()),
        "p1": float(torch.quantile(det.reshape(-1), 0.01).item()),
        "p50": float(torch.quantile(det.reshape(-1), 0.5).item()),
    }


def compute_proxy_metrics(
    *,
    moving_ct: torch.Tensor,
    fixed_ct: torch.Tensor,
    moving_lobes: torch.Tensor,
    fixed_lobes: torch.Tensor,
    moving_support: torch.Tensor,
    fixed_support: torch.Tensor,
    dvf: torch.Tensor,
    lncc_window: int,
    lncc_min_valid_fraction: float,
) -> dict[str, float]:
    warped_ct = warp_volume(moving_ct, dvf, mode="bilinear")
    warped_lobes = warp_volume(moving_lobes, dvf, mode="bilinear")
    warped_support = warp_volume(moving_support, dvf, mode="bilinear")
    lobe = lobe_soft_dice(warped_lobes, fixed_lobes)
    interface = interface_soft_dice(warped_lobes, fixed_lobes)
    support = binary_soft_dice(warped_support, fixed_support)
    lncc_loss = masked_local_ncc_loss(
        fixed_ct,
        warped_ct,
        fixed_support,
        window=int(lncc_window),
        min_valid_fraction=float(lncc_min_valid_fraction),
    )
    return {
        "proxy_lobe_dice": float(lobe.item()),
        "proxy_interface_dice": float(interface.item()),
        "proxy_support_dice": float(support.item()),
        "lncc_loss": float(lncc_loss.item()),
    }


def objective_terms(
    *,
    moving_ct: torch.Tensor,
    fixed_ct: torch.Tensor,
    moving_lobes: torch.Tensor,
    fixed_lobes: torch.Tensor,
    moving_support: torch.Tensor,
    fixed_support: torch.Tensor,
    init_dvf: torch.Tensor,
    residual_dvf: torch.Tensor,
    loss_cfg: dict[str, Any],
    ct_cfg: dict[str, Any],
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    final_dvf = compose_pull(init_dvf, residual_dvf)
    warped_ct = warp_volume(moving_ct, final_dvf, mode="bilinear")
    warped_lobes = warp_volume(moving_lobes, final_dvf, mode="bilinear")
    warped_support = warp_volume(moving_support, final_dvf, mode="bilinear")

    lobe_dice = lobe_soft_dice(warped_lobes, fixed_lobes)
    interface_dice = interface_soft_dice(warped_lobes, fixed_lobes)
    support_dice = binary_soft_dice(warped_support, fixed_support)
    lncc = masked_local_ncc_loss(
        fixed_ct,
        warped_ct,
        fixed_support,
        window=int(ct_cfg.get("lncc_window", 9)),
        min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
    )
    bend = bending_energy(residual_dvf)
    magnitude = residual_dvf.square().mean()
    jac, folding_pct, min_det = jacobian_barrier(
        final_dvf,
        margin=float(loss_cfg.get("jacobian_margin", 0.02)),
    )

    total = (
        float(loss_cfg.get("image_lncc", 1.0)) * lncc
        + float(loss_cfg.get("lobe", 0.6)) * (1.0 - lobe_dice)
        + float(loss_cfg.get("interface", 0.15)) * (1.0 - interface_dice)
        + float(loss_cfg.get("support", 0.05)) * (1.0 - support_dice)
        + float(loss_cfg.get("bending", 0.03)) * bend
        + float(loss_cfg.get("residual_magnitude", 0.01)) * magnitude
        + float(loss_cfg.get("jacobian", 20.0)) * jac
    )
    return total, {
        "total": total,
        "lncc_loss": lncc,
        "proxy_lobe_dice": lobe_dice,
        "proxy_interface_dice": interface_dice,
        "proxy_support_dice": support_dice,
        "bending": bend,
        "residual_magnitude": magnitude,
        "jacobian_loss": jac,
        "folding_pct": folding_pct,
        "min_det": min_det,
    }


def tensor_terms_to_float(terms: dict[str, torch.Tensor]) -> dict[str, float]:
    return {key: float(value.detach().float().item()) for key, value in terms.items()}


def candidate_score(candidate: dict[str, float], baseline: dict[str, float], selection: dict[str, Any]) -> float:
    lobe_gain = candidate["proxy_lobe_dice"] - baseline["proxy_lobe_dice"]
    lncc_gain = baseline["lncc_loss"] - candidate["lncc_loss"]
    interface_gain = candidate["proxy_interface_dice"] - baseline["proxy_interface_dice"]
    support_gain = candidate["proxy_support_dice"] - baseline["proxy_support_dice"]
    return (
        float(selection.get("score_lobe_gain", 1.0)) * lobe_gain
        + float(selection.get("score_lncc_gain", 0.5)) * lncc_gain
        + float(selection.get("score_interface_gain", 0.15)) * interface_gain
        + float(selection.get("score_support_gain", 0.05)) * support_gain
    )


def topology_folding_limit(
    *,
    baseline_folding_pct: float,
    selection: dict[str, Any],
) -> float:
    """Return the full-resolution folding ceiling for one case.

    The default policy is relative to the frozen C1 champion: a candidate may
    increase folding only by a very small absolute percentage-point tolerance,
    while still respecting an emergency absolute ceiling. This avoids rejecting
    a candidate that is topologically better than C1 merely because C1 itself is
    above a globally tiny fixed threshold.
    """
    mode = str(selection.get("topology_guard_mode", "relative_to_c1")).strip().lower()
    max_absolute = float(selection.get("max_absolute_folding_pct", 1e-3))
    max_increase = float(selection.get("max_folding_increase_pct", 5e-5))
    if max_absolute < 0.0 or max_increase < 0.0:
        raise ValueError("Folding guard limits must be non-negative")

    if mode == "relative_to_c1":
        return min(max_absolute, float(baseline_folding_pct) + max_increase)
    if mode == "absolute":
        return max_absolute
    raise ValueError(
        f"Unsupported topology_guard_mode={mode!r}; expected 'relative_to_c1' or 'absolute'"
    )


def passes_acceptance(
    candidate: dict[str, float],
    baseline: dict[str, float],
    *,
    baseline_folding_pct: float,
    selection: dict[str, Any],
) -> tuple[bool, list[str], float]:
    reasons: list[str] = []
    lobe_gain = candidate["proxy_lobe_dice"] - baseline["proxy_lobe_dice"]
    lncc_increase = candidate["lncc_loss"] - baseline["lncc_loss"]
    support_drop = baseline["proxy_support_dice"] - candidate["proxy_support_dice"]
    fold_limit = topology_folding_limit(
        baseline_folding_pct=baseline_folding_pct,
        selection=selection,
    )

    if lobe_gain < float(selection.get("min_proxy_lobe_gain", 0.001)):
        reasons.append(f"proxy_lobe_gain={lobe_gain:.6g} below minimum")
    if lncc_increase > float(selection.get("max_lncc_loss_increase", 0.0005)):
        reasons.append(f"lncc_loss_increase={lncc_increase:.6g} above maximum")
    if support_drop > float(selection.get("max_support_dice_drop", 0.001)):
        reasons.append(f"support_dice_drop={support_drop:.6g} above maximum")
    if candidate["folding_pct"] > fold_limit + 1e-12:
        reasons.append(f"folding_pct={candidate['folding_pct']:.6g} above limit={fold_limit:.6g}")
    return (len(reasons) == 0), reasons, fold_limit


def clone_parameter_state(params: Iterable[torch.Tensor]) -> list[torch.Tensor]:
    return [p.detach().clone() for p in params]


def restore_parameter_state(params: Sequence[torch.Tensor], state: Sequence[torch.Tensor]) -> None:
    if len(params) != len(state):
        raise ValueError("Parameter state length mismatch")
    with torch.no_grad():
        for param, value in zip(params, state):
            param.copy_(value)


def load_case_tensors(
    *,
    exp_ct_path: Path,
    insp_ct_path: Path,
    assets: dict[str, Path],
    device: torch.device,
    ct_cfg: dict[str, Any],
    affine_atol: float = 1e-5,
) -> dict[str, Any]:
    for name, path in assets.items():
        if not path.exists():
            raise FileNotFoundError(f"Missing {name}: {path}")

    moving_ct_np, moving_ct_img = load_canonical_ct(
        exp_ct_path,
        clip_min_hu=float(ct_cfg.get("clip_min_hu", -1000.0)),
        clip_max_hu=float(ct_cfg.get("clip_max_hu", 400.0)),
    )
    fixed_ct_np, fixed_ct_img = load_canonical_ct(
        insp_ct_path,
        clip_min_hu=float(ct_cfg.get("clip_min_hu", -1000.0)),
        clip_max_hu=float(ct_cfg.get("clip_max_hu", 400.0)),
    )
    assert_same_canonical_grid(moving_ct_img, fixed_ct_img, name="EXP/INSP CT", affine_atol=affine_atol)

    moving_labels, _ = load_canonical_label(assets["exp_lobes"], exp_ct_path, affine_atol=affine_atol)
    fixed_labels, _ = load_canonical_label(assets["insp_lobes"], insp_ct_path, affine_atol=affine_atol)
    moving_support_np, _ = load_canonical_support(assets["exp_support"], exp_ct_path, affine_atol=affine_atol)
    fixed_support_np, _ = load_canonical_support(assets["insp_support"], insp_ct_path, affine_atol=affine_atol)
    c1_np, c1_img = load_canonical_dvf(assets["c1_canonical"], insp_ct_path, affine_atol=affine_atol)

    return {
        "moving_ct": volume_to_tensor(moving_ct_np, device=device),
        "fixed_ct": volume_to_tensor(fixed_ct_np, device=device),
        "moving_lobes": labels_to_one_hot(moving_labels, device=device),
        "fixed_lobes": labels_to_one_hot(fixed_labels, device=device),
        "moving_support": support_to_tensor(moving_support_np, device=device),
        "fixed_support": support_to_tensor(fixed_support_np, device=device),
        "c1_dvf": dvf_xyzc_to_tensor(c1_np, device=device),
        "canonical_reference": c1_img,
        "full_shape": tuple(int(v) for v in c1_np.shape[:3]),
    }


def make_lowres_state(full: dict[str, Any], reduce_factor: int) -> dict[str, torch.Tensor]:
    factor = int(reduce_factor)
    return {
        "moving_ct": resize_volume_5d(full["moving_ct"], factor, mode="trilinear"),
        "fixed_ct": resize_volume_5d(full["fixed_ct"], factor, mode="trilinear"),
        "moving_lobes": downsample_one_hot(full["moving_lobes"], factor),
        "fixed_lobes": downsample_one_hot(full["fixed_lobes"], factor),
        "moving_support": resize_volume_5d(full["moving_support"], factor, mode="nearest"),
        "fixed_support": resize_volume_5d(full["fixed_support"], factor, mode="nearest"),
        "c1_dvf": downsample_dvf_5d(full["c1_dvf"], factor),
    }
