#!/usr/bin/env python3
"""SGR-FM C2: segmentation-guided, image-constrained test-time optimization.

Starts from the frozen C1 initializer. Optimizes a small residual SVF per case
without using validation GT. A conservative no-op gate falls back exactly to C1
when proxy gains are not supported by CT evidence and topology constraints.
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.data import discover_validation_cases
from utils.dvf_io import canonical_ras_cxyz_to_original_dvf_xyzc, save_dvf_xyzc
from utils.sgr_fm_c3 import atomic_save_nifti_xyzc
from utils.sgr_fm_segmentation import assert_safe_output_dir, atomic_write_json, write_csv
from utils.sgr_fm_tto import (
    build_config,
    build_residual_dvf,
    candidate_score,
    clone_parameter_state,
    compute_proxy_metrics,
    load_case_tensors,
    make_control_parameter,
    make_lowres_state,
    objective_terms,
    passes_acceptance,
    resolve_under_project,
    sha256_json,
    restore_parameter_state,
    tensor_terms_to_float,
    topology_stats,
    validation_asset_paths,
)
from utils.sgr_fm_c3 import compose_pull, dvf_tensor_to_xyzc


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="SGR-FM C2 segmentation-guided TTO on frozen C1.")
    p.add_argument("--config", default="configs/sgr_fm_c2_tto.yaml")
    p.add_argument("--case-ids", nargs="*", default=None)
    p.add_argument("--output-dir", default=None)
    p.add_argument("--device", default=None)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--skip-evaluation", action="store_true")
    return p.parse_args()


def _resolve_config(args: argparse.Namespace) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    if args.case_ids is not None:
        overrides["case_ids"] = list(args.case_ids)
    if args.output_dir is not None:
        overrides["output_dir"] = args.output_dir
    if args.device is not None:
        overrides["device"] = args.device
    if args.overwrite:
        overrides["overwrite"] = True
    config = build_config(args.config, overrides)
    for key in ("raw_data_root", "segmentation_dir", "c1_dir", "output_dir"):
        config[key] = str(resolve_under_project(PROJECT_ROOT, config[key]))
    return config


def _optimize_stage(
    *,
    stage_name: str,
    coarse_param: torch.nn.Parameter,
    fine_param: torch.nn.Parameter | None,
    trainable_params: list[torch.nn.Parameter],
    low: dict[str, torch.Tensor],
    full_shape: tuple[int, int, int],
    opt_cfg: dict[str, Any],
    loss_cfg: dict[str, Any],
    ct_cfg: dict[str, Any],
    iterations: int,
    lr: float,
    trace: list[dict[str, Any]],
) -> dict[str, Any]:
    optimizer = torch.optim.Adam(trainable_params, lr=float(lr))
    patience = int(opt_cfg.get("early_stop_patience", 25))
    min_improvement = float(opt_cfg.get("min_objective_improvement", 1e-6))
    grad_clip = float(opt_cfg.get("grad_clip", 1.0))

    best_value = float("inf")
    best_state = clone_parameter_state(trainable_params)
    best_iter = 0
    stale = 0

    for iteration in range(1, int(iterations) + 1):
        optimizer.zero_grad(set_to_none=True)
        residual = build_residual_dvf(
            coarse_param,
            fine_param,
            target_shape=low["c1_dvf"].shape[-3:],
            full_shape=full_shape,
            max_fullres_voxels=float(opt_cfg.get("max_residual_fullres_voxels", 1.5)),
            integration_steps=int(opt_cfg.get("integration_steps", 5)),
        )
        total, terms = objective_terms(
            moving_ct=low["moving_ct"], fixed_ct=low["fixed_ct"],
            moving_lobes=low["moving_lobes"], fixed_lobes=low["fixed_lobes"],
            moving_support=low["moving_support"], fixed_support=low["fixed_support"],
            init_dvf=low["c1_dvf"], residual_dvf=residual,
            loss_cfg=loss_cfg, ct_cfg=ct_cfg,
        )
        if not torch.isfinite(total):
            raise RuntimeError(f"{stage_name}: non-finite objective at iteration {iteration}")
        total.backward()
        if grad_clip > 0:
            torch.nn.utils.clip_grad_norm_(trainable_params, max_norm=grad_clip)

        value = float(total.detach().item())
        row = {"stage": stage_name, "iteration": iteration, **tensor_terms_to_float(terms)}
        trace.append(row)
        state_at_value = clone_parameter_state(trainable_params)

        if value < best_value - min_improvement:
            best_value = value
            best_state = state_at_value
            best_iter = iteration
            stale = 0
        else:
            stale += 1

        optimizer.step()
        if stale >= patience:
            break

    restore_parameter_state(trainable_params, best_state)
    return {
        "stage": stage_name,
        "requested_iterations": int(iterations),
        "completed_iterations": int(trace[-1]["iteration"]) if trace and trace[-1]["stage"] == stage_name else 0,
        "best_iteration": int(best_iter),
        "best_objective": float(best_value),
        "early_stopped": bool(stale >= patience),
    }


def _compare_metrics(c1_json: Path, c2_json: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    c1 = json.loads(c1_json.read_text(encoding="utf-8"))
    c2 = json.loads(c2_json.read_text(encoding="utf-8"))
    c1_rows = {str(r["case_id"]): r for r in c1.get("case_metrics", [])}
    c2_rows = {str(r["case_id"]): r for r in c2.get("case_metrics", [])}
    common = sorted(set(c1_rows) & set(c2_rows))
    rows: list[dict[str, Any]] = []
    for case_id in common:
        a, b = c1_rows[case_id], c2_rows[case_id]
        rows.append({
            "case_id": case_id,
            "C1_mean_lobe_dice": float(a["mean_lobe_dice"]),
            "C2_mean_lobe_dice": float(b["mean_lobe_dice"]),
            "delta_dice": float(b["mean_lobe_dice"] - a["mean_lobe_dice"]),
            "C1_folding_percentage": float(a["folding_percentage"]),
            "C2_folding_percentage": float(b["folding_percentage"]),
            "delta_folding_percentage": float(b["folding_percentage"] - a["folding_percentage"]),
        })
    deltas = np.asarray([r["delta_dice"] for r in rows], dtype=np.float64)
    summary = {
        "common_case_count": len(rows),
        "C1_mean_lobe_dice": float(c1["mean_lobe_dice"]),
        "C2_mean_lobe_dice": float(c2["mean_lobe_dice"]),
        "delta_mean_lobe_dice": float(c2["mean_lobe_dice"] - c1["mean_lobe_dice"]),
        "C1_mean_folding_percentage": float(c1["mean_folding_percentage"]),
        "C2_mean_folding_percentage": float(c2["mean_folding_percentage"]),
        "delta_mean_folding_percentage": float(c2["mean_folding_percentage"] - c1["mean_folding_percentage"]),
        "improved_cases": int(np.sum(deltas > 0)) if len(deltas) else 0,
        "unchanged_cases": int(np.sum(np.isclose(deltas, 0.0, atol=1e-12))) if len(deltas) else 0,
        "worsened_cases": int(np.sum(deltas < 0)) if len(deltas) else 0,
        "min_paired_dice_delta": float(deltas.min()) if len(deltas) else None,
        "max_paired_dice_delta": float(deltas.max()) if len(deltas) else None,
    }
    return summary, rows


def main() -> int:
    args = parse_args()
    config = _resolve_config(args)
    raw_root = Path(config["raw_data_root"])
    segmentation_dir = Path(config["segmentation_dir"])
    c1_dir = Path(config["c1_dir"])
    output_dir = Path(config["output_dir"])
    assert_safe_output_dir(output_dir, PROJECT_ROOT)

    c1_run_config = c1_dir / "run_config_resolved.json"
    if not c1_run_config.exists():
        raise FileNotFoundError(f"Missing C1 run config: {c1_run_config}")
    c1_meta = json.loads(c1_run_config.read_text(encoding="utf-8"))
    c1_fingerprint = c1_meta.get("config_fingerprint_sha256")
    accepted_c1_fingerprint = str(config.get("accepted_c1_fingerprint", ""))
    if bool(config.get("require_c1_fingerprint", True)) and c1_fingerprint != accepted_c1_fingerprint:
        raise RuntimeError(
            "C1 fingerprint mismatch; refusing TTO on an unaccepted initializer. "
            f"expected={accepted_c1_fingerprint} actual={c1_fingerprint}"
        )

    method_fingerprint = sha256_json({
        "optimization": config["optimization"],
        "ct": config["ct"],
        "loss": config["loss"],
        "selection": config["selection"],
        "c1_fingerprint": c1_fingerprint,
    })
    previous_run_config = output_dir / "run_config_resolved.json"
    if previous_run_config.exists() and not bool(config.get("overwrite", False)):
        previous = json.loads(previous_run_config.read_text(encoding="utf-8"))
        previous_fp = previous.get("method_fingerprint_sha256")
        if previous_fp and previous_fp != method_fingerprint:
            raise RuntimeError(
                "TTO output directory contains a different method configuration. "
                "Use a new --output-dir or --overwrite. "
                f"existing={previous_fp} current={method_fingerprint}"
            )

    cases = discover_validation_cases(raw_root)
    requested = {str(v) for v in config.get("case_ids", [])}
    if requested:
        cases = [case for case in cases if case.case_id in requested]
        missing = sorted(requested - {case.case_id for case in cases})
        if missing:
            raise FileNotFoundError(f"Requested cases not found: {missing}")
    if not cases:
        raise RuntimeError("No validation cases selected")

    device_name = str(config.get("device", "cuda"))
    if device_name.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    device = torch.device(device_name)

    for sub in ("dvfs", "dvfs_canonical_ras", "case_manifests", "traces", "eval", "comparison"):
        (output_dir / sub).mkdir(parents=True, exist_ok=True)
    atomic_write_json(output_dir / "run_config_resolved.json", {
        "schema_version": 1,
        "experiment": "SGR-FM C2 segmentation-guided image-constrained TTO",
        "config": config,
        "case_count": len(cases),
        "dry_run": bool(args.dry_run),
        "method_fingerprint_sha256": method_fingerprint,
        "verified_c1_fingerprint": c1_fingerprint,
        "critical_note": "Optimization uses predicted segmentations and CT only; validation GT is evaluation-only.",
    })

    opt_cfg = config["optimization"]
    loss_cfg = config["loss"]
    ct_cfg = config["ct"]
    selection = config["selection"]
    records: list[dict[str, Any]] = []

    for idx, case in enumerate(cases, start=1):
        started = time.time()
        print(f"[{idx:02d}/{len(cases):02d}] {case.case_id}", flush=True)
        assets = validation_asset_paths(segmentation_dir, c1_dir, case.case_id)
        out_original = output_dir / "dvfs" / f"{case.case_id}_DVF.nii.gz"
        out_canonical = output_dir / "dvfs_canonical_ras" / f"{case.case_id}_DVF_RAS_XYZC_voxel.nii.gz"
        manifest_path = output_dir / "case_manifests" / f"{case.case_id}.json"
        trace_path = output_dir / "traces" / f"{case.case_id}.csv"

        record: dict[str, Any] = {
            "case_id": case.case_id,
            "status": "started",
            "EXP": str(case.exp_ct),
            "INSP": str(case.insp_ct),
            "assets": {k: str(v) for k, v in assets.items()},
            "output_dvf": str(out_original),
            "output_canonical_dvf": str(out_canonical),
        }
        try:
            if out_original.exists() and out_canonical.exists() and not bool(config.get("overwrite", False)):
                record["status"] = "reused"
                record["elapsed_sec"] = float(time.time() - started)
                records.append(record)
                continue
            if args.dry_run:
                for name, path in assets.items():
                    if not path.exists():
                        raise FileNotFoundError(f"Missing {name}: {path}")
                record["status"] = "dry_run"
                record["elapsed_sec"] = 0.0
                records.append(record)
                atomic_write_json(manifest_path, record)
                continue

            full = load_case_tensors(
                exp_ct_path=case.exp_ct,
                insp_ct_path=case.insp_ct,
                assets=assets,
                device=device,
                ct_cfg=ct_cfg,
            )
            low = make_lowres_state(full, int(opt_cfg.get("reduce_factor", 2)))
            baseline_proxy = compute_proxy_metrics(
                moving_ct=low["moving_ct"], fixed_ct=low["fixed_ct"],
                moving_lobes=low["moving_lobes"], fixed_lobes=low["fixed_lobes"],
                moving_support=low["moving_support"], fixed_support=low["fixed_support"],
                dvf=low["c1_dvf"],
                lncc_window=int(ct_cfg.get("lncc_window", 9)),
                lncc_min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
            )
            baseline_topology = topology_stats(full["c1_dvf"])
            record["baseline_proxy"] = baseline_proxy
            record["baseline_topology_fullres"] = baseline_topology

            coarse_param = make_control_parameter(
                low["c1_dvf"].shape[-3:],
                int(opt_cfg.get("coarse_control_factor", 8)),
                device=device,
                dtype=low["c1_dvf"].dtype,
            )
            fine_param = make_control_parameter(
                low["c1_dvf"].shape[-3:],
                int(opt_cfg.get("fine_control_factor", 4)),
                device=device,
                dtype=low["c1_dvf"].dtype,
            )
            trace: list[dict[str, Any]] = []
            stages: list[dict[str, Any]] = []
            stages.append(_optimize_stage(
                stage_name="coarse",
                coarse_param=coarse_param,
                fine_param=None,
                trainable_params=[coarse_param],
                low=low,
                full_shape=full["full_shape"],
                opt_cfg=opt_cfg, loss_cfg=loss_cfg, ct_cfg=ct_cfg,
                iterations=int(opt_cfg.get("coarse_iterations", 60)),
                lr=float(opt_cfg.get("coarse_lr", 0.05)),
                trace=trace,
            ))
            stages.append(_optimize_stage(
                stage_name="fine",
                coarse_param=coarse_param,
                fine_param=fine_param,
                trainable_params=[coarse_param, fine_param],
                low=low,
                full_shape=full["full_shape"],
                opt_cfg=opt_cfg, loss_cfg=loss_cfg, ct_cfg=ct_cfg,
                iterations=int(opt_cfg.get("fine_iterations", 80)),
                lr=float(opt_cfg.get("fine_lr", 0.02)),
                trace=trace,
            ))
            record["optimization_stages"] = stages
            if trace:
                write_csv(trace_path, trace)

            candidate_rows: list[dict[str, Any]] = []
            accepted: list[tuple[float, dict[str, float], torch.Tensor]] = []
            for scale_value in selection.get("residual_scales", [1.0, 0.75, 0.5, 0.25, 0.125, 0.0]):
                scale = float(scale_value)
                with torch.no_grad():
                    residual_low = build_residual_dvf(
                        coarse_param, fine_param,
                        target_shape=low["c1_dvf"].shape[-3:], full_shape=full["full_shape"],
                        max_fullres_voxels=float(opt_cfg.get("max_residual_fullres_voxels", 1.5)),
                        integration_steps=int(opt_cfg.get("integration_steps", 5)), scale=scale,
                    )
                    final_low = compose_pull(low["c1_dvf"], residual_low)
                    proxy = compute_proxy_metrics(
                        moving_ct=low["moving_ct"], fixed_ct=low["fixed_ct"],
                        moving_lobes=low["moving_lobes"], fixed_lobes=low["fixed_lobes"],
                        moving_support=low["moving_support"], fixed_support=low["fixed_support"],
                        dvf=final_low,
                        lncc_window=int(ct_cfg.get("lncc_window", 9)),
                        lncc_min_valid_fraction=float(ct_cfg.get("lncc_min_valid_fraction", 0.25)),
                    )
                    residual_full = build_residual_dvf(
                        coarse_param, fine_param,
                        target_shape=full["c1_dvf"].shape[-3:], full_shape=full["full_shape"],
                        max_fullres_voxels=float(opt_cfg.get("max_residual_fullres_voxels", 1.5)),
                        integration_steps=int(opt_cfg.get("integration_steps", 5)), scale=scale,
                    )
                    final_full = compose_pull(full["c1_dvf"], residual_full)
                    topo = topology_stats(final_full)
                    metrics = {**proxy, **topo}
                    score = candidate_score(metrics, baseline_proxy, selection)
                    ok, reasons, fold_limit = passes_acceptance(
                        metrics, baseline_proxy,
                        baseline_folding_pct=float(baseline_topology["folding_pct"]),
                        selection=selection,
                    )
                    row = {
                        "scale": scale,
                        "score": float(score),
                        "accepted": bool(ok),
                        "rejection_reasons": reasons,
                        "folding_limit_pct": float(fold_limit),
                        **metrics,
                    }
                    candidate_rows.append(row)
                    if ok:
                        accepted.append((float(score), row, final_full.detach().clone()))

            if accepted:
                accepted.sort(key=lambda item: item[0], reverse=True)
                _, selected_row, selected_full = accepted[0]
                decision = "tto"
            else:
                selected_row = next((r for r in candidate_rows if float(r["scale"]) == 0.0), None)
                if selected_row is None:
                    raise RuntimeError("Selection scales must include 0.0 no-op fallback")
                selected_full = full["c1_dvf"].detach().clone()
                decision = "c1_noop_fallback"

            record["selection_candidates"] = candidate_rows
            record["decision"] = decision
            record["selected"] = selected_row

            if decision == "c1_noop_fallback":
                # Exact byte-preserving fallback to the frozen champion C1.
                shutil.copy2(assets["c1_canonical"], out_canonical)
                shutil.copy2(assets["c1_original"], out_original)
                record["fallback_exact_c1_copy"] = True
            else:
                canonical_xyzc = dvf_tensor_to_xyzc(selected_full)
                if not np.isfinite(canonical_xyzc).all():
                    raise RuntimeError("Selected canonical DVF contains NaN/Inf")
                atomic_save_nifti_xyzc(canonical_xyzc, full["canonical_reference"], out_canonical)
                canonical_cxyz = np.moveaxis(canonical_xyzc, -1, 0)
                original_xyzc = canonical_ras_cxyz_to_original_dvf_xyzc(canonical_cxyz, case.insp_ct)
                save_dvf_xyzc(original_xyzc, case.insp_ct, out_original)
                record["fallback_exact_c1_copy"] = False

            record["status"] = "ok"
            record["elapsed_sec"] = float(time.time() - started)
            atomic_write_json(manifest_path, record)
            records.append(record)
            print(f"  decision={decision} scale={selected_row['scale']} proxy_gain={selected_row['proxy_lobe_dice']-baseline_proxy['proxy_lobe_dice']:+.6f} fold={selected_row['folding_pct']:.6g}%", flush=True)

            del full, low, coarse_param, fine_param, selected_full
            if device.type == "cuda":
                torch.cuda.empty_cache()

        except Exception as exc:
            record["status"] = "failed"
            record["error"] = f"{type(exc).__name__}: {exc}"
            record["traceback"] = traceback.format_exc()
            record["elapsed_sec"] = float(time.time() - started)
            records.append(record)
            atomic_write_json(manifest_path, record)
            print(record["error"], file=sys.stderr, flush=True)
            if bool(config.get("stop_on_error", True)):
                break

    ok_count = sum(r["status"] in {"ok", "reused", "dry_run"} for r in records)
    failed_count = sum(r["status"] == "failed" for r in records)
    decision_counts: dict[str, int] = {}
    for r in records:
        if r.get("decision"):
            decision_counts[str(r["decision"])] = decision_counts.get(str(r["decision"]), 0) + 1

    summary: dict[str, Any] = {
        "schema_version": 1,
        "experiment": "SGR-FM C2 segmentation-guided image-constrained TTO",
        "status": "PASS" if failed_count == 0 and ok_count == len(cases) else "FAIL",
        "case_count": len(cases),
        "processed_count": ok_count,
        "failed_count": failed_count,
        "decision_counts": decision_counts,
        "output_dir": str(output_dir),
        "records": records,
    }

    eval_enabled = bool(config.get("evaluation", {}).get("enabled", True)) and not args.skip_evaluation and not args.dry_run
    if summary["status"] == "PASS" and eval_enabled and len(cases) == 10:
        eval_dir = output_dir / "eval"
        command = [
            sys.executable,
            str(PROJECT_ROOT / "evaluate_validation.py"),
            "--raw-data-root", str(raw_root),
            "--dvf-dir", str(output_dir / "dvfs"),
            "--output-dir", str(eval_dir),
            "--device", str(config.get("evaluation", {}).get("device", config.get("device", "cuda"))),
        ]
        proc = subprocess.run(command, cwd=str(PROJECT_ROOT), check=False)
        summary["evaluation"] = {"command": command, "exit_code": int(proc.returncode)}
        if proc.returncode != 0:
            summary["status"] = "FAIL"
        else:
            c1_json = resolve_under_project(PROJECT_ROOT, config["evaluation"]["c1_metrics_json"])
            c2_json = eval_dir / "validation_metrics.json"
            if c1_json.exists() and c2_json.exists():
                comparison, comparison_rows = _compare_metrics(c1_json, c2_json)
                atomic_write_json(output_dir / "comparison" / "C1_vs_C2_TTO_summary.json", comparison)
                write_csv(output_dir / "comparison" / "C1_vs_C2_TTO_per_case.csv", comparison_rows)
                summary["comparison"] = comparison
            else:
                summary["comparison_warning"] = f"Missing metrics: C1={c1_json.exists()} C2={c2_json.exists()}"

    atomic_write_json(output_dir / "c2_tto_summary.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k != "records"}, indent=2))
    return 0 if summary["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
