SGR-FM C2 — segmentation-guided, image-constrained test-time optimization
========================================================================

Purpose
-------
Start from the frozen C1 DVF and optimize a small residual SVF separately for
each case. The optimizer uses only signals available at inference time:
  * raw EXP/INSP CT (in-memory clipped normalization only for LNCC),
  * TotalSegmentator five-lobe predictions,
  * predicted anatomical support masks.

Validation GT is NOT loaded by the optimizer. It is used only after inference by
the existing evaluate_validation.py script.

Why this differs from failed C3
-------------------------------
* no learned global refiner/checkpoint;
* zero-initialized case-specific optimization;
* CT LNCC is the strongest loss term;
* predicted lobes/interfaces are guidance, not the only target;
* conservative scale search after optimization;
* explicit no-op gate: exact C1 is copied when TTO is not justified;
* full-resolution topology guard before accepting a residual.

Relative C1 topology guard — v2
-------------------------------
The first smoke tests exposed a selector inconsistency: a TTO candidate could
improve folding relative to C1 yet be rejected only because C1 itself was above
an overly small global threshold. The default policy is now explicitly relative
to the frozen C1 champion.

For each case:

  folding_limit = min(
      max_absolute_folding_pct,
      C1_folding_pct + max_folding_increase_pct
  )

Defaults:
  topology_guard_mode: relative_to_c1
  max_folding_increase_pct: 5e-5 percentage points
  max_absolute_folding_pct: 1e-3 percent

This still rejects material topology regressions. It does not guarantee that a
challenge server will round the reported folding value to zero.

Default method
--------------
C1 pull DVF -> coarse-to-fine residual SVF TTO -> exact pull composition.
Optimization runs at factor-2 resolution. A smooth control field is optimized
coarse-to-fine and evaluated at full resolution. Candidate residual scales are:
1.0, 0.75, 0.5, 0.25, 0.125, 0.0.

The 0.0 candidate is an exact C1 fallback. A non-zero candidate is accepted only
if it improves predicted-lobe alignment enough, does not materially worsen CT
LNCC/support overlap, and passes the full-resolution C1-relative folding guard.

Install / overlay
-----------------
From project root:

  unzip -o SGR_FM_C2_TTO_relative_guard_patch.zip -d .

1) Dry-run all assets
---------------------

  python main.py tto \
    --config configs/sgr_fm_c2_tto.yaml \
    --dry-run

2) Re-run the two smoke cases
-----------------------------
Existing smoke outputs must be replaced because selector policy changed:

  python main.py tto \
    --config configs/sgr_fm_c2_tto.yaml \
    --case-ids NLST_0006 \
    --skip-evaluation \
    --overwrite

  python main.py tto \
    --config configs/sgr_fm_c2_tto.yaml \
    --case-ids NLST_0009 \
    --skip-evaluation \
    --overwrite

Inspect:
  outputs/sgr_fm/c2_segmentation_guided_tto/case_manifests/NLST_0006.json
  outputs/sgr_fm/c2_segmentation_guided_tto/case_manifests/NLST_0009.json

Expected selector behavior from the already observed smoke candidate metrics:
  * NLST_0006: scale 1.0 remains accepted.
  * NLST_0009: scale 1.0 now passes the relative topology guard because its
    folding is lower than the corresponding C1 baseline while all alignment
    proxy signals improve.

3) Full 10-case validation run
------------------------------
Only after the two re-smokes are confirmed:

  python main.py tto \
    --config configs/sgr_fm_c2_tto.yaml \
    --overwrite

Outputs
-------
  outputs/sgr_fm/c2_segmentation_guided_tto/
    dvfs/
    dvfs_canonical_ras/
    case_manifests/
    traces/
    eval/validation_metrics.json
    comparison/C1_vs_C2_TTO_summary.json
    comparison/C1_vs_C2_TTO_per_case.csv
    c2_tto_summary.json

First files to upload after the full run
----------------------------------------
  c2_tto_summary.json
  eval/validation_metrics.json
  comparison/C1_vs_C2_TTO_summary.json
  comparison/C1_vs_C2_TTO_per_case.csv

Do not tune defaults from validation GT before the first full result. The first
run remains an ablation of a fixed, test-compatible TTO policy.
