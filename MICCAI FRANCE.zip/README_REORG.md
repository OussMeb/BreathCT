# MICCAI FRANCE organized code layout

Target layout under `/home/oussama/Desktop/MICCAI FRANCE`:

```text
configs/
models/
utils/
main.py
train_refiner.py
infer_validation.py
evaluate_validation.py
```

Run from project root:

```bash
python main.py train --config configs/refiner_stable.yaml --epochs 2 --output-dir outputs/refiner_stable_check
```
