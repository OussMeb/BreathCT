#!/usr/bin/env python3
"""SGR-FM pre-experiment inventory audit for Learn2Breath Task 2.

Purpose
-------
Freeze and verify the state of the raw CT dataset, validation labels, and the
three raw-FM DVF caches before starting segmentation-guided registration.

The audit is intentionally read-only. It never modifies source data or DVFs.

Default expected project layout
-------------------------------
/home/oussama/Desktop/MICCAI FRANCE/
  Learn2Breath_train_val_data/
  outputs/unigradicon_raw_training/dvfs_canonical_ras/
  outputs/unigradicon_raw_validation/dvfs/
  outputs/unigradicon_raw_validation/dvfs_canonical_ras/

Outputs
-------
  sgr_fm_inventory_report.json
  sgr_fm_inventory_checks.csv
  sgr_fm_case_inventory.csv
  sgr_fm_dvf_equivalence.csv
  sgr_fm_stale_references.csv
  sgr_fm_inventory_summary.txt

Scan modes
----------
header   : headers/grids/coverage only; fastest
balanced : default; sampled data checks + full validation DVF equivalence
full     : full finite/statistical scans of CTs, labels, and DVFs; slow I/O

Notes
-----
- DVF convention assumed by this project: XYZC layout, voxel displacement,
  pull warp, fixed/INSP grid.
- Canonical-RAS equivalence is checked against the exact RAS/LPS conversion
  used by the current project. Unsupported orientations are reported, not
  silently guessed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
import time
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

try:
    import nibabel as nib
    import numpy as np
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "This audit requires numpy and nibabel. Install with:\n"
        "  pip install numpy nibabel\n"
        f"Original import error: {exc}"
    ) from exc


CASE_RE = re.compile(r"^(NLST_\d{4})_(EXP|INSP)(?:_(lobe|fissure))?\.nii(?:\.gz)?$")
TRAIN_CANON_DVF_RE = re.compile(r"^(NLST_\d{4})_DVF_RAS_XYZC_voxel\.nii(?:\.gz)?$")
VAL_ORIG_DVF_RE = re.compile(r"^(NLST_\d{4})_DVF\.nii(?:\.gz)?$")
VAL_CANON_DVF_RE = TRAIN_CANON_DVF_RE

TEXT_SUFFIXES = {
    ".py", ".yaml", ".yml", ".json", ".toml", ".ini", ".cfg",
    ".md", ".txt", ".sh", ".bash", ".zsh", ".ps1",
}
SKIP_SCAN_DIRS = {
    ".git", ".venv", "venv", "env", "__pycache__", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", "node_modules",
}


@dataclass
class Check:
    section: str
    check: str
    status: str
    case_id: str
    message: str
    values: dict[str, Any]


@dataclass(frozen=True)
class RawCase:
    split: str
    case_id: str
    exp_ct: Path
    insp_ct: Path
    exp_lobe: Path | None = None
    insp_lobe: Path | None = None
    exp_fissure: Path | None = None
    insp_fissure: Path | None = None


class Audit:
    def __init__(self) -> None:
        self.checks: list[Check] = []

    def add(
        self,
        section: str,
        check: str,
        status: str,
        message: str,
        *,
        case_id: str = "",
        values: dict[str, Any] | None = None,
    ) -> None:
        status = status.upper()
        if status not in {"PASS", "WARN", "FAIL", "INFO", "SKIP"}:
            raise ValueError(f"Unsupported status: {status}")
        self.checks.append(
            Check(section, check, status, case_id, message, values or {})
        )

    def counts(self) -> dict[str, int]:
        counter = Counter(c.status for c in self.checks)
        return {key: int(counter.get(key, 0)) for key in ("PASS", "WARN", "FAIL", "INFO", "SKIP")}


# -----------------------------------------------------------------------------
# Generic helpers
# -----------------------------------------------------------------------------


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Inventory/audit raw Learn2Breath data and raw-FM DVF caches before SGR-FM experiments."
    )
    parser.add_argument(
        "--project-root",
        default="/home/oussama/Desktop/MICCAI FRANCE",
        help="Project root used for stale-reference scanning.",
    )
    parser.add_argument(
        "--raw-data-root",
        default="/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
    )
    parser.add_argument(
        "--training-canonical-dvf-dir",
        default="/home/oussama/Desktop/MICCAI FRANCE/outputs/unigradicon_raw_training/dvfs_canonical_ras",
    )
    parser.add_argument(
        "--validation-dvf-dir",
        default="/home/oussama/Desktop/MICCAI FRANCE/outputs/unigradicon_raw_validation/dvfs",
    )
    parser.add_argument(
        "--validation-canonical-dvf-dir",
        default="/home/oussama/Desktop/MICCAI FRANCE/outputs/unigradicon_raw_validation/dvfs_canonical_ras",
    )
    parser.add_argument(
        "--preprocessed-data-root",
        default="/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_preprocessed",
        help="Only checked for existence and stale dependencies; never modified.",
    )
    parser.add_argument(
        "--output-dir",
        default="/home/oussama/Desktop/MICCAI FRANCE/outputs/sgr_fm/inventories/pre_sgr_fm_audit",
    )
    parser.add_argument("--expected-training-cases", type=int, default=200)
    parser.add_argument("--expected-validation-cases", type=int, default=10)
    parser.add_argument(
        "--scan-mode",
        choices=("header", "balanced", "full"),
        default="balanced",
        help="Data scan depth. 'balanced' is recommended.",
    )
    parser.add_argument(
        "--sample-stride",
        type=int,
        default=8,
        help="Stride per spatial axis for sampled finite/intensity checks in balanced mode.",
    )
    parser.add_argument(
        "--affine-atol",
        type=float,
        default=1e-5,
    )
    parser.add_argument(
        "--equivalence-atol",
        type=float,
        default=5e-5,
        help="Max absolute voxel-displacement tolerance for original-vs-canonical validation DVFs.",
    )
    parser.add_argument(
        "--hash-files",
        action="store_true",
        help="Compute SHA256 hashes for DVF files. Slow but useful for freezing assets.",
    )
    parser.add_argument(
        "--no-source-scan",
        action="store_true",
        help="Skip stale preprocessed-data reference scan.",
    )
    return parser.parse_args()


def json_safe(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        result = float(value)
        return result if math.isfinite(result) else str(result)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, tuple):
        return [json_safe(v) for v in value]
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    return value


def bytes_human(n: int) -> str:
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    value = float(n)
    for unit in units:
        if abs(value) < 1024.0 or unit == units[-1]:
            return f"{value:.2f} {unit}"
        value /= 1024.0
    return f"{n} B"


def dir_size(path: Path) -> tuple[int, int]:
    total = 0
    count = 0
    if not path.exists():
        return total, count
    for p in path.rglob("*"):
        if p.is_file():
            try:
                total += p.stat().st_size
                count += 1
            except OSError:
                pass
    return total, count


def sha256_file(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def axcodes(image: nib.spatialimages.SpatialImage) -> tuple[str, str, str]:
    return tuple(str(v) for v in nib.aff2axcodes(image.affine))  # type: ignore[return-value]


def spacing3(image: nib.spatialimages.SpatialImage) -> tuple[float, float, float]:
    zooms = image.header.get_zooms()
    return tuple(float(v) for v in zooms[:3])


def max_abs_affine_diff(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.max(np.abs(np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64))))


def nifti_header_info(path: Path) -> dict[str, Any]:
    img = nib.load(str(path))
    qform, qcode = img.get_qform(coded=True)
    sform, scode = img.get_sform(coded=True)
    return {
        "path": str(path),
        "shape": [int(v) for v in img.shape],
        "dtype": str(img.get_data_dtype()),
        "spacing": [float(v) for v in spacing3(img)],
        "axcodes": list(axcodes(img)),
        "qform_code": int(qcode),
        "sform_code": int(scode),
        "affine_finite": bool(np.isfinite(img.affine).all()),
        "qform_finite": bool(qform is None or np.isfinite(qform).all()),
        "sform_finite": bool(sform is None or np.isfinite(sform).all()),
    }


def sampled_array(proxy: Any, stride: int) -> np.ndarray:
    stride = max(1, int(stride))
    shape = tuple(int(v) for v in proxy.shape)
    if len(shape) == 3:
        return np.asarray(proxy[::stride, ::stride, ::stride])
    if len(shape) == 4:
        return np.asarray(proxy[::stride, ::stride, ::stride, :])
    return np.asarray(proxy)


def scan_nifti_data(path: Path, *, scan_mode: str, stride: int, label: bool = False) -> dict[str, Any]:
    img = nib.load(str(path))
    if scan_mode == "header":
        return {"scan": "header_only"}

    if scan_mode == "full" or label:
        data = np.asarray(img.dataobj)
        scan_kind = "full"
    else:
        data = sampled_array(img.dataobj, stride)
        scan_kind = f"sampled_stride_{stride}"

    arr = np.asarray(data)
    finite = np.isfinite(arr)
    result: dict[str, Any] = {
        "scan": scan_kind,
        "sample_count": int(arr.size),
        "finite_fraction": float(finite.mean()) if arr.size else float("nan"),
    }
    if arr.size and finite.any():
        vals = arr[finite].astype(np.float64, copy=False)
        result.update(
            {
                "min": float(vals.min()),
                "p01": float(np.percentile(vals, 1)),
                "p50": float(np.percentile(vals, 50)),
                "p99": float(np.percentile(vals, 99)),
                "max": float(vals.max()),
                "mean": float(vals.mean()),
                "std": float(vals.std()),
            }
        )
    if label and arr.size:
        result["labels"] = [int(v) for v in np.unique(arr)]
    return result


def boundary_signature(path: Path, *, stride: int) -> dict[str, Any]:
    """Sample six outer faces to characterize padding/background heterogeneity."""
    img = nib.load(str(path))
    proxy = img.dataobj
    if len(proxy.shape) != 3:
        return {"available": False, "reason": f"not_3d:{proxy.shape}"}
    s = max(1, int(stride))
    faces = [
        np.asarray(proxy[0, ::s, ::s]).ravel(),
        np.asarray(proxy[-1, ::s, ::s]).ravel(),
        np.asarray(proxy[::s, 0, ::s]).ravel(),
        np.asarray(proxy[::s, -1, ::s]).ravel(),
        np.asarray(proxy[::s, ::s, 0]).ravel(),
        np.asarray(proxy[::s, ::s, -1]).ravel(),
    ]
    data = np.concatenate(faces).astype(np.float64, copy=False)
    finite = data[np.isfinite(data)]
    if finite.size == 0:
        return {"available": True, "finite_fraction": 0.0}

    # Rounded most-common values are useful for detecting fixed grey/black padding.
    rounded = np.rint(finite).astype(np.int64)
    common = Counter(rounded.tolist()).most_common(5)
    return {
        "available": True,
        "sample_count": int(data.size),
        "finite_fraction": float(np.isfinite(data).mean()),
        "min": float(finite.min()),
        "p01": float(np.percentile(finite, 1)),
        "p50": float(np.percentile(finite, 50)),
        "p99": float(np.percentile(finite, 99)),
        "max": float(finite.max()),
        "rounded_common_values": [[int(v), int(c)] for v, c in common],
        "fraction_exact_zero": float(np.mean(finite == 0)),
        "fraction_le_minus_1000": float(np.mean(finite <= -1000)),
    }


def get_case_id_from_dvf(path: Path, regex: re.Pattern[str]) -> str | None:
    m = regex.match(path.name)
    return m.group(1) if m else None


def list_niftis(path: Path) -> list[Path]:
    if not path.exists():
        return []
    return sorted(
        [p for p in path.iterdir() if p.is_file() and (p.name.endswith(".nii") or p.name.endswith(".nii.gz"))],
        key=lambda p: p.name,
    )


# -----------------------------------------------------------------------------
# Raw data discovery with duplicate detection
# -----------------------------------------------------------------------------


def discover_raw_cases(raw_root: Path, audit: Audit) -> tuple[list[RawCase], list[RawCase], dict[str, Any]]:
    training_root = raw_root / "training"
    validation_root = raw_root / "validation"

    inventory: dict[str, Any] = {
        "training_root": str(training_root),
        "validation_root": str(validation_root),
        "duplicates": [],
        "unmatched_niftis": [],
    }

    def collect(root: Path, *, recursive: bool) -> dict[str, dict[str, list[Path]]]:
        found: dict[str, dict[str, list[Path]]] = defaultdict(lambda: defaultdict(list))
        paths = root.rglob("*.nii*") if recursive else root.glob("*.nii*")
        for p in sorted(paths):
            if not p.is_file():
                continue
            m = CASE_RE.match(p.name)
            if not m:
                inventory["unmatched_niftis"].append(str(p))
                continue
            case_id, phase, kind = m.groups()
            key = f"{phase}_{kind}" if kind else phase
            found[case_id][key].append(p)
        return found

    train_map = collect(training_root, recursive=False) if training_root.exists() else {}
    val_map = collect(validation_root, recursive=True) if validation_root.exists() else {}

    for split, mapping in (("training", train_map), ("validation", val_map)):
        for case_id, entries in mapping.items():
            for key, paths in entries.items():
                if len(paths) > 1:
                    inventory["duplicates"].append(
                        {"split": split, "case_id": case_id, "key": key, "paths": [str(p) for p in paths]}
                    )

    def one(entries: dict[str, list[Path]], key: str) -> Path | None:
        paths = entries.get(key, [])
        return paths[0] if len(paths) == 1 else None

    train_cases: list[RawCase] = []
    for case_id in sorted(train_map):
        e = train_map[case_id]
        exp, insp = one(e, "EXP"), one(e, "INSP")
        if exp is not None and insp is not None:
            train_cases.append(RawCase("training", case_id, exp, insp))

    val_cases: list[RawCase] = []
    for case_id in sorted(val_map):
        e = val_map[case_id]
        exp, insp = one(e, "EXP"), one(e, "INSP")
        if exp is not None and insp is not None:
            val_cases.append(
                RawCase(
                    "validation",
                    case_id,
                    exp,
                    insp,
                    one(e, "EXP_lobe"),
                    one(e, "INSP_lobe"),
                    one(e, "EXP_fissure"),
                    one(e, "INSP_fissure"),
                )
            )

    audit.add(
        "dataset",
        "raw_root_exists",
        "PASS" if raw_root.exists() else "FAIL",
        str(raw_root),
    )
    audit.add(
        "dataset",
        "training_root_exists",
        "PASS" if training_root.exists() else "FAIL",
        str(training_root),
    )
    audit.add(
        "dataset",
        "validation_root_exists",
        "PASS" if validation_root.exists() else "FAIL",
        str(validation_root),
    )
    audit.add(
        "dataset",
        "duplicate_named_inputs",
        "PASS" if not inventory["duplicates"] else "FAIL",
        f"Duplicate logical inputs: {len(inventory['duplicates'])}",
        values={"duplicates": inventory["duplicates"][:50]},
    )

    return train_cases, val_cases, inventory


# -----------------------------------------------------------------------------
# Dataset/header audit
# -----------------------------------------------------------------------------


def audit_dataset(
    audit: Audit,
    train_cases: list[RawCase],
    val_cases: list[RawCase],
    *,
    expected_training: int,
    expected_validation: int,
    scan_mode: str,
    stride: int,
    affine_atol: float,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    aggregate: dict[str, Any] = {
        "orientation_counts": {"training": Counter(), "validation": Counter()},
        "shape_counts": Counter(),
        "spacing_counts": Counter(),
        "validation_label_coverage": {},
        "ct_data_anomalies": [],
        "boundary_signatures": [],
    }

    audit.add(
        "dataset",
        "training_pair_count",
        "PASS" if len(train_cases) == expected_training else "FAIL",
        f"Found {len(train_cases)} complete training EXP/INSP pairs; expected {expected_training}.",
        values={"found": len(train_cases), "expected": expected_training},
    )
    audit.add(
        "dataset",
        "validation_pair_count",
        "PASS" if len(val_cases) == expected_validation else "FAIL",
        f"Found {len(val_cases)} complete validation EXP/INSP pairs; expected {expected_validation}.",
        values={"found": len(val_cases), "expected": expected_validation},
    )

    for case in [*train_cases, *val_cases]:
        exp_img = nib.load(str(case.exp_ct))
        insp_img = nib.load(str(case.insp_ct))
        exp_ax = axcodes(exp_img)
        insp_ax = axcodes(insp_img)
        aggregate["orientation_counts"][case.split]["".join(insp_ax)] += 1
        aggregate["shape_counts"][str(tuple(insp_img.shape[:3]))] += 1
        aggregate["spacing_counts"][str(tuple(round(v, 6) for v in spacing3(insp_img)))] += 1

        shape_match = tuple(exp_img.shape[:3]) == tuple(insp_img.shape[:3])
        affine_diff = max_abs_affine_diff(exp_img.affine, insp_img.affine)
        affine_match = affine_diff <= affine_atol

        row: dict[str, Any] = {
            "split": case.split,
            "case_id": case.case_id,
            "exp_ct": str(case.exp_ct),
            "insp_ct": str(case.insp_ct),
            "exp_shape": str(tuple(exp_img.shape)),
            "insp_shape": str(tuple(insp_img.shape)),
            "exp_spacing": str(spacing3(exp_img)),
            "insp_spacing": str(spacing3(insp_img)),
            "exp_axcodes": "".join(exp_ax),
            "insp_axcodes": "".join(insp_ax),
            "pair_shape_match": shape_match,
            "pair_max_abs_affine_diff": affine_diff,
            "pair_affine_match": affine_match,
            "exp_lobe": str(case.exp_lobe or ""),
            "insp_lobe": str(case.insp_lobe or ""),
            "exp_fissure": str(case.exp_fissure or ""),
            "insp_fissure": str(case.insp_fissure or ""),
        }

        # Header sanity
        if not np.isfinite(exp_img.affine).all() or not np.isfinite(insp_img.affine).all():
            audit.add(
                "dataset",
                "ct_affine_finite",
                "FAIL",
                "Non-finite CT affine.",
                case_id=case.case_id,
                values={"split": case.split},
            )

        if not shape_match:
            audit.add(
                "dataset",
                "exp_insp_shape_match",
                "FAIL",
                f"EXP shape {exp_img.shape[:3]} != INSP shape {insp_img.shape[:3]}",
                case_id=case.case_id,
                values={"split": case.split},
            )
        if not affine_match:
            audit.add(
                "dataset",
                "exp_insp_affine_match",
                "WARN",
                f"EXP/INSP max affine difference={affine_diff:.6g}",
                case_id=case.case_id,
                values={"split": case.split, "max_abs_affine_diff": affine_diff},
            )

        # Data and background signatures. Balanced uses sampled CTs; full loads all.
        if scan_mode != "header":
            for phase, path in (("EXP", case.exp_ct), ("INSP", case.insp_ct)):
                stats = scan_nifti_data(path, scan_mode=scan_mode, stride=stride, label=False)
                row[f"{phase.lower()}_finite_fraction"] = stats.get("finite_fraction", "")
                row[f"{phase.lower()}_sample_min"] = stats.get("min", "")
                row[f"{phase.lower()}_sample_p50"] = stats.get("p50", "")
                row[f"{phase.lower()}_sample_max"] = stats.get("max", "")
                if float(stats.get("finite_fraction", 1.0)) < 1.0:
                    aggregate["ct_data_anomalies"].append(
                        {"case_id": case.case_id, "split": case.split, "phase": phase, "stats": stats}
                    )
                sig = boundary_signature(path, stride=max(1, stride // 2))
                aggregate["boundary_signatures"].append(
                    {"case_id": case.case_id, "split": case.split, "phase": phase, "path": str(path), **sig}
                )

        # Validation label presence and exact grids/labels.
        if case.split == "validation":
            label_paths = {
                "EXP_lobe": case.exp_lobe,
                "INSP_lobe": case.insp_lobe,
                "EXP_fissure": case.exp_fissure,
                "INSP_fissure": case.insp_fissure,
            }
            coverage = {k: p is not None and p.exists() for k, p in label_paths.items()}
            aggregate["validation_label_coverage"][case.case_id] = coverage

            for key, label_path in label_paths.items():
                if label_path is None or not label_path.exists():
                    audit.add(
                        "labels",
                        "validation_label_presence",
                        "FAIL",
                        f"Missing {key}",
                        case_id=case.case_id,
                    )
                    continue
                phase = "EXP" if key.startswith("EXP") else "INSP"
                ct_img = exp_img if phase == "EXP" else insp_img
                label_img = nib.load(str(label_path))
                shape_ok = tuple(label_img.shape[:3]) == tuple(ct_img.shape[:3])
                aff_diff = max_abs_affine_diff(label_img.affine, ct_img.affine)
                aff_ok = aff_diff <= affine_atol
                data_stats = scan_nifti_data(label_path, scan_mode="full", stride=stride, label=True)
                labels = data_stats.get("labels", [])
                expected = [0, 8, 16, 32, 64, 128] if key.endswith("lobe") else [0, 1, 2]
                labels_ok = labels == expected
                audit.add(
                    "labels",
                    "validation_label_grid",
                    "PASS" if shape_ok and aff_ok else "FAIL",
                    f"{key}: shape_ok={shape_ok}, affine_diff={aff_diff:.6g}",
                    case_id=case.case_id,
                    values={"path": str(label_path), "shape_ok": shape_ok, "max_abs_affine_diff": aff_diff},
                )
                audit.add(
                    "labels",
                    "validation_label_values",
                    "PASS" if labels_ok else "WARN",
                    f"{key}: labels={labels}",
                    case_id=case.case_id,
                    values={"expected": expected, "observed": labels},
                )

        rows.append(row)

    all_labels_ok = all(
        all(v.values()) for v in aggregate["validation_label_coverage"].values()
    ) if aggregate["validation_label_coverage"] else False
    audit.add(
        "labels",
        "validation_label_coverage_summary",
        "PASS" if all_labels_ok and len(val_cases) == expected_validation else "FAIL",
        f"Complete EXP/INSP lobe+fissure coverage: {sum(all(v.values()) for v in aggregate['validation_label_coverage'].values())}/{len(val_cases)} cases.",
    )

    pair_affine_mismatch = sum(1 for r in rows if not r["pair_affine_match"])
    audit.add(
        "dataset",
        "pair_affine_mismatch_summary",
        "PASS" if pair_affine_mismatch == 0 else "WARN",
        f"EXP/INSP affine mismatch cases: {pair_affine_mismatch}.",
        values={"mismatch_count": pair_affine_mismatch},
    )
    audit.add(
        "dataset",
        "orientation_summary",
        "INFO",
        "Observed INSP orientations by split.",
        values={
            split: dict(counter)
            for split, counter in aggregate["orientation_counts"].items()
        },
    )
    audit.add(
        "dataset",
        "shape_summary",
        "INFO",
        "Observed INSP shape counts.",
        values=dict(aggregate["shape_counts"]),
    )
    audit.add(
        "dataset",
        "spacing_summary",
        "INFO",
        "Observed INSP spacing counts.",
        values=dict(aggregate["spacing_counts"]),
    )
    if aggregate["ct_data_anomalies"]:
        audit.add(
            "dataset",
            "ct_finite_summary",
            "FAIL",
            f"CTs with sampled/full non-finite values: {len(aggregate['ct_data_anomalies'])}",
            values={"examples": aggregate["ct_data_anomalies"][:20]},
        )
    elif scan_mode != "header":
        audit.add(
            "dataset",
            "ct_finite_summary",
            "PASS",
            "No non-finite CT values detected in the selected scan mode.",
        )
    else:
        audit.add(
            "dataset",
            "ct_finite_summary",
            "SKIP",
            "Header-only mode: CT voxel finite checks skipped.",
        )

    return rows, aggregate


# -----------------------------------------------------------------------------
# DVF audit
# -----------------------------------------------------------------------------


def index_dvf_dir(path: Path, regex: re.Pattern[str]) -> tuple[dict[str, Path], list[Path], list[dict[str, Any]]]:
    mapping: dict[str, Path] = {}
    unmatched: list[Path] = []
    duplicates: list[dict[str, Any]] = []
    grouped: dict[str, list[Path]] = defaultdict(list)
    for p in list_niftis(path):
        cid = get_case_id_from_dvf(p, regex)
        if cid is None:
            unmatched.append(p)
        else:
            grouped[cid].append(p)
    for cid, paths in sorted(grouped.items()):
        if len(paths) == 1:
            mapping[cid] = paths[0]
        else:
            duplicates.append({"case_id": cid, "paths": [str(p) for p in paths]})
    return mapping, unmatched, duplicates


def audit_dvf_folder(
    audit: Audit,
    *,
    section_name: str,
    folder: Path,
    regex: re.Pattern[str],
    expected_case_ids: set[str],
    fixed_by_case: dict[str, Path],
    canonical: bool,
    scan_mode: str,
    stride: int,
    affine_atol: float,
    hash_files: bool,
) -> tuple[dict[str, Path], list[dict[str, Any]], dict[str, Any]]:
    mapping, unmatched, duplicates = index_dvf_dir(folder, regex)
    rows: list[dict[str, Any]] = []

    audit.add(
        section_name,
        "directory_exists",
        "PASS" if folder.exists() else "FAIL",
        str(folder),
    )
    audit.add(
        section_name,
        "case_coverage",
        "PASS" if set(mapping) == expected_case_ids else "FAIL",
        f"Found {len(mapping)} expected-named DVFs; expected {len(expected_case_ids)}.",
        values={
            "missing": sorted(expected_case_ids - set(mapping)),
            "extra": sorted(set(mapping) - expected_case_ids),
        },
    )
    audit.add(
        section_name,
        "duplicate_case_ids",
        "PASS" if not duplicates else "FAIL",
        f"Duplicate DVF case IDs: {len(duplicates)}",
        values={"duplicates": duplicates},
    )
    audit.add(
        section_name,
        "unmatched_nifti_names",
        "PASS" if not unmatched else "WARN",
        f"Unmatched NIfTI filenames: {len(unmatched)}",
        values={"paths": [str(p) for p in unmatched[:100]]},
    )

    folder_summary: dict[str, Any] = {
        "folder": str(folder),
        "case_count": len(mapping),
        "unmatched": [str(p) for p in unmatched],
        "duplicates": duplicates,
        "shape_counts": Counter(),
        "orientation_counts": Counter(),
        "spacing_counts": Counter(),
        "nonfinite_cases": [],
        "hashes": {},
    }

    for cid, path in sorted(mapping.items()):
        img = nib.load(str(path))
        fixed_path = fixed_by_case.get(cid)
        fixed_img = nib.load(str(fixed_path)) if fixed_path else None
        expected_img = nib.as_closest_canonical(fixed_img) if (canonical and fixed_img is not None) else fixed_img

        shape_ok = len(img.shape) == 4 and img.shape[-1] == 3
        grid_shape_ok = bool(
            expected_img is not None
            and shape_ok
            and tuple(img.shape[:3]) == tuple(expected_img.shape[:3])
        )
        aff_diff = (
            max_abs_affine_diff(img.affine, expected_img.affine)
            if expected_img is not None
            else float("nan")
        )
        affine_ok = bool(expected_img is not None and aff_diff <= affine_atol)
        orientation = axcodes(img)
        orientation_ok = orientation == (("R", "A", "S") if canonical else axcodes(fixed_img)) if fixed_img is not None else False

        folder_summary["shape_counts"][str(tuple(img.shape))] += 1
        folder_summary["orientation_counts"]["".join(orientation)] += 1
        folder_summary["spacing_counts"][str(tuple(round(v, 6) for v in spacing3(img)))] += 1

        stats = scan_nifti_data(path, scan_mode=scan_mode, stride=stride, label=False)
        finite_fraction = stats.get("finite_fraction")
        if finite_fraction is not None and float(finite_fraction) < 1.0:
            folder_summary["nonfinite_cases"].append(cid)

        row = {
            "section": section_name,
            "case_id": cid,
            "path": str(path),
            "shape": str(tuple(img.shape)),
            "spacing": str(spacing3(img)),
            "axcodes": "".join(orientation),
            "dtype": str(img.get_data_dtype()),
            "xyzc_shape_ok": shape_ok,
            "fixed_grid_shape_ok": grid_shape_ok,
            "max_abs_affine_diff_to_expected_grid": aff_diff,
            "affine_ok": affine_ok,
            "orientation_ok": orientation_ok,
            "finite_fraction": stats.get("finite_fraction", ""),
            "sample_min": stats.get("min", ""),
            "sample_p50": stats.get("p50", ""),
            "sample_max": stats.get("max", ""),
            "file_size_bytes": path.stat().st_size,
        }
        if hash_files:
            digest = sha256_file(path)
            row["sha256"] = digest
            folder_summary["hashes"][cid] = digest
        rows.append(row)

        status = "PASS" if shape_ok and grid_shape_ok and affine_ok and orientation_ok else "FAIL"
        if status == "FAIL":
            audit.add(
                section_name,
                "dvf_grid_and_orientation",
                status,
                f"shape_ok={shape_ok}, grid_shape_ok={grid_shape_ok}, affine_ok={affine_ok}, orientation={orientation}",
                case_id=cid,
                values={
                    "path": str(path),
                    "shape": list(img.shape),
                    "expected_shape": list(expected_img.shape) if expected_img is not None else None,
                    "max_abs_affine_diff": aff_diff,
                    "orientation": list(orientation),
                },
            )

    if folder_summary["nonfinite_cases"]:
        audit.add(
            section_name,
            "finite_values_summary",
            "FAIL",
            f"DVFs with non-finite values in selected scan mode: {len(folder_summary['nonfinite_cases'])}",
            values={"case_ids": folder_summary["nonfinite_cases"]},
        )
    elif scan_mode == "header":
        audit.add(
            section_name,
            "finite_values_summary",
            "SKIP",
            "Header-only mode: DVF voxel finite checks skipped.",
        )
    else:
        audit.add(
            section_name,
            "finite_values_summary",
            "PASS",
            "No non-finite DVF values detected in the selected scan mode.",
        )

    audit.add(
        section_name,
        "folder_geometry_summary",
        "INFO",
        "Observed DVF shapes/orientations/spacings.",
        values={
            "shape_counts": dict(folder_summary["shape_counts"]),
            "orientation_counts": dict(folder_summary["orientation_counts"]),
            "spacing_counts": dict(folder_summary["spacing_counts"]),
        },
    )

    return mapping, rows, folder_summary


# -----------------------------------------------------------------------------
# Exact validation original <-> canonical equivalence
# -----------------------------------------------------------------------------


def original_xyzc_to_canonical_ras_xyzc(dvf_xyzc: np.ndarray, original_axcodes: tuple[str, str, str]) -> np.ndarray:
    if dvf_xyzc.ndim != 4 or dvf_xyzc.shape[-1] != 3:
        raise ValueError(f"Expected XYZC DVF, got {dvf_xyzc.shape}")
    arr = np.asarray(dvf_xyzc, dtype=np.float32)
    if original_axcodes == ("R", "A", "S"):
        return arr
    if original_axcodes == ("L", "P", "S"):
        out = arr[::-1, ::-1, :, :].copy()
        out[..., 0] *= -1.0
        out[..., 1] *= -1.0
        return out
    raise NotImplementedError(f"Unsupported original orientation: {original_axcodes}")


def audit_validation_dvf_equivalence(
    audit: Audit,
    *,
    original_map: dict[str, Path],
    canonical_map: dict[str, Path],
    fixed_by_case: dict[str, Path],
    atol: float,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    common = sorted(set(original_map) & set(canonical_map) & set(fixed_by_case))
    if not common:
        audit.add(
            "validation_dvf_equivalence",
            "common_cases",
            "FAIL",
            "No common original/canonical/fixed cases available for equivalence check.",
        )
        return rows

    failures: list[str] = []
    unsupported: list[str] = []
    for cid in common:
        orig_path = original_map[cid]
        can_path = canonical_map[cid]
        fixed_img = nib.load(str(fixed_by_case[cid]))
        orig_ax = axcodes(fixed_img)
        try:
            orig = np.asarray(nib.load(str(orig_path)).dataobj, dtype=np.float32)
            saved = np.asarray(nib.load(str(can_path)).dataobj, dtype=np.float32)
            expected = original_xyzc_to_canonical_ras_xyzc(orig, orig_ax)
            shape_ok = expected.shape == saved.shape
            if shape_ok:
                diff = np.abs(expected.astype(np.float64) - saved.astype(np.float64))
                max_diff = float(diff.max())
                mae = float(diff.mean())
                p999 = float(np.percentile(diff, 99.9))
            else:
                max_diff = mae = p999 = float("inf")
            passed = shape_ok and max_diff <= atol
            if not passed:
                failures.append(cid)
            rows.append(
                {
                    "case_id": cid,
                    "original_dvf": str(orig_path),
                    "canonical_dvf": str(can_path),
                    "fixed_axcodes": "".join(orig_ax),
                    "shape_ok": shape_ok,
                    "max_abs_vector_diff_vox": max_diff,
                    "mae_vector_diff_vox": mae,
                    "p999_abs_vector_diff_vox": p999,
                    "tolerance_vox": atol,
                    "pass": passed,
                }
            )
        except NotImplementedError as exc:
            unsupported.append(cid)
            rows.append(
                {
                    "case_id": cid,
                    "original_dvf": str(orig_path),
                    "canonical_dvf": str(can_path),
                    "fixed_axcodes": "".join(orig_ax),
                    "shape_ok": False,
                    "max_abs_vector_diff_vox": "",
                    "mae_vector_diff_vox": "",
                    "p999_abs_vector_diff_vox": "",
                    "tolerance_vox": atol,
                    "pass": False,
                    "error": str(exc),
                }
            )

    if unsupported:
        audit.add(
            "validation_dvf_equivalence",
            "orientation_support",
            "FAIL",
            f"Unsupported orientations for {len(unsupported)} cases.",
            values={"case_ids": unsupported},
        )
    else:
        audit.add(
            "validation_dvf_equivalence",
            "orientation_support",
            "PASS",
            f"All {len(common)} common cases use supported RAS/LPS orientations.",
        )

    audit.add(
        "validation_dvf_equivalence",
        "original_vs_canonical",
        "PASS" if not failures and not unsupported else "FAIL",
        f"Equivalent within {atol:g} voxel max-abs tolerance for {len(common) - len(failures) - len(unsupported)}/{len(common)} common cases.",
        values={"failed_case_ids": failures, "unsupported_case_ids": unsupported},
    )
    return rows


# -----------------------------------------------------------------------------
# Stale preprocessed-data dependency scan
# -----------------------------------------------------------------------------


def scan_stale_references(project_root: Path, preprocessed_root: Path) -> list[dict[str, Any]]:
    patterns = [
        str(preprocessed_root),
        preprocessed_root.name,
        "Learn2Breath_preprocessed",
    ]
    patterns = sorted(set(p for p in patterns if p), key=len, reverse=True)
    hits: list[dict[str, Any]] = []

    if not project_root.exists():
        return hits

    this_script = Path(__file__).resolve()
    for path in project_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        try:
            if path.resolve() == this_script:
                continue
        except OSError:
            pass
        if any(part in SKIP_SCAN_DIRS for part in path.parts):
            continue
        # Avoid scanning generated outputs/logs; they are records, not active source dependencies.
        try:
            rel = path.relative_to(project_root)
        except ValueError:
            rel = path
        if rel.parts and rel.parts[0] == "outputs":
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for lineno, line in enumerate(text.splitlines(), start=1):
            matched = [p for p in patterns if p in line]
            if matched:
                hits.append(
                    {
                        "path": str(path),
                        "relative_path": str(rel),
                        "line": lineno,
                        "matched": matched,
                        "text": line.strip()[:1000],
                    }
                )
    return hits


# -----------------------------------------------------------------------------
# CSV and report writers
# -----------------------------------------------------------------------------


def write_csv(path: Path, rows: Sequence[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(json_safe(v)) if isinstance(v, (dict, list, tuple)) else v for k, v in row.items()})


def build_summary_text(report: dict[str, Any], checks: list[Check]) -> str:
    counts = report["summary"]
    lines = [
        "SGR-FM pre-experiment inventory audit",
        "=====================================",
        "",
        f"Generated: {report['metadata']['generated_local_time']}",
        f"Scan mode: {report['metadata']['scan_mode']}",
        "",
        "Summary:",
        f"  PASS: {counts['PASS']}",
        f"  WARN: {counts['WARN']}",
        f"  FAIL: {counts['FAIL']}",
        f"  INFO: {counts['INFO']}",
        f"  SKIP: {counts['SKIP']}",
        "",
        "Core inventory:",
        f"  Training pairs: {report['dataset']['training_case_count']}",
        f"  Validation pairs: {report['dataset']['validation_case_count']}",
        f"  Training canonical DVFs: {report['dvfs']['training_canonical']['case_count']}",
        f"  Validation original-grid DVFs: {report['dvfs']['validation_original']['case_count']}",
        f"  Validation canonical-RAS DVFs: {report['dvfs']['validation_canonical']['case_count']}",
        "",
        "Asset disk usage:",
    ]
    for key, value in report["disk_usage"].items():
        lines.append(f"  {key}: {value['human']} ({value['file_count']} files)")

    lines.extend(["", "FAIL checks:"])
    failures = [c for c in checks if c.status == "FAIL"]
    if failures:
        for c in failures:
            suffix = f" [{c.case_id}]" if c.case_id else ""
            lines.append(f"  - {c.section} / {c.check}{suffix}: {c.message}")
    else:
        lines.append("  None")

    lines.extend(["", "WARN checks:"])
    warnings = [c for c in checks if c.status == "WARN"]
    if warnings:
        for c in warnings:
            suffix = f" [{c.case_id}]" if c.case_id else ""
            lines.append(f"  - {c.section} / {c.check}{suffix}: {c.message}")
    else:
        lines.append("  None")

    lines.extend(
        [
            "",
            "Interpretation rule:",
            "  Do not start SGR-FM training if there are unresolved FAIL checks affecting",
            "  case coverage, CT/label grids, DVF grids, non-finite values, or validation",
            "  original-vs-canonical DVF equivalence.",
            "",
        ]
    )
    return "\n".join(lines)


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------


def main() -> int:
    args = parse_args()
    started = time.time()
    audit = Audit()

    project_root = Path(args.project_root).expanduser().resolve()
    raw_root = Path(args.raw_data_root).expanduser().resolve()
    train_can_dir = Path(args.training_canonical_dvf_dir).expanduser().resolve()
    val_orig_dir = Path(args.validation_dvf_dir).expanduser().resolve()
    val_can_dir = Path(args.validation_canonical_dvf_dir).expanduser().resolve()
    preproc_root = Path(args.preprocessed_data_root).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    metadata = {
        "generated_local_time": time.strftime("%Y-%m-%d %H:%M:%S %z"),
        "python": sys.version,
        "numpy": np.__version__,
        "nibabel": nib.__version__,
        "scan_mode": args.scan_mode,
        "sample_stride": args.sample_stride,
        "project_root": str(project_root),
        "raw_data_root": str(raw_root),
        "training_canonical_dvf_dir": str(train_can_dir),
        "validation_dvf_dir": str(val_orig_dir),
        "validation_canonical_dvf_dir": str(val_can_dir),
        "preprocessed_data_root": str(preproc_root),
        "output_dir": str(output_dir),
        "expected_training_cases": args.expected_training_cases,
        "expected_validation_cases": args.expected_validation_cases,
        "affine_atol": args.affine_atol,
        "equivalence_atol": args.equivalence_atol,
        "hash_files": bool(args.hash_files),
        "argv": sys.argv,
    }

    # Setup/path checks
    for name, path in (
        ("project_root", project_root),
        ("raw_data_root", raw_root),
        ("training_canonical_dvf_dir", train_can_dir),
        ("validation_dvf_dir", val_orig_dir),
        ("validation_canonical_dvf_dir", val_can_dir),
    ):
        audit.add(
            "setup",
            name,
            "PASS" if path.exists() else "FAIL",
            str(path),
        )
    audit.add(
        "setup",
        "preprocessed_data_root_status",
        "INFO",
        f"exists={preproc_root.exists()}: {preproc_root}",
        values={"exists": preproc_root.exists()},
    )

    train_cases, val_cases, raw_discovery = discover_raw_cases(raw_root, audit)
    case_rows, dataset_aggregate = audit_dataset(
        audit,
        train_cases,
        val_cases,
        expected_training=args.expected_training_cases,
        expected_validation=args.expected_validation_cases,
        scan_mode=args.scan_mode,
        stride=args.sample_stride,
        affine_atol=args.affine_atol,
    )

    train_fixed = {c.case_id: c.insp_ct for c in train_cases}
    val_fixed = {c.case_id: c.insp_ct for c in val_cases}
    train_ids = set(train_fixed)
    val_ids = set(val_fixed)

    train_can_map, train_dvf_rows, train_dvf_summary = audit_dvf_folder(
        audit,
        section_name="training_canonical_dvfs",
        folder=train_can_dir,
        regex=TRAIN_CANON_DVF_RE,
        expected_case_ids=train_ids,
        fixed_by_case=train_fixed,
        canonical=True,
        scan_mode=args.scan_mode,
        stride=args.sample_stride,
        affine_atol=args.affine_atol,
        hash_files=args.hash_files,
    )
    val_orig_map, val_orig_rows, val_orig_summary = audit_dvf_folder(
        audit,
        section_name="validation_original_dvfs",
        folder=val_orig_dir,
        regex=VAL_ORIG_DVF_RE,
        expected_case_ids=val_ids,
        fixed_by_case=val_fixed,
        canonical=False,
        scan_mode=args.scan_mode,
        stride=args.sample_stride,
        affine_atol=args.affine_atol,
        hash_files=args.hash_files,
    )
    val_can_map, val_can_rows, val_can_summary = audit_dvf_folder(
        audit,
        section_name="validation_canonical_dvfs",
        folder=val_can_dir,
        regex=VAL_CANON_DVF_RE,
        expected_case_ids=val_ids,
        fixed_by_case=val_fixed,
        canonical=True,
        scan_mode=args.scan_mode,
        stride=args.sample_stride,
        affine_atol=args.affine_atol,
        hash_files=args.hash_files,
    )

    equivalence_rows = audit_validation_dvf_equivalence(
        audit,
        original_map=val_orig_map,
        canonical_map=val_can_map,
        fixed_by_case=val_fixed,
        atol=args.equivalence_atol,
    )

    # Cross-split case collision should normally be absent: training IDs 0011+ vs validation 0001-0010.
    collisions = sorted(train_ids & val_ids)
    audit.add(
        "dataset",
        "train_validation_case_id_overlap",
        "PASS" if not collisions else "FAIL",
        f"Train/validation case-ID overlap count: {len(collisions)}",
        values={"case_ids": collisions},
    )

    # Stale source/config references to the old preprocessed dataset.
    stale_rows: list[dict[str, Any]] = []
    if args.no_source_scan:
        audit.add(
            "source_dependencies",
            "preprocessed_reference_scan",
            "SKIP",
            "Skipped by --no-source-scan.",
        )
    else:
        stale_rows = scan_stale_references(project_root, preproc_root)
        audit.add(
            "source_dependencies",
            "preprocessed_reference_scan",
            "PASS" if not stale_rows else "WARN",
            f"Found {len(stale_rows)} source/config references to the preprocessed dataset.",
            values={"examples": stale_rows[:50]},
        )

    # Disk usage.
    usage_paths = {
        "raw_data_root": raw_root,
        "training_canonical_dvfs": train_can_dir,
        "validation_original_dvfs": val_orig_dir,
        "validation_canonical_dvfs": val_can_dir,
        "preprocessed_data_root": preproc_root,
    }
    disk_usage: dict[str, Any] = {}
    for key, path in usage_paths.items():
        size, count = dir_size(path)
        disk_usage[key] = {
            "path": str(path),
            "exists": path.exists(),
            "bytes": size,
            "human": bytes_human(size),
            "file_count": count,
        }

    # Freeze manifest of core DVF assets, always including file size/mtime; optional SHA256.
    asset_manifest: list[dict[str, Any]] = []
    for role, mapping in (
        ("training_canonical", train_can_map),
        ("validation_original", val_orig_map),
        ("validation_canonical", val_can_map),
    ):
        for cid, path in sorted(mapping.items()):
            st = path.stat()
            record = {
                "role": role,
                "case_id": cid,
                "path": str(path),
                "size_bytes": st.st_size,
                "mtime_ns": st.st_mtime_ns,
            }
            if args.hash_files:
                record["sha256"] = sha256_file(path)
            asset_manifest.append(record)

    report = {
        "metadata": metadata,
        "summary": audit.counts(),
        "dataset": {
            "training_case_count": len(train_cases),
            "validation_case_count": len(val_cases),
            "training_case_ids": sorted(train_ids),
            "validation_case_ids": sorted(val_ids),
            "raw_discovery": raw_discovery,
            "orientation_counts": {
                split: dict(counter)
                for split, counter in dataset_aggregate["orientation_counts"].items()
            },
            "shape_counts": dict(dataset_aggregate["shape_counts"]),
            "spacing_counts": dict(dataset_aggregate["spacing_counts"]),
            "validation_label_coverage": dataset_aggregate["validation_label_coverage"],
            "ct_data_anomalies": dataset_aggregate["ct_data_anomalies"],
            "boundary_signatures": dataset_aggregate["boundary_signatures"],
        },
        "dvfs": {
            "training_canonical": json_safe(train_dvf_summary),
            "validation_original": json_safe(val_orig_summary),
            "validation_canonical": json_safe(val_can_summary),
            "validation_equivalence": equivalence_rows,
            "convention_assumed": {
                "layout": "X,Y,Z,3",
                "units": "voxel_displacement",
                "warp": "pull",
                "fixed_grid": "INSP",
                "canonical_internal_orientation": "RAS",
            },
        },
        "source_dependencies": {
            "preprocessed_data_root_exists": preproc_root.exists(),
            "preprocessed_reference_count": len(stale_rows),
            "references": stale_rows,
        },
        "disk_usage": disk_usage,
        "asset_manifest": asset_manifest,
        "checks": [json_safe(asdict(c)) for c in audit.checks],
    }
    report["metadata"]["elapsed_sec"] = float(time.time() - started)

    # Outputs.
    report_path = output_dir / "sgr_fm_inventory_report.json"
    checks_path = output_dir / "sgr_fm_inventory_checks.csv"
    cases_path = output_dir / "sgr_fm_case_inventory.csv"
    dvfs_path = output_dir / "sgr_fm_dvf_inventory.csv"
    equiv_path = output_dir / "sgr_fm_dvf_equivalence.csv"
    stale_path = output_dir / "sgr_fm_stale_references.csv"
    manifest_path = output_dir / "sgr_fm_asset_manifest.csv"
    summary_path = output_dir / "sgr_fm_inventory_summary.txt"

    report_path.write_text(json.dumps(json_safe(report), indent=2), encoding="utf-8")
    write_csv(checks_path, [json_safe(asdict(c)) for c in audit.checks])
    write_csv(cases_path, case_rows)
    write_csv(dvfs_path, [*train_dvf_rows, *val_orig_rows, *val_can_rows])
    write_csv(equiv_path, equivalence_rows)
    write_csv(stale_path, stale_rows)
    write_csv(manifest_path, asset_manifest)
    summary_path.write_text(build_summary_text(report, audit.checks), encoding="utf-8")

    print(build_summary_text(report, audit.checks))
    print("Outputs:")
    for p in (summary_path, report_path, checks_path, cases_path, dvfs_path, equiv_path, stale_path, manifest_path):
        print(f"  {p}")

    # Non-zero exit only for FAIL checks; WARN does not block.
    return 2 if report["summary"]["FAIL"] > 0 else 0


if __name__ == "__main__":
    raise SystemExit(main())

