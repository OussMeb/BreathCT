#!/usr/bin/env python3
import numpy as np, torch
from utils.sgr_fm_c9_1_guarded_soft_fissure_fusion import (
    _signed_distance_channels, _interface_surfaces, _interface_distance,
    _residual_from_param, _pseudo_guard_reasons,
)
from utils.sgr_fm_c3 import compose_pull

def main():
    lab=np.zeros((32,28,30),np.int16)
    lab[4:16,4:13,4:14]=32; lab[4:16,13:22,4:14]=64; lab[4:16,4:22,14:26]=128
    sdf=_signed_distance_channels(lab,(1.5,1.5,1.5),12.0,[8,16,32,64,128])
    surf=_interface_surfaces(lab,1); dist=_interface_distance(surf,(1.5,1.5,1.5),10.0)
    assert sdf.shape==(5,32,28,30) and surf.shape==(2,32,28,30) and np.isfinite(sdf).all()
    z=torch.zeros((1,3,16,14,15)); assert torch.allclose(compose_pull(z,z),z)
    gate=torch.ones((1,1,16,14,15)); gate[..., :8,:,:]=0
    state={'target_shape':(16,14,15),'full_shape':(32,28,30),'gate':gate}
    stage={'max_residual_fullres_voxels':0.4,'integration_steps':5,'post_integration_gate_power':1.0}
    p=torch.full((1,3,4,4,4),0.25,requires_grad=True); r=_residual_from_param(p,state,stage,1.0)
    assert r.shape==z.shape and torch.isfinite(r).all()
    assert float(r[..., :8,:,:].abs().max())==0.0
    loss=r.square().mean(); loss.backward(); assert torch.isfinite(loss)
    cfg={'selection':{
        'max_parent_global_pseudo_loss':2e-5,'max_parent_rml_pseudo_loss':2.5e-5,
        'max_stage_global_pseudo_loss':2e-5,'max_stage_rml_pseudo_loss':2.5e-5,
        'max_non_rml_pseudo_loss':2.5e-4,
    }}
    parent={f'dice_{x}':0.98 for x in [8,16,32,64,128]}; cand=dict(parent); cand['dice_64']=0.9799
    reasons,_=_pseudo_guard_reasons(1.0,0.97998,cand,0.98,parent,0.98,parent,cfg)
    assert 'parent_rml_pseudo_loss' in reasons
    print('C9.1-GSFTF SYNTHETIC SMOKE: PASS')
    print({'sdf_shape':sdf.shape,'interface_voxels':[int(x.sum()) for x in surf],'distance_range':[float(dist.min()),float(dist.max())]})
if __name__=='__main__': main()
