SGR-FM C9.1-GSFTF PATCH
=========================

Changes from C9
---------------
- Full-resolution global and RML pseudo-Dice guards against the immutable C8B parent.
- Candidate scoring includes parent and stage pseudo-Dice deltas.
- Final residual is multiplied by the spatial gate after SVF integration.
- Residual capacity and schedule are reduced.
- RML SDF and right-fissure losses use narrow continuous surface bands.
- Exact pull composition and exact C8B fallback are preserved.

Install
-------
unzip -o SGR_FM_C9_1_GSFTF_patch.zip

Checks
------
python -m py_compile \
  utils/sgr_fm_c9_1_guarded_soft_fissure_fusion.py \
  run_sgr_fm_c9_1_guarded_soft_fissure_fusion_validation.py \
  smoke_sgr_fm_c9_1_guarded_soft_fissure_fusion.py
python smoke_sgr_fm_c9_1_guarded_soft_fissure_fusion.py

Smoke run
---------
python run_sgr_fm_c9_1_guarded_soft_fissure_fusion_validation.py \
  --config configs/sgr_fm_c9_1_guarded_soft_fissure_fusion.yaml \
  --cases NLST_0006 NLST_0009

Do not run all ten cases until these two manifests are reviewed.
