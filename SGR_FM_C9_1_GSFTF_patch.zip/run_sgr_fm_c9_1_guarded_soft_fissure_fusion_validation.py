#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path
from utils.sgr_fm_c9_1_guarded_soft_fissure_fusion import load_config, discover_cases, run_case, summarize, write_csv

def main() -> int:
    ap=argparse.ArgumentParser(description='Run SGR-FM C9.1 guarded soft-fissure refinement.')
    ap.add_argument('--config',default='configs/sgr_fm_c9_1_guarded_soft_fissure_fusion.yaml')
    ap.add_argument('--cases',nargs='*',default=None)
    ap.add_argument('--dry-run',action='store_true')
    args=ap.parse_args(); cfg=load_config(args.config); out=Path(cfg['output_root'])
    for d in ('dvfs','case_manifests','traces','eval'): (out/d).mkdir(parents=True,exist_ok=True)
    (out/'run_config_resolved.json').write_text(json.dumps(cfg,indent=2))
    cases=args.cases or discover_cases(cfg)
    if args.dry_run:
        print(json.dumps({'status':'DRY_RUN','method':'C9.1-GSFTF','cases':cases,'parent_dir':cfg['parent_dir'],'output_root':cfg['output_root'],'uses_validation_gt':False},indent=2)); return 0
    records=[]; failed=[]
    for case_id in cases:
        try:
            rec=run_case(case_id,cfg); records.append(rec)
            print(f"PASS {case_id} mode={rec['mode']} pseudo_delta={rec['delta_original_pseudo_mean_dice']:+.6f} rml_delta={rec['delta_rml_pseudo_dice']:+.6f} fold={rec['final_folding_pct']:.6f}%")
        except Exception as exc:
            failed.append({'case_id':case_id,'error':repr(exc)}); print(f'FAIL {case_id}: {exc!r}',file=sys.stderr)
            if not cfg.get('continue_on_error',False): break
    summary=summarize(cfg,records,failed)
    (out/'c9_1_guarded_soft_fissure_fusion_summary.json').write_text(json.dumps(summary,indent=2)); write_csv(cfg,records)
    eval_script=Path(cfg.get('evaluate_script','evaluate_validation.py'))
    if len(records)==10 and not failed and eval_script.exists():
        subprocess.run([sys.executable,str(eval_script),'--raw-data-root',str(cfg['raw_data_root']),'--dvf-dir',str(out/'dvfs'),'--output-dir',str(out/'eval')],check=False)
    print(json.dumps(summary,indent=2)); return 0 if not failed else 1

if __name__=='__main__': raise SystemExit(main())
