#!/usr/bin/env python3
"""SGR-FM C9.1-GSFTF: guarded soft-target fissure fusion.

C9.1 starts from the frozen C8B DVF and performs small, localized residual-SVF
refinement in the original fixed-image grid. It never loads validation GT.
The method preserves continuous signed-distance targets, uses patient-specific
EXP/INSP disagreement and CT/MIND evidence to construct a right-fissure gate,
and composes each accepted residual exactly in pull convention.
"""
from __future__ import annotations

import csv
import json
import math
import re
import shutil
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import binary_dilation, distance_transform_edt, map_coordinates

from utils.refine_spatial import (
    downsample_dvf_5d,
    integrate_svf,
    resize_dvf_5d,
    resize_volume_5d,
    warp_volume,
)
from utils.sgr_fm_c3 import compose_pull
from utils.sgr_fm_c4_hast import structural_gradient_loss
from utils.sgr_fm_c5b_lmind import mind_ssc_3d
from utils.sgr_fm_tto import bending_energy, build_residual_svf, jacobian_barrier, make_control_parameter

LABELS = (8, 16, 32, 64, 128)
RML_INDEX = 3
RIGHT_INDICES = (2, 3, 4)
NON_RML_INDICES = (0, 1, 2, 4)


def load_config(path: str | Path) -> Dict[str, Any]:
    import yaml
    cfg = yaml.safe_load(Path(path).read_text()) or {}
    defaults: Dict[str, Any] = {
        'output_root': 'outputs/sgr_fm/c9_1_guarded_soft_fissure_fusion',
        'parent_dir': 'outputs/sgr_fm/c8b_pseudolabel_calibrated',
        'fallback_parent_dir': 'outputs/sgr_fm/c7b_multi_init_semantic',
        'raw_data_root': 'Learn2Breath_train_val_data',
        'pseudo_segmentation_root': 'outputs/sgr_fm/segmentation_phase1_totalsegmentator',
        'evaluate_script': 'evaluate_validation.py',
        'device': 'cuda',
        'continue_on_error': False,
        'labels': list(LABELS),
    }
    for k, v in defaults.items(): cfg.setdefault(k, v)
    return cfg


def discover_cases(cfg: Dict[str, Any]) -> List[str]:
    out = set()
    for key in ('parent_dir', 'fallback_parent_dir'):
        for p in (Path(cfg[key])/'dvfs').glob('NLST_*_DVF.nii.gz'):
            out.add(p.name.split('_DVF')[0])
    return sorted(out)


def _load(path: Path) -> Tuple[nib.Nifti1Image, np.ndarray]:
    img = nib.load(str(path))
    return img, img.get_fdata(dtype=np.float32)


def _save_like(ref: nib.Nifti1Image, data: np.ndarray, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    hdr = ref.header.copy()
    hdr.set_data_dtype(np.float32)
    nib.Nifti1Image(data.astype(np.float32), ref.affine, hdr).to_filename(str(path))


def _find_parent(case_id: str, cfg: Dict[str, Any]) -> Path:
    for key in ('parent_dir', 'fallback_parent_dir'):
        p = Path(cfg[key])/'dvfs'/f'{case_id}_DVF.nii.gz'
        if p.is_file(): return p
    raise FileNotFoundError(f'No parent DVF for {case_id}')


def _find_pseudo_lobe(root: Path, case_id: str, phase: str) -> Path:
    scored = []
    for p in root.rglob('*.nii*'):
        n = p.name.lower()
        if case_id.lower() not in n or phase.lower() not in n: continue
        score = 0
        if 'lobe' in n or 'lobes' in n: score += 40
        if any(x in n for x in ('seg', 'label', 'mask')): score += 5
        if any(x in n for x in ('fissure', 'interface', 'support', 'body', 'corrected')): score -= 100
        if 'gt' in n: score -= 100
        if score > 0: scored.append((score, -len(str(p)), p))
    if not scored: raise FileNotFoundError(f'Pseudo lobe file missing for {case_id} {phase}')
    return max(scored)[2]


def _find_ct(root: Path, case_id: str, phase: str) -> Path:
    exact = []
    scored = []
    for p in root.rglob('*.nii*'):
        n = p.name.lower()
        if case_id.lower() not in n or phase.lower() not in n: continue
        if any(x in n for x in ('seg', 'label', 'mask', 'lobe', 'fissure', 'dvf')): continue
        score = 0
        if 'ct_data' in str(p).lower(): score += 50
        if n in (f'{case_id.lower()}_{phase.lower()}.nii.gz', f'{case_id.lower()}_{phase.lower()}.nii'): score += 100
        if 'validation' in str(p).lower(): score += 10
        scored.append((score, -len(str(p)), p))
    if not scored: raise FileNotFoundError(f'Raw CT missing for {case_id} {phase}')
    return max(scored)[2]


def _assert_grid(ref: nib.Nifti1Image, other: nib.Nifti1Image, name: str, atol: float = 1e-4) -> None:
    if tuple(ref.shape[:3]) != tuple(other.shape[:3]):
        raise ValueError(f'{name} shape mismatch: {other.shape[:3]} vs {ref.shape[:3]}')
    if not np.allclose(ref.affine, other.affine, rtol=0.0, atol=atol):
        raise ValueError(f'{name} affine mismatch; max={np.max(np.abs(ref.affine-other.affine))}')


def _dvf_tensor(a: np.ndarray, device: torch.device) -> torch.Tensor:
    if a.ndim == 4 and a.shape[-1] == 3:
        x = np.moveaxis(a, -1, 0)
    elif a.ndim == 4 and a.shape[0] == 3:
        x = a
    else:
        raise ValueError(f'Expected XYZ3 or 3XYZ DVF, got {a.shape}')
    return torch.from_numpy(np.ascontiguousarray(x[None].astype(np.float32))).to(device)


def _dvf_numpy(t: torch.Tensor) -> np.ndarray:
    return t.detach().cpu().numpy()[0].transpose(1,2,3,0).astype(np.float32)


def _volume_tensor(a: np.ndarray, device: torch.device) -> torch.Tensor:
    return torch.from_numpy(np.ascontiguousarray(a[None,None].astype(np.float32))).to(device)


def _labels_onehot(a: np.ndarray, labels: Sequence[int], device: torch.device) -> torch.Tensor:
    x = np.stack([(a == int(l)).astype(np.float32) for l in labels], axis=0)[None]
    return torch.from_numpy(np.ascontiguousarray(x)).to(device)


def _normalize_ct(a: np.ndarray, lo: float, hi: float) -> np.ndarray:
    x = np.clip(a, lo, hi)
    return ((x-lo)/max(hi-lo, 1e-6)*2.0-1.0).astype(np.float32)


def _spacing(img: nib.Nifti1Image) -> Tuple[float,float,float]:
    return tuple(float(v) for v in nib.affines.voxel_sizes(img.affine)[:3])


def _signed_distance_channels(labels_xyz: np.ndarray, spacing: Sequence[float], clip_mm: float, labels: Sequence[int]) -> np.ndarray:
    out = []
    for lab in labels:
        m = labels_xyz == int(lab)
        if not np.any(m):
            out.append(np.full(labels_xyz.shape, -1.0, np.float32)); continue
        d = distance_transform_edt(m, sampling=spacing) - distance_transform_edt(~m, sampling=spacing)
        out.append(np.clip(d, -clip_mm, clip_mm).astype(np.float32)/max(clip_mm,1e-6))
    return np.stack(out, axis=0)


def _connectivity6() -> np.ndarray:
    s = np.zeros((3,3,3), bool)
    s[1,1,1] = True
    s[0,1,1]=s[2,1,1]=s[1,0,1]=s[1,2,1]=s[1,1,0]=s[1,1,2]=True
    return s


def _interface_surfaces(labels_xyz: np.ndarray, dilation_iterations: int = 1) -> np.ndarray:
    st = _connectivity6()
    def iface(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        da = binary_dilation(a, structure=st, iterations=dilation_iterations)
        db = binary_dilation(b, structure=st, iterations=dilation_iterations)
        return ((a & db) | (b & da)).astype(np.float32)
    rh = iface(labels_xyz==32, labels_xyz==64)
    ro = iface(labels_xyz==128, (labels_xyz==32)|(labels_xyz==64))
    return np.stack([rh,ro], axis=0)


def _interface_distance(surfaces: np.ndarray, spacing: Sequence[float], clip_mm: float) -> np.ndarray:
    out=[]
    for s in surfaces:
        if np.any(s>0.5): d=distance_transform_edt(~(s>0.5), sampling=spacing)
        else: d=np.full(s.shape, clip_mm, np.float32)
        out.append(np.clip(d,0,clip_mm).astype(np.float32)/max(clip_mm,1e-6))
    return np.stack(out,axis=0)


def _channel_dice(pred: torch.Tensor, target: torch.Tensor, eps: float=1e-6) -> torch.Tensor:
    dims=(0,2,3,4)
    inter=(pred*target).sum(dims); den=(pred+target).sum(dims)
    return (2*inter+eps)/(den+eps)


def _binary_dice(pred: torch.Tensor, target: torch.Tensor, eps: float=1e-6) -> torch.Tensor:
    dims=tuple(range(1,pred.ndim)); inter=(pred*target).sum(dims); den=(pred+target).sum(dims)
    return ((2*inter+eps)/(den+eps)).mean()


def _robust_norm(x: torch.Tensor, qlo: float=0.50, qhi: float=0.95) -> torch.Tensor:
    f=x.detach().float().flatten(); lo=torch.quantile(f,qlo); hi=torch.quantile(f,qhi)
    return ((x-lo)/(hi-lo).clamp_min(1e-6)).clamp(0,1)


def _gradient_mag(x: torch.Tensor) -> torch.Tensor:
    gx=F.pad(x[...,1:,:,:]-x[...,:-1,:,:],(0,0,0,0,0,1))
    gy=F.pad(x[...,:,1:,:]-x[...,:,:-1,:],(0,0,0,1,0,0))
    gz=F.pad(x[...,:,:,1:]-x[...,:,:,:-1],(0,1,0,0,0,0))
    return torch.sqrt(gx*gx+gy*gy+gz*gz+1e-8)


def _charbonnier(x: torch.Tensor, eps: float) -> torch.Tensor:
    return torch.sqrt(x*x+eps*eps)


def _weighted_mean(x: torch.Tensor, w: torch.Tensor) -> torch.Tensor:
    return (x*w).sum()/w.sum().clamp_min(1.0)


def _surface_loss(warped_dist: torch.Tensor, target_dist: torch.Tensor, warped_surface: torch.Tensor, target_surface: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    a=_weighted_mean(warped_surface*target_dist, weight)
    b=_weighted_mean(target_surface*warped_dist, weight)
    return 0.5*(a+b)


def _folding_pct_np(dvf: np.ndarray) -> float:
    ux,uy,uz=dvf[...,0],dvf[...,1],dvf[...,2]
    a=np.gradient(ux); b=np.gradient(uy); c=np.gradient(uz)
    J00,J01,J02=1+a[0],a[1],a[2]; J10,J11,J12=b[0],1+b[1],b[2]; J20,J21,J22=c[0],c[1],1+c[2]
    det=J00*(J11*J22-J12*J21)-J01*(J10*J22-J12*J20)+J02*(J10*J21-J11*J20)
    return float(100*np.mean(det<=0))


def _warp_label_np(moving: np.ndarray, dvf: np.ndarray) -> np.ndarray:
    X,Y,Z=moving.shape
    xx,yy,zz=np.meshgrid(np.arange(X),np.arange(Y),np.arange(Z),indexing='ij')
    return map_coordinates(moving.astype(np.float32),[xx+dvf[...,0],yy+dvf[...,1],zz+dvf[...,2]],order=0,mode='nearest').round().astype(np.int16)


def _dice_np(a: np.ndarray, b: np.ndarray, labels: Sequence[int]) -> Tuple[float,Dict[str,float]]:
    per={}; vals=[]
    for lab in labels:
        aa=a==lab; bb=b==lab; den=int(aa.sum()+bb.sum())
        v=float('nan') if den==0 else float(2*np.logical_and(aa,bb).sum()/den)
        per[f'dice_{lab}']=v
        if np.isfinite(v): vals.append(v)
    return float(np.mean(vals)),per


def _mind_loss(fixed_mind: torch.Tensor, prewarped_mind: torch.Tensor, residual: torch.Tensor, gate: torch.Tensor, eps: float) -> torch.Tensor:
    warped=warp_volume(prewarped_mind,residual,mode='bilinear')
    return _weighted_mean(_charbonnier(warped-fixed_mind,eps).mean(dim=1,keepdim=True),gate)


def _prepare_stage(full: Dict[str,Any], current: torch.Tensor, stage: Dict[str,Any], cfg: Dict[str,Any]) -> Dict[str,Any]:
    r=int(stage['reduce_factor']); device=current.device
    fixed_ct=resize_volume_5d(full['fixed_ct'],r,'trilinear')
    moving_ct=resize_volume_5d(full['moving_ct'],r,'trilinear')
    fixed_lab=resize_volume_5d(full['fixed_lab_float'],r,'nearest')[0,0].round().cpu().numpy().astype(np.int16)
    moving_lab=resize_volume_5d(full['moving_lab_float'],r,'nearest')[0,0].round().cpu().numpy().astype(np.int16)
    current_r=downsample_dvf_5d(current,r)
    spacing=tuple(v*r for v in full['spacing'])
    labels=full['labels']
    fixed_lobes=_labels_onehot(fixed_lab,labels,device); moving_lobes=_labels_onehot(moving_lab,labels,device)
    sdf_clip=float(cfg['anatomy']['sdf_clip_mm']); int_clip=float(cfg['anatomy']['interface_clip_mm'])
    fsdf=torch.from_numpy(_signed_distance_channels(fixed_lab,spacing,sdf_clip,labels)[None]).to(device)
    msdf=torch.from_numpy(_signed_distance_channels(moving_lab,spacing,sdf_clip,labels)[None]).to(device)
    fsurf_np=_interface_surfaces(fixed_lab,int(cfg['anatomy']['interface_dilation_iterations']))
    msurf_np=_interface_surfaces(moving_lab,int(cfg['anatomy']['interface_dilation_iterations']))
    fsurf=torch.from_numpy(fsurf_np[None]).to(device); msurf=torch.from_numpy(msurf_np[None]).to(device)
    fdist=torch.from_numpy(_interface_distance(fsurf_np,spacing,int_clip)[None]).to(device)
    mdist=torch.from_numpy(_interface_distance(msurf_np,spacing,int_clip)[None]).to(device)
    pre_ct=warp_volume(moving_ct,current_r,'bilinear')
    pre_lobes=warp_volume(moving_lobes,current_r,'bilinear').clamp(0,1)
    pre_sdf=warp_volume(msdf,current_r,'bilinear')
    pre_surf=warp_volume(msurf,current_r,'bilinear').clamp(0,1)
    pre_dist=warp_volume(mdist,current_r,'bilinear').clamp(0,1)
    mind_cfg=cfg['mind']; fixed_mind=mind_ssc_3d(fixed_ct,mind_cfg).detach(); pre_mind=mind_ssc_3d(pre_ct,mind_cfg).detach()
    mismatch=(fixed_mind-pre_mind).abs().mean(1,keepdim=True)
    mismatch_n=_robust_norm(mismatch,float(cfg['priority']['mind_quantile_low']),float(cfg['priority']['mind_quantile_high']))
    edge_n=_robust_norm(_gradient_mag(fixed_ct),0.55,0.97)
    lobe_dis=(fixed_lobes[:,RIGHT_INDICES]-pre_lobes[:,RIGHT_INDICES]).abs().mean(1,keepdim=True)
    sdf_dis=(fsdf[:,RML_INDEX:RML_INDEX+1]-pre_sdf[:,RML_INDEX:RML_INDEX+1]).abs().clamp(0,1)
    fissure=torch.exp(-fdist.min(1,keepdim=True).values/max(float(cfg['priority']['fissure_sigma']),1e-6))
    raw=(float(cfg['priority']['disagreement_weight'])*lobe_dis + float(cfg['priority']['sdf_disagreement_weight'])*sdf_dis + float(cfg['priority']['mind_weight'])*mismatch_n + float(cfg['priority']['edge_weight'])*edge_n + float(cfg['priority']['fissure_weight'])*fissure)
    denom=sum(float(cfg['priority'][k]) for k in ('disagreement_weight','sdf_disagreement_weight','mind_weight','edge_weight','fissure_weight'))
    raw=raw/max(denom,1e-6)
    active=torch.sigmoid((raw-float(cfg['priority']['sigmoid_center']))/max(float(cfg['priority']['sigmoid_temperature']),1e-6))
    right=fixed_lobes[:,RIGHT_INDICES].sum(1,keepdim=True).clamp(0,1)
    k=int(cfg['priority']['right_support_dilation_kernel']); right_band=F.max_pool3d(right,kernel_size=k,stride=1,padding=k//2)
    gate=right_band*(float(cfg['priority']['gate_floor'])+(1-float(cfg['priority']['gate_floor']))*active)
    sk=int(cfg['priority']['smooth_kernel'])
    if sk>1: gate=F.avg_pool3d(gate,kernel_size=sk,stride=1,padding=sk//2)
    gate=gate.detach().clamp(0,1)
    # Continuous patient-specific target: trust direct INSP more where fixed CT supports a boundary;
    # elsewhere retain a conservative blend with the parent-transported EXP geometry.
    alpha=(float(cfg['fusion']['fixed_anchor_floor'])+(1-float(cfg['fusion']['fixed_anchor_floor']))*edge_n).clamp(0,1)
    alpha=(alpha*gate + float(cfg['fusion']['outside_gate_anchor'])*(1-gate)).detach()
    fused_sdf=alpha*fsdf+(1-alpha)*pre_sdf
    fused_dist=alpha*fdist+(1-alpha)*pre_dist
    return {
        'fixed_ct':fixed_ct,'pre_ct':pre_ct,'fixed_lobes':fixed_lobes,'pre_lobes':pre_lobes,
        'fixed_sdf':fsdf,'pre_sdf':pre_sdf,'fused_sdf':fused_sdf.detach(),
        'fixed_surf':fsurf,'pre_surf':pre_surf,'fixed_dist':fdist,'pre_dist':pre_dist,'fused_dist':fused_dist.detach(),
        'fixed_mind':fixed_mind,'pre_mind':pre_mind,'gate':gate,'current_r':current_r,
        'full_shape':tuple(int(v) for v in current.shape[-3:]),'target_shape':tuple(int(v) for v in current_r.shape[-3:]),
        'diagnostics':{
            'gate_mean':float(gate.mean()),'gate_p90':float(torch.quantile(gate.flatten(),.90)),
            'gate_fraction_gt_0_5':float((gate>.5).float().mean()),'mean_right_lobe_disagreement':float(lobe_dis.mean()),
            'mean_rml_sdf_disagreement':float(sdf_dis.mean()),'mean_mind_mismatch_norm':float(mismatch_n.mean()),
            'mean_fixed_anchor_alpha':float(alpha.mean()),
        }
    }



def _residual_from_param(param: torch.Tensor, state: Dict[str,Any], stage: Dict[str,Any], scale: float=1.0) -> torch.Tensor:
    svf=build_residual_svf(
        param,None,
        target_shape=state['target_shape'],
        full_shape=state['full_shape'],
        max_fullres_voxels=float(stage['max_residual_fullres_voxels']),
        scale=scale,
    )
    gate=state['gate'].clamp(0,1)
    residual=integrate_svf(svf*gate,int(stage['integration_steps']))
    # Integration can spread displacement beyond the intended ROI. Apply the
    # same smooth gate to the final residual so the accepted field remains local.
    power=float(stage.get('post_integration_gate_power',1.0))
    return residual*gate.pow(power)


def _metric_tensors(state: Dict[str,Any], residual: torch.Tensor, cfg: Dict[str,Any]) -> Dict[str,torch.Tensor]:
    wl=warp_volume(state['pre_lobes'],residual,'bilinear').clamp(0,1)
    wsdf=warp_volume(state['pre_sdf'],residual,'bilinear')
    wdist=warp_volume(state['pre_dist'],residual,'bilinear').clamp(0,1)
    wct=warp_volume(state['pre_ct'],residual,'bilinear')
    dices=_channel_dice(wl,state['fixed_lobes'])
    non_pres=_channel_dice(wl[:,NON_RML_INDICES],state['pre_lobes'][:,NON_RML_INDICES]).mean()
    gate=state['gate']; eps=float(cfg['anatomy']['charbonnier_eps'])

    # C9.1 uses narrow continuous bands around both the current and fused
    # surfaces. This prevents large homogeneous regions from dominating SDF loss.
    sdf_frac=float(cfg['anatomy'].get('sdf_band_fraction',0.30))
    target_rml=state['fused_sdf'][:,RML_INDEX:RML_INDEX+1]
    current_rml=state['pre_sdf'][:,RML_INDEX:RML_INDEX+1]
    sdf_band=((target_rml.abs()<sdf_frac)|(current_rml.abs()<sdf_frac)).float()
    sdf_loss=_weighted_mean(
        _charbonnier(wsdf[:,RML_INDEX:RML_INDEX+1]-target_rml,eps),
        gate*sdf_band,
    )

    interface_frac=float(cfg['anatomy'].get('interface_band_fraction',0.30))
    rh_band=((state['fused_dist'][:,0:1]<interface_frac)|(state['pre_dist'][:,0:1]<interface_frac)).float()
    ro_band=((state['fused_dist'][:,1:2]<interface_frac)|(state['pre_dist'][:,1:2]<interface_frac)).float()
    rh=_weighted_mean(
        _charbonnier(wdist[:,0:1]-state['fused_dist'][:,0:1],eps),
        gate*rh_band,
    )
    ro=_weighted_mean(
        _charbonnier(wdist[:,1:2]-state['fused_dist'][:,1:2],eps),
        gate*ro_band,
    )
    mind=_mind_loss(state['fixed_mind'],state['pre_mind'],residual,gate,float(cfg['mind']['charbonnier_eps']))
    structural=structural_gradient_loss(state['fixed_ct'],wct,gate,min_magnitude=float(cfg['ct']['gradient_min_magnitude']))
    return {
        'global_lobe_dice':dices.mean(),
        'rml_dice':dices[RML_INDEX],
        'non_rml_preservation':non_pres,
        'rml_sdf_loss':sdf_loss,
        'right_horizontal_loss':rh,
        'right_oblique_loss':ro,
        'mind_loss':mind,
        'structural_loss':structural,
    }

def _metrics(state: Dict[str,Any], residual: torch.Tensor, cfg: Dict[str,Any]) -> Dict[str,float]:
    with torch.no_grad(): return {k:float(v.item()) for k,v in _metric_tensors(state,residual,cfg).items()}


def _objective(state: Dict[str,Any], residual: torch.Tensor, cfg: Dict[str,Any], stage: Dict[str,Any]) -> Tuple[torch.Tensor,Dict[str,torch.Tensor]]:
    t=_metric_tensors(state,residual,cfg); w=stage['weights']
    final_r=compose_pull(state['current_r'],residual)
    jac,fold,min_det=jacobian_barrier(final_r,margin=float(w['jacobian_margin']))
    outside=1-state['gate']; outside_mag=(residual.square().sum(1,keepdim=True)*outside).sum()/outside.sum().clamp_min(1)
    bend=bending_energy(residual); mag=residual.square().mean()
    total=(float(w['rml_dice'])*(1-t['rml_dice']) + float(w['global_lobe_dice'])*(1-t['global_lobe_dice']) + float(w['rml_sdf'])*t['rml_sdf_loss'] + float(w['right_horizontal'])*t['right_horizontal_loss'] + float(w['right_oblique'])*t['right_oblique_loss'] + float(w['mind'])*t['mind_loss'] + float(w['structural'])*t['structural_loss'] + float(w['non_rml_preservation'])*(1-t['non_rml_preservation']) + float(w['outside_gate_magnitude'])*outside_mag + float(w['bending'])*bend + float(w['magnitude'])*mag + float(w['jacobian'])*jac)
    t.update({'total':total,'jacobian_loss':jac,'folding_pct':fold,'min_det':min_det,'outside_gate_magnitude':outside_mag,'bending':bend,'magnitude':mag})
    return total,t


def _optimize(state: Dict[str,Any], cfg: Dict[str,Any], stage: Dict[str,Any], device: torch.device) -> Tuple[torch.Tensor,Dict[str,Any]]:
    param=make_control_parameter(state['target_shape'],int(stage['control_factor']),device=device,dtype=torch.float32)
    opt=torch.optim.Adam([param],lr=float(stage['lr'])); best_loss=float('inf'); best=None; best_it=0; patience=0; history=[]
    for it in range(1,int(stage['iterations'])+1):
        opt.zero_grad(set_to_none=True); residual=_residual_from_param(param,state,stage,1.0); loss,terms=_objective(state,residual,cfg,stage)
        if not torch.isfinite(loss): raise RuntimeError(f'Non-finite C9 loss at iter {it}')
        loss.backward(); torch.nn.utils.clip_grad_norm_([param],float(stage.get('grad_clip',1.0))); opt.step()
        val=float(loss.detach())
        if it==1 or it%10==0: history.append({'iter':it,'loss':val,'rml_dice':float(terms['rml_dice'].detach()),'sdf':float(terms['rml_sdf_loss'].detach()),'mind':float(terms['mind_loss'].detach()),'folding_pct_lowres':float(terms['folding_pct'].detach())})
        if val < best_loss-float(stage.get('min_objective_improvement',1e-7)):
            best_loss=val; best=param.detach().clone(); best_it=it; patience=0
        else: patience+=1
        if patience>=int(stage.get('early_stop_patience',60)): break
    if best is None: best=param.detach().clone()
    return best,{'best_loss':best_loss,'best_iteration':best_it,'iterations_run':it,'history':history}



def _candidate_score(
    m: Dict[str,float],
    b: Dict[str,float],
    fold: float,
    cfg: Dict[str,Any],
    *,
    parent_global_gain: float,
    parent_rml_gain: float,
    stage_global_gain: float,
    stage_rml_gain: float,
) -> float:
    s=cfg['selection']
    score=(
        float(s['score_parent_rml_gain'])*parent_rml_gain
        + float(s['score_parent_global_gain'])*parent_global_gain
        + float(s['score_stage_rml_gain'])*stage_rml_gain
        + float(s['score_stage_global_gain'])*stage_global_gain
        + float(s['score_sdf_gain'])*(b['rml_sdf_loss']-m['rml_sdf_loss'])
        + float(s['score_horizontal_gain'])*(b['right_horizontal_loss']-m['right_horizontal_loss'])
        + float(s['score_oblique_gain'])*(b['right_oblique_loss']-m['right_oblique_loss'])
        + float(s['score_mind_gain'])*(b['mind_loss']-m['mind_loss'])
        + float(s['score_structural_gain'])*(b['structural_loss']-m['structural_loss'])
        + float(s['score_non_rml_gain'])*(m['non_rml_preservation']-b['non_rml_preservation'])
    )
    if fold>float(s['soft_folding_start_pct']):
        a=float(s['soft_folding_start_pct']); z=float(s['hard_reject_folding_pct'])
        score-=float(s['folding_penalty'])*min(1.0,max(0.0,(fold-a)/max(z-a,1e-6)))
    return score

def _pseudo_guard_reasons(
    scale: float,
    candidate_mean: float,
    candidate_per: Dict[str,float],
    stage_mean: float,
    stage_per: Dict[str,float],
    parent_mean: float,
    parent_per: Dict[str,float],
    cfg: Dict[str,Any],
) -> Tuple[List[str],Dict[str,float]]:
    parent_global_gain=candidate_mean-parent_mean
    parent_rml_gain=candidate_per['dice_64']-parent_per['dice_64']
    stage_global_gain=candidate_mean-stage_mean
    stage_rml_gain=candidate_per['dice_64']-stage_per['dice_64']
    max_parent_non_rml_loss=max(parent_per[f'dice_{l}']-candidate_per[f'dice_{l}'] for l in LABELS if l!=64)
    max_stage_non_rml_loss=max(stage_per[f'dice_{l}']-candidate_per[f'dice_{l}'] for l in LABELS if l!=64)
    d={
        'parent_global_gain':parent_global_gain,
        'parent_rml_gain':parent_rml_gain,
        'stage_global_gain':stage_global_gain,
        'stage_rml_gain':stage_rml_gain,
        'max_parent_non_rml_loss':max_parent_non_rml_loss,
        'max_stage_non_rml_loss':max_stage_non_rml_loss,
    }
    if float(scale)<=0.0:
        return [],d
    s=cfg['selection']; reasons=[]
    if parent_global_gain < -float(s['max_parent_global_pseudo_loss']): reasons.append('parent_global_pseudo_loss')
    if parent_rml_gain < -float(s['max_parent_rml_pseudo_loss']): reasons.append('parent_rml_pseudo_loss')
    if stage_global_gain < -float(s['max_stage_global_pseudo_loss']): reasons.append('stage_global_pseudo_loss')
    if stage_rml_gain < -float(s['max_stage_rml_pseudo_loss']): reasons.append('stage_rml_pseudo_loss')
    if max(max_parent_non_rml_loss,max_stage_non_rml_loss) > float(s['max_non_rml_pseudo_loss']): reasons.append('non_rml_pseudo_loss')
    return reasons,d


def _select(current: torch.Tensor, state: Dict[str,Any], param: torch.Tensor, stage: Dict[str,Any], full: Dict[str,Any], cfg: Dict[str,Any]) -> Tuple[torch.Tensor,Dict[str,Any]]:
    zero=torch.zeros_like(state['current_r']); base_m=_metrics(state,zero,cfg)
    current_np=_dvf_numpy(current)
    stage_mean,stage_per=_dice_np(full['fixed_lab'],_warp_label_np(full['moving_lab'],current_np),full['labels'])
    parent_mean=float(full['parent_mean']); parent_per=full['parent_per']
    details=[]; best=None
    for scale in stage['selection_scales']:
        residual_r=_residual_from_param(param,state,stage,float(scale)) if float(scale)>0 else zero
        residual_full=resize_dvf_5d(residual_r,state['full_shape'])
        candidate=compose_pull(current,residual_full); candidate_np=_dvf_numpy(candidate)
        fold=_folding_pct_np(candidate_np); m=_metrics(state,residual_r,cfg)
        mean,per=_dice_np(full['fixed_lab'],_warp_label_np(full['moving_lab'],candidate_np),full['labels'])
        reasons,deltas=_pseudo_guard_reasons(
            float(scale),mean,per,stage_mean,stage_per,parent_mean,parent_per,cfg
        )
        score=_candidate_score(
            m,base_m,fold,cfg,
            parent_global_gain=deltas['parent_global_gain'],
            parent_rml_gain=deltas['parent_rml_gain'],
            stage_global_gain=deltas['stage_global_gain'],
            stage_rml_gain=deltas['stage_rml_gain'],
        )
        if fold>float(cfg['selection']['hard_reject_folding_pct']): reasons.append('hard_folding')
        if float(scale)>0:
            if score<float(cfg['selection']['min_composite_gain']): reasons.append('insufficient_composite_gain')
            if m['mind_loss']-base_m['mind_loss']>float(cfg['selection']['max_mind_increase']): reasons.append('mind_increase')
        rec={
            'scale':float(scale),'score':float(score),'folding_pct':fold,
            'original_pseudo_mean_dice':mean,'original_pseudo_per_lobe':per,
            **deltas,'metrics':m,'rejected':bool(reasons),'reject_reasons':sorted(set(reasons)),
        }
        details.append(rec)
        if not reasons and (best is None or rec['score']>best['record']['score']):
            best={'record':rec,'candidate':candidate}
    if best is None:
        z=next(r for r in details if r['scale']==0.0)
        return current,{'selected':z,'candidates':details,'baseline_metrics':base_m,'stage_baseline_mean':stage_mean,'parent_baseline_mean':parent_mean}
    return best['candidate'],{'selected':best['record'],'candidates':details,'baseline_metrics':base_m,'stage_baseline_mean':stage_mean,'parent_baseline_mean':parent_mean}


def run_case(case_id: str, cfg: Dict[str,Any]) -> Dict[str,Any]:
    t0=time.time(); device=torch.device(cfg['device'] if cfg['device']!='cuda' or torch.cuda.is_available() else 'cpu')
    labels=[int(x) for x in cfg.get('labels',LABELS)]
    parent_path=_find_parent(case_id,cfg); pimg,pdvf=_load(parent_path)
    fixed_p=_find_pseudo_lobe(Path(cfg['pseudo_segmentation_root']),case_id,'INSP'); moving_p=_find_pseudo_lobe(Path(cfg['pseudo_segmentation_root']),case_id,'EXP')
    fixed_img,fixed_lab=_load(fixed_p); moving_img,moving_lab=_load(moving_p)
    fixed_ct_p=_find_ct(Path(cfg['raw_data_root']),case_id,'INSP'); moving_ct_p=_find_ct(Path(cfg['raw_data_root']),case_id,'EXP')
    fct_img,fct=_load(fixed_ct_p); mct_img,mct=_load(moving_ct_p)
    for img,name in ((fixed_img,'fixed pseudo'),(moving_img,'moving pseudo'),(fct_img,'fixed CT'),(mct_img,'moving CT')): _assert_grid(pimg,img,name)
    fixed_lab=fixed_lab.round().astype(np.int16); moving_lab=moving_lab.round().astype(np.int16)
    current=_dvf_tensor(pdvf,device); parent=current.detach().clone(); parent_np=_dvf_numpy(parent)
    parent_mean,parent_per=_dice_np(fixed_lab,_warp_label_np(moving_lab,parent_np),labels)
    lo=float(cfg['ct']['clip_min_hu']); hi=float(cfg['ct']['clip_max_hu'])
    full={
        'fixed_ct':_volume_tensor(_normalize_ct(fct,lo,hi),device),
        'moving_ct':_volume_tensor(_normalize_ct(mct,lo,hi),device),
        'fixed_lab_float':_volume_tensor(fixed_lab.astype(np.float32),device),
        'moving_lab_float':_volume_tensor(moving_lab.astype(np.float32),device),
        'fixed_lab':fixed_lab,'moving_lab':moving_lab,'spacing':_spacing(pimg),'labels':labels,
        'parent_mean':parent_mean,'parent_per':dict(parent_per),
    }
    stage_records=[]
    for stage in cfg['stages']:
        state=_prepare_stage(full,current,stage,cfg)
        param,opt=_optimize(state,cfg,stage,device)
        new_current,sel=_select(current,state,param,stage,full,cfg)
        current=new_current.detach()
        stage_records.append({'stage':stage['name'],'state_diagnostics':state['diagnostics'],'optimizer':opt,'selection':sel})
    final_np=_dvf_numpy(current)
    final_mean,final_per=_dice_np(fixed_lab,_warp_label_np(moving_lab,final_np),labels)
    parent_fold=_folding_pct_np(parent_np); final_fold=_folding_pct_np(final_np)
    changed=bool(np.max(np.abs(final_np-parent_np))>1e-7)
    mode='c9_1_guarded_soft_fissure_fusion' if changed else 'exact_parent_fallback'
    final_global_gain=final_mean-parent_mean
    final_rml_gain=final_per['dice_64']-parent_per['dice_64']
    fg=cfg['final_guard']
    if (
        final_global_gain < -float(fg['max_parent_global_pseudo_loss'])
        or final_rml_gain < -float(fg['max_parent_rml_pseudo_loss'])
        or final_fold>float(cfg['selection']['hard_reject_folding_pct'])
    ):
        current=parent; final_np=parent_np; final_mean=parent_mean; final_per=dict(parent_per)
        final_fold=parent_fold; changed=False; mode='exact_parent_fallback_final_guard'
        final_global_gain=0.0; final_rml_gain=0.0
    out=Path(cfg['output_root']); out_dvf=out/'dvfs'/f'{case_id}_DVF.nii.gz'
    if not changed:
        out_dvf.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(parent_path,out_dvf)
    else:
        _save_like(pimg,final_np,out_dvf)
    rec={
        'case_id':case_id,'status':'ok','mode':mode,'device':str(device),
        'parent_dvf':str(parent_path),'fixed_pseudo':str(fixed_p),'moving_pseudo':str(moving_p),
        'fixed_ct':str(fixed_ct_p),'moving_ct':str(moving_ct_p),'uses_validation_gt':False,
        'parent_original_pseudo_mean_dice':parent_mean,'final_original_pseudo_mean_dice':final_mean,
        'delta_original_pseudo_mean_dice':final_global_gain,
        'parent_original_per_lobe':parent_per,'final_original_per_lobe':final_per,
        'delta_rml_pseudo_dice':final_rml_gain,
        'parent_folding_pct':parent_fold,'final_folding_pct':final_fold,
        'max_abs_dvf_change_vox':float(np.max(np.abs(final_np-parent_np))),
        'stages':stage_records,'elapsed_sec':time.time()-t0,
    }
    (out/'case_manifests').mkdir(parents=True,exist_ok=True)
    (out/'case_manifests'/f'{case_id}.json').write_text(json.dumps(rec,indent=2))
    return rec

def summarize(cfg: Dict[str,Any], records: List[Dict[str,Any]], failed: List[Dict[str,Any]]) -> Dict[str,Any]:
    modes={}
    for r in records: modes[r['mode']]=modes.get(r['mode'],0)+1
    def mean(k): return float(np.mean([r[k] for r in records])) if records else None
    return {'status':'PASS' if not failed else 'PARTIAL_FAIL','method':'SGR-FM C9.1-GSFTF guarded soft-target fissure fusion','case_count':len(records),'failure_count':len(failed),'mode_histogram':modes,'uses_validation_gt':False,'parent_mean_original_pseudo_dice':mean('parent_original_pseudo_mean_dice'),'final_mean_original_pseudo_dice':mean('final_original_pseudo_mean_dice'),'delta_mean_original_pseudo_dice':None if not records else mean('final_original_pseudo_mean_dice')-mean('parent_original_pseudo_mean_dice'),'mean_final_folding_pct':mean('final_folding_pct'),'max_final_folding_pct':None if not records else float(max(r['final_folding_pct'] for r in records)),'failed_cases':failed,'output_root':cfg['output_root'],'parent_dir':cfg['parent_dir']}


def write_csv(cfg: Dict[str,Any], records: List[Dict[str,Any]]) -> None:
    p=Path(cfg['output_root'])/'c9_1_guarded_soft_fissure_fusion_per_case.csv'; p.parent.mkdir(parents=True,exist_ok=True)
    fields=['case_id','mode','parent_original_pseudo_mean_dice','final_original_pseudo_mean_dice','delta_original_pseudo_mean_dice','delta_rml_pseudo_dice','parent_folding_pct','final_folding_pct','max_abs_dvf_change_vox']
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); [w.writerow({k:r.get(k) for k in fields}) for r in records]
