#!/usr/bin/env python3
import json, math, os, re, hashlib
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np

try:
    import nibabel as nib
except Exception as e:  # pragma: no cover
    nib = None

try:
    from scipy.ndimage import map_coordinates
except Exception:
    map_coordinates = None


def _simple_parse(text: str):
    out = {}
    for ln in text.splitlines():
        ln = ln.strip()
        if not ln or ln.startswith('#'):
            continue
        if ':' in ln:
            k, v = ln.split(':', 1)
            k, v = k.strip(), v.strip()
            if v.startswith('[') and v.endswith(']'):
                try:
                    out[k] = json.loads(v.replace("'", '"'))
                except Exception:
                    out[k] = [x.strip() for x in v[1:-1].split(',') if x.strip()]
            elif v.lower() in ('true', 'false'):
                out[k] = v.lower() == 'true'
            else:
                try:
                    out[k] = json.loads(v)
                except Exception:
                    out[k] = v.strip('"')
    return out


def load_config(path: str) -> Dict:
    p = Path(path)
    text = p.read_text()
    if p.suffix.lower() == '.json':
        cfg = json.loads(text)
    else:
        try:
            import yaml  # type: ignore
            cfg = yaml.safe_load(text)
        except Exception:
            cfg = _simple_parse(text)
    defaults = {
        'output_root': 'outputs/sgr_fm/c7b_multi_init_semantic',
        'parent_c6_dir': 'outputs/sgr_fm/c6_rml_aware',
        'parent_c7a_v2_dir': 'outputs/sgr_fm/c7a_v2_relaxed_selector',
        'raw_data_root': 'Learn2Breath_train_val_data',
        'soft_folding_start_pct': 0.25,
        'soft_folding_full_pct': 0.30,
        'hard_reject_folding_pct': 0.50,
        'blend_alphas': [0.25, 0.5, 0.75],
        'extrapolation_scales': [1.10, 1.20],
        'weights': {
            'lncc': 0.20,
            'seg_proxy': 1.0,
            'support_proxy': 0.35,
            'smoothness': 0.03,
            'magnitude': 0.01,
            'disagreement_bonus': 0.05,
        },
        'accept_margin': 0.002,
        'evaluate_script': 'evaluate_validation.py',
        'segmentation_root': 'outputs/sgr_fm/segmentation_phase1_totalsegmentator',
    }
    for k, v in defaults.items():
        cfg.setdefault(k, v)
    cfg['output_root'] = str(cfg['output_root'])
    return cfg


def discover_cases_from_dvf_dir(d: Path) -> List[str]:
    cases = []
    if not d.exists():
        return cases
    for p in sorted(d.glob('NLST_*_DVF.nii.gz')):
        m = re.match(r'(NLST_\d+)_DVF\.nii\.gz', p.name)
        if m:
            cases.append(m.group(1))
    return cases


def _load_nifti(path: Path):
    img = nib.load(str(path))
    data = img.get_fdata(dtype=np.float32)
    return img, data


def _save_nifti_like(ref_img, data: np.ndarray, path: Path):
    if data.dtype != np.float32:
        data = data.astype(np.float32)
    img = nib.Nifti1Image(data, affine=ref_img.affine, header=ref_img.header)
    img.to_filename(str(path))


def _find_file(root: Path, patterns: List[str]) -> Optional[Path]:
    if not root.exists():
        return None
    name_l = [p.lower() for p in patterns]
    for p in root.rglob('*'):
        if not p.is_file():
            continue
        n = p.name.lower()
        if all(x in n for x in name_l):
            return p
    return None


def _find_case_image(raw_root: Path, case_id: str, phase: str) -> Optional[Path]:
    return _find_file(raw_root, [case_id.lower(), phase.lower(), '.nii'])


def _find_case_seg(seg_root: Path, case_id: str, phase: str) -> Optional[Path]:
    candidates = [
        [case_id.lower(), phase.lower(), 'lobe'],
        [case_id.lower(), phase.lower(), 'lobes'],
        [case_id.lower(), phase.lower(), 'seg'],
        [case_id.lower(), phase.lower(), 'label'],
    ]
    for pats in candidates:
        p = _find_file(seg_root, pats)
        if p:
            return p
    return None


def _get_grid(shape):
    zz, yy, xx = np.meshgrid(
        np.arange(shape[0], dtype=np.float32),
        np.arange(shape[1], dtype=np.float32),
        np.arange(shape[2], dtype=np.float32),
        indexing='ij'
    )
    return zz, yy, xx


def _warp_scalar(moving: np.ndarray, dvf: np.ndarray, order=1) -> np.ndarray:
    if map_coordinates is None:
        raise RuntimeError('scipy.ndimage.map_coordinates is required')
    if dvf.shape[-1] != 3:
        raise ValueError('DVF expected as [Z,Y,X,3]')
    z, y, x = _get_grid(moving.shape)
    coords = [z + dvf[..., 0], y + dvf[..., 1], x + dvf[..., 2]]
    return map_coordinates(moving, coords, order=order, mode='nearest').astype(np.float32)


def _warp_label(moving: np.ndarray, dvf: np.ndarray) -> np.ndarray:
    return _warp_scalar(moving.astype(np.float32), dvf, order=0).round().astype(np.int16)


def _lncc(a: np.ndarray, b: np.ndarray, eps=1e-6) -> float:
    a = a.astype(np.float32)
    b = b.astype(np.float32)
    a = a - a.mean()
    b = b - b.mean()
    num = float(np.mean(a * b))
    den = float(np.sqrt(np.mean(a * a) * np.mean(b * b)) + eps)
    return num / den


def _dice_labels(a: np.ndarray, b: np.ndarray, labels: List[int]) -> float:
    vals = []
    for lab in labels:
        aa = (a == lab)
        bb = (b == lab)
        den = aa.sum() + bb.sum()
        if den == 0:
            continue
        vals.append((2.0 * (aa & bb).sum()) / den)
    return float(np.mean(vals)) if vals else 0.0


def _support_overlap(a: np.ndarray, b: np.ndarray) -> float:
    aa = a > 0
    bb = b > 0
    den = aa.sum() + bb.sum()
    if den == 0:
        return 0.0
    return float((2.0 * (aa & bb).sum()) / den)


def _jacobian_folding_pct(dvf: np.ndarray) -> float:
    # finite differences in voxel coordinates
    uz = dvf[..., 0]; uy = dvf[..., 1]; ux = dvf[..., 2]
    dz_uz, dy_uz, dx_uz = np.gradient(uz)
    dz_uy, dy_uy, dx_uy = np.gradient(uy)
    dz_ux, dy_ux, dx_ux = np.gradient(ux)
    J00 = 1 + dz_uz; J01 = dy_uz; J02 = dx_uz
    J10 = dz_uy; J11 = 1 + dy_uy; J12 = dx_uy
    J20 = dz_ux; J21 = dy_ux; J22 = 1 + dx_ux
    det = (
        J00 * (J11 * J22 - J12 * J21)
        - J01 * (J10 * J22 - J12 * J20)
        + J02 * (J10 * J21 - J11 * J20)
    )
    return float(100.0 * np.mean(det < 0))


def _mag(dvf: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.sum(dvf * dvf, axis=-1))))


def _smoothness(dvf: np.ndarray) -> float:
    vals = []
    for c in range(3):
        grads = np.gradient(dvf[..., c])
        vals.extend([np.mean(g*g) for g in grads])
    return float(np.mean(vals))


def _case_hash(case_id: str, arr: np.ndarray) -> str:
    h = hashlib.sha256()
    h.update(case_id.encode('utf-8'))
    h.update(np.asarray(arr.shape, dtype=np.int32).tobytes())
    h.update(arr.astype(np.float32).tobytes())
    return h.hexdigest()


def _build_candidates(dvf_c6: np.ndarray, dvf_c7: np.ndarray, cfg: Dict) -> List[Tuple[str, np.ndarray]]:
    out = [('C6_parent', dvf_c6), ('C7A_v2_parent', dvf_c7)]
    diff = dvf_c7 - dvf_c6
    for alpha in cfg.get('blend_alphas', [0.25, 0.5, 0.75]):
        cand = (1-alpha) * dvf_c6 + alpha * dvf_c7
        out.append((f'blend_{alpha:.2f}', cand.astype(np.float32)))
    for scale in cfg.get('extrapolation_scales', [1.10, 1.20]):
        cand = dvf_c7 + (scale - 1.0) * diff
        out.append((f'extrap_{scale:.2f}', cand.astype(np.float32)))
    return out


def _candidate_score(case_id: str, name: str, dvf: np.ndarray, fixed_ct: Optional[np.ndarray], moving_ct: Optional[np.ndarray], fixed_seg: Optional[np.ndarray], moving_seg: Optional[np.ndarray], cfg: Dict) -> Dict:
    weights = cfg['weights']
    folding_pct = _jacobian_folding_pct(dvf)
    if folding_pct > cfg['hard_reject_folding_pct']:
        return {
            'candidate': name,
            'rejected': True,
            'reject_reason': 'hard_folding',
            'folding_pct': folding_pct,
        }

    warped_ct = warped_seg = None
    lncc = seg_proxy = support_proxy = 0.0
    if fixed_ct is not None and moving_ct is not None:
        warped_ct = _warp_scalar(moving_ct, dvf, order=1)
        lncc = _lncc(fixed_ct, warped_ct)
    if fixed_seg is not None and moving_seg is not None:
        warped_seg = _warp_label(moving_seg, dvf)
        labels = [int(x) for x in sorted(np.unique(fixed_seg)) if int(x) > 0]
        seg_proxy = _dice_labels(fixed_seg, warped_seg, labels)
        support_proxy = _support_overlap(fixed_seg, warped_seg)

    magnitude = _mag(dvf)
    smooth = _smoothness(dvf)
    # disagreement bonus prefers nontrivial deviations from C6/C7 midpoint for hard cases, but small weight
    disagreement_bonus = float(np.std(dvf))
    score = (
        weights['seg_proxy'] * seg_proxy
        + weights['support_proxy'] * support_proxy
        + weights['lncc'] * max(lncc, 0.0)
        + weights['disagreement_bonus'] * disagreement_bonus
        - weights['smoothness'] * smooth
        - weights['magnitude'] * magnitude
    )
    soft0 = cfg['soft_folding_start_pct']
    soft1 = cfg['soft_folding_full_pct']
    if folding_pct > soft0:
        if folding_pct <= soft1:
            frac = (folding_pct - soft0) / max(1e-6, soft1 - soft0)
            score -= 0.05 * frac
        else:
            frac = (folding_pct - soft1) / max(1e-6, cfg['hard_reject_folding_pct'] - soft1)
            score -= 0.05 + 0.30 * min(1.0, max(0.0, frac))
    return {
        'candidate': name,
        'rejected': False,
        'score': float(score),
        'folding_pct': float(folding_pct),
        'lncc': float(lncc),
        'seg_proxy': float(seg_proxy),
        'support_proxy': float(support_proxy),
        'magnitude_rms': float(magnitude),
        'smoothness': float(smooth),
        'disagreement_bonus': float(disagreement_bonus),
    }


def run_case(case_id: str, cfg: Dict) -> Dict:
    if nib is None:
        raise RuntimeError('nibabel is required')
    out_root = Path(cfg['output_root'])
    c6_path = Path(cfg['parent_c6_dir']) / 'dvfs' / f'{case_id}_DVF.nii.gz'
    c7_path = Path(cfg['parent_c7a_v2_dir']) / 'dvfs' / f'{case_id}_DVF.nii.gz'
    if not c6_path.exists() or not c7_path.exists():
        raise FileNotFoundError(f'missing parent DVF for {case_id}')

    c6_img, dvf_c6 = _load_nifti(c6_path)
    _, dvf_c7 = _load_nifti(c7_path)
    if dvf_c6.shape != dvf_c7.shape:
        raise ValueError(f'shape mismatch for {case_id}: {dvf_c6.shape} vs {dvf_c7.shape}')

    raw_root = Path(cfg['raw_data_root'])
    seg_root = Path(cfg.get('segmentation_root', ''))
    fix_img_p = _find_case_image(raw_root, case_id, 'insp')
    mov_img_p = _find_case_image(raw_root, case_id, 'exp')
    fix_seg_p = _find_case_seg(seg_root, case_id, 'insp')
    mov_seg_p = _find_case_seg(seg_root, case_id, 'exp')

    fixed_ct = moving_ct = fixed_seg = moving_seg = None
    if fix_img_p and mov_img_p:
        _, fixed_ct = _load_nifti(fix_img_p)
        _, moving_ct = _load_nifti(mov_img_p)
    if fix_seg_p and mov_seg_p:
        _, fixed_seg = _load_nifti(fix_seg_p)
        _, moving_seg = _load_nifti(mov_seg_p)
        fixed_seg = fixed_seg.astype(np.int16)
        moving_seg = moving_seg.astype(np.int16)

    candidates = _build_candidates(dvf_c6, dvf_c7, cfg)
    scored = []
    for nm, dvf in candidates:
        scored.append(_candidate_score(case_id, nm, dvf, fixed_ct, moving_ct, fixed_seg, moving_seg, cfg))

    viable = [s for s in scored if not s.get('rejected')]
    if not viable:
        chosen_name, chosen_dvf = 'C7A_v2_parent', dvf_c7
        selected = {'candidate': chosen_name, 'score': None, 'fallback_reason': 'all_rejected'}
    else:
        viable.sort(key=lambda x: x['score'], reverse=True)
        selected = viable[0]
        chosen_name = selected['candidate']
        chosen_dvf = dict(candidates)[chosen_name]

    # export
    out_dvf = out_root / 'dvfs' / f'{case_id}_DVF.nii.gz'
    _save_nifti_like(c6_img, chosen_dvf, out_dvf)
    out_dvf2 = out_root / 'dvfs_canonical_ras' / f'{case_id}_DVF.nii.gz'
    _save_nifti_like(c6_img, chosen_dvf, out_dvf2)

    mani = {
        'case_id': case_id,
        'selected_candidate': chosen_name,
        'selected_score': selected.get('score'),
        'selected_folding_pct': selected.get('folding_pct'),
        'selected_hash': _case_hash(case_id, chosen_dvf),
        'candidate_details': scored,
        'inputs': {
            'c6_dvf': str(c6_path),
            'c7a_v2_dvf': str(c7_path),
            'fixed_ct': str(fix_img_p) if fix_img_p else None,
            'moving_ct': str(mov_img_p) if mov_img_p else None,
            'fixed_seg': str(fix_seg_p) if fix_seg_p else None,
            'moving_seg': str(mov_seg_p) if mov_seg_p else None,
        },
        'config_snapshot': {
            'soft_folding_start_pct': cfg['soft_folding_start_pct'],
            'soft_folding_full_pct': cfg['soft_folding_full_pct'],
            'hard_reject_folding_pct': cfg['hard_reject_folding_pct'],
            'blend_alphas': cfg['blend_alphas'],
            'extrapolation_scales': cfg['extrapolation_scales'],
        },
    }
    mani_path = out_root / 'case_manifests' / f'{case_id}_manifest.json'
    mani_path.write_text(json.dumps(mani, indent=2))
    return mani


def summarize_run(cfg: Dict, manifests: List[Dict], failed: List[Dict]) -> Dict:
    counts = {}
    foldings = []
    for m in manifests:
        counts[m['selected_candidate']] = counts.get(m['selected_candidate'], 0) + 1
        if m.get('selected_folding_pct') is not None:
            foldings.append(m['selected_folding_pct'])
    return {
        'status': 'PASS' if not failed else 'PARTIAL_FAIL',
        'method': 'SGR-FM C7B multi-init semantic selector',
        'case_count': len(manifests),
        'failure_count': len(failed),
        'selection_histogram': counts,
        'mean_selected_folding_pct': float(np.mean(foldings)) if foldings else None,
        'max_selected_folding_pct': float(np.max(foldings)) if foldings else None,
        'failed_cases': failed,
        'output_root': cfg['output_root'],
        'parent_c6_dir': cfg['parent_c6_dir'],
        'parent_c7a_v2_dir': cfg['parent_c7a_v2_dir'],
    }
