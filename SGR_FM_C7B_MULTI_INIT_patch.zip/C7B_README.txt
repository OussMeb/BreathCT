C7B multi-init semantic selector patch

Files:
- run_sgr_fm_c7b_multi_init_validation.py
- utils/sgr_fm_c7b_multi_init.py
- smoke_sgr_fm_c7b_multi_init_synthetic.py
- configs/sgr_fm_c7b_multi_init.yaml

Suggested commands:
python -m py_compile run_sgr_fm_c7b_multi_init_validation.py utils/sgr_fm_c7b_multi_init.py smoke_sgr_fm_c7b_multi_init_synthetic.py
python smoke_sgr_fm_c7b_multi_init_synthetic.py
python run_sgr_fm_c7b_multi_init_validation.py --config configs/sgr_fm_c7b_multi_init.yaml --dry-run
python run_sgr_fm_c7b_multi_init_validation.py --config configs/sgr_fm_c7b_multi_init.yaml --cases NLST_0006 NLST_0007 NLST_0009
python run_sgr_fm_c7b_multi_init_validation.py --config configs/sgr_fm_c7b_multi_init.yaml

Outputs:
outputs/sgr_fm/c7b_multi_init_semantic/
  dvfs/
  dvfs_canonical_ras/
  case_manifests/
  eval/
  c7b_multi_init_summary.json
