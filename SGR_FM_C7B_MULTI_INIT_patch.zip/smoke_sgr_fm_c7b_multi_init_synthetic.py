#!/usr/bin/env python3
import json, shutil, tempfile
from pathlib import Path
import numpy as np
import nibabel as nib
from utils.sgr_fm_c7b_multi_init import load_config, run_case, summarize_run


def save(p: Path, arr: np.ndarray):
    p.parent.mkdir(parents=True, exist_ok=True)
    nib.Nifti1Image(arr.astype(np.float32), affine=np.eye(4)).to_filename(str(p))


def save_lab(p: Path, arr: np.ndarray):
    p.parent.mkdir(parents=True, exist_ok=True)
    nib.Nifti1Image(arr.astype(np.int16), affine=np.eye(4)).to_filename(str(p))


def main():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        case = 'NLST_0006'
        c6 = root/'outputs/sgr_fm/c6_rml_aware/dvfs'
        c7 = root/'outputs/sgr_fm/c7a_v2_relaxed_selector/dvfs'
        raw = root/'Learn2Breath_train_val_data'
        seg = root/'outputs/sgr_fm/segmentation_phase1_totalsegmentator'
        shape=(8,8,8,3)
        dvf0=np.zeros(shape,np.float32)
        dvf1=np.zeros(shape,np.float32); dvf1[...,2]=0.2
        save(c6/f'{case}_DVF.nii.gz', dvf0)
        save(c7/f'{case}_DVF.nii.gz', dvf1)
        ct_fix=np.zeros(shape[:3],np.float32); ct_fix[:, :, 4:]=1
        ct_mov=np.zeros(shape[:3],np.float32); ct_mov[:, :, 3:]=1
        seg_fix=np.zeros(shape[:3],np.int16); seg_fix[:, :, 4:]=1
        seg_mov=np.zeros(shape[:3],np.int16); seg_mov[:, :, 3:]=1
        save(raw/f'{case}_INSP.nii.gz', ct_fix)
        save(raw/f'{case}_EXP.nii.gz', ct_mov)
        save_lab(seg/f'{case}_INSP_lobes.nii.gz', seg_fix)
        save_lab(seg/f'{case}_EXP_lobes.nii.gz', seg_mov)
        cfgp = root/'cfg.yaml'
        cfgp.write_text('\n'.join([
            f'output_root: "{root/"outputs/sgr_fm/c7b_multi_init_semantic"}"',
            f'parent_c6_dir: "{root/"outputs/sgr_fm/c6_rml_aware"}"',
            f'parent_c7a_v2_dir: "{root/"outputs/sgr_fm/c7a_v2_relaxed_selector"}"',
            f'raw_data_root: "{raw}"',
            f'segmentation_root: "{seg}"',
            'soft_folding_start_pct: 0.25',
            'soft_folding_full_pct: 0.3',
            'hard_reject_folding_pct: 0.5',
        ]))
        cfg = load_config(str(cfgp))
        mani = run_case(case, cfg)
        sm = summarize_run(cfg, [mani], [])
        assert (Path(cfg['output_root'])/'dvfs'/f'{case}_DVF.nii.gz').exists()
        assert sm['case_count']==1
        print('SGR-FM C7B MULTI-INIT SYNTHETIC SMOKE: PASS')
        print(json.dumps({'selected_candidate': mani['selected_candidate'], 'summary': sm}, indent=2))

if __name__ == '__main__':
    main()
