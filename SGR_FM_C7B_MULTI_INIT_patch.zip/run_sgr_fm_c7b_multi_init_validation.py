#!/usr/bin/env python3
import argparse, json, os, sys, subprocess
from pathlib import Path
from utils.sgr_fm_c7b_multi_init import (
    load_config, run_case, summarize_run, discover_cases_from_dvf_dir
)


def main():
    ap = argparse.ArgumentParser(description='SGR-FM C7B multi-init semantic selector validation runner')
    ap.add_argument('--config', required=True)
    ap.add_argument('--cases', nargs='*', default=None)
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    cfg = load_config(args.config)
    out_root = Path(cfg['output_root'])
    out_root.mkdir(parents=True, exist_ok=True)
    for sub in ['dvfs', 'dvfs_canonical_ras', 'case_manifests', 'comparison', 'eval', 'traces']:
        (out_root / sub).mkdir(exist_ok=True)

    if args.cases:
        cases = args.cases
    else:
        cases = discover_cases_from_dvf_dir(Path(cfg['parent_c7a_v2_dir']) / 'dvfs')

    if args.dry_run:
        payload = {
            'status': 'DRY_RUN',
            'cases': cases,
            'output_root': str(out_root),
            'parent_c6_dir': cfg['parent_c6_dir'],
            'parent_c7a_v2_dir': cfg['parent_c7a_v2_dir'],
        }
        print(json.dumps(payload, indent=2))
        return 0

    manifests = []
    failed = []
    for case_id in cases:
        try:
            mani = run_case(case_id, cfg)
            manifests.append(mani)
            print(f"PASS {case_id} choice={mani['selected_candidate']} proxy={mani.get('selected_score')}")
        except Exception as e:
            failed.append({'case_id': case_id, 'error': repr(e)})
            print(f"FAIL {case_id}: {e}", file=sys.stderr)

    summary = summarize_run(cfg, manifests, failed)
    summary_path = out_root / 'c7b_multi_init_summary.json'
    summary_path.write_text(json.dumps(summary, indent=2))

    # invoke challenge evaluation if available and all cases present
    eval_script = Path(cfg.get('evaluate_script', 'evaluate_validation.py'))
    if not failed and eval_script.exists() and cfg.get('raw_data_root'):
        cmd = [
            sys.executable, str(eval_script),
            '--raw-data-root', str(cfg['raw_data_root']),
            '--dvf-dir', str(out_root / 'dvfs'),
            '--output-dir', str(out_root / 'eval'),
        ]
        try:
            subprocess.run(cmd, check=False)
        except Exception as e:
            summary.setdefault('warnings', []).append(f'eval invocation failed: {e!r}')
            summary_path.write_text(json.dumps(summary, indent=2))

    print(json.dumps(summary, indent=2))
    return 0 if not failed else 1


if __name__ == '__main__':
    raise SystemExit(main())
