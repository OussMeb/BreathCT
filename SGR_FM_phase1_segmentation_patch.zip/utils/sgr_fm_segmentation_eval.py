from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Sequence

import nibabel as nib
import numpy as np

from utils.metrics import dice_binary, lobe_dice, mean_lobe_dice
from utils.sgr_fm_segmentation import LOBE_SPECS, load_3d


def evaluate_lobes(pred_path: Path, gt_path: Path) -> dict[str, Any]:
    pred = load_3d(pred_path).astype(np.int16, copy=False)
    gt = load_3d(gt_path).astype(np.int16, copy=False)
    if pred.shape != gt.shape:
        raise ValueError(f"Lobe prediction/GT shape mismatch: {pred.shape} vs {gt.shape}")

    labels = tuple(spec[1] for spec in LOBE_SPECS)
    expected = {0, *labels}
    observed_gt = {int(v) for v in np.unique(gt)}
    unexpected_gt = sorted(observed_gt - expected)
    missing_gt = sorted(set(labels) - observed_gt)
    if unexpected_gt or missing_gt:
        raise RuntimeError(
            f"Unexpected validation lobe encoding in {gt_path}: "
            f"observed={sorted(observed_gt)}, unexpected={unexpected_gt}, missing={missing_gt}"
        )
    per_label = lobe_dice(pred, gt, labels)
    row: dict[str, Any] = {
        "mean_lobe_dice": mean_lobe_dice(pred, gt, labels),
        "pred_lung_voxels": int(np.sum(pred > 0)),
        "gt_lung_voxels": int(np.sum(gt > 0)),
        "whole_lung_dice": dice_binary(pred > 0, gt > 0),
    }
    for _, label, short_name in LOBE_SPECS:
        row[f"dice_{short_name}"] = float(per_label[label])
        row[f"pred_voxels_{short_name}"] = int(np.sum(pred == label))
        row[f"gt_voxels_{short_name}"] = int(np.sum(gt == label))
    return row


def _distance_to_mask(mask: np.ndarray, spacing: Sequence[float]) -> tuple[np.ndarray | None, str]:
    try:
        from scipy.ndimage import distance_transform_edt
    except ImportError:
        # Do not run an O(volume * propagation_steps) Python fallback on 3D CTs.
        # Exact interface Dice remains available; tolerance metrics are omitted.
        return None, "unavailable_scipy_missing"

    if not np.any(mask):
        return np.full(mask.shape, np.inf, dtype=np.float32), "scipy_edt"
    dist = distance_transform_edt(~mask.astype(bool), sampling=tuple(float(v) for v in spacing))
    return np.asarray(dist, dtype=np.float32), "scipy_edt"


def evaluate_fissure_interface(
    pred_interface_path: Path,
    gt_fissure_path: Path,
    tolerances_mm: Sequence[float],
) -> dict[str, Any]:
    pred_img = nib.load(str(pred_interface_path))
    gt_img = nib.load(str(gt_fissure_path))
    pred = np.asanyarray(pred_img.dataobj) > 0
    gt = np.asanyarray(gt_img.dataobj) > 0
    if pred.shape != gt.shape:
        raise ValueError(f"Interface/GT shape mismatch: {pred.shape} vs {gt.shape}")

    spacing = tuple(float(v) for v in gt_img.header.get_zooms()[:3])
    dist_to_gt, method_gt = _distance_to_mask(gt, spacing)
    dist_to_pred, method_pred = _distance_to_mask(pred, spacing)

    row: dict[str, Any] = {
        "pred_interface_voxels": int(pred.sum()),
        "gt_fissure_voxels": int(gt.sum()),
        "exact_binary_dice": dice_binary(pred, gt),
        "distance_method": method_gt if method_gt == method_pred else f"{method_gt}|{method_pred}",
    }

    if dist_to_gt is not None and dist_to_pred is not None:
        for tolerance in tolerances_mm:
            key = str(float(tolerance)).replace(".", "p")
            precision = float(np.mean(dist_to_gt[pred] <= float(tolerance))) if np.any(pred) else 0.0
            recall = float(np.mean(dist_to_pred[gt] <= float(tolerance))) if np.any(gt) else 0.0
            f1 = 0.0 if precision + recall == 0 else float(2.0 * precision * recall / (precision + recall))
            row[f"precision_tol_{key}mm"] = precision
            row[f"recall_tol_{key}mm"] = recall
            row[f"f1_tol_{key}mm"] = f1
    return row


def summarize_numeric_rows(rows: list[dict[str, Any]], group_keys: Sequence[str] = ()) -> dict[str, Any]:
    if not rows:
        return {"count": 0}
    numeric_keys: list[str] = []
    for key in rows[0]:
        if key in group_keys:
            continue
        values = [row.get(key) for row in rows]
        if all(isinstance(v, (int, float, np.integer, np.floating)) for v in values):
            numeric_keys.append(key)

    summary: dict[str, Any] = {"count": len(rows)}
    for key in numeric_keys:
        values = np.asarray([float(row[key]) for row in rows], dtype=np.float64)
        summary[f"mean_{key}"] = float(np.mean(values))
        summary[f"min_{key}"] = float(np.min(values))
        summary[f"max_{key}"] = float(np.max(values))
    return summary


def make_qc_figure(
    ct_path: Path,
    support_path: Path | None,
    lobe_path: Path | None,
    gt_lobe_path: Path | None,
    output_path: Path,
    *,
    title: str,
) -> dict[str, Any]:
    try:
        import matplotlib.pyplot as plt
        from matplotlib.colors import ListedColormap
    except ImportError:
        return {"status": "skipped", "reason": "matplotlib_not_installed"}

    ct = load_3d(ct_path).astype(np.float32, copy=False)
    support = load_3d(support_path) > 0 if support_path and support_path.exists() else None
    lobes = load_3d(lobe_path).astype(np.int16, copy=False) if lobe_path and lobe_path.exists() else None
    gt = load_3d(gt_lobe_path).astype(np.int16, copy=False) if gt_lobe_path and gt_lobe_path.exists() else None

    union = lobes > 0 if lobes is not None and np.any(lobes > 0) else (support if support is not None else None)
    if union is not None and np.any(union):
        coords = np.argwhere(union)
        center = np.rint(coords.mean(axis=0)).astype(int)
    else:
        center = np.asarray(ct.shape) // 2

    # Axial-like, coronal-like, sagittal-like array slices. This is QC, not a radiological display export.
    slices = [
        (ct[:, :, center[2]], 2, int(center[2]), "axis-2"),
        (ct[:, center[1], :], 1, int(center[1]), "axis-1"),
        (ct[center[0], :, :], 0, int(center[0]), "axis-0"),
    ]
    rows = 2 if gt is not None else 1
    fig, axes = plt.subplots(rows, 3, figsize=(15, 5 * rows), squeeze=False)
    cmap = ListedColormap(["black", "tab:blue", "tab:cyan", "tab:red", "tab:orange", "tab:purple"])
    label_to_index = {0: 0, 8: 1, 16: 2, 32: 3, 64: 4, 128: 5}

    def extract(arr: np.ndarray, axis: int, index: int) -> np.ndarray:
        if axis == 0:
            return arr[index, :, :]
        if axis == 1:
            return arr[:, index, :]
        return arr[:, :, index]

    for col, (ct_slice, axis, index, axis_name) in enumerate(slices):
        ax = axes[0, col]
        ax.imshow(np.rot90(ct_slice), cmap="gray", vmin=-1000, vmax=400)
        if lobes is not None:
            ls = extract(lobes, axis, index)
            mapped = np.vectorize(label_to_index.get, otypes=[np.uint8])(ls)
            masked = np.ma.masked_where(mapped == 0, mapped)
            ax.imshow(np.rot90(masked), cmap=cmap, vmin=0, vmax=5, alpha=0.42, interpolation="nearest")
        if support is not None:
            ss = extract(support.astype(np.uint8), axis, index)
            try:
                ax.contour(np.rot90(ss), levels=[0.5], linewidths=0.7)
            except ValueError:
                pass
        ax.set_title(f"Pred/support {axis_name}={index}")
        ax.axis("off")

        if gt is not None:
            ax2 = axes[1, col]
            ax2.imshow(np.rot90(ct_slice), cmap="gray", vmin=-1000, vmax=400)
            gs = extract(gt, axis, index)
            mapped_gt = np.vectorize(label_to_index.get, otypes=[np.uint8])(gs)
            masked_gt = np.ma.masked_where(mapped_gt == 0, mapped_gt)
            ax2.imshow(np.rot90(masked_gt), cmap=cmap, vmin=0, vmax=5, alpha=0.42, interpolation="nearest")
            ax2.set_title(f"GT lobes {axis_name}={index}")
            ax2.axis("off")

    fig.suptitle(title)
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return {"status": "ok", "path": str(output_path)}
