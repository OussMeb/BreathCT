from __future__ import annotations

import csv
import importlib.metadata
import json
import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import nibabel as nib
import numpy as np
from nibabel.orientations import aff2axcodes

from utils.data import CaseFiles, discover_training_cases, discover_validation_cases


# Learn2Breath lobe labels already used by utils.metrics.LOBE_LABELS.
# Semantic mapping follows the established sublobe convention:
# 8=LUL, 16=LLL, 32=RUL, 64=RML, 128=RLL.
LOBE_SPECS: tuple[tuple[str, int, str], ...] = (
    ("lung_upper_lobe_left", 8, "LUL"),
    ("lung_lower_lobe_left", 16, "LLL"),
    ("lung_upper_lobe_right", 32, "RUL"),
    ("lung_middle_lobe_right", 64, "RML"),
    ("lung_lower_lobe_right", 128, "RLL"),
)

EXPECTED_LOBE_LABELS = (0, 8, 16, 32, 64, 128)
FROZEN_MARKER = ".sgr_fm_frozen.json"


@dataclass(frozen=True)
class VolumeCase:
    split: str
    case_id: str
    phase: str
    ct_path: Path
    gt_lobe_path: Path | None
    gt_fissure_path: Path | None

    @property
    def stem(self) -> str:
        return f"{self.case_id}_{self.phase}"


@dataclass(frozen=True)
class GridInfo:
    shape: tuple[int, ...]
    spacing: tuple[float, ...]
    axcodes: tuple[str, ...]
    affine: np.ndarray


def load_yaml_or_json(path: str | Path) -> dict[str, Any]:
    config_path = Path(path).expanduser()
    if not config_path.exists():
        raise FileNotFoundError(f"Config does not exist: {config_path}")

    if config_path.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml
        except ImportError as exc:
            raise RuntimeError("PyYAML is required: pip install pyyaml") from exc
        with config_path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
    elif config_path.suffix.lower() == ".json":
        with config_path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    else:
        raise ValueError(f"Unsupported config format: {config_path.suffix}")

    if not isinstance(data, dict):
        raise ValueError(f"Config must contain a mapping: {config_path}")
    return data.get("sgr_fm_segmentation", data)


def recursive_update(base: dict[str, Any], updates: dict[str, Any]) -> dict[str, Any]:
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            recursive_update(base[key], value)
        else:
            base[key] = value
    return base


def default_config() -> dict[str, Any]:
    return {
        "raw_data_root": "/home/oussama/Desktop/MICCAI FRANCE/Learn2Breath_train_val_data",
        "output_dir": "outputs/sgr_fm/segmentation_phase1_totalsegmentator",
        "splits": ["validation"],
        "phases": ["EXP", "INSP"],
        "case_ids": [],
        "overwrite": False,
        "stop_on_error": True,
        "keep_backend_tmp": False,
        "strict_grid": True,
        "affine_atol": 1e-5,
        "require_frozen_dvfs": True,
        "frozen_manifest": "outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json",
        "run_support": True,
        "run_lobes": True,
        "backend": {
            "command": "TotalSegmentator",
            "device": "gpu",
            "support_task": "body",
            "lobe_task": "total",
            "robust_crop": True,
            "fast": False,
            "write_backend_report": True,
            "extra_args": [],
        },
        "evaluation": {
            "enabled": True,
            "fissure_tolerances_mm": [1.5, 3.0, 4.5],
        },
        "qc": {
            "enabled": True,
            "validation_all": True,
            "training_max_volumes": 10,
        },
    }


def resolve_project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def resolve_under_project(project_root: Path, value: str | Path) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = project_root / path
    return path.resolve()


def discover_volumes(
    raw_data_root: str | Path,
    splits: Sequence[str],
    phases: Sequence[str],
    case_ids: Sequence[str] | None = None,
) -> list[VolumeCase]:
    requested_cases = set(case_ids or [])
    requested_phases = {str(v).upper() for v in phases}
    volumes: list[VolumeCase] = []

    for split in splits:
        if split == "training":
            cases = discover_training_cases(raw_data_root)
        elif split == "validation":
            cases = discover_validation_cases(raw_data_root)
        else:
            raise ValueError(f"Unsupported split: {split}")

        for case in cases:
            if requested_cases and case.case_id not in requested_cases:
                continue
            if "EXP" in requested_phases:
                volumes.append(
                    VolumeCase(
                        split=split,
                        case_id=case.case_id,
                        phase="EXP",
                        ct_path=case.exp_ct,
                        gt_lobe_path=case.exp_lobe,
                        gt_fissure_path=case.exp_fissure,
                    )
                )
            if "INSP" in requested_phases:
                volumes.append(
                    VolumeCase(
                        split=split,
                        case_id=case.case_id,
                        phase="INSP",
                        ct_path=case.insp_ct,
                        gt_lobe_path=case.insp_lobe,
                        gt_fissure_path=case.insp_fissure,
                    )
                )

    if requested_cases:
        found = {v.case_id for v in volumes}
        missing = sorted(requested_cases - found)
        if missing:
            raise FileNotFoundError(f"Requested case IDs not found: {missing}")

    return sorted(volumes, key=lambda v: (v.split, v.case_id, v.phase))


def grid_info(path: str | Path) -> GridInfo:
    image = nib.load(str(path))
    return GridInfo(
        shape=tuple(int(v) for v in image.shape),
        spacing=tuple(float(v) for v in image.header.get_zooms()[:3]),
        axcodes=tuple(str(v) for v in aff2axcodes(image.affine)),
        affine=np.asarray(image.affine, dtype=np.float64),
    )


def assert_same_grid(
    candidate_path: str | Path,
    reference_path: str | Path,
    *,
    affine_atol: float,
    name: str,
) -> dict[str, Any]:
    candidate = grid_info(candidate_path)
    reference = grid_info(reference_path)
    shape_ok = tuple(candidate.shape[:3]) == tuple(reference.shape[:3])
    affine_ok = bool(np.allclose(candidate.affine, reference.affine, atol=affine_atol, rtol=0.0))
    if not shape_ok or not affine_ok:
        max_affine_diff = float(np.max(np.abs(candidate.affine - reference.affine)))
        raise RuntimeError(
            f"{name}: output grid differs from raw CT. "
            f"shape {candidate.shape[:3]} vs {reference.shape[:3]}, "
            f"axcodes {candidate.axcodes} vs {reference.axcodes}, "
            f"max affine diff={max_affine_diff:.6g}. "
            "SGR-FM Phase 1 does not silently resample segmentation outputs."
        )
    return {
        "shape": list(candidate.shape[:3]),
        "spacing": list(candidate.spacing),
        "axcodes": list(candidate.axcodes),
        "shape_match": shape_ok,
        "affine_match": affine_ok,
    }


def save_array_like_atomic(
    data: np.ndarray,
    reference_path: str | Path,
    output_path: str | Path,
    *,
    dtype: np.dtype[Any] | type[Any],
) -> None:
    reference = nib.load(str(reference_path))
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    array = np.asarray(data, dtype=dtype)
    if tuple(array.shape[:3]) != tuple(reference.shape[:3]):
        raise ValueError(f"Output shape {array.shape} does not match reference {reference.shape}")

    with tempfile.NamedTemporaryFile(
        prefix=output.name + ".tmp.", suffix=".nii.gz", dir=output.parent, delete=False
    ) as handle:
        tmp = Path(handle.name)
    try:
        image = nib.Nifti1Image(array, reference.affine, header=reference.header.copy())
        image.header.set_data_dtype(np.dtype(dtype))
        # Do not inherit CT intensity scaling into categorical masks.
        image.header.set_slope_inter(1.0, 0.0)
        _, qcode = reference.get_qform(coded=True)
        _, scode = reference.get_sform(coded=True)
        # Preserve the effective input grid exactly.
        image.set_qform(reference.affine, code=int(qcode or 1))
        image.set_sform(reference.affine, code=int(scode or 1))
        nib.save(image, str(tmp))
        os.replace(tmp, output)
    finally:
        if tmp.exists():
            tmp.unlink(missing_ok=True)


def load_3d(path: str | Path) -> np.ndarray:
    image = nib.load(str(path))
    data = np.asanyarray(image.dataobj)
    if data.ndim != 3:
        raise ValueError(f"Expected 3D NIfTI, got {data.shape}: {path}")
    return np.asarray(data)


def check_frozen_foundation(project_root: Path, manifest_value: str | Path, require: bool) -> dict[str, Any]:
    repos = {
        "training_canonical_ras": project_root / "outputs/unigradicon_raw_training/dvfs_canonical_ras",
        "validation_original_grid": project_root / "outputs/unigradicon_raw_validation/dvfs",
        "validation_canonical_ras": project_root / "outputs/unigradicon_raw_validation/dvfs_canonical_ras",
    }
    manifest_path = resolve_under_project(project_root, manifest_value)
    status = {
        "manifest": str(manifest_path),
        "manifest_present": manifest_path.exists(),
        "repositories": {},
    }
    for name, repo in repos.items():
        marker = repo / FROZEN_MARKER
        status["repositories"][name] = {
            "path": str(repo),
            "repo_present": repo.exists(),
            "marker_present": marker.exists(),
        }

    ok = bool(status["manifest_present"]) and all(
        bool(item["marker_present"]) for item in status["repositories"].values()
    )
    status["ok"] = ok
    if require and not ok:
        raise RuntimeError(
            "Frozen FM foundation check failed. SGR-FM segmentation does not use the DVFs, "
            "but the experiment policy requires the audited C0 repositories to remain marked frozen. "
            f"Details: {json.dumps(status, indent=2)}"
        )
    return status


def assert_safe_output_dir(output_dir: Path, project_root: Path) -> None:
    protected = [
        project_root / "outputs/unigradicon_raw_training/dvfs_canonical_ras",
        project_root / "outputs/unigradicon_raw_validation/dvfs",
        project_root / "outputs/unigradicon_raw_validation/dvfs_canonical_ras",
    ]
    resolved = output_dir.resolve()
    for repo in protected:
        repo_resolved = repo.resolve()
        try:
            resolved.relative_to(repo_resolved)
        except ValueError:
            continue
        raise PermissionError(f"Refusing to write SGR-FM segmentations inside frozen DVF repo: {repo_resolved}")


def resolve_executable(command: str) -> str:
    resolved = shutil.which(command)
    if resolved is None:
        raise FileNotFoundError(
            f"Could not find '{command}' on PATH. Install/activate the segmentation backend first."
        )
    return resolved


def package_version(distribution: str) -> str | None:
    try:
        return importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        return None


def run_logged_command(command: Sequence[str], log_path: Path) -> tuple[int, float]:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()
    with log_path.open("w", encoding="utf-8") as log:
        log.write("$ " + " ".join(str(v) for v in command) + "\n\n")
        log.flush()
        completed = subprocess.run(
            [str(v) for v in command],
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )
        elapsed = time.time() - started
        log.write(f"\n[exit_code] {completed.returncode}\n")
        log.write(f"[elapsed_sec] {elapsed:.3f}\n")
    return int(completed.returncode), float(elapsed)


def build_totalseg_support_command(
    executable: str,
    ct_path: Path,
    output_dir: Path,
    report_path: Path | None,
    backend: dict[str, Any],
) -> list[str]:
    command = [
        executable,
        "-i",
        str(ct_path),
        "-o",
        str(output_dir),
        "-ta",
        str(backend.get("support_task", "body")),
        "--device",
        str(backend.get("device", "gpu")),
    ]
    if bool(backend.get("fast", False)):
        command.append("--fast")
    if report_path is not None:
        command.extend(["--report", str(report_path)])
    command.extend(str(v) for v in backend.get("extra_args", []))
    return command


def build_totalseg_lobe_command(
    executable: str,
    ct_path: Path,
    output_dir: Path,
    report_path: Path | None,
    backend: dict[str, Any],
) -> list[str]:
    command = [
        executable,
        "-i",
        str(ct_path),
        "-o",
        str(output_dir),
        "-ta",
        str(backend.get("lobe_task", "total")),
        "--device",
        str(backend.get("device", "gpu")),
        "--roi_subset",
        *[spec[0] for spec in LOBE_SPECS],
    ]
    if bool(backend.get("fast", False)):
        command.append("--fast")
    if bool(backend.get("robust_crop", True)):
        command.append("--robust_crop")
    if report_path is not None:
        command.extend(["--report", str(report_path)])
    command.extend(str(v) for v in backend.get("extra_args", []))
    return command


def validate_support_output(raw_support_path: Path, ct_path: Path, affine_atol: float) -> dict[str, Any]:
    grid = assert_same_grid(raw_support_path, ct_path, affine_atol=affine_atol, name="support")
    data = load_3d(raw_support_path)
    finite = bool(np.isfinite(data).all())
    if not finite:
        raise RuntimeError(f"Support segmentation contains NaN/Inf: {raw_support_path}")
    mask = data > 0
    if not np.any(mask):
        raise RuntimeError(f"Support segmentation is empty: {raw_support_path}")
    grid.update({"finite": finite, "foreground_voxels": int(mask.sum())})
    return grid


def compile_lobes_from_directory(
    lobe_dir: Path,
    ct_path: Path,
    *,
    affine_atol: float,
) -> tuple[np.ndarray, dict[str, Any]]:
    reference_shape = tuple(int(v) for v in nib.load(str(ct_path)).shape[:3])
    compiled = np.zeros(reference_shape, dtype=np.int16)
    occupied = np.zeros(reference_shape, dtype=bool)
    class_stats: dict[str, Any] = {}
    overlap_voxels = 0

    for class_name, challenge_label, short_name in LOBE_SPECS:
        path = lobe_dir / f"{class_name}.nii.gz"
        if not path.exists():
            raise FileNotFoundError(f"Missing TotalSegmentator lobe output: {path}")
        assert_same_grid(path, ct_path, affine_atol=affine_atol, name=class_name)
        raw = load_3d(path)
        if not np.isfinite(raw).all():
            raise RuntimeError(f"Non-finite lobe mask: {path}")
        mask = raw > 0
        voxels = int(mask.sum())
        if voxels == 0:
            raise RuntimeError(f"Predicted lobe is empty: {class_name} ({path})")
        overlap = mask & occupied
        n_overlap = int(overlap.sum())
        overlap_voxels += n_overlap
        if n_overlap:
            raise RuntimeError(
                f"TotalSegmentator lobe masks overlap by {n_overlap} voxels while adding {class_name}. "
                "Phase 1 uses strict compilation and will not silently choose a label."
            )
        compiled[mask] = np.int16(challenge_label)
        occupied |= mask
        class_stats[short_name] = {
            "class_name": class_name,
            "label": challenge_label,
            "voxels": voxels,
            "source": str(path),
        }

    return compiled, {
        "classes": class_stats,
        "overlap_voxels": int(overlap_voxels),
        "union_voxels": int(occupied.sum()),
        "observed_labels": [int(v) for v in np.unique(compiled)],
    }


def validate_compiled_lobes(path: Path, ct_path: Path, affine_atol: float) -> dict[str, Any]:
    grid = assert_same_grid(path, ct_path, affine_atol=affine_atol, name="compiled_lobes")
    data = load_3d(path)
    if not np.isfinite(data).all():
        raise RuntimeError(f"Compiled lobe segmentation contains NaN/Inf: {path}")
    labels = tuple(int(v) for v in np.unique(data))
    unexpected = sorted(set(labels) - set(EXPECTED_LOBE_LABELS))
    if unexpected:
        raise RuntimeError(f"Unexpected labels {unexpected} in {path}")
    for _, label, short_name in LOBE_SPECS:
        if int(np.sum(data == label)) == 0:
            raise RuntimeError(f"Compiled lobe {short_name}/{label} is empty: {path}")
    grid.update({"observed_labels": list(labels)})
    return grid


def pair_interface(labels: np.ndarray, label_a: int, label_b: int) -> np.ndarray:
    data = np.asarray(labels)
    out = np.zeros(data.shape, dtype=bool)
    for axis in range(3):
        sl0 = [slice(None)] * 3
        sl1 = [slice(None)] * 3
        sl0[axis] = slice(0, -1)
        sl1[axis] = slice(1, None)
        a0 = data[tuple(sl0)]
        a1 = data[tuple(sl1)]
        hit = ((a0 == label_a) & (a1 == label_b)) | ((a0 == label_b) & (a1 == label_a))
        out0 = out[tuple(sl0)]
        out1 = out[tuple(sl1)]
        out0 |= hit
        out1 |= hit
    return out


def derive_lobe_interfaces(labels: np.ndarray) -> tuple[np.ndarray, dict[str, int]]:
    # Internal SGR-FM interface labels (not challenge fissure labels):
    # 1 left oblique, 2 right horizontal, 3 right oblique.
    left_oblique = pair_interface(labels, 8, 16)
    right_horizontal = pair_interface(labels, 32, 64)
    right_oblique = pair_interface(labels, 32, 128) | pair_interface(labels, 64, 128)

    output = np.zeros(labels.shape, dtype=np.uint8)
    output[left_oblique] = 1
    output[right_horizontal] = 2
    output[right_oblique] = 3
    return output, {
        "left_oblique_voxels": int(left_oblique.sum()),
        "right_horizontal_voxels": int(right_horizontal.sum()),
        "right_oblique_voxels": int(right_oblique.sum()),
        "union_voxels": int((output > 0).sum()),
    }


def support_lobe_qc(support: np.ndarray | None, lobes: np.ndarray | None) -> dict[str, Any]:
    stats: dict[str, Any] = {}
    if support is not None:
        support_b = np.asarray(support).astype(bool)
        stats["support_voxels"] = int(support_b.sum())
        stats["support_fraction"] = float(support_b.mean())
        border = np.zeros(support_b.shape, dtype=bool)
        border[0, :, :] = border[-1, :, :] = True
        border[:, 0, :] = border[:, -1, :] = True
        border[:, :, 0] = border[:, :, -1] = True
        stats["support_border_voxels"] = int((support_b & border).sum())
        stats["support_touches_border"] = bool(np.any(support_b & border))
    if lobes is not None:
        lobe_union = np.asarray(lobes) > 0
        stats["lobe_union_voxels"] = int(lobe_union.sum())
        stats["lobe_union_fraction"] = float(lobe_union.mean())
        for _, label, short_name in LOBE_SPECS:
            stats[f"{short_name}_voxels"] = int(np.sum(np.asarray(lobes) == label))
        if support is not None and np.any(lobe_union):
            inside = np.logical_and(lobe_union, np.asarray(support).astype(bool)).sum()
            stats["lobe_inside_support_fraction"] = float(inside / max(1, int(lobe_union.sum())))
    return stats


def atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fieldnames: Sequence[str] | None = None) -> None:
    rows_list = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows_list:
        path.write_text("", encoding="utf-8")
        return
    if fieldnames is None:
        keys: list[str] = []
        for row in rows_list:
            for key in row:
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fieldnames), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows_list)
