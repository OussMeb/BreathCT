SGR-FM PHASE-1 SEGMENTATION RUNNER
=================================

Created against the uploaded current project archive (MICCAI FRANCE.zip).

Added files
-----------
run_sgr_fm_segmentation.py
utils/sgr_fm_segmentation.py
utils/sgr_fm_segmentation_eval.py
configs/sgr_fm_phase1_segmentation.yaml

Patched convenience entry point
-------------------------------
main.py
  Adds: python main.py segment ...
  Existing train/infer/evaluate/unigradicon commands are preserved.

Phase-1 backend
---------------
TotalSegmentator CLI.

Support branch:
  TotalSegmentator -ta body
  Reads body.nii.gz and saves a strict original-grid uint8 support mask.

Lobe branch:
  TotalSegmentator -ta total --roi_subset <five lobe classes> --robust_crop
  Compiles five binary masks into Learn2Breath labels:
    8   LUL
    16  LLL
    32  RUL
    64  RML
    128 RLL

No raw CT is modified. No custom HU normalization is performed by this runner.
The raw NIfTI path is passed directly to the backend. Any backend-internal model
operations remain backend behavior and are recorded by version/log/report.

Safety properties
-----------------
- raw Learn2Breath discovery uses existing utils.data.py
- no preprocessed-data fallback
- output cannot be placed inside the three frozen FM DVF repositories
- fast frozen-foundation marker/manifest check at startup
- strict output shape+affine check against each raw CT
- no silent segmentation resampling
- NaN/Inf checks
- non-empty five-lobe checks
- strict overlap rejection when compiling lobe masks
- atomic final NIfTI writes
- resumable: valid existing outputs are reused unless --overwrite
- backend temporary masks are removed after success/failure by default
- GT labels are never passed to TotalSegmentator

Validation benchmark outputs
----------------------------
metrics/validation_lobe_metrics.csv
metrics/validation_lobe_summary.json
metrics/validation_fissure_interface_metrics.csv
metrics/validation_fissure_interface_summary.json

Fissure handling
----------------
The runner derives internal lobe interfaces:
  1 left oblique
  2 right horizontal
  3 right oblique
These are not asserted to be the challenge fissure label encoding.
For validation, the union of predicted interfaces is compared against the union of
GT fissure voxels with exact Dice and tolerance-based precision/recall/F1.
Tolerance metrics use scipy.ndimage.distance_transform_edt when SciPy is installed;
otherwise exact Dice is still reported and expensive fallback propagation is avoided.

Recommended sequence
--------------------
1) Install/activate backend and verify command:

   TotalSegmentator --help

2) One-volume smoke test (no segmentation writes with --dry-run):

   python main.py segment \
     --config configs/sgr_fm_phase1_segmentation.yaml \
     --case-ids NLST_0001 \
     --phases EXP \
     --dry-run

3) Actual one-volume smoke test:

   python main.py segment \
     --config configs/sgr_fm_phase1_segmentation.yaml \
     --case-ids NLST_0001 \
     --phases EXP

4) Full validation benchmark (20 volumes):

   python main.py segment \
     --config configs/sgr_fm_phase1_segmentation.yaml

5) Only after reviewing validation metrics/QC, run 400 training volumes:

   python main.py segment \
     --config configs/sgr_fm_phase1_segmentation.yaml \
     --splits training

Output root
-----------
outputs/sgr_fm/segmentation_phase1_totalsegmentator/
  support/{split}/
  lobes/{split}/
  interfaces/{split}/
  logs/{split}/
  backend_reports/{split}/
  qc/{split}/
  metrics/
  manifests/

Notes
-----
- Config defaults to validation only intentionally, to avoid spending days before
  measuring segmentation quality.
- Config defaults to high-resolution (no --fast).
- The lobe command uses --roi_subset and --robust_crop.
- The runner captures the installed TotalSegmentator package version when available.
