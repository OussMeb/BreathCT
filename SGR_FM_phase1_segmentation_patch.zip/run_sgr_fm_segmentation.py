#!/usr/bin/env python3
"""SGR-FM Phase-1 anatomical-support and five-lobe segmentation runner.

Design constraints:
- raw Learn2Breath CT paths only; no preprocessed-data fallback
- original NIfTI grid preserved for saved segmentations
- frozen FM DVF repositories are never read as segmentation inputs and never written
- TotalSegmentator backend isolated behind subprocess logs and per-volume reports
- strict geometry/label checks before a segmentation is admitted to the manifest
- validation lobe benchmarking and fissure-interface geometry metrics
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import tempfile
import time
import traceback
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.sgr_fm_segmentation import (
    LOBE_SPECS,
    atomic_write_json,
    assert_safe_output_dir,
    build_totalseg_lobe_command,
    build_totalseg_support_command,
    check_frozen_foundation,
    compile_lobes_from_directory,
    default_config,
    derive_lobe_interfaces,
    discover_volumes,
    grid_info,
    load_3d,
    load_yaml_or_json,
    package_version,
    recursive_update,
    resolve_executable,
    resolve_under_project,
    run_logged_command,
    save_array_like_atomic,
    support_lobe_qc,
    validate_compiled_lobes,
    validate_support_output,
    write_csv,
)
from utils.sgr_fm_segmentation_eval import (
    evaluate_fissure_interface,
    evaluate_lobes,
    make_qc_figure,
    summarize_numeric_rows,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="SGR-FM Phase-1 segmentation benchmark runner.")
    parser.add_argument("--config", default="configs/sgr_fm_phase1_segmentation.yaml")
    parser.add_argument("--raw-data-root")
    parser.add_argument("--output-dir")
    parser.add_argument("--splits", nargs="+", choices=("training", "validation"))
    parser.add_argument("--phases", nargs="+", choices=("EXP", "INSP"))
    parser.add_argument("--case-ids", nargs="*")
    parser.add_argument("--device")
    parser.add_argument("--command")
    parser.add_argument("--limit", type=int, default=None, help="Process at most N discovered volumes.")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--fast", action="store_true", help="Use TotalSegmentator lower-resolution --fast mode.")
    parser.add_argument("--keep-backend-tmp", action="store_true")
    parser.add_argument("--skip-support", action="store_true")
    parser.add_argument("--skip-lobes", action="store_true")
    parser.add_argument("--skip-evaluation", action="store_true")
    parser.add_argument("--skip-qc", action="store_true")
    parser.add_argument("--allow-unfrozen-dvfs", action="store_true")
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> dict[str, Any]:
    config = default_config()
    config_path = Path(args.config).expanduser()
    if not config_path.is_absolute():
        config_path = PROJECT_ROOT / config_path
    recursive_update(config, load_yaml_or_json(config_path))

    if args.raw_data_root:
        config["raw_data_root"] = args.raw_data_root
    if args.output_dir:
        config["output_dir"] = args.output_dir
    if args.splits:
        config["splits"] = list(args.splits)
    if args.phases:
        config["phases"] = list(args.phases)
    if args.case_ids is not None:
        config["case_ids"] = list(args.case_ids)
    if args.device:
        config["backend"]["device"] = args.device
    if args.command:
        config["backend"]["command"] = args.command
    if args.overwrite:
        config["overwrite"] = True
    if args.fast:
        config["backend"]["fast"] = True
    if args.keep_backend_tmp:
        config["keep_backend_tmp"] = True
    if args.skip_support:
        config["run_support"] = False
    if args.skip_lobes:
        config["run_lobes"] = False
    if args.skip_evaluation:
        config["evaluation"]["enabled"] = False
    if args.skip_qc:
        config["qc"]["enabled"] = False
    if args.allow_unfrozen_dvfs:
        config["require_frozen_dvfs"] = False
    return config


def output_paths(output_dir: Path, volume: Any) -> dict[str, Path]:
    return {
        "support": output_dir / "support" / volume.split / f"{volume.stem}_support.nii.gz",
        "lobes": output_dir / "lobes" / volume.split / f"{volume.stem}_lobes.nii.gz",
        "interfaces": output_dir / "interfaces" / volume.split / f"{volume.stem}_lobe_interfaces.nii.gz",
        "log_support": output_dir / "logs" / volume.split / f"{volume.stem}_support.log",
        "log_lobes": output_dir / "logs" / volume.split / f"{volume.stem}_lobes.log",
        "report_support": output_dir / "backend_reports" / volume.split / f"{volume.stem}_support_report.json",
        "report_lobes": output_dir / "backend_reports" / volume.split / f"{volume.stem}_lobes_report.json",
        "qc": output_dir / "qc" / volume.split / f"{volume.stem}_qc.png",
    }


def should_make_qc(config: dict[str, Any], volume: Any, training_qc_count: int) -> bool:
    qc = config["qc"]
    if not bool(qc.get("enabled", True)):
        return False
    if volume.split == "validation":
        return bool(qc.get("validation_all", True))
    return training_qc_count < int(qc.get("training_max_volumes", 10))


def process_volume(
    volume: Any,
    config: dict[str, Any],
    output_dir: Path,
    executable: str,
    *,
    dry_run: bool,
    make_qc: bool,
) -> tuple[dict[str, Any], dict[str, Any] | None, dict[str, Any] | None]:
    started = time.time()
    paths = output_paths(output_dir, volume)
    backend = config["backend"]
    overwrite = bool(config.get("overwrite", False))
    affine_atol = float(config.get("affine_atol", 1e-5))
    run_support = bool(config.get("run_support", True))
    run_lobes = bool(config.get("run_lobes", True))
    write_report = bool(backend.get("write_backend_report", True))

    record: dict[str, Any] = {
        "split": volume.split,
        "case_id": volume.case_id,
        "phase": volume.phase,
        "ct_path": str(volume.ct_path),
        "gt_lobe_path": str(volume.gt_lobe_path) if volume.gt_lobe_path else "",
        "gt_fissure_path": str(volume.gt_fissure_path) if volume.gt_fissure_path else "",
        "status": "started",
        "support_path": str(paths["support"]) if run_support else "",
        "lobes_path": str(paths["lobes"]) if run_lobes else "",
        "interfaces_path": str(paths["interfaces"]) if run_lobes else "",
    }

    support_command: list[str] | None = None
    lobe_command: list[str] | None = None
    if run_support:
        support_command = build_totalseg_support_command(
            executable,
            volume.ct_path,
            Path("<TEMP_SUPPORT_DIR>"),
            paths["report_support"] if write_report else None,
            backend,
        )
    if run_lobes:
        lobe_command = build_totalseg_lobe_command(
            executable,
            volume.ct_path,
            Path("<TEMP_LOBE_DIR>"),
            paths["report_lobes"] if write_report else None,
            backend,
        )

    if dry_run:
        record["status"] = "dry_run"
        record["support_command_template"] = support_command
        record["lobe_command_template"] = lobe_command
        record["elapsed_sec"] = 0.0
        return record, None, None

    support_data: np.ndarray | None = None
    lobe_data: np.ndarray | None = None
    lobe_eval: dict[str, Any] | None = None
    fissure_eval: dict[str, Any] | None = None

    tmp_root = output_dir / "_backend_tmp" / volume.split / volume.stem
    if tmp_root.exists() and overwrite:
        shutil.rmtree(tmp_root)
    tmp_root.mkdir(parents=True, exist_ok=True)

    try:
        # Anatomical support branch.
        if run_support:
            reuse = paths["support"].exists() and not overwrite
            if reuse:
                record["support_status"] = "reused"
                record["support_grid"] = validate_support_output(paths["support"], volume.ct_path, affine_atol)
            else:
                tmp_support = tmp_root / "support"
                tmp_support.mkdir(parents=True, exist_ok=True)
                command = build_totalseg_support_command(
                    executable,
                    volume.ct_path,
                    tmp_support,
                    paths["report_support"] if write_report else None,
                    backend,
                )
                paths["report_support"].parent.mkdir(parents=True, exist_ok=True)
                code, elapsed = run_logged_command(command, paths["log_support"])
                record["support_backend_elapsed_sec"] = elapsed
                record["support_exit_code"] = code
                if code != 0:
                    raise RuntimeError(f"Support backend failed with exit code {code}; see {paths['log_support']}")
                raw_support = tmp_support / "body.nii.gz"
                if not raw_support.exists():
                    raise FileNotFoundError(
                        f"Body task did not produce body.nii.gz in {tmp_support}. "
                        "Check the backend log and installed TotalSegmentator version."
                    )
                record["support_grid"] = validate_support_output(raw_support, volume.ct_path, affine_atol)
                support_data = (load_3d(raw_support) > 0).astype(np.uint8)
                save_array_like_atomic(support_data, volume.ct_path, paths["support"], dtype=np.uint8)
                validate_support_output(paths["support"], volume.ct_path, affine_atol)
                record["support_status"] = "generated"
            support_data = load_3d(paths["support"]) > 0

        # Five-lobe branch.
        if run_lobes:
            reuse_lobes = paths["lobes"].exists() and not overwrite
            if reuse_lobes:
                record["lobes_status"] = "reused"
                record["lobe_grid"] = validate_compiled_lobes(paths["lobes"], volume.ct_path, affine_atol)
                lobe_data = load_3d(paths["lobes"]).astype(np.int16, copy=False)
            else:
                tmp_lobes = tmp_root / "lobes"
                tmp_lobes.mkdir(parents=True, exist_ok=True)
                command = build_totalseg_lobe_command(
                    executable,
                    volume.ct_path,
                    tmp_lobes,
                    paths["report_lobes"] if write_report else None,
                    backend,
                )
                paths["report_lobes"].parent.mkdir(parents=True, exist_ok=True)
                code, elapsed = run_logged_command(command, paths["log_lobes"])
                record["lobes_backend_elapsed_sec"] = elapsed
                record["lobes_exit_code"] = code
                if code != 0:
                    raise RuntimeError(f"Lobe backend failed with exit code {code}; see {paths['log_lobes']}")
                lobe_data, compile_stats = compile_lobes_from_directory(
                    tmp_lobes,
                    volume.ct_path,
                    affine_atol=affine_atol,
                )
                record["lobe_compile"] = compile_stats
                save_array_like_atomic(lobe_data, volume.ct_path, paths["lobes"], dtype=np.int16)
                record["lobe_grid"] = validate_compiled_lobes(paths["lobes"], volume.ct_path, affine_atol)
                record["lobes_status"] = "generated"

            # Interfaces are derived deterministically from the admitted lobe labelmap.
            # Missing interface files never trigger an expensive backend rerun.
            if paths["interfaces"].exists() and not overwrite:
                record["interfaces_status"] = "reused"
            else:
                interfaces, interface_stats = derive_lobe_interfaces(lobe_data)
                if int(interface_stats["union_voxels"]) == 0:
                    raise RuntimeError("Derived lobe interfaces are empty; refusing to admit segmentation.")
                save_array_like_atomic(interfaces, volume.ct_path, paths["interfaces"], dtype=np.uint8)
                record["interface_stats"] = interface_stats
                record["interfaces_status"] = "generated"
            lobe_data = load_3d(paths["lobes"]).astype(np.int16, copy=False)

        record["qc_stats"] = support_lobe_qc(support_data, lobe_data)
        if run_support and run_lobes:
            inside = float(record["qc_stats"].get("lobe_inside_support_fraction", 0.0))
            if inside < 0.995:
                record["warning_lobe_support_containment"] = (
                    f"Only {inside:.6f} of predicted lobe voxels are inside support mask."
                )

        # Validation-only benchmarking. Ground truth is never passed to the backend.
        if bool(config["evaluation"].get("enabled", True)) and volume.split == "validation" and run_lobes:
            if volume.gt_lobe_path is None:
                raise FileNotFoundError(f"Missing validation lobe GT for {volume.stem}")
            lobe_eval = {
                "split": volume.split,
                "case_id": volume.case_id,
                "phase": volume.phase,
                **evaluate_lobes(paths["lobes"], volume.gt_lobe_path),
            }
            if volume.gt_fissure_path is not None:
                fissure_eval = {
                    "split": volume.split,
                    "case_id": volume.case_id,
                    "phase": volume.phase,
                    **evaluate_fissure_interface(
                        paths["interfaces"],
                        volume.gt_fissure_path,
                        config["evaluation"].get("fissure_tolerances_mm", [1.5, 3.0, 4.5]),
                    ),
                }

        if make_qc:
            record["qc_figure"] = make_qc_figure(
                volume.ct_path,
                paths["support"] if run_support else None,
                paths["lobes"] if run_lobes else None,
                volume.gt_lobe_path if volume.split == "validation" else None,
                paths["qc"],
                title=f"{volume.stem} [{volume.split}]",
            )

        record["status"] = "ok"
        record["elapsed_sec"] = float(time.time() - started)
        return record, lobe_eval, fissure_eval
    except Exception as exc:
        record["status"] = "failed"
        record["error_type"] = type(exc).__name__
        record["error"] = str(exc)
        record["traceback"] = traceback.format_exc()
        record["elapsed_sec"] = float(time.time() - started)
        return record, None, None
    finally:
        if tmp_root.exists() and not bool(config.get("keep_backend_tmp", False)):
            shutil.rmtree(tmp_root, ignore_errors=True)


def main() -> int:
    args = parse_args()
    config = build_config(args)

    output_dir = resolve_under_project(PROJECT_ROOT, config["output_dir"])
    raw_data_root = resolve_under_project(PROJECT_ROOT, config["raw_data_root"])
    config["raw_data_root"] = str(raw_data_root)
    config["output_dir"] = str(output_dir)
    assert_safe_output_dir(output_dir, PROJECT_ROOT)
    output_dir.mkdir(parents=True, exist_ok=True)

    foundation = check_frozen_foundation(
        PROJECT_ROOT,
        config.get("frozen_manifest", "outputs/sgr_fm/frozen_assets/fm_dvf_freeze_manifest.json"),
        require=bool(config.get("require_frozen_dvfs", True)),
    )

    executable = resolve_executable(str(config["backend"].get("command", "TotalSegmentator")))
    backend_version = package_version("TotalSegmentator")

    volumes = discover_volumes(
        raw_data_root,
        config.get("splits", ["validation"]),
        config.get("phases", ["EXP", "INSP"]),
        config.get("case_ids", []),
    )
    if args.limit is not None:
        if args.limit < 1:
            raise ValueError("--limit must be >= 1")
        volumes = volumes[: args.limit]
    if not volumes:
        raise RuntimeError("No raw CT volumes discovered.")

    run_meta = {
        "schema_version": 1,
        "project_root": str(PROJECT_ROOT),
        "raw_data_root": str(raw_data_root),
        "output_dir": str(output_dir),
        "backend_executable": executable,
        "backend_version": backend_version,
        "lobe_mapping": [
            {"backend_class": name, "challenge_label": label, "short_name": short}
            for name, label, short in LOBE_SPECS
        ],
        "frozen_foundation": foundation,
        "config": config,
        "volume_count": len(volumes),
        "dry_run": bool(args.dry_run),
    }
    atomic_write_json(output_dir / "manifests/run_config_resolved.json", run_meta)

    print(json.dumps({
        "volume_count": len(volumes),
        "splits": config.get("splits"),
        "phases": config.get("phases"),
        "output_dir": str(output_dir),
        "backend": executable,
        "backend_version": backend_version,
        "frozen_foundation_ok": foundation.get("ok"),
        "dry_run": bool(args.dry_run),
    }, indent=2))

    records: list[dict[str, Any]] = []
    lobe_rows: list[dict[str, Any]] = []
    fissure_rows: list[dict[str, Any]] = []
    training_qc_count = 0

    for index, volume in enumerate(volumes, start=1):
        make_qc = should_make_qc(config, volume, training_qc_count)
        print(f"[{index:03d}/{len(volumes):03d}] {volume.split} {volume.stem}", flush=True)
        record, lobe_eval, fissure_eval = process_volume(
            volume,
            config,
            output_dir,
            executable,
            dry_run=bool(args.dry_run),
            make_qc=make_qc,
        )
        records.append(record)
        if make_qc and volume.split == "training" and record.get("qc_figure", {}).get("status") == "ok":
            training_qc_count += 1
        if lobe_eval is not None:
            lobe_rows.append(lobe_eval)
        if fissure_eval is not None:
            fissure_rows.append(fissure_eval)

        write_csv(output_dir / "manifests/phase1_segmentation_manifest.csv", records)
        atomic_write_json(output_dir / "manifests/phase1_segmentation_manifest.json", records)
        if lobe_rows:
            write_csv(output_dir / "metrics/validation_lobe_metrics.csv", lobe_rows)
            atomic_write_json(
                output_dir / "metrics/validation_lobe_summary.json",
                {"summary": summarize_numeric_rows(lobe_rows, group_keys=("split", "case_id", "phase")), "rows": lobe_rows},
            )
        if fissure_rows:
            write_csv(output_dir / "metrics/validation_fissure_interface_metrics.csv", fissure_rows)
            atomic_write_json(
                output_dir / "metrics/validation_fissure_interface_summary.json",
                {"summary": summarize_numeric_rows(fissure_rows, group_keys=("split", "case_id", "phase", "distance_method")), "rows": fissure_rows},
            )

        if record["status"] == "failed" and bool(config.get("stop_on_error", True)):
            print(json.dumps(record, indent=2), file=sys.stderr)
            break

    counts: dict[str, int] = {}
    for record in records:
        counts[record["status"]] = counts.get(record["status"], 0) + 1
    summary = {
        "schema_version": 1,
        "status": "PASS" if counts.get("failed", 0) == 0 else "FAIL",
        "processed_records": len(records),
        "requested_volumes": len(volumes),
        "status_counts": counts,
        "validation_lobe_summary": summarize_numeric_rows(lobe_rows, group_keys=("split", "case_id", "phase")),
        "validation_fissure_summary": summarize_numeric_rows(
            fissure_rows, group_keys=("split", "case_id", "phase", "distance_method")
        ),
        "output_dir": str(output_dir),
        "backend_version": backend_version,
        "frozen_foundation_ok": foundation.get("ok"),
    }
    atomic_write_json(output_dir / "manifests/phase1_segmentation_summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if summary["status"] == "PASS" else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
